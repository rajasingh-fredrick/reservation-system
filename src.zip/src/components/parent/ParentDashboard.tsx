"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Archive, ArrowRight, CalendarDays, Check, CircleUserRound, LogOut, Plus, RefreshCw, Save, X } from "lucide-react";
import { MusicIcon } from "@/components/ui/Motifs";
import { api, ApiRequestError, errorMessage, formatDateTime } from "@/lib/client";
import { INSTRUMENTS } from "@/lib/contracts";
import { ConfirmDialog } from "@/components/ui/Confirm";
import { InlineError, Notice } from "@/components/ui/Feedback";

type ChildProfile = {
  id: string;
  fullName: string;
  birthMonth: number;
  birthYear: number;
  additionalInformation: string;
  status: "Pending approval" | "Approved" | "Rejected" | "Archived";
  statusReason: string | null;
  instruments: Array<{ instrument: (typeof INSTRUMENTS)[number]; yearsExperience: number }>;
};

type ChildForm = Omit<ChildProfile, "id" | "status" | "statusReason">;
type FamilyReservation = { id: string; status: string; child_name: string; season_name: string; event_name: string; song_title: string; instrument: string; starts_at: string; timezone: string };

const emptyForm = (): ChildForm => ({
  fullName: "",
  birthMonth: new Date().getMonth() + 1,
  birthYear: new Date().getFullYear(),
  additionalInformation: "",
  instruments: [],
});

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function statusStyle(status: ChildProfile["status"]) {
  if (status === "Approved") return "border-forest-300 gradient-tint text-forest-900";
  if (status === "Rejected") return "border-rose-deep/30 bg-rose-soft text-rose-deep";
  if (status === "Archived") return "border-parchment-300 bg-parchment-100 text-ink-muted";
  return "border-amber-accent/40 bg-amber-soft/60 text-amber-deep";
}

export function ParentDashboard() {
  const router = useRouter();
  const [children, setChildren] = useState<ChildProfile[]>([]);
  const [reservations, setReservations] = useState<FamilyReservation[]>([]);
  const [form, setForm] = useState<ChildForm>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [archiveTarget, setArchiveTarget] = useState<ChildProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [emailUnverified, setEmailUnverified] = useState(false);
  const childNameRef = useRef<HTMLInputElement>(null);

  function focusChildForm() {
    childNameRef.current?.focus({ preventScroll: true });
    childNameRef.current?.scrollIntoView({ block: "center" });
  }

  async function refreshChildren(signal?: AbortSignal) {
    const childResult = await api<{ children: ChildProfile[] }>("/api/parent/children", { signal });
    const reservationResult = await api<{ reservations: FamilyReservation[] }>("/api/parent/reservations", { signal });
    setChildren(childResult.children);
    setReservations(reservationResult.reservations.filter((reservation) => reservation.status === "Confirmed"));
    setEmailUnverified(false);
  }

  useEffect(() => {
    const controller = new AbortController();
    void refreshChildren(controller.signal).catch((err: unknown) => {
      if (err instanceof DOMException && err.name === "AbortError") return;
      if (err instanceof ApiRequestError && err.status === 401) {
        router.replace("/sign-in?next=%2Fparent");
        return;
      }
      if (err instanceof ApiRequestError && err.code === "EMAIL_NOT_VERIFIED") setEmailUnverified(true);
      else setError(errorMessage(err));
    }).finally(() => setLoading(false));
    return () => controller.abort();
  }, [router]);

  function startEdit(child: ChildProfile) {
    setEditingId(child.id);
    setForm({
      fullName: child.fullName,
      birthMonth: child.birthMonth,
      birthYear: child.birthYear,
      additionalInformation: child.additionalInformation,
      instruments: child.instruments.map((instrument) => ({ ...instrument })),
    });
    setError(null);
    focusChildForm();
  }

  function resetForm() {
    setEditingId(null);
    setForm(emptyForm());
    setError(null);
  }

  function startAdd() {
    resetForm();
    focusChildForm();
  }

  function toggleInstrument(instrument: (typeof INSTRUMENTS)[number], checked: boolean) {
    setForm((current) => ({
      ...current,
      instruments: checked
        ? [...current.instruments, { instrument, yearsExperience: 0 }]
        : current.instruments.filter((item) => item.instrument !== instrument),
    }));
  }

  async function saveChild(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const method = editingId ? "PATCH" : "POST";
      const endpoint = editingId ? `/api/parent/children/${editingId}` : "/api/parent/children";
      await api(endpoint, { method, json: form });
      await refreshChildren();
      resetForm();
    } catch (err) {
      if (err instanceof ApiRequestError && err.code === "EMAIL_NOT_VERIFIED") setEmailUnverified(true);
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function archiveChild() {
    if (!archiveTarget) return;
    await api(`/api/parent/children/${archiveTarget.id}`, { method: "DELETE", json: {} });
    await refreshChildren();
    if (editingId === archiveTarget.id) resetForm();
    setArchiveTarget(null);
  }

  async function signOut() {
    try {
      await api("/api/auth/sign-out", { method: "POST", json: {} });
      router.replace("/sign-in?signedOut=1");
    } catch (err) {
      setError(errorMessage(err));
    }
  }

  return (
    <main id="main" className="gradient-canvas min-h-dvh text-ink">
      <header className="gradient-brand border-b border-forest-900/10 text-ink">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <Link href="/parent" className="inline-flex items-center gap-3 rounded-xl focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-amber-soft">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/60 ring-1 ring-white/70"><MusicIcon className="h-5 w-5 text-ink" aria-hidden="true" /></span>
            <span><span className="block font-serif text-lg font-semibold">Harmony</span><span className="block text-[0.68rem] uppercase tracking-[0.16em] text-ink">Family workspace</span></span>
          </Link>
          <button type="button" className="btn-ghost min-h-11 text-ink hover:bg-white/10 hover:text-forest-900" onClick={() => void signOut()}><LogOut className="h-4 w-4" aria-hidden="true" />Sign out</button>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Parent or guardian</p>
            <h1 className="mt-1 font-serif text-3xl text-forest-900">Your family</h1>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-soft">Manage child profiles and check approval status. Each child must be approved before reserving a music spot.</p>
          </div>
          <Link href="/parent/seasons" className="btn-secondary min-h-11">Browse seasons<ArrowRight className="h-4 w-4" aria-hidden="true" /></Link>
        </div>

        <section className="mb-8" aria-labelledby="upcoming-heading">
          <div className="mb-3 flex items-center justify-between gap-3"><h2 id="upcoming-heading" className="font-serif text-xl text-forest-900"><Link href="/parent/seasons#reservations-heading" className="rounded underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-offset-4">Upcoming reservations</Link></h2><Link href="/parent/seasons" className="text-sm font-medium text-forest-800 underline-offset-4 hover:underline">View seasons</Link></div>
          {!loading && !reservations.filter((reservation) => Date.parse(reservation.starts_at) >= Date.now()).length ? <p className="rounded-xl border border-dashed border-parchment-300 bg-parchment-50 px-4 py-5 text-sm text-ink-muted">No upcoming reservations. Approved children can book available spots during registration.</p> : null}
          <div className="grid gap-3 sm:grid-cols-2">
            {reservations.filter((reservation) => Date.parse(reservation.starts_at) >= Date.now()).slice(0, 4).map((reservation) => <Link key={reservation.id} href={`/parent/seasons#reservation-${encodeURIComponent(reservation.id)}`} className="block rounded-xl border border-forest-200 gradient-tint p-4 transition-shadow hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-4"><p className="text-xs font-semibold uppercase tracking-wide text-forest-800">{reservation.season_name}</p><h3 className="mt-1 font-semibold text-forest-900">{reservation.child_name} · {reservation.instrument}</h3><p className="mt-1 text-sm text-ink-soft">{reservation.event_name} · {formatDateTime(reservation.starts_at, reservation.timezone)}</p><p className="mt-1 text-sm text-ink-muted">{reservation.song_title}</p><span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-forest-800">View reservation details<ArrowRight className="h-4 w-4" aria-hidden="true" /></span></Link>)}
          </div>
        </section>

        {emailUnverified ? <Notice tone="warn">Verify your email before accessing family information. Check the verification link sent to your inbox, then sign in again.</Notice> : null}
        <InlineError message={error} className="mb-5" />

        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(20rem,0.72fr)] lg:items-start">
          <section aria-labelledby="children-heading">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <h2 id="children-heading" className="font-serif text-xl text-forest-900">Children</h2>
              <div className="flex items-center gap-3">
                <span className="text-sm text-ink-muted">{children.filter((child) => child.status !== "Archived").length} active</span>
                <button type="button" className="btn-primary min-h-11" onClick={startAdd} aria-controls="child-editor" disabled={busy || loading || emailUnverified}><Plus className="h-4 w-4" aria-hidden="true" />Add child</button>
              </div>
            </div>
            {loading ? <p className="rounded-2xl border border-parchment-300 bg-parchment-50 p-5 text-sm text-ink-muted" role="status">Loading family profiles…</p> : null}
            {!loading && !children.length ? (
              <div className="rounded-2xl border border-dashed border-forest-800/30 bg-parchment-50 p-7 text-center sm:p-9">
                <CircleUserRound className="mx-auto h-8 w-8 text-forest-700" aria-hidden="true" />
                <h3 className="mt-3 font-serif text-lg text-forest-900">No child profiles yet</h3>
                <p className="mx-auto mt-1 max-w-sm text-sm text-ink-muted">Add a child to start the approval process for ministry registration.</p>
                <button type="button" className="btn-primary mt-4" onClick={startAdd} aria-controls="child-editor" disabled={busy || emailUnverified}><Plus className="h-4 w-4" aria-hidden="true" />Add child</button>
              </div>
            ) : null}
            <div className="space-y-3">
              {children.map((child) => (
                <article key={child.id} className="card p-4 sm:p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="break-words font-semibold text-forest-900">{child.fullName}</h3>
                      <p className="mt-1 text-sm text-ink-muted">Birth month and year: {months[child.birthMonth - 1]} {child.birthYear}</p>
                    </div>
                    <span className={`chip ${statusStyle(child.status)}`}>{child.status}</span>
                  </div>
                  <ul className="mt-3 flex flex-wrap gap-2" aria-label={`Instruments for ${child.fullName}`}>
                    {child.instruments.map((item) => <li key={item.instrument} className="chip border-forest-100 gradient-tint text-forest-900">{item.instrument}: {item.yearsExperience} yr</li>)}
                  </ul>
                  {child.statusReason ? <p className="mt-3 rounded-lg bg-parchment-100 px-3 py-2 text-sm text-ink-soft">Coordinator note: {child.statusReason}</p> : null}
                  {child.additionalInformation ? <p className="mt-3 text-sm text-ink-soft">{child.additionalInformation}</p> : null}
                  <div className="mt-4 flex flex-wrap gap-2 border-t border-parchment-200 pt-3">
                    {child.status !== "Archived" ? <button type="button" className="btn-secondary min-h-11" onClick={() => startEdit(child)} aria-controls="child-editor" disabled={busy || emailUnverified}><Save className="h-4 w-4" aria-hidden="true" />Edit profile</button> : null}
                    {child.status !== "Archived" ? <button type="button" className="btn-ghost min-h-11 text-rose-deep hover:bg-rose-soft" onClick={() => setArchiveTarget(child)}><Archive className="h-4 w-4" aria-hidden="true" />Archive</button> : null}
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section id="child-editor" className="card p-5 sm:p-6" aria-labelledby="editor-heading">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="eyebrow">Profile details</p>
                <h2 id="editor-heading" className="mt-1 font-serif text-xl text-forest-900">{editingId ? "Edit child" : "Add a child"}</h2>
              </div>
              {editingId ? <button type="button" className="icon-btn" onClick={resetForm} aria-label="Cancel editing"><X className="h-5 w-5" aria-hidden="true" /></button> : null}
            </div>
            {editingId && children.find((child) => child.id === editingId)?.status === "Approved" ? <Notice className="mt-4">Changes to a child’s name, birth month/year, instruments, or experience send the profile back for approval. Existing reservations are preserved and flagged for coordinator review, not silently cancelled.</Notice> : null}
            <form onSubmit={saveChild} className="mt-5 space-y-4">
              <div><label htmlFor="child-name" className="field-label">Child’s full name</label><input ref={childNameRef} id="child-name" className="input" autoComplete="off" value={form.fullName} onChange={(event) => setForm((value) => ({ ...value, fullName: event.target.value }))} required maxLength={160} disabled={busy || emailUnverified} /></div>
              <fieldset>
                <legend className="field-label">Birth month and year</legend>
                <div className="grid grid-cols-[minmax(0,1fr)_7rem] gap-3">
                  <select aria-label="Birth month" className="input" value={form.birthMonth} onChange={(event) => setForm((value) => ({ ...value, birthMonth: Number(event.target.value) }))} disabled={busy || emailUnverified}>
                    {months.map((month, index) => <option key={month} value={index + 1}>{month}</option>)}
                  </select>
                  <input aria-label="Birth year" type="number" className="input" min={1900} max={new Date().getFullYear()} step={1} value={form.birthYear} onChange={(event) => setForm((value) => ({ ...value, birthYear: Number(event.target.value) }))} required disabled={busy || emailUnverified} />
                </div>
                <p className="field-hint">Day of birth is not collected.</p>
              </fieldset>
              <fieldset className="space-y-2">
                <legend className="field-label">Instruments and experience</legend>
                <p className="mb-2 text-xs text-ink-muted">Choose at least one instrument. Experience can be 0 for a beginner.</p>
                {INSTRUMENTS.map((instrument) => {
                  const selected = form.instruments.find((item) => item.instrument === instrument);
                  return (
                    <div key={instrument} className="grid min-h-12 grid-cols-[minmax(0,1fr)_7rem] items-center gap-3 rounded-xl border border-parchment-200 px-3 py-2">
                      <label className="flex min-h-10 items-center gap-3 text-sm font-medium text-ink"><input type="checkbox" className="h-4 w-4 accent-forest-800" checked={Boolean(selected)} onChange={(event) => toggleInstrument(instrument, event.target.checked)} disabled={busy || emailUnverified} />{instrument}</label>
                      <label className="text-xs text-ink-muted">Years
                        <input aria-label={`${instrument} years of experience`} type="number" className="input mt-1" min={0} max={30} step={0.5} value={selected?.yearsExperience ?? ""} onChange={(event) => setForm((value) => ({ ...value, instruments: value.instruments.map((item) => item.instrument === instrument ? { ...item, yearsExperience: Number(event.target.value) } : item) }))} disabled={!selected || busy || emailUnverified} />
                      </label>
                    </div>
                  );
                })}
              </fieldset>
              <div><label htmlFor="child-notes" className="field-label">Additional information <span className="font-normal text-ink-muted">(optional)</span></label><textarea id="child-notes" className="input min-h-24 resize-y" maxLength={3000} value={form.additionalInformation} onChange={(event) => setForm((value) => ({ ...value, additionalInformation: event.target.value }))} disabled={busy || emailUnverified} /><p className="field-hint">{form.additionalInformation.length}/3000 characters</p></div>
              <InlineError message={error} />
              <div className="flex flex-wrap gap-2">
                <button type="submit" className="btn-primary min-h-11" disabled={busy || loading || emailUnverified} aria-busy={busy}>{busy ? <RefreshCw className="h-4 w-4 animate-spin" aria-hidden="true" /> : editingId ? <Check className="h-4 w-4" aria-hidden="true" /> : <Plus className="h-4 w-4" aria-hidden="true" />}{editingId ? "Save changes" : "Submit for approval"}</button>
                {editingId ? <button type="button" className="btn-secondary min-h-11" onClick={resetForm} disabled={busy}>Cancel</button> : null}
              </div>
            </form>
          </section>
        </div>
      </div>
      <ConfirmDialog
        open={Boolean(archiveTarget)}
        onClose={() => setArchiveTarget(null)}
        title="Archive this child profile?"
        confirmLabel="Archive profile"
        busyLabel="Archiving…"
        onConfirm={archiveChild}
      >
        <p>Archiving preserves the child’s historical records and removes the profile from future registration. Existing reservations are not silently cancelled.</p>
      </ConfirmDialog>
    </main>
  );
}