"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, CalendarDays, Check, Download, Eye, Link2, LogOut, RefreshCw, Users } from "lucide-react";
import { api, ApiRequestError, errorMessage, formatDateTime, safeTz } from "@/lib/client";
import { INSTRUMENTS, type SongRole } from "@/lib/contracts";
import { ConfirmDialog } from "@/components/ui/Confirm";
import { InlineError, Notice } from "@/components/ui/Feedback";
import { Modal } from "@/components/ui/Modal";
import { EventSlider } from "@/components/seasons/EventSlider";

type ParentChild = { id: string; full_name: string; status: string; instruments: string[] };
type Requirement = {
  instrument: (typeof INSTRUMENTS)[number];
  capacity: number;
  reserved: number;
  available: number;
  availableSpots: number[];
  reservedSpots: { spotNumber: number; childName: string }[];
};
type EventSheet = { id: string; label: string; instrument: string | null; version: number; fileName: string };
type EventSong = {
  id: string;
  songId: string;
  allowExtra: boolean;
  songRole: SongRole | null;
  title: string;
  composer: string;
  notes: string;
  libraryNotes: string;
  links: string[];
  sheets: EventSheet[];
  requirements: Requirement[];
};
type MinistryEvent = { id: string; name: string; startsAt: string; endsAt: string; location: string; songs: EventSong[] };
type ParentSeason = {
  id: string;
  name: string;
  description: string;
  start_date: string;
  end_date: string;
  registration_opens_at: string;
  registration_closes_at: string;
  timezone: string;
  location: string;
  instructions: string;
  cancellation_hours: number;
  status: string;
  events: MinistryEvent[];
};
type Reservation = {
  id: string;
  status: string;
  instrument: string;
  spot_number: number;
  child_id: string;
  child_name: string;
  season_id: string;
  season_name: string;
  timezone: string;
  event_id: string;
  event_name: string;
  starts_at: string;
  ends_at: string;
  location: string;
  song_title: string;
  song_role: SongRole | null;
  song_id: string;
  is_extra: boolean;
  review_required?: boolean;
  review_reason?: string | null;
};
type Selection = { childId: string; spotNumber: string };
type BrowserData = { seasons: ParentSeason[]; children: ParentChild[]; reservations: Reservation[] };
type InstrumentTarget = { seasonId: string; eventId: string; songId: string; instrument: string; spotNumber: number | null };

function instrumentLabel(requirement: Requirement, spotNumber: number | null = null) {
  const names = requirement.reservedSpots
    .filter((spot) => spotNumber === null || spot.spotNumber === spotNumber)
    .map((spot) => spot.childName);
  return [requirement.instrument, ...names].join(" · ");
}

function SongInformation({ song }: { song: EventSong }) {
  return <div className="min-w-0 space-y-3 text-sm text-ink-soft">
    {song.songRole ? <p className="chip gradient-tint text-forest-900">{song.songRole}</p> : null}
    {song.allowExtra ? <p className="rounded-lg border border-forest-300 gradient-tint p-3 text-forest-900"><strong>Extra song for this season.</strong> Each eligible child can reserve this song once, with or without a regular-song reservation.</p> : null}
    {song.libraryNotes ? <div><h6 className="font-semibold text-forest-900">Song notes</h6><p className="whitespace-pre-wrap break-words">{song.libraryNotes}</p></div> : null}
    {song.notes ? <div><h6 className="font-semibold text-forest-900">Notes for this event</h6><p className="whitespace-pre-wrap break-words">{song.notes}</p></div> : null}
    {song.links?.length ? <div><h6 className="font-semibold text-forest-900">Song links</h6><ul className="mt-1 space-y-1">{song.links.map((link, index) => <li key={`${index}-${link}`}><a className="inline-flex max-w-full items-start gap-2 text-forest-800 underline underline-offset-2" href={link} target="_blank" rel="noopener noreferrer"><Link2 className="mt-0.5 size-4 shrink-0" aria-hidden /><span className="min-w-0 break-all">{link}</span></a></li>)}</ul></div> : null}
    {song.sheets.length ? <div><h6 className="font-semibold text-forest-900">Music sheets</h6><ul className="mt-1 space-y-2">{song.sheets.map((sheet) => {
      const url = `/api/sheets/${encodeURIComponent(sheet.id)}/download?version=${sheet.version}`;
      return <li key={sheet.id} className="flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1">
        <span className="min-w-0 break-words font-medium">{sheet.label}{sheet.instrument ? ` · ${sheet.instrument}` : ""}</span>
        <a className="inline-flex min-h-10 items-center gap-1 text-forest-800 underline" href={`${url}&preview=true`} target="_blank" rel="noopener noreferrer" aria-label={`Preview ${sheet.label}`}><Eye className="size-4" aria-hidden />Preview</a>
        <a className="inline-flex min-h-10 items-center gap-1 text-forest-800 underline" href={url} download aria-label={`Download ${sheet.label}`}><Download className="size-4" aria-hidden />Download</a>
      </li>;
    })}</ul></div> : null}
  </div>;
}

function registrationStatus(season: ParentSeason, now: number) {
  if (season.status === "Registration Closed" || now > Date.parse(season.registration_closes_at)) return "Registration closed";
  if (now < Date.parse(season.registration_opens_at)) return "Registration opens later";
  return "Registration open";
}

function eventDateFilterValue(instant: string, timezone: string) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: safeTz(timezone),
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(instant));
}

export function ParentSeasonBrowser({ embedded = false }: { embedded?: boolean } = {}) {
  const router = useRouter();
  const [data, setData] = useState<BrowserData>({ seasons: [], children: [], reservations: [] });
  const [loading, setLoading] = useState(true);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [seasonFilter, setSeasonFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("");
  const [instrumentFilter, setInstrumentFilter] = useState("all");
  const [availabilityFilter, setAvailabilityFilter] = useState("all");
  const [selections, setSelections] = useState<Record<string, Selection>>({});
  const [cancelTarget, setCancelTarget] = useState<{ id: string; message: string } | null>(null);
  const [instrumentTarget, setInstrumentTarget] = useState<InstrumentTarget | null>(null);

  const refresh = useCallback(async (signal?: AbortSignal) => {
    const result = await api<BrowserData>("/api/parent/seasons", { signal });
    setData(result);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void refresh(controller.signal).catch((err: unknown) => {
      if (err instanceof DOMException && err.name === "AbortError") return;
      if (err instanceof ApiRequestError && err.status === 401) {
        router.replace("/sign-in?next=%2Fparent%2Fseasons");
        return;
      }
      setError(errorMessage(err));
    }).finally(() => setLoading(false));
    return () => controller.abort();
  }, [refresh, router]);

  useEffect(() => {
    if (loading) return;
    function focusReservation() {
      const hash = window.location.hash;
      const reservation = data.reservations.find((item) => item.status === "Confirmed" && hash === `#reservation-${encodeURIComponent(item.id)}`);
      const targetId = reservation ? `reservation-${reservation.id}` : hash === "#reservations-heading" ? "reservations-heading" : null;
      if (!targetId) return;
      if (reservation) {
        const season = data.seasons.find((item) => item.id === reservation.season_id);
        const event = season?.events.find((item) => item.id === reservation.event_id);
        if (season && event) {
          setSeasonFilter(season.id);
          setDateFilter(eventDateFilterValue(event.startsAt, season.timezone));
        }
      }
      const target = document.getElementById(targetId);
      target?.focus({ preventScroll: true });
      target?.scrollIntoView({ block: "start" });
    }
    focusReservation();
    window.addEventListener("hashchange", focusReservation);
    return () => window.removeEventListener("hashchange", focusReservation);
  }, [loading, data.reservations, data.seasons]);

  const filteredSeasons = useMemo(() => data.seasons.filter((season) => seasonFilter === "all" || season.id === seasonFilter), [data.seasons, seasonFilter]);
  const now = Date.now();
  const approvedChildren = data.children.filter((child) => child.status === "Approved");

  function childHasInstrument(childId: string, instrument: string) {
    const child = data.children.find((item) => item.id === childId);
    return child?.status === "Approved" && child.instruments.includes(instrument);
  }

  function setSelection(key: string, patch: Partial<Selection>) {
    setSelections((current) => {
      const previous = current[key] ?? { childId: "", spotNumber: "" };
      return { ...current, [key]: { ...previous, ...patch } };
    });
  }

  async function book(season: ParentSeason, event: MinistryEvent, song: EventSong, requirement: Requirement) {
    const key = `${song.id}:${requirement.instrument}`;
    const selection = selections[key];
    if (!selection?.childId || !selection.spotNumber) {
      setError("Choose an approved child and an available spot before confirming.");
      return;
    }
    setBusyKey(key);
    setError(null);
    setNotice(null);
    try {
      const result = await api<{ notificationQueued: boolean }>("/api/parent/reservations", {
        method: "POST",
        json: {
          childId: selection.childId,
          eventId: event.id,
          eventSongId: song.id,
          instrument: requirement.instrument,
          spotNumber: Number(selection.spotNumber),
        },
      });
      setNotice(result.notificationQueued ? `Reservation confirmed for ${season.name}. The confirmation email is queued for delivery.` : "Reservation confirmed, but the confirmation email was not queued. Contact the coordinator.");
      await refresh();
      setSelection(key, { childId: "", spotNumber: "" });
      setInstrumentTarget(null);
    } catch (err) {
      setError(errorMessage(err));
      await refresh().catch(() => undefined);
    } finally {
      setBusyKey(null);
    }
  }

  async function cancelReservation() {
    if (!cancelTarget) return;
    await api(`/api/parent/reservations/${cancelTarget.id}`, { method: "DELETE", json: {} });
    setNotice("Reservation cancelled and the spot released.");
    await refresh();
    setCancelTarget(null);
  }

  async function signOut() {
    try {
      await api("/api/auth/sign-out", { method: "POST", json: {} });
      router.replace("/sign-in?signedOut=1");
    } catch (err) {
      setError(errorMessage(err));
    }
  }

  const activeReservations = data.reservations.filter((item) => item.status === "Confirmed");
  function alreadyRegistered(childId: string, seasonId: string, song: EventSong) {
    return activeReservations.some((reservation) => reservation.child_id === childId && reservation.season_id === seasonId
      && (song.allowExtra ? reservation.song_id === song.songId : !reservation.is_extra));
  }
  function bookingChildren(seasonId: string, event: MinistryEvent, song: EventSong, instrument: string) {
    return approvedChildren.filter((child) => child.instruments.includes(instrument)
      && !alreadyRegistered(child.id, seasonId, song)
      && !activeReservations.some((reservation) => reservation.child_id === child.id && reservation.season_id !== seasonId
        && Date.parse(reservation.starts_at) < Date.parse(event.endsAt) && Date.parse(reservation.ends_at) > Date.parse(event.startsAt)));
  }
  const detailSeason = data.seasons.find((season) => season.id === instrumentTarget?.seasonId);
  const detailEvent = detailSeason?.events.find((event) => event.id === instrumentTarget?.eventId);
  const detailSong = detailEvent?.songs.find((song) => song.id === instrumentTarget?.songId);
  const detailRequirement = detailSong?.requirements.find((requirement) => requirement.instrument === instrumentTarget?.instrument);
  const detailKey = detailSong && detailRequirement ? `${detailSong.id}:${detailRequirement.instrument}` : "";
  const detailSelection = selections[detailKey] ?? { childId: "", spotNumber: "" };
  const detailSpotAvailable = instrumentTarget?.spotNumber != null && Boolean(detailRequirement?.availableSpots.includes(instrumentTarget.spotNumber));
  const detailEligibleChildren = detailSeason && detailEvent && detailSong ? bookingChildren(detailSeason.id, detailEvent, detailSong, instrumentTarget?.instrument ?? "") : [];
  const detailCanBook = detailSeason && detailEvent && detailSpotAvailable && registrationStatus(detailSeason, now) === "Registration open"
    && now < Date.parse(detailEvent.startsAt) && detailEligibleChildren.length > 0;

  function viewInstrument(season: ParentSeason, event: MinistryEvent, song: EventSong, requirement: Requirement, spotNumber: number | null = null) {
    setError(null);
    setSelection(`${song.id}:${requirement.instrument}`, { childId: "", spotNumber: spotNumber == null ? "" : String(spotNumber) });
    setInstrumentTarget({ seasonId: season.id, eventId: event.id, songId: song.id, instrument: requirement.instrument, spotNumber });
  }

  const Container = embedded ? "div" : "main";

  return (
    <Container id={embedded ? undefined : "main"} className={embedded ? "mb-8 text-ink" : "gradient-canvas min-h-dvh text-ink"}>
      {!embedded ? <header className="gradient-brand border-b border-forest-900/10 text-ink">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <Link href="/parent" className="inline-flex min-h-11 items-center gap-2 rounded-lg text-sm font-medium text-ink hover:text-forest-900"><ArrowLeft className="h-4 w-4" aria-hidden="true" />Family workspace</Link>
          <button type="button" className="btn-ghost min-h-11 text-ink hover:bg-white/10 hover:text-forest-900" onClick={() => void signOut()}><LogOut className="h-4 w-4" aria-hidden="true" />Sign out</button>
        </div>
      </header> : null}
      <div className={embedded ? "" : "mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10"}>
        {!embedded ? <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
          <div><p className="eyebrow">Music ministry</p><h1 className="mt-1 font-serif text-3xl text-forest-900">Seasons and reservations</h1><p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-soft">Reserve one regular song per approved child in each season, plus one spot per song marked as an extra song.</p></div>
          <button type="button" className="btn-secondary min-h-11" onClick={() => void refresh()} disabled={loading || Boolean(busyKey)}><RefreshCw className="h-4 w-4" aria-hidden="true" />Refresh availability</button>
        </div> : null}
        {notice ? <Notice tone="success" className="mb-4">{notice}</Notice> : null}
        <InlineError message={error} className="mb-4" />

        <section className="card mb-8 p-4" aria-label="Season filters">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div><label htmlFor="season-filter" className="field-label">Season</label><select id="season-filter" className="input" value={seasonFilter} onChange={(event) => setSeasonFilter(event.target.value)}><option value="all">All seasons</option>{data.seasons.map((season) => <option key={season.id} value={season.id}>{season.name}</option>)}</select></div>
            <div><label htmlFor="date-filter" className="field-label">Event date</label><input id="date-filter" type="date" className="input" value={dateFilter} onChange={(event) => setDateFilter(event.target.value)} /></div>
            <div><label htmlFor="instrument-filter" className="field-label">Instrument</label><select id="instrument-filter" className="input" value={instrumentFilter} onChange={(event) => setInstrumentFilter(event.target.value)}><option value="all">All instruments</option>{INSTRUMENTS.map((instrument) => <option key={instrument}>{instrument}</option>)}</select></div>
            <div><label htmlFor="availability-filter" className="field-label">Availability</label><select id="availability-filter" className="input" value={availabilityFilter} onChange={(event) => setAvailabilityFilter(event.target.value)}><option value="all">Any availability</option><option value="available">Available spots</option><option value="open">Registration open</option></select></div>
          </div>
        </section>

        {!embedded ? <section aria-labelledby="reservations-heading" className="mb-9">
          <div className="mb-3 flex items-center justify-between gap-3"><h2 id="reservations-heading" tabIndex={-1} className="scroll-mt-6 font-serif text-xl text-forest-900">Your reservations</h2><span className="text-sm text-ink-muted">{activeReservations.length} confirmed</span></div>
          {activeReservations.length === 0 ? <p className="rounded-xl border border-dashed border-parchment-300 px-4 py-5 text-sm text-ink-muted">No confirmed reservations yet.</p> : null}
          <div className="grid gap-3 md:grid-cols-2">
            {activeReservations.map((reservation) => {
              const cutoff = Date.parse(reservation.starts_at) - Number(data.seasons.find((s) => s.id === reservation.season_id)?.cancellation_hours ?? 0) * 3_600_000;
              const canCancel = Date.now() <= cutoff;
              return <article key={reservation.id} id={`reservation-${reservation.id}`} tabIndex={-1} className="scroll-mt-6 rounded-2xl border border-forest-200 gradient-tint p-4 focus-visible:outline-2 focus-visible:outline-offset-4">
                <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-xs font-semibold uppercase tracking-wide text-forest-800">{reservation.season_name}</p><h3 className="mt-1 font-semibold text-forest-950">{reservation.child_name} · {reservation.instrument}{reservation.song_role ? ` · ${reservation.song_role}` : ""}</h3></div><span className="chip border-forest-300 bg-white text-forest-900">Confirmed</span></div>
                <p className="mt-2 text-sm text-ink-soft">{reservation.event_name} · {formatDateTime(reservation.starts_at, safeTz(reservation.timezone))}</p>
                <p className="mt-1 text-sm text-ink-muted">{reservation.song_title} · spot {reservation.spot_number}{reservation.is_extra ? " · Extra song" : ""}</p>
                {reservation.review_required ? <p className="mt-3 rounded-lg border border-amber-accent/40 bg-amber-soft/50 px-3 py-2 text-sm text-amber-deep">A coordinator is reviewing this reservation after a profile change. It remains confirmed unless the coordinator contacts you with an update.</p> : null}
                {canCancel ? <button type="button" className="btn-danger-ghost mt-3 min-h-11" onClick={() => setCancelTarget({ id: reservation.id, message: `${reservation.child_name} · ${reservation.event_name} · ${reservation.instrument}` })}>Cancel reservation</button> : <p className="mt-3 text-sm text-amber-deep">Cancellation cutoff passed. Contact the ministry coordinator for help.</p>}
              </article>;
            })}
          </div>
        </section> : null}

        <section aria-labelledby="seasons-heading">
          <div className="mb-4 flex items-center gap-2"><CalendarDays className="h-5 w-5 text-forest-700" aria-hidden="true" /><h2 id="seasons-heading" className="font-serif text-xl text-forest-900">Published seasons</h2></div>
          {loading ? <p className="rounded-xl border border-parchment-300 bg-parchment-50 p-5 text-sm text-ink-muted" role="status">Loading seasons…</p> : null}
          {!loading && !data.seasons.length ? <div className="rounded-2xl border border-dashed border-parchment-300 bg-parchment-50 p-7 text-center"><Users className="mx-auto h-8 w-8 text-forest-700" aria-hidden="true" /><h3 className="mt-3 font-serif text-lg text-forest-900">No published seasons</h3><p className="mt-1 text-sm text-ink-muted">Check back when registration opens for the next ministry season.</p></div> : null}
          <div className="space-y-5">
            {filteredSeasons.map((season) => {
              const registration = registrationStatus(season, now);
              const visibleEvents = season.events.filter((event) => (!dateFilter || eventDateFilterValue(event.startsAt, season.timezone) === dateFilter)
                && (availabilityFilter !== "open" || registration === "Registration open")
                && (availabilityFilter !== "available" || event.songs.some((song) => song.requirements.some((item) => item.available > 0 && (instrumentFilter === "all" || item.instrument === instrumentFilter)))));
              return <article key={season.id} className="card overflow-hidden">
                <div className="grid gap-3 border-b border-parchment-200 bg-white/50 p-4 sm:p-5 md:grid-cols-[minmax(0,1fr)_auto] md:items-start">
                  <div><p className="eyebrow">{season.start_date} to {season.end_date}</p><h3 className="mt-1 font-serif text-2xl text-forest-900">{season.name}</h3><p className="mt-2 max-w-3xl text-sm leading-relaxed text-ink-soft">{season.description}</p>{season.instructions ? <p className="mt-2 text-sm text-ink-muted">{season.instructions}</p> : null}</div>
                  <span className={`chip min-h-8 ${registration === "Registration open" ? "border-forest-300 gradient-tint text-forest-900" : "border-amber-accent/40 bg-amber-soft/60 text-amber-deep"}`}>{registration}</span>
                </div>
                <div className="space-y-4 p-4 sm:p-5">
                  <p className="text-xs text-ink-muted">Registration {formatDateTime(season.registration_opens_at, safeTz(season.timezone))} to {formatDateTime(season.registration_closes_at, safeTz(season.timezone))} · {season.location || "Location to be announced"}</p>
                  {!visibleEvents.length ? <p className="rounded-xl bg-parchment-100 px-4 py-3 text-sm text-ink-muted">No events match these filters.</p> : null}
                  <EventSlider events={visibleEvents} timezone={safeTz(season.timezone)} seasonName={season.name}>
                    {(event, index) => <div key={event.id} className={`rounded-xl border border-parchment-300 p-4 ${index % 2 === 0 ? "bg-white" : "gradient-tint"}`}>
                    <p className="mb-3 font-serif text-lg text-forest-900">{formatDateTime(event.startsAt, safeTz(season.timezone), { dateStyle: "full" })}</p>
                    <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="field-label">Date</p><p className="text-sm text-ink-soft">{formatDateTime(event.startsAt, safeTz(season.timezone))}</p><h4 className="mt-1 font-semibold text-forest-900">{event.name}</h4><p className="mt-1 text-sm text-ink-soft">Ends {formatDateTime(event.endsAt, safeTz(season.timezone), { timeStyle: "short" })}</p></div><p className="text-sm text-ink-muted">{event.location || season.location}</p></div>
                    <div className="mt-4 space-y-3">
                      {event.songs.map((song, songIndex) => <div key={song.id} role="group" aria-label={`Song ${song.title}`} className={`w-full min-w-0 rounded-xl border border-parchment-300 p-3 sm:p-4 ${songIndex % 2 === 0 ? "bg-white/80" : "gradient-tint"}`}>
                        <div className="mb-3"><p className="field-label">Song name</p><h5 className="break-words font-medium text-ink">{song.title}{song.composer ? <span className="ml-1 font-normal text-ink-muted">· {song.composer}</span> : null}</h5></div>
                        <SongInformation song={song} />
                        <div className="mt-3 grid gap-3 xl:grid-cols-2">
                          {song.requirements.filter((item) => instrumentFilter === "all" || item.instrument === instrumentFilter).map((requirement) => {
                            const key = `${song.id}:${requirement.instrument}`;
                            const eligible = approvedChildren.filter((child) => childHasInstrument(child.id, requirement.instrument));
                            const unbookedChildren = eligible.filter((child) => !alreadyRegistered(child.id, season.id, song));
                            const canBook = registration === "Registration open" && requirement.availableSpots.length > 0 && bookingChildren(season.id, event, song, requirement.instrument).length > 0 && now < Date.parse(event.startsAt);
                            return <div key={key} role="group" aria-label={`${requirement.instrument} for ${song.title}`} className="min-w-0 rounded-xl bg-parchment-100/70 p-3">
                              <div className="flex flex-wrap items-center justify-between gap-2"><button type="button" className="min-h-11 break-words text-left font-semibold text-forest-900 underline underline-offset-4" aria-label={`View ${instrumentLabel(requirement)} details for ${song.title}`} onClick={() => viewInstrument(season, event, song, requirement)}>{instrumentLabel(requirement)}</button><span className={`chip ${requirement.available > 0 ? "border-forest-300 gradient-tint text-forest-900" : "border-rose-deep/30 bg-rose-soft text-rose-deep"}`}>{requirement.available > 0 ? `${requirement.available} of ${requirement.capacity} available` : "Full"}</span></div>
                              <p className="mt-1 text-xs text-ink-muted">{requirement.reserved} reserved · {requirement.capacity} total</p>
                              <ul className="mt-3 space-y-2" aria-label={`${requirement.instrument} spots for ${song.title}`}>
                                {Array.from({ length: requirement.capacity }, (_, index) => index + 1).map((spotNumber) => {
                                  const available = requirement.availableSpots.includes(spotNumber);
                                  return <li key={spotNumber} className="flex flex-wrap items-center justify-between gap-2 border-t border-parchment-300 pt-2">
                                    <button type="button" className="min-h-11 break-words text-left text-sm text-forest-900 underline underline-offset-4" aria-label={`View ${instrumentLabel(requirement, spotNumber)} spot ${spotNumber} details for ${song.title}`} onClick={() => viewInstrument(season, event, song, requirement, spotNumber)}>Spot {spotNumber} · {available ? "Available" : `Reserved · ${instrumentLabel(requirement, spotNumber)}`}</button>
                                    {available ? <button type="button" className="btn-primary btn-sm min-h-11" aria-label={`Register for ${requirement.instrument} spot ${spotNumber} in ${song.title}`} disabled={!canBook || Boolean(busyKey)} onClick={() => viewInstrument(season, event, song, requirement, spotNumber)}><Check className="size-4" aria-hidden />Register child</button> : null}
                                  </li>;
                                })}
                              </ul>
                              {!eligible.length ? <p className="mt-3 text-sm text-amber-deep">{data.children.some((child) => child.status === "Pending" && child.instruments.includes(requirement.instrument)) ? "Pending Child Approval" : "No approved child in your family is listed for this instrument."}</p> : null}
                              {eligible.length > 0 && unbookedChildren.length === 0 ? <p className="mt-3 text-sm text-forest-800">{song.allowExtra ? "All eligible children are already registered for this extra song this season." : "All eligible children already have a regular-song reservation this season."}</p> : null}
                              {!requirement.availableSpots.length ? <p className="mt-3 text-sm text-rose-deep">This requirement is full.</p> : null}
                              {registration !== "Registration open" ? <p className="mt-3 text-sm text-amber-deep">{registration}.</p> : null}
                            </div>;
                          })}
                          {!song.requirements.some((item) => instrumentFilter === "all" || item.instrument === instrumentFilter) ? <p className="text-sm text-ink-muted">No configured requirements match the instrument filter.</p> : null}
                        </div>
                      </div>)}
                    </div>
                  </div>}
                  </EventSlider>
                </div>
              </article>;
            })}
          </div>
        </section>
      </div>
      <Modal open={Boolean(detailSeason && detailEvent && detailSong && detailRequirement)} onClose={() => setInstrumentTarget(null)} locked={Boolean(busyKey)} size="lg" title={detailSong && detailRequirement ? `${instrumentLabel(detailRequirement, instrumentTarget?.spotNumber ?? null)} · ${detailSong.title}` : "Instrument details"} footer={<>
        <button type="button" className="btn-secondary" disabled={Boolean(busyKey)} onClick={() => setInstrumentTarget(null)}>Close</button>
        {detailCanBook && detailSeason && detailEvent && detailSong && detailRequirement ? <button type="button" className="btn-primary" disabled={!detailSelection.childId || !detailEligibleChildren.some((child) => child.id === detailSelection.childId) || Boolean(busyKey)} aria-busy={busyKey === detailKey} onClick={() => void book(detailSeason, detailEvent, detailSong, detailRequirement)}>{busyKey === detailKey ? <RefreshCw className="size-4 animate-spin" aria-hidden /> : <Check className="size-4" aria-hidden />}Confirm reservation</button> : null}
      </>}>
        {detailSeason && detailEvent && detailSong && detailRequirement ? <div className="min-w-0 space-y-4">
          <dl className="space-y-2 text-sm"><div><dt className="field-label">Date</dt><dd>{formatDateTime(detailEvent.startsAt, safeTz(detailSeason.timezone))}</dd></div><div><dt className="field-label">Event</dt><dd className="break-words">{detailEvent.name} · {detailEvent.location || detailSeason.location}</dd></div><div><dt className="field-label">Song name</dt><dd className="break-words">{detailSong.title}</dd></div><div><dt className="field-label">Instrument requested</dt><dd className="break-words">{instrumentLabel(detailRequirement, instrumentTarget?.spotNumber ?? null)} · {detailRequirement.available} available · {detailRequirement.reserved} reserved · {detailRequirement.capacity} total</dd></div></dl>
          <SongInformation song={detailSong} />
          {instrumentTarget?.spotNumber != null ? <p className="font-semibold text-forest-900">Spot {instrumentTarget.spotNumber} · {detailSpotAvailable ? "Available" : `Reserved · ${instrumentLabel(detailRequirement, instrumentTarget.spotNumber)}`}</p> : <ul className="space-y-2" aria-label="Instrument spots">{Array.from({ length: detailRequirement.capacity }, (_, index) => index + 1).map((spotNumber) => <li key={spotNumber}><button type="button" className="min-h-11 break-words text-left text-sm text-forest-900 underline" onClick={() => viewInstrument(detailSeason, detailEvent, detailSong, detailRequirement, spotNumber)}>Spot {spotNumber} · {detailRequirement.availableSpots.includes(spotNumber) ? "Available" : `Reserved · ${instrumentLabel(detailRequirement, spotNumber)}`}</button></li>)}</ul>}
          {detailCanBook ? <div><label htmlFor="registration-child" className="field-label">Child</label><select id="registration-child" className="input" value={detailSelection.childId} disabled={Boolean(busyKey)} onChange={(event) => setSelection(detailKey, { childId: event.target.value })}><option value="">Select child</option>{detailEligibleChildren.map((child) => <option key={child.id} value={child.id}>{child.full_name}</option>)}</select></div> : null}
          {detailSeason && registrationStatus(detailSeason, now) !== "Registration open" ? <p className="text-sm text-amber-deep">{registrationStatus(detailSeason, now)}.</p> : null}
          {detailSpotAvailable && !detailEligibleChildren.length ? <p className="text-sm text-amber-deep">No eligible child is available for this spot. Check approval, instruments, existing season reservations, and performance times.</p> : null}
          <InlineError message={error} />
        </div> : null}
      </Modal>
      <ConfirmDialog open={Boolean(cancelTarget)} onClose={() => setCancelTarget(null)} title="Cancel this reservation?" confirmLabel="Cancel reservation" busyLabel="Cancelling…" onConfirm={cancelReservation}>
        <p>{cancelTarget?.message}</p><p>The spot will be released and cancellation recorded. This action cannot be undone.</p>
      </ConfirmDialog>
    </Container>
  );
}