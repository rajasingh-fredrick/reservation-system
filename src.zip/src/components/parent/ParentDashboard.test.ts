import { isValidElement, type ReactNode } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ParentDashboard } from "./ParentDashboard";
import { ParentSeasonBrowser } from "./ParentSeasonBrowser";
import { api } from "@/lib/client";
import { SONG_ROLES } from "@/lib/contracts";

const hooks = vi.hoisted(() => ({
  values: [] as unknown[],
  index: 0,
  focus: vi.fn(),
  scrollIntoView: vi.fn(),
  effects: [] as Array<() => void | (() => void)>,
}));

vi.mock("next/navigation", () => ({ useRouter: () => ({ replace: vi.fn() }) }));
vi.mock("@/lib/client", async (importOriginal) => ({
  ...await importOriginal<typeof import("@/lib/client")>(),
  api: vi.fn(),
}));
vi.mock("react", async (importOriginal) => ({
  ...await importOriginal<typeof import("react")>(),
  useEffect: (effect: () => void | (() => void)) => { hooks.effects.push(effect); },
  useCallback: (callback: unknown) => callback,
  useMemo: (factory: () => unknown) => factory(),
  useRef: () => ({ current: { focus: hooks.focus, scrollIntoView: hooks.scrollIntoView } }),
  useState: (initial: unknown) => {
    const index = hooks.index++;
    if (!(index in hooks.values)) hooks.values[index] = typeof initial === "function" ? initial() : initial;
    return [hooks.values[index], (value: unknown) => {
      hooks.values[index] = typeof value === "function" ? value(hooks.values[index]) : value;
    }];
  },
}));

type Props = {
  children?: ReactNode;
  title?: ReactNode;
  footer?: ReactNode;
  id?: string;
  value?: string;
  href?: string;
  onClick?: () => void;
  onSubmit?: (event: { preventDefault: () => void }) => Promise<void>;
  disabled?: boolean;
  "aria-controls"?: string;
};

function elements(node: ReactNode): Props[] {
  if (Array.isArray(node)) return node.flatMap(elements);
  if (!isValidElement<Props>(node)) return [];
  return [node.props, ...elements(node.props.children)];
}

function render() {
  hooks.index = 0;
  return elements(ParentDashboard());
}

const child = {
  id: "child-1", fullName: "Existing Child", birthMonth: 3, birthYear: 2016,
  additionalInformation: "Piano lessons", instruments: [{ instrument: "Piano", yearsExperience: 2 }],
  status: "Approved", statusReason: null,
};

describe("family child editor actions", () => {
  beforeEach(() => {
    hooks.values = [[child], [], undefined, null, null, false, false, null, false];
    delete hooks.values[2];
    hooks.focus.mockClear();
    hooks.scrollIntoView.mockClear();
    vi.mocked(api).mockReset();
    hooks.effects = [];
  });

  afterEach(() => vi.unstubAllGlobals());

  it.each([null, 1, 2, 3])("shows only own children's names beside the instrument and keeps spot %s booking rules", (spotNumber) => {
    hooks.values = [{
      seasons: [{
        id: "season", name: "Winter", description: "", start_date: "2099-01-01", end_date: "2099-12-31",
        registration_opens_at: "2020-01-01T00:00:00Z", registration_closes_at: "2099-12-31T00:00:00Z",
        timezone: "UTC", location: "", instructions: "", cancellation_hours: 24, status: "Published",
        events: [{
          id: "event", name: "Service", startsAt: "2099-12-01T10:00:00Z", endsAt: "2099-12-01T11:00:00Z",
          location: "", songs: [{
            id: "appearance", songId: "song", title: "Test song", composer: "", notes: "", libraryNotes: "",
            songRole: null, allowExtra: false, links: [], sheets: [],
            requirements: [{
              instrument: "Piano", capacity: 3, reserved: 2, available: 1, availableSpots: [3],
              reservedSpots: [{ spotNumber: 1, childName: "Own Child" }],
            }],
          }],
        }],
      }],
      children: [{ id: "eligible", full_name: "Eligible Child", status: "Approved", instruments: ["Piano"] }],
      reservations: [],
    }, false];
    hooks.values[11] = { seasonId: "season", eventId: "event", songId: "appearance", instrument: "Piano", spotNumber };
    hooks.index = 0;
    const nodes = elements(ParentSeasonBrowser());
    const panel = nodes.find((props) => typeof props.title === "string" && props.title.endsWith(" · Test song"))!;
    const expectedLabel = spotNumber === 1 || spotNumber === null ? "Piano · Own Child" : "Piano";
    expect(panel.title).toBe(`${expectedLabel} · Test song`);
    const html = renderToStaticMarkup(panel.children);
    expect(html).toContain(`${expectedLabel} · 1 available · 2 reserved · 3 total`);
    expect(renderToStaticMarkup(panel.footer).includes("Confirm reservation")).toBe(spotNumber === 3);
    expect(html.includes('id="registration-child"')).toBe(spotNumber === 3);
    hooks.index = 0;
    const listing = renderToStaticMarkup(ParentSeasonBrowser());
    expect(listing).toContain("Piano · Own Child");
    expect(listing).toContain("Spot 2 · Reserved · Piano");
    expect(listing).not.toContain("Other Family Child");
    expect(listing).toContain('aria-label="Register for Piano spot 3 in Test song"');
    expect(listing).not.toContain('aria-label="Register for Piano spot 2 in Test song"');
  });

  it.each(SONG_ROLES)("shows %s only once per song in the family season listing", (songRole) => {
    hooks.values = [{
      seasons: [{
        id: "season", name: "Winter", description: "", start_date: "2099-01-01", end_date: "2099-12-31",
        registration_opens_at: "2098-01-01T00:00:00Z", registration_closes_at: "2099-12-31T00:00:00Z",
        timezone: "UTC", location: "", instructions: "", cancellation_hours: 24, status: "Published",
        events: [{
          id: "event", name: "Service", startsAt: "2099-12-01T10:00:00Z", endsAt: "2099-12-01T11:00:00Z",
          location: "", songs: Array.from({ length: 3 }, (_, index) => ({
            id: `appearance-${index}`, songId: `song-${index}`, title: `Test song ${index + 1}`, composer: "", notes: "", libraryNotes: "",
            songRole, allowExtra: false, links: [], sheets: [], requirements: [],
          })),
        }],
      }], children: [], reservations: [],
    }, false];
    hooks.index = 0;
    const html = renderToStaticMarkup(ParentSeasonBrowser());
    const rows = [...html.matchAll(/aria-label="Song Test song \d" class="([^"]+)"/g)];
    expect(rows).toHaveLength(3);
    rows.forEach((row, index) => {
      expect(row[1]).toContain("w-full");
      expect(row[1]).toContain("rounded-xl");
      expect(row[1]).toContain(index % 2 === 0 ? "bg-white/80" : "gradient-tint");
      const start = html.indexOf(row[0]);
      const end = rows[index + 1] ? html.indexOf(rows[index + 1][0]) : html.length;
      expect(html.slice(start, end).split(songRole)).toHaveLength(2);
    });
  });

  it("links the upcoming heading and each card to the reservation details", () => {
    hooks.values[1] = [{
      id: "reservation-1", season_name: "Winter", child_name: "Existing Child",
      instrument: "Piano", event_name: "Service", song_title: "Song",
      starts_at: "2099-12-01T10:00:00Z", timezone: "UTC",
    }];
    const links = render().filter((props) => props.href);
    expect(links.some((props) => props.href === "/parent/seasons#reservations-heading")).toBe(true);
    expect(links.some((props) => props.href === "/parent/seasons#reservation-reservation-1")).toBe(true);
  });

  it.each(["#reservation-reservation-1", "#reservations-heading"])("focuses the details destination after loading: %s", (hash) => {
    const reservation = {
      id: "reservation-1", status: "Confirmed", season_name: "Winter",
      child_name: "Existing Child", instrument: "Piano", event_name: "Service",
      song_title: "Song", starts_at: "2099-12-01T10:00:00Z", timezone: "UTC",
    };
    hooks.values = [{ seasons: [], children: [], reservations: [reservation] }, false];
    hooks.index = 0;
    const tree = elements(ParentSeasonBrowser());
    const targetId = hash.slice(1);
    expect(tree.some((props) => props.id === targetId)).toBe(true);
    const getElementById = vi.fn(() => ({ focus: hooks.focus, scrollIntoView: hooks.scrollIntoView }));
    const removeEventListener = vi.fn();
    vi.stubGlobal("document", { getElementById });
    vi.stubGlobal("window", { location: { hash }, addEventListener: vi.fn(), removeEventListener });
    const cleanup = hooks.effects[1]();
    expect(getElementById).toHaveBeenCalledWith(targetId);
    expect(hooks.focus).toHaveBeenCalledWith({ preventScroll: true });
    expect(hooks.scrollIntoView).toHaveBeenCalledWith({ block: "start" });
    if (cleanup) cleanup();
    expect(removeEventListener).toHaveBeenCalledWith("hashchange", expect.any(Function));
  });

  it("keeps Add child available with existing profiles and focuses the form", () => {
    const add = render().find((props) => props["aria-controls"] === "child-editor");
    expect(add?.disabled).toBe(false);
    add?.onClick?.();
    expect(hooks.focus).toHaveBeenCalledWith({ preventScroll: true });
    expect(hooks.scrollIntoView).toHaveBeenCalledWith({ block: "center" });
    expect(render().find((props) => props.id === "child-name")?.value).toBe("");
  });

  it("switches from editing an existing child to a clean new profile", () => {
    const actions = render().filter((props) => props["aria-controls"] === "child-editor");
    actions[1].onClick?.();
    expect(render().find((props) => props.id === "child-name")?.value).toBe("Existing Child");
    render().find((props) => props["aria-controls"] === "child-editor")?.onClick?.();
    expect(hooks.values[3]).toBeNull();
    expect(render().find((props) => props.id === "child-name")?.value).toBe("");
    expect(hooks.focus).toHaveBeenCalledTimes(2);
  });

  it("wires both empty-state and header actions to focus the new profile", () => {
    hooks.values[0] = [];
    const actions = render().filter((props) => props["aria-controls"] === "child-editor");
    expect(actions).toHaveLength(2);
    for (const action of actions) {
      expect(action.disabled).toBe(false);
      action.onClick?.();
    }
    expect(hooks.focus).toHaveBeenCalledTimes(2);
  });

  it.each([5, 6, 8])("disables Add child when loading, saving, or unverified (state %i)", (index) => {
    hooks.values[index] = true;
    expect(render().find((props) => props["aria-controls"] === "child-editor")?.disabled).toBe(true);
  });

  it("creates rather than updates after switching from Edit to Add child", async () => {
    render().filter((props) => props["aria-controls"] === "child-editor")[1].onClick?.();
    render().find((props) => props["aria-controls"] === "child-editor")?.onClick?.();
    hooks.values[2] = {
      fullName: "New Child", birthMonth: 5, birthYear: 2018,
      additionalInformation: "", instruments: [{ instrument: "Piano", yearsExperience: 0 }],
    };
    vi.mocked(api)
      .mockResolvedValueOnce({})
      .mockResolvedValueOnce({ children: [child] })
      .mockResolvedValueOnce({ reservations: [] });
    const preventDefault = vi.fn();
    await render().find((props) => props.onSubmit)?.onSubmit?.({ preventDefault });
    expect(preventDefault).toHaveBeenCalledOnce();
    expect(api).toHaveBeenNthCalledWith(1, "/api/parent/children", {
      method: "POST",
      json: expect.objectContaining({ fullName: "New Child" }),
    });
    expect(render().find((props) => props.id === "child-name")?.value).toBe("");
  });
});
