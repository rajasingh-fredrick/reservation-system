"use client";

import { useEffect, useState } from "react";
import { api, errorMessage } from "@/lib/client";
import { InlineError } from "@/components/ui/Feedback";

export function EmailPreferences() {
  const [subscribed, setSubscribed] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    void api<{ subscribed: boolean }>("/api/parent/email-preferences", { signal: controller.signal })
      .then((result) => setSubscribed(result.subscribed))
      .catch((err: unknown) => {
        if (err instanceof DOMException && err.name === "AbortError") return;
        setError(errorMessage(err));
      });
    return () => controller.abort();
  }, []);

  async function toggle() {
    if (subscribed === null) return;
    setBusy(true);
    setError(null);
    setSaved(false);
    try {
      const result = await api<{ subscribed: boolean }>("/api/parent/email-preferences",
        { method: "PATCH", json: { subscribed: !subscribed } });
      setSubscribed(result.subscribed);
      setSaved(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card mb-8 p-5 sm:p-6" aria-labelledby="email-preferences-heading">
      <h2 id="email-preferences-heading" className="font-serif text-xl text-forest-900">Email notifications</h2>
      <p className="mt-2 text-sm text-ink-soft">Subscribe to season announcements, performance reminders, and ministry announcements. You can unsubscribe at any time. Account security, child-profile, and reservation emails are separate.</p>
      <InlineError message={error} className="mt-3" />
      {subscribed !== null ? (
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <p className="text-sm text-ink">You are {subscribed ? "subscribed" : "unsubscribed"}.</p>
          <button type="button" className="btn-secondary min-h-11" disabled={busy} onClick={() => void toggle()}>
            {busy ? "Saving..." : subscribed ? "Unsubscribe" : "Subscribe"}
          </button>
        </div>
      ) : !error ? <p role="status" className="mt-3 text-sm text-ink-muted">Loading email preferences...</p> : null}
      {saved ? <p role="status" className="mt-3 text-sm text-ink">Email preference saved.</p> : null}
    </section>
  );
}
