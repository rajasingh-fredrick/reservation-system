import { isValidElement, type ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { api } from "@/lib/client";
import { EmailPreferences } from "./EmailPreferences";

const hooks = vi.hoisted(() => ({ values: [] as unknown[], index: 0, effects: [] as Array<() => unknown> }));
vi.mock("@/lib/client", async (original) => ({ ...await original<typeof import("@/lib/client")>(), api: vi.fn() }));
vi.mock("react", async (original) => ({
  ...await original<typeof import("react")>(),
  useEffect: (effect: () => unknown) => { hooks.effects.push(effect); },
  useState: (initial: unknown) => {
    const index = hooks.index++;
    if (!(index in hooks.values)) hooks.values[index] = initial;
    return [hooks.values[index], (value: unknown) => { hooks.values[index] = value; }];
  },
}));
type Props = { children?: ReactNode; onClick?: () => void; disabled?: boolean; message?: string | null };
function elements(node: ReactNode): Props[] {
  if (Array.isArray(node)) return node.flatMap(elements);
  if (!isValidElement<Props>(node)) return [];
  return [node.props, ...elements(node.props.children)];
}
function render() {
  hooks.index = 0;
  return elements(EmailPreferences());
}
beforeEach(() => {
  hooks.values = [false, false, null, false];
  hooks.effects = [];
  vi.mocked(api).mockReset();
});
describe("Family Workspace email preferences", () => {
  it("loads the saved preference", async () => {
    vi.mocked(api).mockResolvedValue({ subscribed: true });
    render();
    hooks.effects[0]();
    await vi.waitFor(() => expect(hooks.values[0]).toBe(true));
    expect(render().some((props) => props.children === "Unsubscribe")).toBe(true);
  });
  it("subscribes, confirms persistence, and permits unsubscribing", async () => {
    vi.mocked(api).mockResolvedValueOnce({ subscribed: true }).mockResolvedValueOnce({ subscribed: false });
    render().find((props) => props.children === "Subscribe")!.onClick!();
    expect(render().find((props) => props.children === "Saving...")!.disabled).toBe(true);
    await vi.waitFor(() => expect(hooks.values[0]).toBe(true));
    expect(api).toHaveBeenCalledWith("/api/parent/email-preferences", { method: "PATCH", json: { subscribed: true } });
    expect(render().some((props) => props.children === "Email preference saved.")).toBe(true);
    render().find((props) => props.children === "Unsubscribe")!.onClick!();
    await vi.waitFor(() => expect(hooks.values[0]).toBe(false));
    expect(api).toHaveBeenLastCalledWith("/api/parent/email-preferences", { method: "PATCH", json: { subscribed: false } });
  });
  it("surfaces save failure without falsely updating the preference", async () => {
    vi.mocked(api).mockRejectedValue(new Error("Preference could not be saved"));
    render().find((props) => props.children === "Subscribe")!.onClick!();
    await vi.waitFor(() => expect(hooks.values[1]).toBe(false));
    expect(hooks.values[0]).toBe(false);
    expect(render().some((props) => props.message === "Preference could not be saved")).toBe(true);
    expect(hooks.values[3]).toBe(false);
  });
});
