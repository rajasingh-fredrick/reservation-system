"use client";

import { useId, useState } from "react";
import clsx from "clsx";
import { FileText, FileUp, Trash2 } from "lucide-react";
import { INSTRUMENTS, MAX_PDF_BYTES, type Instrument } from "@/lib/contracts";
import { formatBytes } from "@/lib/client";

export interface PendingSheet {
  key: string;
  file: File;
  label: string;
  instrument: Instrument | "";
  arrangement: string;
}

let seq = 0;

export function isPdf(file: File) {
  return file.type === "application/pdf" || /\.pdf$/i.test(file.name);
}

function guessInstrument(name: string): Instrument | "" {
  const lower = name.toLowerCase();
  const sorted = [...INSTRUMENTS].sort((a, b) => b.length - a.length);
  for (const inst of sorted) if (lower.includes(inst.toLowerCase())) return inst;
  if (lower.includes("bass")) return "Bass Guitar";
  if (lower.includes("sax")) return "Saxophone";
  return "";
}

export function toPending(file: File): PendingSheet {
  seq += 1;
  const base = file.name.replace(/\.pdf$/i, "").replace(/[_-]+/g, " ").trim();
  return { key: `p${seq}-${file.name}`, file, label: base || "Sheet", instrument: guessInstrument(file.name), arrangement: "" };
}

/** Appends the multipart fields shared by song creation and adding sheets. */
export function appendSheetFields(form: FormData, rows: PendingSheet[]) {
  for (const row of rows) form.append("files", row.file, row.file.name);
  form.append("sheetLabels", JSON.stringify(rows.map((r) => r.label.trim())));
  form.append("sheetInstruments", JSON.stringify(rows.map((r) => (r.instrument === "" ? null : r.instrument))));
  form.append("sheetArrangements", JSON.stringify(rows.map((r) => r.arrangement.trim())));
  form.append("permission", "true");
}

export function validateRows(rows: PendingSheet[]): string | null {
  if (rows.length === 0) return "Add at least one PDF sheet.";
  const missing = rows.findIndex((r) => !r.label.trim());
  if (missing >= 0) return `Sheet ${missing + 1} needs a label (for example "Lead sheet" or "Violin part").`;
  return null;
}

export function SheetUploadRows({
  rows,
  onChange,
  disabled,
  multiple = true,
  maxBytes = MAX_PDF_BYTES,
}: {
  rows: PendingSheet[];
  onChange: (rows: PendingSheet[]) => void;
  disabled?: boolean;
  multiple?: boolean;
  maxBytes?: number;
}) {
  const baseId = useId();
  const [rejected, setRejected] = useState<string[]>([]);
  const [dragging, setDragging] = useState(false);

  function addFiles(list: FileList | File[] | null) {
    if (!list) return;
    const files = Array.from(list);
    const bad: string[] = [];
    const good: PendingSheet[] = [];
    for (const file of files) {
      if (!isPdf(file)) bad.push(`${file.name} is not a PDF`);
      else if (file.size > maxBytes) bad.push(`${file.name} is larger than ${formatBytes(maxBytes)}`);
      else if (file.size === 0) bad.push(`${file.name} is empty`);
      else good.push(toPending(file));
    }
    setRejected(bad);
    if (good.length) onChange(multiple ? [...rows, ...good] : [good[0]]);
  }

  function update(key: string, patch: Partial<PendingSheet>) {
    onChange(rows.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  }

  return (
    <div className="space-y-3">
      <label
        htmlFor={`${baseId}-files`}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (!disabled) addFiles(e.dataTransfer.files);
        }}
        className={clsx(
          "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed px-4 py-6 text-center transition focus-within:ring-2 focus-within:ring-amber-accent",
          dragging ? "border-amber-accent bg-amber-soft/50" : "border-parchment-300 bg-parchment-100/60 hover:border-forest-300 hover:bg-white/60",
          disabled && "pointer-events-none opacity-60",
        )}
      >
        <FileUp className="h-7 w-7 text-forest-700" aria-hidden="true" />
        <span className="text-sm font-semibold text-forest-900">Choose PDF sheets or drop them here</span>
        <span className="text-xs text-ink-muted">
          {multiple ? "Add several files at once — each becomes its own labelled sheet." : "Choose one replacement PDF."} PDF only, up to {formatBytes(maxBytes)} each.
        </span>
        <input
          id={`${baseId}-files`}
          type="file"
          accept="application/pdf,.pdf"
          multiple={multiple}
          className="sr-only"
          disabled={disabled}
          onChange={(e) => {
            addFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </label>

      {rejected.length > 0 ? (
        <ul role="alert" className="space-y-1 rounded-xl border border-rose-deep/25 bg-rose-soft px-3 py-2 text-sm text-rose-deep">
          {rejected.map((r) => (
            <li key={r}>{r} — skipped.</li>
          ))}
        </ul>
      ) : null}

      {multiple && rows.length > 0 ? (
        <ol className="space-y-3" aria-label="Sheets to upload">
          {rows.map((row, i) => (
            <li key={row.key} className="rounded-2xl border border-parchment-300 bg-white/70 p-3.5">
              <div className="mb-3 flex items-center gap-2">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-rose-soft text-rose-deep">
                  <FileText className="h-4 w-4" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-ink">{row.file.name}</p>
                  <p className="text-xs text-ink-muted">
                    Sheet {i + 1} · {formatBytes(row.file.size)}
                  </p>
                </div>
                <button type="button" className="icon-btn" disabled={disabled} onClick={() => onChange(rows.filter((r) => r.key !== row.key))} aria-label={`Remove ${row.file.name}`}>
                  <Trash2 className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <label className="field-label" htmlFor={`${baseId}-${row.key}-label`}>
                    Label <span className="text-rose-deep">*</span>
                  </label>
                  <input id={`${baseId}-${row.key}-label`} className="input" value={row.label} required disabled={disabled} onChange={(e) => update(row.key, { label: e.target.value })} />
                </div>
                <div>
                  <label className="field-label" htmlFor={`${baseId}-${row.key}-inst`}>
                    Instrument
                  </label>
                  <select id={`${baseId}-${row.key}-inst`} className="input" value={row.instrument} disabled={disabled} onChange={(e) => update(row.key, { instrument: e.target.value as Instrument | "" })}>
                    <option value="">Any / full score</option>
                    {INSTRUMENTS.map((inst) => (
                      <option key={inst} value={inst}>
                        {inst}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="field-label" htmlFor={`${baseId}-${row.key}-arr`}>
                    Arrangement
                  </label>
                  <input id={`${baseId}-${row.key}-arr`} className="input" placeholder="e.g. Beginner, Key of G" value={row.arrangement} disabled={disabled} onChange={(e) => update(row.key, { arrangement: e.target.value })} />
                </div>
              </div>
            </li>
          ))}
        </ol>
      ) : null}
      {!multiple && rows[0] ? (
        <p className="flex items-center gap-2 rounded-xl bg-white/70 px-3 py-2 text-sm text-ink">
          <FileText className="h-4 w-4 text-rose-deep" aria-hidden="true" />
          <span className="truncate">{rows[0].file.name}</span>
          <span className="text-ink-muted">· {formatBytes(rows[0].file.size)}</span>
          <button type="button" className="btn-ghost btn-sm ml-auto" disabled={disabled} onClick={() => onChange([])}>
            Clear
          </button>
        </p>
      ) : null}
    </div>
  );
}

export function PermissionCheck({ checked, onChange, disabled }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  const id = useId();
  return (
    <div className="flex items-start gap-3 rounded-xl border border-forest-100 gradient-tint px-3.5 py-3">
      <input id={id} type="checkbox" className="mt-0.5 h-4 w-4 accent-forest-700" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <label htmlFor={id} className="text-sm text-forest-900">
        I confirm our ministry has permission (licence, purchase or public domain) to store and share these sheets with participating families.
      </label>
    </div>
  );
}

export function ImpactCheck({ checked, onChange, count, disabled }: { checked: boolean; onChange: (v: boolean) => void; count: number; disabled?: boolean }) {
  const id = useId();
  return (
    <div className="flex items-start gap-3 rounded-xl border border-amber-accent/40 bg-amber-soft/50 px-3.5 py-3">
      <input id={id} type="checkbox" className="mt-0.5 h-4 w-4 accent-amber-deep" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <label htmlFor={id} className="text-sm text-amber-deep">
        I understand this change affects {count === 1 ? "1 scheduled event" : `${count} scheduled events`} that already use this material.
      </label>
    </div>
  );
}