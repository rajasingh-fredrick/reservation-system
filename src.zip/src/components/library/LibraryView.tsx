"use client";

import { useMemo, useState } from "react";
import { Archive, ArchiveRestore, CalendarClock, FileStack, LayoutGrid, List, Library, Plus, Search, Sparkles, Trash2, X } from "lucide-react";
import { INSTRUMENTS, type Song } from "@/lib/contracts";
import { api, errorMessage, formatRelative, plural, uniqueUsageEvents } from "@/lib/client";
import { useAdmin, useAdminData } from "@/components/shell/AdminProvider";
import { EmptyState, PageHeader, StatCard, Tag } from "@/components/ui/Bits";
import { ConfirmDialog } from "@/components/ui/Confirm";
import { useToast } from "@/components/ui/Feedback";
import { MusicIcon, SheetStackArt, StaffFlourish } from "@/components/ui/Motifs";
import { CreateSongDialog } from "./SongDialogs";
import { SongDrawer } from "./SongDrawer";

type View = "grid" | "list";
type StatusFilter = "active" | "archived" | "all" | "unused";
type BulkAction = "archive" | "restore" | "delete";

export function LibraryView() {
  const data = useAdminData();
  const { refresh } = useAdmin();
  const toast = useToast();
  const [query, setQuery] = useState("");
  const [instrument, setInstrument] = useState("");
  const [status, setStatus] = useState<StatusFilter>("active");
  const [view, setView] = useState<View>("grid");
  const [creating, setCreating] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => new Set());
  const [pendingBulkAction, setPendingBulkAction] = useState<BulkAction | null>(null);

  const stats = useMemo(() => {
    const active = data.songs.filter((s) => !s.archived);
    const sheets = active.reduce((n, s) => n + s.sheets.filter((x) => !x.archived).length, 0);
    const inUse = active.filter((s) => s.usages.length > 0).length;
    const now = Date.now();
    const upcoming = data.seasons.flatMap((s) => s.events).filter((e) => new Date(e.startsAt).getTime() >= now).length;
    return { active: active.length, sheets, inUse, upcoming };
  }, [data]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return data.songs
      .filter((s) => {
        if (status === "active" && s.archived) return false;
        if (status === "archived" && !s.archived) return false;
        if (status === "unused" && (s.archived || s.usages.length > 0)) return false;
        if (instrument && !s.sheets.some((x) => !x.archived && (instrument === "__any" ? x.instrument === null : x.instrument === instrument))) return false;
        if (!q) return true;
        return [s.title, s.composer, s.notes, ...(s.links ?? []), ...s.sheets.map((x) => `${x.label} ${x.arrangement} ${x.instrument ?? ""}`)].join(" ").toLowerCase().includes(q);
      })
      .sort((a, b) => a.title.localeCompare(b.title));
  }, [data.songs, query, instrument, status]);

  const filtersActive = query !== "" || instrument !== "" || status !== "active";
  const selected = filtered.filter((song) => selectedIds.has(song.id));
  const selectedActive = selected.filter((song) => !song.archived);
  const selectedArchived = selected.filter((song) => song.archived);
  const deletable = selected.filter((song) => song.usages.length === 0);
  const allVisibleSelected = filtered.length > 0 && filtered.every((song) => selectedIds.has(song.id));
  const bulkTargets = pendingBulkAction === "archive" ? selectedActive
    : pendingBulkAction === "restore" ? selectedArchived
      : pendingBulkAction === "delete" ? deletable : [];

  function toggleSongSelection(songId: string, checked: boolean) {
    setSelectedIds((current) => {
      const next = new Set(current);
      if (checked) next.add(songId);
      else next.delete(songId);
      return next;
    });
  }

  function toggleVisibleSelection(checked: boolean) {
    setSelectedIds((current) => {
      const next = new Set(current);
      filtered.forEach((song) => checked ? next.add(song.id) : next.delete(song.id));
      return next;
    });
  }

  async function confirmBulkAction() {
    if (!pendingBulkAction || !bulkTargets.length) return;
    const action = pendingBulkAction;
    const completed: string[] = [];
    const failed: string[] = [];
    for (const song of bulkTargets) {
      try {
        if (action === "delete") {
          await api(`/api/admin/songs/${encodeURIComponent(song.id)}`, { method: "DELETE" });
        } else {
          await api(`/api/admin/songs/${encodeURIComponent(song.id)}`, {
            method: "PATCH",
            json: { archived: action === "archive", ...(song.usages.length ? { confirmImpact: true } : {}) },
          });
        }
        completed.push(song.id);
      } catch {
        failed.push(song.title);
      }
    }
    let refreshFailed = false;
    if (completed.length) {
      try {
        await refresh();
      } catch {
        refreshFailed = true;
      }
      setSelectedIds((current) => new Set([...current].filter((id) => !completed.includes(id))));
    }
    setPendingBulkAction(null);
    const verb = action === "archive" ? "archived" : action === "restore" ? "restored" : "deleted";
    if (failed.length) {
      const names = failed.slice(0, 3).join(", ");
      toast("error", `${completed.length} songs ${verb}; ${failed.length} failed${names ? `: ${names}` : ""}.${refreshFailed ? " The library also could not refresh." : " Failed songs remain selected so you can retry."}`);
    } else if (refreshFailed) {
      toast("error", `${completed.length} songs ${verb}, but the library could not refresh.`);
    } else {
      toast("success", `${completed.length} songs ${verb}.`);
    }
  }

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-3xl border border-forest-800 gradient-brand px-6 py-8 text-ink shadow-lg sm:px-10">
        <StaffFlourish className="pointer-events-none absolute -right-10 top-4 h-40 w-[34rem] text-amber-accent/25" />
        <div className="relative max-w-2xl">
          <p className="eyebrow text-ink">Song library</p>
          <h1 className="mt-2 font-serif text-3xl leading-tight sm:text-4xl">Every part, ready for every young musician.</h1>
          <p className="mt-3 text-ink">Keep lead sheets, instrument parts and arrangements in one place, then pick them for each season’s events.</p>
          <button type="button" className="btn-accent mt-6" onClick={() => setCreating(true)}>
            <Plus className="h-4 w-4" aria-hidden="true" /> Add a song
          </button>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Active songs" value={stats.active} icon={<MusicIcon className="h-5 w-5" />} hint={`${data.songs.length - stats.active} archived`} />
        <StatCard label="PDF sheets" value={stats.sheets} icon={<FileStack className="h-5 w-5" />} tone="sage" hint="Active parts" />
        <StatCard label="Songs scheduled" value={stats.inUse} icon={<Sparkles className="h-5 w-5" />} tone="amber" hint="Used in events" />
        <StatCard label="Upcoming events" value={stats.upcoming} icon={<CalendarClock className="h-5 w-5" />} hint="Across all seasons" />
      </div>

      {data.songs.length === 0 ? (
        <EmptyState
          art={<SheetStackArt className="h-36 w-48" />}
          title="Your library is waiting for its first song"
          action={
            <button type="button" className="btn-primary" onClick={() => setCreating(true)}>
              <Plus className="h-4 w-4" aria-hidden="true" /> Upload your first song
            </button>
          }
        >
          <ol className="mx-auto mt-2 max-w-md list-decimal space-y-1 pl-5 text-left text-sm text-ink-soft">
            <li>Add a song with one or more PDF parts — label each by instrument and arrangement.</li>
            <li>Create a season and its weekly events.</li>
            <li>Pick songs for each event and set instrument capacities.</li>
          </ol>
        </EmptyState>
      ) : (
        <section aria-labelledby="library-heading" className="space-y-4">
          <PageHeader
            title={<span id="library-heading">Browse the library</span>}
            description={`${plural(filtered.length, "song")} shown`}
            actions={
              <div className="flex rounded-xl border border-parchment-300 bg-parchment-50 p-1" role="group" aria-label="Layout">
                <button type="button" className={`icon-btn ${view === "grid" ? "gradient-brand text-ink" : ""}`} aria-pressed={view === "grid"} aria-label="Grid view" onClick={() => setView("grid")}>
                  <LayoutGrid className="h-4 w-4" />
                </button>
                <button type="button" className={`icon-btn ${view === "list" ? "gradient-brand text-ink" : ""}`} aria-pressed={view === "list"} aria-label="List view" onClick={() => setView("list")}>
                  <List className="h-4 w-4" />
                </button>
              </div>
            }
          />
          <div className="card flex flex-col gap-3 p-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" aria-hidden="true" />
              <label htmlFor="library-search" className="sr-only">
                Search songs
              </label>
              <input id="library-search" type="search" className="input pl-9" placeholder="Search title, composer, sheet label…" value={query} onChange={(e) => { setSelectedIds(new Set()); setQuery(e.target.value); }} />
            </div>
            <label htmlFor="library-instrument" className="sr-only">
              Instrument
            </label>
            <select id="library-instrument" className="input sm:w-44" value={instrument} onChange={(e) => { setSelectedIds(new Set()); setInstrument(e.target.value); }}>
              <option value="">All instruments</option>
              <option value="__any">General / full score</option>
              {INSTRUMENTS.map((i) => (
                <option key={i} value={i}>
                  {i}
                </option>
              ))}
            </select>
            <label htmlFor="library-status" className="sr-only">
              Status
            </label>
            <select id="library-status" className="input sm:w-40" value={status} onChange={(e) => { setSelectedIds(new Set()); setStatus(e.target.value as StatusFilter); }}>
              <option value="active">Active</option>
              <option value="unused">Not yet scheduled</option>
              <option value="archived">Archived</option>
              <option value="all">Everything</option>
            </select>
          </div>

          {filtered.length ? <div className="card flex flex-col gap-3 p-3 sm:flex-row sm:items-center sm:justify-between">
            <label className="flex min-h-10 items-center gap-2 text-sm font-medium text-ink">
              <input type="checkbox" className="h-4 w-4 accent-forest-800" checked={allVisibleSelected} onChange={(event) => toggleVisibleSelection(event.target.checked)} />
              Select all {filtered.length} visible songs
            </label>
            {selected.length ? <div className="flex flex-wrap items-center gap-2">
              <span className="mr-1 text-sm text-ink-muted">{selected.length} selected</span>
              {selectedActive.length ? <button type="button" className="btn-secondary min-h-10" onClick={() => setPendingBulkAction("archive")}><Archive className="h-4 w-4" aria-hidden="true" />Archive {selectedActive.length}</button> : null}
              {selectedArchived.length ? <button type="button" className="btn-secondary min-h-10" onClick={() => setPendingBulkAction("restore")}><ArchiveRestore className="h-4 w-4" aria-hidden="true" />Restore {selectedArchived.length}</button> : null}
              <button type="button" className="btn-danger-ghost min-h-10" onClick={() => setPendingBulkAction("delete")} disabled={!deletable.length} title={!deletable.length ? "Selected songs used in events must be archived instead." : undefined}><Trash2 className="h-4 w-4" aria-hidden="true" />Delete unused {deletable.length}</button>
              {selected.length > deletable.length ? <p className="basis-full text-xs text-ink-muted">Songs used in events can’t be deleted. Archive them instead.</p> : null}
            </div> : null}
          </div> : null}

          {filtered.length === 0 ? (
            <EmptyState
              art={<Library className="h-12 w-12 text-forest-300" />}
              title="No songs match"
              action={
                filtersActive ? (
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={() => {
                      setQuery("");
                      setInstrument("");
                      setStatus("active");
                      setSelectedIds(new Set());
                    }}
                  >
                    <X className="h-4 w-4" aria-hidden="true" /> Clear filters
                  </button>
                ) : undefined
              }
            >
              Try a different search or filter.
            </EmptyState>
          ) : view === "grid" ? (
            <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {filtered.map((song) => (
                <li key={song.id}>
                  <SongCard song={song} selected={selectedIds.has(song.id)} onSelect={(checked) => toggleSongSelection(song.id, checked)} onOpen={() => setOpenId(song.id)} />
                </li>
              ))}
            </ul>
          ) : (
            <div className="card overflow-x-auto">
              <table className="w-full min-w-[40rem] text-left text-sm">
                <thead className="border-b border-parchment-300 text-xs uppercase tracking-wide text-ink-muted">
                  <tr>
                    <th scope="col" className="px-4 py-3 font-medium"><span className="sr-only">Select</span></th>
                    <th scope="col" className="px-4 py-3 font-medium">Song</th>
                    <th scope="col" className="px-4 py-3 font-medium">Instruments</th>
                    <th scope="col" className="px-4 py-3 font-medium">Sheets</th>
                    <th scope="col" className="px-4 py-3 font-medium">Events</th>
                    <th scope="col" className="px-4 py-3 font-medium">Updated</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((song) => (
                    <tr key={song.id} className="border-b border-parchment-200 last:border-0 hover:bg-parchment-100">
                      <td className="px-4 py-3"><input type="checkbox" className="h-4 w-4 accent-forest-800" checked={selectedIds.has(song.id)} onChange={(event) => toggleSongSelection(song.id, event.target.checked)} aria-label={`Select ${song.title}`} /></td>
                      <td className="px-4 py-3">
                        <button type="button" className="text-left font-medium text-forest-900 underline-offset-2 hover:underline" onClick={() => setOpenId(song.id)}>
                          {song.title}
                        </button>
                        <div className="text-xs text-ink-muted">{song.composer || "—"}{song.archived ? " · Archived" : ""}</div>
                      </td>
                      <td className="px-4 py-3 text-ink-soft">{instrumentsOf(song).join(", ") || "General"}</td>
                      <td className="px-4 py-3">{song.sheets.filter((s) => !s.archived).length}</td>
                      <td className="px-4 py-3">{uniqueUsageEvents(song.usages).length}</td>
                      <td className="px-4 py-3 text-ink-muted">{formatRelative(song.updatedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      <CreateSongDialog open={creating} onClose={() => setCreating(false)} onCreated={(id) => id && setOpenId(id)} />
      <SongDrawer songId={openId} onClose={() => setOpenId(null)} />
      <ConfirmDialog
        open={pendingBulkAction !== null}
        onClose={() => setPendingBulkAction(null)}
        title={`${pendingBulkAction === "archive" ? "Archive" : pendingBulkAction === "restore" ? "Restore" : "Delete"} ${bulkTargets.length} songs?`}
        confirmLabel={`${pendingBulkAction === "archive" ? "Archive" : pendingBulkAction === "restore" ? "Restore" : "Delete"} ${bulkTargets.length} songs`}
        busyLabel="Applying…"
        tone={pendingBulkAction === "restore" ? "primary" : "danger"}
        usages={pendingBulkAction === "archive" || pendingBulkAction === "restore" ? bulkTargets.flatMap((song) => song.usages) : undefined}
        onConfirm={confirmBulkAction}
      >
        {pendingBulkAction === "archive" ? "Archived songs are hidden from the event picker. Existing event selections remain intact." : null}
        {pendingBulkAction === "restore" ? "Restored songs return to the event picker." : null}
        {pendingBulkAction === "delete" ? <>This permanently deletes the {plural(bulkTargets.length, "unused song")} and all associated sheets and versions. This can’t be undone.{selected.length > deletable.length ? ` ${selected.length - deletable.length} selected songs in use will be skipped.` : ""}</> : null}
      </ConfirmDialog>
    </div>
  );
}

function instrumentsOf(song: Song): string[] {
  return Array.from(new Set(song.sheets.filter((s) => !s.archived && s.instrument).map((s) => s.instrument as string)));
}

function SongCard({ song, selected, onSelect, onOpen }: { song: Song; selected: boolean; onSelect: (checked: boolean) => void; onOpen: () => void }) {
  const insts = instrumentsOf(song);
  const sheets = song.sheets.filter((s) => !s.archived).length;
  const events = uniqueUsageEvents(song.usages).length;
  return (
    <article className={`card group flex h-full w-full flex-col p-5 transition-shadow hover:shadow-md ${song.archived ? "opacity-70" : ""}`}>
      <div className="flex items-start justify-between gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-xl gradient-brand text-ink shadow-sm" aria-hidden="true">
          <MusicIcon className="h-5 w-5" />
        </span>
        <div className="flex items-center gap-2">
          <label className="flex min-h-10 items-center gap-1.5 text-xs text-ink-muted"><input type="checkbox" className="h-4 w-4 accent-forest-800" checked={selected} onChange={(event) => onSelect(event.target.checked)} aria-label={`Select ${song.title}`} /><span className="sr-only">Select song</span></label>
          {song.archived ? <Tag tone="muted">Archived</Tag> : events ? <Tag tone="amber">{plural(events, "event")}</Tag> : <Tag tone="neutral">Unscheduled</Tag>}
        </div>
      </div>
      <h3 className="mt-4"><button type="button" onClick={onOpen} className="text-left font-serif text-xl leading-snug text-forest-900 underline-offset-2 group-hover:text-forest-700 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2">{song.title}</button></h3>
      <p className="text-sm text-ink-muted">{song.composer || "Composer not set"}</p>
      <div className="staff-lines mt-4 flex flex-1 flex-wrap content-start gap-1.5 py-1">
        {insts.length ? insts.slice(0, 4).map((i) => <Tag key={i} tone="forest">{i}</Tag>) : <Tag tone="sage">General score</Tag>}
        {insts.length > 4 ? <Tag tone="neutral">+{insts.length - 4}</Tag> : null}
      </div>
      <p className="mt-4 flex items-center justify-between border-t border-parchment-200 pt-3 text-xs text-ink-muted">
        <span>{plural(sheets, "sheet")}</span>
        <span>Updated {formatRelative(song.updatedAt)}</span>
      </p>
    </article>
  );
}