"use client";

import { useMemo, useState } from "react";
import { CalendarClock, FileStack, LayoutGrid, List, Library, Music2, Plus, Search, Sparkles, X } from "lucide-react";
import { INSTRUMENTS, type Song } from "@/lib/contracts";
import { formatRelative, plural, uniqueUsageEvents } from "@/lib/client";
import { useAdminData } from "@/components/shell/AdminProvider";
import { EmptyState, PageHeader, StatCard, Tag } from "@/components/ui/Bits";
import { SheetStackArt, StaffFlourish } from "@/components/ui/Motifs";
import { CreateSongDialog } from "./SongDialogs";
import { SongDrawer } from "./SongDrawer";

type View = "grid" | "list";
type StatusFilter = "active" | "archived" | "all" | "unused";

export function LibraryView() {
  const data = useAdminData();
  const [query, setQuery] = useState("");
  const [instrument, setInstrument] = useState("");
  const [status, setStatus] = useState<StatusFilter>("active");
  const [view, setView] = useState<View>("grid");
  const [creating, setCreating] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);

  const stats = useMemo(() => {
    const active = data.songs.filter((s) => !s.archived);
    const sheets = active.reduce((n, s) => n + s.sheets.filter((x) => !x.archived).length, 0);
    const inUse = active.filter((s) => s.usages.length > 0).length;
    const now = Date.now();
    const upcoming = data.seasons.flatMap((s) => s.events).filter((e) => new Date(e.startsAt).getTime() >= now).length;
    return { active: active.length, sheets, inUse, upcoming };
  }, [data]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return data.songs
      .filter((s) => {
        if (status === "active" && s.archived) return false;
        if (status === "archived" && !s.archived) return false;
        if (status === "unused" && (s.archived || s.usages.length > 0)) return false;
        if (instrument && !s.sheets.some((x) => !x.archived && (instrument === "__any" ? x.instrument === null : x.instrument === instrument))) return false;
        if (!q) return true;
        return [s.title, s.composer, s.notes, ...(s.links ?? []), ...s.sheets.map((x) => `${x.label} ${x.arrangement} ${x.instrument ?? ""}`)].join(" ").toLowerCase().includes(q);
      })
      .sort((a, b) => a.title.localeCompare(b.title));
  }, [data.songs, query, instrument, status]);

  const filtersActive = query !== "" || instrument !== "" || status !== "active";

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-3xl border border-forest-800 bg-forest-900 px-6 py-8 text-parchment-50 shadow-lg sm:px-10">
        <StaffFlourish className="pointer-events-none absolute -right-10 top-4 h-40 w-[34rem] text-amber-accent/25" />
        <div className="relative max-w-2xl">
          <p className="eyebrow text-amber-soft">Song library</p>
          <h1 className="mt-2 font-serif text-3xl leading-tight sm:text-4xl">Every part, ready for every young musician.</h1>
          <p className="mt-3 text-parchment-200/90">Keep lead sheets, instrument parts and arrangements in one place, then pick them for each season’s events.</p>
          <button type="button" className="btn-accent mt-6" onClick={() => setCreating(true)}>
            <Plus className="h-4 w-4" aria-hidden="true" /> Add a song
          </button>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Active songs" value={stats.active} icon={<Music2 className="h-5 w-5" />} hint={`${data.songs.length - stats.active} archived`} />
        <StatCard label="PDF sheets" value={stats.sheets} icon={<FileStack className="h-5 w-5" />} tone="sage" hint="Active parts" />
        <StatCard label="Songs scheduled" value={stats.inUse} icon={<Sparkles className="h-5 w-5" />} tone="amber" hint="Used in events" />
        <StatCard label="Upcoming events" value={stats.upcoming} icon={<CalendarClock className="h-5 w-5" />} hint="Across all seasons" />
      </div>

      {data.songs.length === 0 ? (
        <EmptyState
          art={<SheetStackArt className="h-36 w-48" />}
          title="Your library is waiting for its first song"
          action={
            <button type="button" className="btn-primary" onClick={() => setCreating(true)}>
              <Plus className="h-4 w-4" aria-hidden="true" /> Upload your first song
            </button>
          }
        >
          <ol className="mx-auto mt-2 max-w-md list-decimal space-y-1 pl-5 text-left text-sm text-ink-soft">
            <li>Add a song with one or more PDF parts — label each by instrument and arrangement.</li>
            <li>Create a season and its weekly events.</li>
            <li>Pick songs for each event and set instrument capacities.</li>
          </ol>
        </EmptyState>
      ) : (
        <section aria-labelledby="library-heading" className="space-y-4">
          <PageHeader
            title={<span id="library-heading">Browse the library</span>}
            description={`${plural(filtered.length, "song")} shown`}
            actions={
              <div className="flex rounded-xl border border-parchment-300 bg-parchment-50 p-1" role="group" aria-label="Layout">
                <button type="button" className={`icon-btn ${view === "grid" ? "bg-forest-800 text-parchment-50" : ""}`} aria-pressed={view === "grid"} aria-label="Grid view" onClick={() => setView("grid")}>
                  <LayoutGrid className="h-4 w-4" />
                </button>
                <button type="button" className={`icon-btn ${view === "list" ? "bg-forest-800 text-parchment-50" : ""}`} aria-pressed={view === "list"} aria-label="List view" onClick={() => setView("list")}>
                  <List className="h-4 w-4" />
                </button>
              </div>
            }
          />
          <div className="card flex flex-col gap-3 p-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" aria-hidden="true" />
              <label htmlFor="library-search" className="sr-only">
                Search songs
              </label>
              <input id="library-search" type="search" className="input pl-9" placeholder="Search title, composer, sheet label…" value={query} onChange={(e) => setQuery(e.target.value)} />
            </div>
            <label htmlFor="library-instrument" className="sr-only">
              Instrument
            </label>
            <select id="library-instrument" className="input sm:w-44" value={instrument} onChange={(e) => setInstrument(e.target.value)}>
              <option value="">All instruments</option>
              <option value="__any">General / full score</option>
              {INSTRUMENTS.map((i) => (
                <option key={i} value={i}>
                  {i}
                </option>
              ))}
            </select>
            <label htmlFor="library-status" className="sr-only">
              Status
            </label>
            <select id="library-status" className="input sm:w-40" value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)}>
              <option value="active">Active</option>
              <option value="unused">Not yet scheduled</option>
              <option value="archived">Archived</option>
              <option value="all">Everything</option>
            </select>
          </div>

          {filtered.length === 0 ? (
            <EmptyState
              art={<Library className="h-12 w-12 text-forest-300" />}
              title="No songs match"
              action={
                filtersActive ? (
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={() => {
                      setQuery("");
                      setInstrument("");
                      setStatus("active");
                    }}
                  >
                    <X className="h-4 w-4" aria-hidden="true" /> Clear filters
                  </button>
                ) : undefined
              }
            >
              Try a different search or filter.
            </EmptyState>
          ) : view === "grid" ? (
            <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {filtered.map((song) => (
                <li key={song.id}>
                  <SongCard song={song} onOpen={() => setOpenId(song.id)} />
                </li>
              ))}
            </ul>
          ) : (
            <div className="card overflow-x-auto">
              <table className="w-full min-w-[40rem] text-left text-sm">
                <thead className="border-b border-parchment-300 text-xs uppercase tracking-wide text-ink-muted">
                  <tr>
                    <th scope="col" className="px-4 py-3 font-medium">Song</th>
                    <th scope="col" className="px-4 py-3 font-medium">Instruments</th>
                    <th scope="col" className="px-4 py-3 font-medium">Sheets</th>
                    <th scope="col" className="px-4 py-3 font-medium">Events</th>
                    <th scope="col" className="px-4 py-3 font-medium">Updated</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((song) => (
                    <tr key={song.id} className="border-b border-parchment-200 last:border-0 hover:bg-parchment-100">
                      <td className="px-4 py-3">
                        <button type="button" className="text-left font-medium text-forest-900 underline-offset-2 hover:underline" onClick={() => setOpenId(song.id)}>
                          {song.title}
                        </button>
                        <div className="text-xs text-ink-muted">{song.composer || "—"}{song.archived ? " · Archived" : ""}</div>
                      </td>
                      <td className="px-4 py-3 text-ink-soft">{instrumentsOf(song).join(", ") || "General"}</td>
                      <td className="px-4 py-3">{song.sheets.filter((s) => !s.archived).length}</td>
                      <td className="px-4 py-3">{uniqueUsageEvents(song.usages).length}</td>
                      <td className="px-4 py-3 text-ink-muted">{formatRelative(song.updatedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      <CreateSongDialog open={creating} onClose={() => setCreating(false)} onCreated={(id) => id && setOpenId(id)} />
      <SongDrawer songId={openId} onClose={() => setOpenId(null)} />
    </div>
  );
}

function instrumentsOf(song: Song): string[] {
  return Array.from(new Set(song.sheets.filter((s) => !s.archived && s.instrument).map((s) => s.instrument as string)));
}

function SongCard({ song, onOpen }: { song: Song; onOpen: () => void }) {
  const insts = instrumentsOf(song);
  const sheets = song.sheets.filter((s) => !s.archived).length;
  const events = uniqueUsageEvents(song.usages).length;
  return (
    <button type="button" onClick={onOpen} className={`card-interactive group flex h-full w-full flex-col p-5 text-left ${song.archived ? "opacity-70" : ""}`}>
      <div className="flex items-start justify-between gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-xl bg-forest-800 text-amber-soft shadow-sm" aria-hidden="true">
          <Music2 className="h-5 w-5" />
        </span>
        {song.archived ? <Tag tone="muted">Archived</Tag> : events ? <Tag tone="amber">{plural(events, "event")}</Tag> : <Tag tone="neutral">Unscheduled</Tag>}
      </div>
      <h3 className="mt-4 font-serif text-xl leading-snug text-forest-900 group-hover:text-forest-700">{song.title}</h3>
      <p className="text-sm text-ink-muted">{song.composer || "Composer not set"}</p>
      <div className="staff-lines mt-4 flex flex-1 flex-wrap content-start gap-1.5 py-1">
        {insts.length ? insts.slice(0, 4).map((i) => <Tag key={i} tone="forest">{i}</Tag>) : <Tag tone="sage">General score</Tag>}
        {insts.length > 4 ? <Tag tone="neutral">+{insts.length - 4}</Tag> : null}
      </div>
      <p className="mt-4 flex items-center justify-between border-t border-parchment-200 pt-3 text-xs text-ink-muted">
        <span>{plural(sheets, "sheet")}</span>
        <span>Updated {formatRelative(song.updatedAt)}</span>
      </p>
    </button>
  );
}