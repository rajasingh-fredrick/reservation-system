"use client";

import { useState } from "react";
import { Archive, ArchiveRestore, Download, FilePlus2, FileText, History, Link2, Pencil, Trash2 } from "lucide-react";
import type { Sheet, Song } from "@/lib/contracts";
import { api, browserTimeZone, errorMessage, formatBytes, formatDateTime, formatRelative, plural, sheetDownloadUrl, uniqueUsageEvents } from "@/lib/client";
import { Modal } from "@/components/ui/Modal";
import { useToast } from "@/components/ui/Feedback";
import { Tag } from "@/components/ui/Bits";
import { ConfirmDialog, ImpactList } from "@/components/ui/Confirm";
import { useAdmin } from "@/components/shell/AdminProvider";
import { AddSheetsDialog, EditSheetDialog, EditSongDialog } from "./SongDialogs";

type Pending =
  | { kind: "archive-song" }
  | { kind: "delete-song" }
  | { kind: "archive-sheet"; sheet: Sheet }
  | { kind: "delete-sheet"; sheet: Sheet }
  | null;

export function SongDrawer({ songId, onClose }: { songId: string | null; onClose: () => void }) {
  const { data } = useAdmin();
  const song = songId ? data?.songs.find((s) => s.id === songId) ?? null : null;
  return (
    <Modal open={Boolean(song)} onClose={onClose} variant="drawer" size="lg" eyebrow={song?.composer || "Song"} title={song?.title ?? "Song"}>
      {song ? <SongDetail song={song} onDeleted={onClose} /> : null}
    </Modal>
  );
}

function SongDetail({ song, onDeleted }: { song: Song; onDeleted: () => void }) {
  const { refresh } = useAdmin();
  const toast = useToast();
  const [editing, setEditing] = useState(false);
  const [adding, setAdding] = useState(false);
  const [editingSheet, setEditingSheet] = useState<Sheet | null>(null);
  const [pending, setPending] = useState<Pending>(null);
  const [showArchived, setShowArchived] = useState(false);
  const usageEvents = uniqueUsageEvents(song.usages);
  const activeSheets = song.sheets.filter((s) => !s.archived);
  const archivedSheets = song.sheets.filter((s) => s.archived);
  const visibleSheets = showArchived ? song.sheets : activeSheets;

  async function reload(message: string) {
    toast("success", message);
    try {
      await refresh();
    } catch (err) {
      toast("error", `Saved, but the library could not reload: ${errorMessage(err)}`);
    }
  }

  async function confirmPending() {
    if (!pending) return;
    if (pending.kind === "archive-song") {
      const next = !song.archived;
      await api(`/api/admin/songs/${encodeURIComponent(song.id)}`, { method: "PATCH", json: { archived: next, ...(usageEvents.length ? { confirmImpact: true } : {}) } });
      setPending(null);
      await reload(next ? `“${song.title}” archived.` : `“${song.title}” restored to the library.`);
    } else if (pending.kind === "delete-song") {
      await api(`/api/admin/songs/${encodeURIComponent(song.id)}`, { method: "DELETE" });
      setPending(null);
      onDeleted();
      await reload(`“${song.title}” deleted.`);
    } else if (pending.kind === "archive-sheet") {
      const s = pending.sheet;
      const form = new FormData();
      form.append("archived", s.archived ? "false" : "true");
      if (s.usages.length) form.append("confirmImpact", "true");
      await api(`/api/admin/sheets/${encodeURIComponent(s.id)}`, { method: "PATCH", form });
      setPending(null);
      await reload(s.archived ? `“${s.label}” restored.` : `“${s.label}” archived.`);
    } else if (pending.kind === "delete-sheet") {
      const s = pending.sheet;
      await api(`/api/admin/sheets/${encodeURIComponent(s.id)}`, { method: "DELETE" });
      setPending(null);
      await reload(`“${s.label}” deleted.`);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2">
        {song.archived ? <Tag tone="muted" icon={<Archive className="h-3.5 w-3.5" />}>Archived</Tag> : <Tag tone="forest">Active</Tag>}
        <Tag tone="sage">{plural(activeSheets.length, "sheet")}</Tag>
        {usageEvents.length ? <Tag tone="amber">Used in {plural(usageEvents.length, "event")}</Tag> : <Tag tone="neutral">Not scheduled</Tag>}
        <span className="text-xs text-ink-muted">Updated {formatRelative(song.updatedAt)}</span>
      </div>

      {song.notes ? <p className="whitespace-pre-line rounded-xl border border-parchment-300 bg-parchment-50 p-4 text-sm text-ink-soft">{song.notes}</p> : null}

      {song.links?.length ? (
        <section aria-label="Song links" className="min-w-0 space-y-2">
          <h3 className="font-serif text-lg text-forest-900">Song links</h3>
          <ul className="space-y-2">
            {song.links.map((link, index) => (
              <li key={`${index}-${link}`}>
                <a className="inline-flex max-w-full items-start gap-2 text-sm text-forest-700 underline underline-offset-2" href={link} target="_blank" rel="noopener noreferrer">
                  <Link2 className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                  <span className="min-w-0 break-all">{link}</span>
                </a>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn-secondary btn-sm" onClick={() => setEditing(true)}>
          <Pencil className="h-4 w-4" aria-hidden="true" /> Edit details
        </button>
        <button type="button" className="btn-primary btn-sm" onClick={() => setAdding(true)} disabled={song.archived}>
          <FilePlus2 className="h-4 w-4" aria-hidden="true" /> Add sheets
        </button>
        <button type="button" className="btn-ghost btn-sm" onClick={() => setPending({ kind: "archive-song" })}>
          {song.archived ? <ArchiveRestore className="h-4 w-4" aria-hidden="true" /> : <Archive className="h-4 w-4" aria-hidden="true" />}
          {song.archived ? "Restore" : "Archive"}
        </button>
        <button
          type="button"
          className="btn-danger-ghost btn-sm"
          onClick={() => setPending({ kind: "delete-song" })}
          disabled={usageEvents.length > 0}
          title={usageEvents.length ? "This song is scheduled in events. Archive it instead, or remove it from those events first." : undefined}
        >
          <Trash2 className="h-4 w-4" aria-hidden="true" /> Delete
        </button>
      </div>
      {usageEvents.length > 0 ? <p className="text-xs text-ink-muted">Songs used in events can’t be deleted — archive them to hide from the picker while keeping history intact.</p> : null}

      <section aria-labelledby="sheets-heading" className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <h3 id="sheets-heading" className="font-serif text-lg text-forest-900">
            Sheets
          </h3>
          {archivedSheets.length ? (
            <label className="flex items-center gap-2 text-sm text-ink-soft">
              <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} className="accent-forest-700" />
              Show {archivedSheets.length} archived
            </label>
          ) : null}
        </div>
        {visibleSheets.length === 0 ? (
          <p className="rounded-xl border border-dashed border-parchment-300 p-4 text-sm text-ink-muted">No active sheets. Add a PDF so leaders can select it for events.</p>
        ) : (
          <ul className="space-y-3">
            {visibleSheets.map((sheet) => (
              <SheetRow key={sheet.id} sheet={sheet} onEdit={() => setEditingSheet(sheet)} onArchive={() => setPending({ kind: "archive-sheet", sheet })} onDelete={() => setPending({ kind: "delete-sheet", sheet })} />
            ))}
          </ul>
        )}
      </section>

      <section aria-labelledby="usage-heading" className="space-y-3">
        <h3 id="usage-heading" className="font-serif text-lg text-forest-900">
          Where it’s used
        </h3>
        {song.usages.length ? <ImpactList usages={song.usages} title="Scheduled events" /> : <p className="text-sm text-ink-muted">Not yet added to any event. Add it from a season’s event setup.</p>}
      </section>

      <EditSongDialog song={song} open={editing} onClose={() => setEditing(false)} />
      <AddSheetsDialog song={song} open={adding} onClose={() => setAdding(false)} />
      {editingSheet ? <EditSheetDialog sheet={song.sheets.find((s) => s.id === editingSheet.id) ?? editingSheet} open onClose={() => setEditingSheet(null)} /> : null}

      <ConfirmDialog
        open={pending?.kind === "archive-song"}
        onClose={() => setPending(null)}
        title={song.archived ? `Restore “${song.title}”?` : `Archive “${song.title}”?`}
        confirmLabel={song.archived ? "Restore song" : "Archive song"}
        busyLabel="Saving…"
        tone="primary"
        usages={song.usages}
        onConfirm={confirmPending}
      >
        {song.archived ? "The song returns to the library and the event song picker." : "Archived songs are hidden from the event picker. Events already using it keep their selections."}
      </ConfirmDialog>
      <ConfirmDialog open={pending?.kind === "delete-song"} onClose={() => setPending(null)} title={`Delete “${song.title}”?`} confirmLabel="Delete permanently" busyLabel="Deleting…" onConfirm={confirmPending}>
        This removes the song and all {plural(song.sheets.length, "sheet")} including previous versions. This can’t be undone.
      </ConfirmDialog>
      <ConfirmDialog
        open={pending?.kind === "archive-sheet"}
        onClose={() => setPending(null)}
        title={pending?.kind === "archive-sheet" ? `${pending.sheet.archived ? "Restore" : "Archive"} “${pending.sheet.label}”?` : ""}
        confirmLabel={pending?.kind === "archive-sheet" && pending.sheet.archived ? "Restore sheet" : "Archive sheet"}
        busyLabel="Saving…"
        tone="primary"
        usages={pending?.kind === "archive-sheet" ? pending.sheet.usages : undefined}
        onConfirm={confirmPending}
      >
        Archived sheets can’t be newly selected for events. Existing selections keep working.
      </ConfirmDialog>
      <ConfirmDialog
        open={pending?.kind === "delete-sheet"}
        onClose={() => setPending(null)}
        title={pending?.kind === "delete-sheet" ? `Delete “${pending.sheet.label}”?` : ""}
        confirmLabel="Delete sheet"
        busyLabel="Deleting…"
        onConfirm={confirmPending}
      >
        All versions of this PDF will be removed. This can’t be undone.
      </ConfirmDialog>
    </div>
  );
}

function SheetRow({ sheet, onEdit, onArchive, onDelete }: { sheet: Sheet; onEdit: () => void; onArchive: () => void; onDelete: () => void }) {
  const [versionsOpen, setVersionsOpen] = useState(false);
  const [previewVersion, setPreviewVersion] = useState<number | null>(null);
  const usages = uniqueUsageEvents(sheet.usages);
  const inUse = usages.length;
  return (
    <li className={`card p-4 ${sheet.archived ? "opacity-75" : ""}`}>
      <div className="flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-forest-50 text-forest-700" aria-hidden="true">
          <FileText className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-medium text-ink">{sheet.label}</p>
          <div className="mt-1 flex flex-wrap gap-1.5">
            <Tag tone="forest">{sheet.instrument ?? "Any instrument"}</Tag>
            {sheet.arrangement ? <Tag tone="sage">{sheet.arrangement}</Tag> : null}
            <Tag tone="neutral">v{sheet.version}</Tag>
            {sheet.archived ? <Tag tone="muted">Archived</Tag> : null}
            {inUse ? <Tag tone="amber">{plural(inUse, "event")}</Tag> : null}
          </div>
          <p className="mt-1 truncate text-xs text-ink-muted">
            {sheet.fileName} · {formatBytes(sheet.size)}
          </p>
        </div>
      </div>
      {inUse > 0 ? (
        <details className="mt-3 text-sm text-ink-soft">
          <summary className="cursor-pointer font-medium text-forest-700">Used in {plural(inUse, "event")}</summary>
          <ul className="mt-2 space-y-2" aria-label={`${sheet.label} usage`}>
            {usages.map((usage) => (
              <li key={usage.eventId} className="break-words border-l-2 border-forest-100 pl-3">
                <span className="block font-medium">{usage.eventName}</span>
                <span className="block text-xs text-ink-muted">{usage.seasonName} · {formatDateTime(usage.startsAt, browserTimeZone(), { dateStyle: "medium" })}</span>
              </li>
            ))}
          </ul>
        </details>
      ) : null}
      <div className="mt-3 flex flex-wrap gap-1.5">
        <button type="button" className="btn-secondary btn-sm" aria-expanded={previewVersion !== null} onClick={() => setPreviewVersion((version) => version === null ? sheet.version : null)}>
          <FileText className="h-4 w-4" aria-hidden="true" /> {previewVersion !== null ? "Hide preview" : "Preview"}
        </button>
        <a className="btn-secondary btn-sm" href={sheetDownloadUrl(sheet.id)} download aria-label={`Download ${sheet.label} (current version)`}>
          <Download className="h-4 w-4" aria-hidden="true" /> Download
        </a>
        {sheet.version > 1 ? (
          <button type="button" className="btn-ghost btn-sm" aria-expanded={versionsOpen} onClick={() => setVersionsOpen((v) => !v)}>
            <History className="h-4 w-4" aria-hidden="true" /> Versions
          </button>
        ) : null}
        <button type="button" className="btn-ghost btn-sm" onClick={onEdit} aria-label={`Edit or replace ${sheet.label}`}>
          <Pencil className="h-4 w-4" aria-hidden="true" /> Edit / replace
        </button>
        <button type="button" className="btn-ghost btn-sm" onClick={onArchive}>
          {sheet.archived ? <ArchiveRestore className="h-4 w-4" aria-hidden="true" /> : <Archive className="h-4 w-4" aria-hidden="true" />}
          {sheet.archived ? "Restore" : "Archive"}
        </button>
        <button type="button" className="btn-danger-ghost btn-sm" onClick={onDelete} disabled={inUse > 0} title={inUse ? "Selected in events — archive instead." : undefined} aria-label={`Delete ${sheet.label}`}>
          <Trash2 className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
      {previewVersion !== null ? (
        <iframe
          className="mt-3 h-[min(70vh,42rem)] w-full rounded-lg border border-parchment-300 bg-white"
          src={sheetDownloadUrl(sheet.id, previewVersion, true)}
          title={`Preview ${sheet.label}, version ${previewVersion}`}
        />
      ) : null}
      {versionsOpen ? (
        <ul className="mt-3 space-y-1 border-t border-parchment-200 pt-3 text-sm">
          {Array.from({ length: sheet.version }, (_, i) => sheet.version - i).map((v) => (
            <li key={v} className="flex items-center justify-between">
              <span className="text-ink-soft">Version {v}{v === sheet.version ? " (current)" : ""}</span>
              <span className="flex gap-3">
                <button type="button" className="text-forest-700 underline-offset-2 hover:underline" aria-pressed={previewVersion === v} onClick={() => setPreviewVersion((version) => version === v ? null : v)}>
                  Preview
                </button>
                <a className="text-forest-700 underline-offset-2 hover:underline" href={sheetDownloadUrl(sheet.id, v)} download>
                  Download
                </a>
              </span>
            </li>
          ))}
        </ul>
      ) : null}
    </li>
  );
}