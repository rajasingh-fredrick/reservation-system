"use client";

import { useEffect, useId, useState, type FormEvent } from "react";
import { FilePlus2, Pencil, Plus, Replace, Trash2 } from "lucide-react";
import { MusicIcon } from "@/components/ui/Motifs";
import { INSTRUMENTS, type Instrument, type Sheet, type Song } from "@/lib/contracts";
import { api, errorMessage, plural, uniqueUsageEvents } from "@/lib/client";
import { Modal } from "@/components/ui/Modal";
import { BusyButton, InlineError, Notice, useToast } from "@/components/ui/Feedback";
import { Field } from "@/components/ui/Bits";
import { ImpactList } from "@/components/ui/Confirm";
import { useAdmin } from "@/components/shell/AdminProvider";
import { ImpactCheck, PermissionCheck, SheetUploadRows, appendSheetFields, validateRows, type PendingSheet } from "./SheetUploadRows";

function extractId(value: unknown): string | null {
  if (value && typeof value === "object") {
    const v = value as { id?: unknown; song?: { id?: unknown } };
    if (typeof v.id === "string") return v.id;
    if (v.song && typeof v.song.id === "string") return v.song.id;
  }
  return null;
}

function SongLinkFields({ links, onChange, disabled }: { links: string[]; onChange: (links: string[]) => void; disabled: boolean }) {
  const id = useId();
  return (
    <fieldset className="space-y-2" disabled={disabled}>
      <legend className="field-label">Song links</legend>
      {links.map((link, index) => (
        <div key={index} className="flex min-w-0 items-center gap-2">
          <label htmlFor={`${id}-${index}`} className="sr-only">Link {index + 1}</label>
          <input id={`${id}-${index}`} type="url" className="input min-w-0 flex-1" value={link} placeholder="https://" onChange={(event) => onChange(links.map((value, position) => position === index ? event.target.value : value))} />
          <button type="button" className="btn-ghost shrink-0" aria-label={`Remove link ${index + 1}`} title={`Remove link ${index + 1}`} onClick={() => onChange(links.filter((_, position) => position !== index))}><Trash2 className="size-4" aria-hidden /></button>
        </div>
      ))}
      <button type="button" className="btn-ghost btn-sm" disabled={links.length >= 30} onClick={() => onChange([...links, ""])}><Plus className="size-4" aria-hidden /> Add link</button>
    </fieldset>
  );
}

export function CreateSongDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated?: (songId: string | null) => void }) {
  const formId = useId();
  const { refresh } = useAdmin();
  const toast = useToast();
  const [title, setTitle] = useState("");
  const [composer, setComposer] = useState("");
  const [notes, setNotes] = useState("");
  const [links, setLinks] = useState<string[]>([]);
  const [rows, setRows] = useState<PendingSheet[]>([]);
  const [permission, setPermission] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setTitle("");
      setComposer("");
      setNotes("");
      setLinks([]);
      setRows([]);
      setPermission(false);
      setError(null);
    }
  }, [open]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return setError("Give the song a title.");
    const rowError = validateRows(rows);
    if (rowError) return setError(rowError);
    if (!permission) return setError("Please confirm you have permission to share these sheets.");
    setBusy(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("title", title.trim());
      form.append("composer", composer.trim());
      form.append("notes", notes.trim());
      form.append("links", JSON.stringify(links.map((link) => link.trim()).filter(Boolean)));
      appendSheetFields(form, rows);
      const created = await api<unknown>("/api/admin/songs", { method: "POST", form });
      toast("success", `“${title.trim()}” added with ${plural(rows.length, "sheet")}.`);
      onCreated?.(extractId(created));
      onClose();
      try {
        await refresh();
      } catch (err) {
        toast("error", `Song saved, but the library could not reload: ${errorMessage(err)}`);
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size="xl"
      eyebrow="Song library"
      title="Add a song"
      description="Upload every part at once — lead sheets, instrument parts and simplified arrangements."
      footer={
        <>
          <button type="button" className="btn-secondary" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form={formId} className="btn-primary" busy={busy} busyLabel="Uploading…">
            <MusicIcon className="h-4 w-4" aria-hidden="true" /> Save song
          </BusyButton>
        </>
      }
    >
      <form id={formId} onSubmit={submit} className="space-y-5" noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Title" htmlFor={`${formId}-title`} required>
            <input id={`${formId}-title`} className="input" value={title} onChange={(e) => setTitle(e.target.value)} disabled={busy} required data-autofocus autoComplete="off" />
          </Field>
          <Field label="Composer / source" htmlFor={`${formId}-composer`} hint="Optional">
            <input id={`${formId}-composer`} className="input" value={composer} onChange={(e) => setComposer(e.target.value)} disabled={busy} autoComplete="off" />
          </Field>
        </div>
        <Field label="Notes for leaders" htmlFor={`${formId}-notes`} hint="Key, tempo, licence reference…">
          <textarea id={`${formId}-notes`} className="input min-h-20" value={notes} onChange={(e) => setNotes(e.target.value)} disabled={busy} />
        </Field>
        <fieldset className="space-y-3">
          <legend className="field-label">PDF sheets</legend>
          <SheetUploadRows rows={rows} onChange={setRows} disabled={busy} />
        </fieldset>
        <SongLinkFields links={links} onChange={setLinks} disabled={busy} />
        <PermissionCheck checked={permission} onChange={setPermission} disabled={busy} />
        <InlineError message={error} />
      </form>
    </Modal>
  );
}

export function AddSheetsDialog({ song, open, onClose }: { song: Song; open: boolean; onClose: () => void }) {
  const formId = useId();
  const { refresh } = useAdmin();
  const toast = useToast();
  const [rows, setRows] = useState<PendingSheet[]>([]);
  const [permission, setPermission] = useState(false);
  const [impact, setImpact] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const usageEvents = uniqueUsageEvents(song.usages);

  useEffect(() => {
    if (open) {
      setRows([]);
      setPermission(false);
      setImpact(false);
      setError(null);
    }
  }, [open]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const rowError = validateRows(rows);
    if (rowError) return setError(rowError);
    if (!permission) return setError("Please confirm you have permission to share these sheets.");
    if (usageEvents.length > 0 && !impact) return setError("Confirm you understand which scheduled events are affected.");
    setBusy(true);
    setError(null);
    try {
      const form = new FormData();
      appendSheetFields(form, rows);
      if (usageEvents.length > 0) form.append("confirmImpact", "true");
      await api<unknown>(`/api/admin/songs/${encodeURIComponent(song.id)}/sheets`, { method: "POST", form });
      toast("success", `${plural(rows.length, "sheet")} added to “${song.title}”.`);
      onClose();
      try {
        await refresh();
      } catch (err) {
        toast("error", `Saved, but the library could not reload: ${errorMessage(err)}`);
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size="xl"
      eyebrow={song.title}
      title="Add sheets"
      description="New sheets join this song. Events keep their current sheet selections until you change them."
      footer={
        <>
          <button type="button" className="btn-secondary" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form={formId} className="btn-primary" busy={busy} busyLabel="Uploading…">
            <FilePlus2 className="h-4 w-4" aria-hidden="true" /> Add sheets
          </BusyButton>
        </>
      }
    >
      <form id={formId} onSubmit={submit} className="space-y-5" noValidate>
        <SheetUploadRows rows={rows} onChange={setRows} disabled={busy} />
        <PermissionCheck checked={permission} onChange={setPermission} disabled={busy} />
        {usageEvents.length > 0 ? (
          <>
            <ImpactList usages={song.usages} title="This song is used in" />
            <ImpactCheck checked={impact} onChange={setImpact} count={usageEvents.length} disabled={busy} />
          </>
        ) : null}
        <InlineError message={error} />
      </form>
    </Modal>
  );
}

export function EditSongDialog({ song, open, onClose }: { song: Song; open: boolean; onClose: () => void }) {
  const formId = useId();
  const { refresh } = useAdmin();
  const toast = useToast();
  const [title, setTitle] = useState(song.title);
  const [composer, setComposer] = useState(song.composer);
  const [notes, setNotes] = useState(song.notes);
  const [links, setLinks] = useState<string[]>(song.links ?? []);
  const [impact, setImpact] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const usageEvents = uniqueUsageEvents(song.usages);

  useEffect(() => {
    if (open) {
      setTitle(song.title);
      setComposer(song.composer);
      setNotes(song.notes);
      setLinks(song.links ?? []);
      setImpact(false);
      setError(null);
    }
  }, [open, song]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return setError("The title cannot be empty.");
    if (usageEvents.length > 0 && !impact) return setError("Confirm you understand which scheduled events are affected.");
    setBusy(true);
    setError(null);
    try {
      await api<unknown>(`/api/admin/songs/${encodeURIComponent(song.id)}`, {
        method: "PATCH",
        json: { title: title.trim(), composer: composer.trim(), notes: notes.trim(), links: links.map((link) => link.trim()).filter(Boolean), ...(usageEvents.length > 0 ? { confirmImpact: true } : {}) },
      });
      toast("success", "Song details saved.");
      onClose();
      try {
        await refresh();
      } catch (err) {
        toast("error", `Saved, but the library could not reload: ${errorMessage(err)}`);
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size="lg"
      eyebrow="Edit song"
      title={song.title}
      footer={
        <>
          <button type="button" className="btn-secondary" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form={formId} className="btn-primary" busy={busy} busyLabel="Saving…">
            <Pencil className="h-4 w-4" aria-hidden="true" /> Save changes
          </BusyButton>
        </>
      }
    >
      <form id={formId} onSubmit={submit} className="space-y-4" noValidate>
        <Field label="Title" htmlFor={`${formId}-title`} required>
          <input id={`${formId}-title`} className="input" value={title} onChange={(e) => setTitle(e.target.value)} disabled={busy} data-autofocus />
        </Field>
        <Field label="Composer / source" htmlFor={`${formId}-composer`}>
          <input id={`${formId}-composer`} className="input" value={composer} onChange={(e) => setComposer(e.target.value)} disabled={busy} />
        </Field>
        <Field label="Notes for leaders" htmlFor={`${formId}-notes`}>
          <textarea id={`${formId}-notes`} className="input min-h-24" value={notes} onChange={(e) => setNotes(e.target.value)} disabled={busy} />
        </Field>
        <SongLinkFields links={links} onChange={setLinks} disabled={busy} />
        {usageEvents.length > 0 ? (
          <>
            <ImpactList usages={song.usages} title="Families will see this change in" />
            <ImpactCheck checked={impact} onChange={setImpact} count={usageEvents.length} disabled={busy} />
          </>
        ) : null}
        <InlineError message={error} />
      </form>
    </Modal>
  );
}

export function EditSheetDialog({ sheet, open, onClose }: { sheet: Sheet; open: boolean; onClose: () => void }) {
  const formId = useId();
  const { refresh } = useAdmin();
  const toast = useToast();
  const [label, setLabel] = useState(sheet.label);
  const [instrument, setInstrument] = useState<Instrument | "">(sheet.instrument ?? "");
  const [arrangement, setArrangement] = useState(sheet.arrangement);
  const [replacement, setReplacement] = useState<PendingSheet[]>([]);
  const [permission, setPermission] = useState(false);
  const [impact, setImpact] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const usageEvents = uniqueUsageEvents(sheet.usages);

  useEffect(() => {
    if (open) {
      setLabel(sheet.label);
      setInstrument(sheet.instrument ?? "");
      setArrangement(sheet.arrangement);
      setReplacement([]);
      setPermission(false);
      setImpact(false);
      setError(null);
    }
  }, [open, sheet]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!label.trim()) return setError("The sheet needs a label.");
    const file = replacement[0]?.file;
    if (file && !permission) return setError("Please confirm you have permission to share the replacement PDF.");
    if (usageEvents.length > 0 && !impact) return setError("Confirm you understand which scheduled events are affected.");
    setBusy(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("label", label.trim());
      form.append("instrument", instrument);
      form.append("arrangement", arrangement.trim());
      if (file) {
        form.append("file", file, file.name);
        form.append("permission", "true");
      }
      if (usageEvents.length > 0) form.append("confirmImpact", "true");
      await api<unknown>(`/api/admin/sheets/${encodeURIComponent(sheet.id)}`, { method: "PATCH", form });
      toast("success", file ? `New version of “${label.trim()}” uploaded. Earlier versions are kept.` : "Sheet details saved.");
      onClose();
      try {
        await refresh();
      } catch (err) {
        toast("error", `Saved, but the library could not reload: ${errorMessage(err)}`);
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size="lg"
      eyebrow={`Sheet · version ${sheet.version}`}
      title={`Edit “${sheet.label}”`}
      description="Update labels or upload a replacement PDF. Replacing creates a new version; earlier versions remain downloadable."
      footer={
        <>
          <button type="button" className="btn-secondary" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form={formId} className="btn-primary" busy={busy} busyLabel="Saving…">
            {replacement.length ? <Replace className="h-4 w-4" aria-hidden="true" /> : <Pencil className="h-4 w-4" aria-hidden="true" />}
            {replacement.length ? "Upload new version" : "Save sheet"}
          </BusyButton>
        </>
      }
    >
      <form id={formId} onSubmit={submit} className="space-y-4" noValidate>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Label" htmlFor={`${formId}-label`} required>
            <input id={`${formId}-label`} className="input" value={label} onChange={(e) => setLabel(e.target.value)} disabled={busy} data-autofocus />
          </Field>
          <Field label="Instrument" htmlFor={`${formId}-inst`}>
            <select id={`${formId}-inst`} className="input" value={instrument} onChange={(e) => setInstrument(e.target.value as Instrument | "")} disabled={busy}>
              <option value="">Any / full score</option>
              {INSTRUMENTS.map((inst) => (
                <option key={inst} value={inst}>
                  {inst}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Arrangement" htmlFor={`${formId}-arr`}>
            <input id={`${formId}-arr`} className="input" value={arrangement} onChange={(e) => setArrangement(e.target.value)} disabled={busy} />
          </Field>
        </div>
        <fieldset className="space-y-2">
          <legend className="field-label">Replace PDF (optional)</legend>
          <SheetUploadRows rows={replacement} onChange={setReplacement} disabled={busy} multiple={false} />
        </fieldset>
        {replacement.length ? <PermissionCheck checked={permission} onChange={setPermission} disabled={busy} /> : null}
        {usageEvents.length > 0 ? (
          <>
            <Notice tone="warn">Events that selected this sheet will show the updated details to families.</Notice>
            <ImpactList usages={sheet.usages} />
            <ImpactCheck checked={impact} onChange={setImpact} count={usageEvents.length} disabled={busy} />
          </>
        ) : null}
        <InlineError message={error} />
      </form>
    </Modal>
  );
}