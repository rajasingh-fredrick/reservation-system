"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import { Activity, CalendarRange, ChevronDown, ClipboardList, LayoutDashboard, Library, LogOut, Mail, Menu, RefreshCw, ShieldAlert, ShieldCheck, Users, WifiOff } from "lucide-react";
import { AdminProvider, useAdmin, useRetryLoad } from "./AdminProvider";
import { Modal } from "@/components/ui/Modal";
import { BusyButton, InlineError, Spinner, ToastProvider, useToast } from "@/components/ui/Feedback";
import { WorkspaceSkeleton } from "@/components/ui/Bits";
import { HarmonyMark, StaffFlourish } from "@/components/ui/Motifs";
import { errorMessage } from "@/lib/client";

const NAV = [
  { href: "/", label: "Song library", short: "Library", Icon: Library },
  { href: "/dashboard", label: "Dashboard", short: "Dashboard", Icon: LayoutDashboard },
  { href: "/reservations", label: "Reservations", short: "Roster", Icon: ClipboardList },
  { href: "/seasons", label: "Seasons & events", short: "Seasons", Icon: CalendarRange },
  { href: "/administrators", label: "Administrator access", short: "Admins", Icon: ShieldCheck },
  { href: "/notifications", label: "Email parents", short: "Email", Icon: Mail },
  { href: "/parent", label: "Family workspace", short: "Family", Icon: Users },
  { href: "/activity", label: "Activity log", short: "Activity", Icon: Activity },
] as const;

function isActive(pathname: string, href: string) {
  if (href === "/") return pathname === "/" || pathname.startsWith("/library");
  return pathname === href || pathname.startsWith(`${href}/`);
}

export function AdminShell({ children }: { children: ReactNode }) {
  return (
    <ToastProvider>
      <AdminProvider>
        <ShellFrame>{children}</ShellFrame>
      </AdminProvider>
    </ToastProvider>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-3 rounded-xl text-parchment-50">
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-accent/15 ring-1 ring-amber-accent/40">
        <HarmonyMark className="h-7 w-7" />
      </span>
      <span className="leading-tight">
        <span className="block font-serif text-xl font-semibold tracking-tight">Harmony</span>
        {!compact ? <span className="block text-[0.7rem] uppercase tracking-[0.18em] text-amber-soft/80">Music ministry</span> : null}
      </span>
    </Link>
  );
}

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname() || "/";
  const { data } = useAdmin();
  const counts: Record<string, number | undefined> = {
    "/": data?.songs.filter((s) => !s.archived).length,
    "/seasons": data?.seasons.filter((s) => s.status !== "Archived").length,
  };
  return (
    <nav aria-label="Admin workspace">
      <ul className="space-y-1">
        {NAV.map(({ href, label, Icon }) => {
          const active = isActive(pathname, href);
          return (
            <li key={href}>
              <Link
                href={href}
                onClick={onNavigate}
                aria-current={active ? "page" : undefined}
                className={clsx(
                  "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
                  active ? "bg-parchment-50 text-forest-900 shadow-sm" : "text-parchment-200 hover:bg-white/8 hover:text-white",
                )}
              >
                {active ? <span className="absolute -left-3 top-2 bottom-2 w-1 rounded-r bg-amber-accent" aria-hidden="true" /> : null}
                <Icon className={clsx("h-5 w-5", active ? "text-forest-700" : "text-amber-soft/80")} aria-hidden="true" />
                <span className="flex-1">{label}</span>
                {counts[href] !== undefined ? (
                  <span className={clsx("rounded-full px-2 py-0.5 text-xs tabular-nums", active ? "bg-forest-50 text-forest-800" : "bg-white/10 text-parchment-100")}>
                    {counts[href]}
                  </span>
                ) : null}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

function ScopeNote() {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5 text-xs leading-relaxed text-parchment-200">
      <p className="mb-1 flex items-center gap-1.5 font-semibold text-amber-soft">
        <ShieldCheck className="h-4 w-4" aria-hidden="true" /> Admin workspace
      </p>
      This workspace covers the song library, seasons, events, and parent email. Parent reservations and role management live elsewhere and are not part of this
      view.
    </div>
  );
}

function UserMenu({ variant }: { variant: "sidebar" | "topbar" }) {
  const { user, signOut } = useAdmin();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    function onDoc(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setOpen(false);
        buttonRef.current?.focus();
      }
    }
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (!user) return null;
  const initials = user.name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("") || "A";

  async function doSignOut() {
    setBusy(true);
    try {
      await signOut();
    } catch (err) {
      toast("error", `Sign out failed: ${errorMessage(err)}`);
      setBusy(false);
    }
  }

  return (
    <div ref={wrapRef} className="relative">
      <button
        ref={buttonRef}
        type="button"
        aria-haspopup="true"
        aria-expanded={open}
        aria-controls={`user-menu-${variant}`}
        onClick={() => setOpen((o) => !o)}
        className={clsx(
          "flex w-full items-center gap-3 rounded-xl p-2 text-left transition",
          variant === "sidebar" ? "text-parchment-50 hover:bg-white/8" : "text-ink hover:bg-parchment-200/70",
        )}
      >
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-accent font-semibold text-forest-950">{initials}</span>
        <span className={clsx("min-w-0 flex-1", variant === "topbar" && "hidden sm:block")}>
          <span className="block truncate text-sm font-semibold">{user.name}</span>
          <span className={clsx("block truncate text-xs", variant === "sidebar" ? "text-parchment-200" : "text-ink-muted")}>{user.email}</span>
        </span>
        <ChevronDown className={clsx("h-4 w-4 shrink-0 transition", open && "rotate-180")} aria-hidden="true" />
        <span className="sr-only">Account menu</span>
      </button>
      {open ? (
        <div
          id={`user-menu-${variant}`}
          className={clsx(
            "anim-pop absolute z-40 w-64 rounded-2xl border border-parchment-300 bg-parchment-50 p-2 text-ink shadow-[var(--shadow-lift)]",
            variant === "sidebar" ? "bottom-full left-0 mb-2" : "right-0 top-full mt-2",
          )}
        >
          <div className="border-b border-parchment-200 px-3 pb-2.5 pt-1.5">
            <p className="truncate text-sm font-semibold">{user.name}</p>
            <p className="truncate text-xs text-ink-muted">{user.email}</p>
            <p className="mt-1.5 inline-flex items-center gap-1 text-xs font-medium text-forest-700">
              <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" /> Verified administrator
            </p>
          </div>
          <BusyButton busy={busy} busyLabel="Signing out…" className="btn-ghost mt-1 w-full justify-start" onClick={doSignOut}>
            <LogOut className="h-4 w-4" aria-hidden="true" /> Sign out
          </BusyButton>
        </div>
      ) : null}
    </div>
  );
}

function ShellFrame({ children }: { children: ReactNode }) {
  const { phase, error, refreshing } = useAdmin();
  const pathname = usePathname() || "/";
  const [drawer, setDrawer] = useState(false);
  const current = NAV.find((n) => isActive(pathname, n.href));

  if (phase === "checking") {
    return (
      <div className="flex min-h-dvh items-center justify-center" role="status">
        <div className="flex flex-col items-center gap-3 text-forest-800">
          <HarmonyMark className="anim-float h-14 w-14" />
          <p className="flex items-center gap-2 text-sm font-medium">
            <Spinner /> Checking your session…
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh lg:pl-72">
      <aside className="sidebar-texture fixed inset-y-0 left-0 z-30 hidden w-72 flex-col gap-6 px-5 py-6 text-parchment-100 lg:flex" aria-label="Sidebar">
        <Brand />
        <StaffFlourish className="-mt-2 h-6 w-full text-amber-accent/35" />
        <NavLinks />
        <div className="mt-auto space-y-4">
          <ScopeNote />
          <UserMenu variant="sidebar" />
        </div>
      </aside>

      <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-parchment-300/70 bg-parchment-100/90 px-3 py-2 backdrop-blur lg:hidden">
        <button type="button" className="icon-btn" aria-label="Open navigation" aria-expanded={drawer} onClick={() => setDrawer(true)}>
          <Menu className="h-5 w-5" aria-hidden="true" />
        </button>
        <Link href="/" className="flex items-center gap-2 text-forest-900">
          <HarmonyMark className="h-7 w-7" />
          <span className="font-serif text-lg font-semibold">Harmony</span>
        </Link>
        {current ? <span className="ml-1 hidden truncate text-sm text-ink-muted sm:inline">/ {current.short}</span> : null}
        <div className="ml-auto">
          <UserMenu variant="topbar" />
        </div>
      </header>

      <Modal open={drawer} onClose={() => setDrawer(false)} variant="left" title="Harmony" eyebrow="Music ministry">
        <div className="flex h-full flex-col gap-6">
          <NavLinks onNavigate={() => setDrawer(false)} />
          <div className="mt-auto">
            <ScopeNote />
          </div>
        </div>
      </Modal>

      {refreshing ? (
        <div className="fixed right-4 top-16 z-40 flex items-center gap-2 rounded-full border border-parchment-300 bg-parchment-50 px-3 py-1.5 text-xs font-medium text-forest-800 shadow lg:top-4" role="status">
          <Spinner /> Updating…
        </div>
      ) : null}

      <main id="main" tabIndex={-1} className="mx-auto w-full max-w-7xl px-4 pb-24 pt-6 outline-none sm:px-6 lg:px-10 lg:pt-10">
        {phase === "loading" ? <WorkspaceSkeleton /> : null}
        {phase === "forbidden" ? <Forbidden message={error} /> : null}
        {phase === "error" ? <LoadFailed message={error} /> : null}
        {phase === "ready" ? children : null}
      </main>

      <nav aria-label="Quick navigation" className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-forest-800 bg-forest-900 pb-[env(safe-area-inset-bottom)] lg:hidden">
        {NAV.map(({ href, short, Icon }) => {
          const active = isActive(pathname, href);
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? "page" : undefined}
              className={clsx("flex flex-col items-center gap-0.5 py-2 text-[0.7rem] font-medium", active ? "text-amber-soft" : "text-parchment-200")}
            >
              <Icon className="h-5 w-5" aria-hidden="true" />
              {short}
              <span className={clsx("mt-0.5 h-0.5 w-6 rounded-full", active ? "bg-amber-accent" : "bg-transparent")} aria-hidden="true" />
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

function Forbidden({ message }: { message: string | null }) {
  const { signOut } = useAdmin();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="card mx-auto mt-10 max-w-xl p-8 text-center">
      <ShieldAlert className="mx-auto h-12 w-12 text-amber-deep" aria-hidden="true" />
      <h1 className="mt-4 text-3xl font-semibold text-forest-900">Administrator access required</h1>
      <p className="mt-3 text-sm leading-relaxed text-ink-soft">
        {message || "This account cannot open the admin workspace."} Only verified administrator accounts may manage the song library and seasons. If you
        just created the first administrator, open the verification link from your email (or the development server log) and sign in again.
      </p>
      <InlineError message={err} className="mt-4 text-left" />
      <BusyButton
        busy={busy}
        busyLabel="Signing out…"
        className="btn-primary mt-6"
        onClick={async () => {
          setBusy(true);
          setErr(null);
          try {
            await signOut();
          } catch (e) {
            setErr(errorMessage(e));
            setBusy(false);
          }
        }}
      >
        <LogOut className="h-4 w-4" aria-hidden="true" /> Sign in with another account
      </BusyButton>
    </div>
  );
}

function LoadFailed({ message }: { message: string | null }) {
  const retry = useRetryLoad();
  const [busy, setBusy] = useState(false);
  return (
    <div className="card mx-auto mt-10 max-w-xl p-8 text-center" role="alert">
      <WifiOff className="mx-auto h-12 w-12 text-rose-deep" aria-hidden="true" />
      <h1 className="mt-4 text-3xl font-semibold text-forest-900">The workspace could not load</h1>
      <p className="mt-3 text-sm text-ink-soft">{message}</p>
      <BusyButton
        busy={busy}
        busyLabel="Retrying…"
        className="btn-primary mt-6"
        onClick={async () => {
          setBusy(true);
          await retry();
          setBusy(false);
        }}
      >
        <RefreshCw className="h-4 w-4" aria-hidden="true" /> Try again
      </BusyButton>
    </div>
  );
}