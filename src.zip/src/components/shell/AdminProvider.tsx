"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { usePathname, useRouter } from "next/navigation";
import type { AdminData } from "@/lib/contracts";
import { api, ApiRequestError, errorMessage } from "@/lib/client";

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  emailVerified?: boolean;
  role?: string;
}

interface SessionPayload {
  user: SessionUser;
  session: unknown;
}

type Phase = "checking" | "loading" | "ready" | "forbidden" | "error";

interface AdminContextValue {
  user: SessionUser | null;
  data: AdminData | null;
  phase: Phase;
  error: string | null;
  refreshing: boolean;
  /** Re-fetch admin data. Resolves after state updates; throws on failure. */
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AdminContext = createContext<AdminContextValue | null>(null);

export function useAdmin(): AdminContextValue {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error("useAdmin must be used inside <AdminProvider>");
  return ctx;
}

/** Convenience accessor once the shell guarantees data is ready. */
export function useAdminData(): AdminData {
  const { data } = useAdmin();
  if (!data) throw new Error("Admin data is not loaded yet");
  return data;
}

export function AdminProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<SessionUser | null>(null);
  const [data, setData] = useState<AdminData | null>(null);
  const [phase, setPhase] = useState<Phase>("checking");
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const pathRef = useRef(pathname);
  pathRef.current = pathname;

  const toSignIn = useCallback(() => {
    router.replace(`/sign-in?next=${encodeURIComponent(pathRef.current || "/")}`);
  }, [router]);

  const loadData = useCallback(
    async (signal?: AbortSignal) => {
      try {
        const next = await api<AdminData>("/api/admin/data", { signal });
        setData(next);
        setError(null);
        setPhase("ready");
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") return;
        if (err instanceof ApiRequestError && err.status === 401) {
          toSignIn();
          return;
        }
        if (err instanceof ApiRequestError && err.status === 403) {
          setError(err.message);
          setPhase("forbidden");
          return;
        }
        throw err;
      }
    },
    [toSignIn],
  );

  useEffect(() => {
    const ctrl = new AbortController();
    (async () => {
      try {
        const session = await api<SessionPayload | null>("/api/auth/get-session", { signal: ctrl.signal });
        if (!session || !session.user) {
          toSignIn();
          return;
        }
        setUser(session.user);
        setPhase("loading");
        await loadData(ctrl.signal);
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") return;
        setError(errorMessage(err));
        setPhase("error");
      }
    })();
    return () => ctrl.abort();
    // Session is checked once per mount of the admin shell.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await loadData();
    } finally {
      setRefreshing(false);
    }
  }, [loadData]);

  const retry = useCallback(async () => {
    setPhase("loading");
    try {
      await loadData();
    } catch (err) {
      setError(errorMessage(err));
      setPhase("error");
    }
  }, [loadData]);

  const signOut = useCallback(async () => {
    await api("/api/auth/sign-out", { method: "POST", json: {} });
    setPhase("checking");
    setUser(null);
    setData(null);
    router.replace("/sign-in?signedOut=1");
  }, [router]);

  const value = useMemo<AdminContextValue>(
    () => ({ user, data, phase, error, refreshing, refresh, signOut }),
    [user, data, phase, error, refreshing, refresh, signOut],
  );

  return (
    <AdminContext.Provider value={value}>
      <RetryContext.Provider value={retry}>{children}</RetryContext.Provider>
    </AdminContext.Provider>
  );
}

const RetryContext = createContext<() => Promise<void>>(async () => undefined);
export function useRetryLoad() {
  return useContext(RetryContext);
}