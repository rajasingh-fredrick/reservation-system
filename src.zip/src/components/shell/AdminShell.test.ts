import { createElement, type ReactNode } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { AdminData } from "@/lib/contracts";
import { AdminShell } from "./AdminShell";
import { useAdminData } from "./AdminProvider";

const state = vi.hoisted(() => ({
  data: null as AdminData | null,
  phase: "ready",
}));

vi.mock("next/navigation", () => ({
  usePathname: () => "/",
}));

vi.mock("./AdminProvider", () => ({
  AdminProvider: ({ children }: { children: ReactNode }) => children,
  useAdmin: () => ({
    data: state.data,
    phase: state.phase,
    user: null,
    error: null,
    refreshing: false,
  }),
  useAdminData: () => {
    if (!state.data) throw new Error("Admin data is not loaded yet");
    return state.data;
  },
  useRetryLoad: () => vi.fn(),
}));

function AdminPage() {
  const data = useAdminData();
  return createElement("p", null, `Library loaded: ${data.songs.length} songs`);
}

function render() {
  return renderToStaticMarkup(createElement(AdminShell, null, createElement(AdminPage)));
}

describe("admin shell data boundary", () => {
  beforeEach(() => {
    state.data = { songs: [], seasons: [], audit: [] };
    state.phase = "ready";
  });

  it("renders admin pages when data is ready", () => {
    expect(render()).toContain("Library loaded: 0 songs");
  });

  it("does not render data-dependent pages after sign-out clears data", () => {
    state.data = null;
    expect(render()).not.toContain("Library loaded");
  });

  it("shows the session transition without rendering the signed-out page", () => {
    state.data = null;
    state.phase = "checking";
    const html = render();
    expect(html).toContain("Checking your session");
    expect(html).not.toContain("Library loaded");
  });

  it("does not render admin pages while loading even if previous data exists", () => {
    state.phase = "loading";
    expect(render()).not.toContain("Library loaded");
  });
});
