"use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { useAdminData } from "@/components/shell/AdminProvider";
import { EmptyState, PageHeader } from "@/components/ui/Bits";

export function ActivityView() {
  const { audit } = useAdminData();
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => {
    const value = query.trim().toLowerCase();
    return audit.filter((entry) => !value || `${entry.action} ${entry.description} ${entry.actorName}`.toLowerCase().includes(value));
  }, [audit, query]);

  return (
    <div>
      <PageHeader eyebrow="Administration" title="Activity log" description="Recent administrator actions and schedule changes." />
      <div className="card mb-5 flex items-center gap-3 p-3">
        <Search className="ml-2 h-4 w-4 shrink-0 text-ink-muted" aria-hidden="true" />
        <label htmlFor="activity-search" className="sr-only">Search activity</label>
        <input id="activity-search" type="search" className="input border-0 bg-transparent shadow-none" placeholder="Filter by action, description, or administrator…" value={query} onChange={(event) => setQuery(event.target.value)} />
      </div>
      {!filtered.length ? <EmptyState title={audit.length ? "No activity matches" : "No activity recorded yet"}>{audit.length ? "Try a different search." : "Administrator actions will appear here."}</EmptyState> : null}
      <ol className="space-y-3">
        {filtered.map((entry) => <li key={entry.id} className="rounded-2xl border border-parchment-300 bg-parchment-50 p-4 shadow-[var(--shadow-card)] sm:p-5">
          <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-xs font-semibold uppercase tracking-wide text-forest-800">{entry.action.replaceAll("_", " ")}</p><p className="mt-1 text-sm leading-relaxed text-ink">{entry.description}</p></div><time className="shrink-0 text-xs text-ink-muted" dateTime={entry.createdAt}>{new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(new Date(entry.createdAt))}</time></div>
          <p className="mt-3 text-xs text-ink-muted">By {entry.actorName}</p>
        </li>)}
      </ol>
    </div>
  );
}