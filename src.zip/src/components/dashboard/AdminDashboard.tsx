"use client";

import { useCallback, useEffect, useState } from "react";
import { Check, RefreshCw, UserRoundCheck, UserRoundX } from "lucide-react";
import { api, ApiRequestError, errorMessage } from "@/lib/client";
import { INSTRUMENTS } from "@/lib/contracts";
import { EmptyState, PageHeader } from "@/components/ui/Bits";
import { InlineError, Notice } from "@/components/ui/Feedback";
import { ReservationReviewQueue } from "./ReservationReviewQueue";

type PendingChild = {
  id: string;
  fullName: string;
  birthMonth: number;
  birthYear: number;
  additionalInformation: string;
  createdAt: string;
  parentName: string;
  parentEmail: string;
  instruments: Array<{ instrument: (typeof INSTRUMENTS)[number]; yearsExperience: number }>;
};

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

export function AdminDashboard() {
  const [children, setChildren] = useState<PendingChild[]>([]);
  const [reasons, setReasons] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notificationWarning, setNotificationWarning] = useState(false);

  const refresh = useCallback(async (signal?: AbortSignal) => {
    const result = await api<{ children: PendingChild[] }>("/api/admin/children", { signal });
    setChildren(result.children);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void refresh(controller.signal).catch((err: unknown) => {
      if (err instanceof DOMException && err.name === "AbortError") return;
      setError(errorMessage(err));
    }).finally(() => setLoading(false));
    return () => controller.abort();
  }, [refresh]);

  async function decide(child: PendingChild, status: "Approved" | "Rejected") {
    const reason = reasons[child.id]?.trim() ?? "";
    if (status === "Rejected" && !reason) {
      setError(`Add a parent-visible reason before rejecting ${child.fullName}'s profile.`);
      return;
    }
    setBusyId(child.id);
    setError(null);
    setNotificationWarning(false);
    try {
      const result = await api<{ notificationSent: boolean }>(`/api/admin/children/${child.id}`, {
        method: "PATCH",
        json: { status, ...(status === "Rejected" ? { reason } : {}) },
      });
      if (!result.notificationSent) setNotificationWarning(true);
      await refresh();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Coordinator workspace"
        title="Dashboard"
        description="Review child profiles before families can register for ministry events. Decisions are recorded in the activity log."
        actions={<button type="button" className="btn-secondary min-h-11" onClick={() => void refresh()} disabled={loading || Boolean(busyId)}><RefreshCw className="h-4 w-4" aria-hidden="true" />Refresh</button>}
      />
      <div className="mb-6 grid gap-3 sm:grid-cols-2">
        <div className="rounded-2xl border border-amber-accent/40 bg-amber-soft/50 p-4">
          <p className="font-serif text-3xl font-semibold text-amber-deep">{children.length}</p>
          <p className="mt-1 text-sm font-medium text-ink">Profiles awaiting review</p>
        </div>
        <div className="rounded-2xl border border-forest-200 bg-forest-50/70 p-4">
          <p className="flex items-center gap-2 font-semibold text-forest-900"><Check className="h-4 w-4" aria-hidden="true" />Approval required</p>
          <p className="mt-1 text-sm text-ink-soft">Only approved child profiles can be used for registrations.</p>
        </div>
      </div>
      {notificationWarning ? <Notice tone="warn" className="mb-4">The decision was saved, but the notification email could not be delivered. Contact the parent directly and review mail configuration.</Notice> : null}
      <InlineError message={error} className="mb-4" />
      {loading ? <p className="card p-5 text-sm text-ink-muted" role="status">Loading pending profiles…</p> : null}
      {!loading && children.length === 0 ? <EmptyState art={<UserRoundCheck className="h-10 w-10 text-forest-700" aria-hidden="true" />} title="All caught up">There are no child profiles waiting for review.</EmptyState> : null}
      <div className="space-y-4">
        {children.map((child) => (
          <article key={child.id} className="rounded-2xl border border-parchment-300 bg-parchment-50 p-4 shadow-[var(--shadow-card)] sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="eyebrow">Pending approval</p>
                <h2 className="mt-1 font-serif text-xl text-forest-900">{child.fullName}</h2>
                <p className="mt-1 text-sm text-ink-muted">Born {months[child.birthMonth - 1]} {child.birthYear}</p>
              </div>
              <p className="text-sm text-ink-muted">Submitted {new Date(child.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div>
                <h3 className="text-sm font-semibold text-ink">Parent or guardian</h3>
                <p className="mt-1 text-sm text-ink-soft">{child.parentName}</p>
                <a className="text-sm text-forest-800 underline-offset-4 hover:underline" href={`mailto:${child.parentEmail}`}>{child.parentEmail}</a>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-ink">Instruments and experience</h3>
                <ul className="mt-1 flex flex-wrap gap-2">
                  {child.instruments.map((item) => <li key={item.instrument} className="chip border-forest-100 bg-forest-50 text-forest-900">{item.instrument}: {item.yearsExperience} yr</li>)}
                </ul>
              </div>
            </div>
            {child.additionalInformation ? <div className="mt-4 rounded-xl bg-parchment-100 p-3"><h3 className="text-xs font-semibold uppercase tracking-wide text-ink-muted">Additional information</h3><p className="mt-1 whitespace-pre-wrap text-sm text-ink-soft">{child.additionalInformation}</p></div> : null}
            <div className="mt-5 border-t border-parchment-200 pt-4">
              <label htmlFor={`rejection-${child.id}`} className="field-label">Rejection reason <span className="font-normal text-ink-muted">(required to reject)</span></label>
              <textarea id={`rejection-${child.id}`} className="input min-h-20 resize-y" maxLength={1000} value={reasons[child.id] ?? ""} onChange={(event) => setReasons((current) => ({ ...current, [child.id]: event.target.value }))} disabled={busyId === child.id} />
              <div className="mt-3 flex flex-wrap gap-2">
                <button type="button" className="btn-primary min-h-11" onClick={() => void decide(child, "Approved")} disabled={Boolean(busyId)} aria-busy={busyId === child.id}>{busyId === child.id ? <RefreshCw className="h-4 w-4 animate-spin" aria-hidden="true" /> : <UserRoundCheck className="h-4 w-4" aria-hidden="true" />}Approve profile</button>
                <button type="button" className="btn-danger-ghost min-h-11" onClick={() => void decide(child, "Rejected")} disabled={Boolean(busyId)}><UserRoundX className="h-4 w-4" aria-hidden="true" />Reject with reason</button>
              </div>
            </div>
          </article>
        ))}
      </div>
      <ReservationReviewQueue />
    </div>
  );
}