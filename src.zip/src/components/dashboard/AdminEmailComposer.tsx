"use client";

import { useEffect, useMemo, useState } from "react";
import { Mail, Search, Send, Users } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { ConfirmDialog } from "@/components/ui/Confirm";
import { EmptyState, Field, PageHeader } from "@/components/ui/Bits";
import { BusyButton, InlineError, Notice, useToast } from "@/components/ui/Feedback";
import { ChildNotificationDelivery } from "./ChildNotificationDelivery";

type ParentRecipient = { id: string; name: string; email: string };
type SendResult = {
  queuedCount: number;
  totalCount: number;
};

export function AdminEmailComposer() {
  const toast = useToast();
  const [parents, setParents] = useState<ParentRecipient[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [allParents, setAllParents] = useState(false);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [resultMessage, setResultMessage] = useState<string | null>(null);
  const [confirmationOpen, setConfirmationOpen] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    void api<{ parents: ParentRecipient[] }>("/api/admin/notifications/email", { signal: controller.signal })
      .then(({ parents: results }) => setParents(results))
      .catch((err: unknown) => {
        if (err instanceof DOMException && err.name === "AbortError") return;
        setLoadError(errorMessage(err));
      })
      .finally(() => setLoading(false));
    return () => controller.abort();
  }, []);

  const visibleParents = useMemo(() => {
    const term = search.trim().toLocaleLowerCase();
    if (!term) return parents;
    return parents.filter((parent) =>
      `${parent.name} ${parent.email}`.toLocaleLowerCase().includes(term),
    );
  }, [parents, search]);

  const recipientCount = allParents ? parents.length : selectedIds.length;

  function toggleParent(id: string) {
    setAllParents(false);
    setSelectedIds((current) => current.includes(id)
      ? current.filter((selectedId) => selectedId !== id)
      : [...current, id]);
    setResultMessage(null);
  }

  async function sendEmail() {
    const response = await api<SendResult>("/api/admin/notifications/email", {
      method: "POST",
      json: {
        allParents,
        recipientIds: allParents ? [] : selectedIds,
        subject,
        message,
      },
    });
    setAllParents(false);
    setSelectedIds([]);
    setResultMessage(`Email queued for ${response.queuedCount} parent${response.queuedCount === 1 ? "" : "s"}. The backend worker will deliver it shortly; check delivery status below.`);
    toast("success", `Email queued for ${response.queuedCount} parent${response.queuedCount === 1 ? "" : "s"}.`);
  }

  return (
    <div>
      <PageHeader
        eyebrow="Parent communication"
        title="Email parents"
        description="Compose a plain-text message for subscribed, verified parents. The backend worker delivers queued messages shortly."
      />
      {loadError ? <InlineError message={loadError} className="mb-4" /> : null}
      {resultMessage ? <Notice tone="success" className="mb-4">{resultMessage}</Notice> : null}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.15fr)_minmax(20rem,0.85fr)]">
        <section className="card p-4 sm:p-6" aria-labelledby="email-recipients-heading">
          <div className="mb-4 flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl gradient-brand text-ink"><Users className="h-5 w-5" aria-hidden="true" /></span>
            <div>
              <h2 id="email-recipients-heading" className="font-serif text-2xl text-forest-900">Recipients</h2>
              <p className="text-sm text-ink-muted">{loading ? "Loading parents…" : `${parents.length} subscribed, verified parent${parents.length === 1 ? "" : "s"}`}</p>
            </div>
          </div>

          <label className="flex min-h-12 items-center gap-3 rounded-xl border border-forest-200 gradient-tint px-3 py-2 text-sm font-semibold text-forest-900">
            <input
              type="checkbox"
              className="size-4 accent-forest-800"
              checked={allParents}
              onChange={(event) => {
                setAllParents(event.target.checked);
                setSelectedIds([]);
                setResultMessage(null);
              }}
              disabled={loading || parents.length === 0 || Boolean(loadError)}
            />
            Send to all subscribed parents
          </label>

          <div className="relative mt-4">
            <label htmlFor="parent-search" className="sr-only">Search parents by name or email</label>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" aria-hidden="true" />
            <input
              id="parent-search"
              className="input pl-9"
              type="search"
              placeholder="Search parents"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              disabled={loading || Boolean(loadError)}
            />
          </div>

          {loading ? <p className="py-6 text-center text-sm text-ink-muted" role="status">Loading subscribed parent accounts…</p> : null}
          {!loading && !loadError && parents.length === 0 ? (
            <EmptyState title="No subscribed parents found">Verified parents can subscribe to ministry email notifications in Family Workspace.</EmptyState>
          ) : null}
          {!loading && !loadError && parents.length > 0 ? (
            <div className="mt-3 max-h-[28rem] divide-y divide-parchment-200 overflow-y-auto rounded-xl border border-parchment-300" aria-label="Verified parent accounts">
              {visibleParents.length ? visibleParents.map((parent) => (
                <label key={parent.id} className="flex min-h-14 items-center gap-3 px-3 py-2.5 hover:bg-parchment-100/70">
                  <input
                    type="checkbox"
                    className="size-4 shrink-0 accent-forest-800"
                    checked={allParents || selectedIds.includes(parent.id)}
                    onChange={() => toggleParent(parent.id)}
                    disabled={allParents}
                  />
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold text-ink">{parent.name}</span>
                    <span className="block truncate text-xs text-ink-muted">{parent.email}</span>
                  </span>
                </label>
              )) : <p className="p-4 text-sm text-ink-muted">No parents match this search.</p>}
            </div>
          ) : null}
          <p className="mt-3 text-xs leading-relaxed text-ink-muted">Each parent receives a separate email. Addresses are not shared with other recipients.</p>
        </section>

        <section className="card h-fit p-4 sm:p-6" aria-labelledby="email-compose-heading">
          <div className="mb-4 flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-soft text-amber-deep"><Mail className="h-5 w-5" aria-hidden="true" /></span>
            <div>
              <h2 id="email-compose-heading" className="font-serif text-2xl text-forest-900">Compose message</h2>
              <p className="text-sm text-ink-muted">Plain text · sent immediately</p>
            </div>
          </div>
          <div className="space-y-4">
            <Field label="Subject" htmlFor="parent-email-subject" required>
              <input id="parent-email-subject" className="input" value={subject} maxLength={200} onChange={(event) => setSubject(event.target.value)} />
            </Field>
            <Field label="Message" htmlFor="parent-email-message" required hint={`${message.length}/10,000 characters`}>
              <textarea id="parent-email-message" className="input min-h-56 resize-y" value={message} maxLength={10000} onChange={(event) => setMessage(event.target.value)} />
            </Field>
            <BusyButton
              type="button"
              className="btn-primary min-h-11 w-full"
              busy={false}
              disabled={loading || Boolean(loadError) || recipientCount === 0 || !subject.trim() || !message.trim()}
              onClick={() => {
                setConfirmationOpen(true);
              }}
            >
              <Send className="h-4 w-4" aria-hidden="true" />
              Queue email for {recipientCount} parent{recipientCount === 1 ? "" : "s"}
            </BusyButton>
          </div>
        </section>
      </div>

      <ChildNotificationDelivery />

      <ConfirmDialog
        open={confirmationOpen}
        onClose={() => setConfirmationOpen(false)}
        title="Queue this email for delivery?"
        confirmLabel={`Queue for ${recipientCount} parent${recipientCount === 1 ? "" : "s"}`}
        busyLabel="Queuing..."
        tone="primary"
        onConfirm={async () => {
          await sendEmail();
          setConfirmationOpen(false);
        }}
      >
        <p>This message will be queued for prompt backend delivery to {allParents ? "all subscribed, verified parents" : `${recipientCount} selected parent${recipientCount === 1 ? "" : "s"}`}.</p>
        <p><span className="font-semibold text-ink">Subject:</span> {subject}</p>
      </ConfirmDialog>
    </div>
  );
}
