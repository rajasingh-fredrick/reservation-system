"use client";

import { useEffect, useMemo, useState } from "react";
import { Download, Printer, RefreshCw, Search } from "lucide-react";
import { api, ApiRequestError, errorMessage, formatDateTime, safeTz } from "@/lib/client";
import { INSTRUMENTS } from "@/lib/contracts";
import { useAdminData } from "@/components/shell/AdminProvider";
import { EmptyState, PageHeader } from "@/components/ui/Bits";
import { InlineError } from "@/components/ui/Feedback";

type RosterRow = {
  id: string;
  status: string;
  instrument: string;
  spot_number: number;
  created_at: string;
  child_name: string;
  parent_name: string;
  parent_email: string;
  parent_phone: string;
  season_id: string;
  season_name: string;
  timezone: string;
  event_id: string;
  event_name: string;
  starts_at: string;
  ends_at: string;
  song_id: string;
  song_title: string;
};

type Filters = { season: string; date: string; song: string; instrument: string; child: string; parent: string; status: string };
const emptyFilters: Filters = { season: "", date: "", song: "", instrument: "", child: "", parent: "", status: "" };

export function ReservationRoster() {
  const adminData = useAdminData();
  const [filters, setFilters] = useState<Filters>(emptyFilters);
  const [applied, setApplied] = useState<Filters>(emptyFilters);
  const [reservations, setReservations] = useState<RosterRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [requestId, setRequestId] = useState(0);

  const queryString = useMemo(() => {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(applied)) if (value) params.set(key, value);
    return params.toString();
  }, [applied]);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    void api<{ reservations: RosterRow[] }>(`/api/admin/reservations${queryString ? `?${queryString}` : ""}`, { signal: controller.signal })
      .then((result) => setReservations(result.reservations))
      .catch((err: unknown) => {
        if (err instanceof DOMException && err.name === "AbortError") return;
        if (err instanceof ApiRequestError && err.status === 401) return;
        setError(errorMessage(err));
      })
      .finally(() => setLoading(false));
    return () => controller.abort();
  }, [queryString, requestId]);

  function setFilter(key: keyof Filters, value: string) {
    setFilters((current) => ({ ...current, [key]: value }));
  }

  function exportCsv() {
    const params = new URLSearchParams(queryString);
    params.set("format", "csv");
    window.location.assign(`/api/admin/reservations?${params.toString()}`);
  }

  return (
    <div>
      <PageHeader eyebrow="Registrations" title="Reservation roster" description="Review registrations by season, event, song, instrument, child, parent, or status. Exported details are restricted to administrators." actions={
        <><button type="button" className="btn-secondary min-h-11 print:hidden" onClick={() => window.print()}><Printer className="h-4 w-4" aria-hidden="true" />Print roster</button><button type="button" className="btn-primary min-h-11 print:hidden" onClick={exportCsv}><Download className="h-4 w-4" aria-hidden="true" />Export CSV</button></>
      } />
      <form className="mb-5 rounded-2xl border border-parchment-300 bg-parchment-50 p-4 shadow-[var(--shadow-card)] print:hidden" onSubmit={(event) => { event.preventDefault(); setApplied({ ...filters }); }}>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div><label htmlFor="roster-season" className="field-label">Season</label><select id="roster-season" className="input" value={filters.season} onChange={(event) => setFilter("season", event.target.value)}><option value="">All seasons</option>{adminData.seasons.map((season) => <option key={season.id} value={season.id}>{season.name}</option>)}</select></div>
          <div><label htmlFor="roster-date" className="field-label">Event date</label><input id="roster-date" type="date" className="input" value={filters.date} onChange={(event) => setFilter("date", event.target.value)} /></div>
          <div><label htmlFor="roster-song" className="field-label">Song</label><select id="roster-song" className="input" value={filters.song} onChange={(event) => setFilter("song", event.target.value)}><option value="">All songs</option>{adminData.songs.map((song) => <option key={song.id} value={song.id}>{song.title}</option>)}</select></div>
          <div><label htmlFor="roster-instrument" className="field-label">Instrument</label><select id="roster-instrument" className="input" value={filters.instrument} onChange={(event) => setFilter("instrument", event.target.value)}><option value="">All instruments</option>{INSTRUMENTS.map((instrument) => <option key={instrument}>{instrument}</option>)}</select></div>
          <div><label htmlFor="roster-child" className="field-label">Child</label><input id="roster-child" className="input" value={filters.child} onChange={(event) => setFilter("child", event.target.value)} placeholder="Search child name" /></div>
          <div><label htmlFor="roster-parent" className="field-label">Parent</label><input id="roster-parent" className="input" value={filters.parent} onChange={(event) => setFilter("parent", event.target.value)} placeholder="Name or email" /></div>
          <div><label htmlFor="roster-status" className="field-label">Status</label><select id="roster-status" className="input" value={filters.status} onChange={(event) => setFilter("status", event.target.value)}><option value="">Any status</option><option>Confirmed</option><option>Cancelled</option><option>Admin cancelled</option></select></div>
          <div className="flex items-end gap-2"><button type="submit" className="btn-primary min-h-11 flex-1"><Search className="h-4 w-4" aria-hidden="true" />Apply filters</button><button type="button" className="btn-secondary min-h-11" onClick={() => { setFilters(emptyFilters); setApplied(emptyFilters); }}>Clear</button></div>
        </div>
      </form>
      {error ? <InlineError message={error} className="mb-4" /> : null}
      <div className="mb-3 flex items-center justify-between gap-3"><p className="text-sm text-ink-muted">{reservations.length} records</p><button type="button" className="icon-btn print:hidden" aria-label="Refresh roster" onClick={() => setRequestId((value) => value + 1)} disabled={loading}><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} aria-hidden="true" /></button></div>
      {loading ? <p className="card p-5 text-sm text-ink-muted" role="status">Loading roster…</p> : null}
      {!loading && !reservations.length ? <EmptyState title="No reservations match">Change a filter or choose another season.</EmptyState> : null}
      <div className="grid gap-3 md:grid-cols-2 print:grid-cols-1">
        {reservations.map((item) => <article key={item.id} className="break-inside-avoid rounded-2xl border border-parchment-300 bg-parchment-50 p-4 shadow-[var(--shadow-card)] print:border-black print:shadow-none">
          <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-xs font-semibold uppercase tracking-wide text-forest-800">{item.season_name}</p><h2 className="mt-1 font-semibold text-forest-900">{item.child_name} · {item.instrument}</h2></div><span className="chip border-parchment-300 bg-white text-ink-soft">{item.status}</span></div>
          <p className="mt-2 text-sm text-ink">{item.event_name} · {formatDateTime(item.starts_at, safeTz(item.timezone))}</p>
          <p className="mt-1 text-sm text-ink-muted">{item.song_title} · spot {item.spot_number}</p>
          <div className="mt-3 border-t border-parchment-200 pt-3 text-sm"><p className="font-medium text-ink">{item.parent_name}</p><a href={`mailto:${item.parent_email}`} className="text-forest-800 underline-offset-4 hover:underline">{item.parent_email}</a>{item.parent_phone ? <p className="mt-1 text-ink-muted">{item.parent_phone}</p> : null}</div>
        </article>)}
      </div>
    </div>
  );
}