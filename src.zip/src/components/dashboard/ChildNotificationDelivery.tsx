"use client";

import { useCallback, useEffect, useState } from "react";
import { api, errorMessage } from "@/lib/client";
import { InlineError, Notice } from "@/components/ui/Feedback";

type Delivery = {
  id: string; kind: string; status: string; attempts: number;
  parent_name: string; child_name: string;
};
type AutomatedDelivery = Omit<Delivery, "child_name"> & { season_name: string; event_name: string | null };
type ImmediateDelivery = Omit<Delivery, "child_name">;

export function ChildNotificationDelivery() {
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [automated, setAutomated] = useState<AutomatedDelivery[]>([]);
  const [immediate, setImmediate] = useState<ImmediateDelivery[]>([]);
  const load = useCallback(async (signal?: AbortSignal) => {
    const response = await api<{ notifications: Delivery[]; automatedNotifications: AutomatedDelivery[]; immediateNotifications: ImmediateDelivery[] }>("/api/admin/notifications/children", { signal });
    setDeliveries(response.notifications);
    setAutomated(response.automatedNotifications);
    setImmediate(response.immediateNotifications);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal).catch((err: unknown) => {
      if (err instanceof DOMException && err.name === "AbortError") return;
      setError(errorMessage(err));
    }).finally(() => setLoading(false));
    return () => controller.abort();
  }, [load]);

  async function refresh() {
    setBusy(true);
    setError(null);
    try { await load(); }
    catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  async function retry(id: string) {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const response = await api<{ status: string }>("/api/admin/notifications/children", { method: "POST", json: { id } });
      setResult(`Notification status: ${response.status}. Pending retries are delivered by the backend worker.`);
      await load();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  }

  return (
    <section className="card mt-6 p-4 sm:p-6" aria-labelledby="child-notification-heading">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 id="child-notification-heading" className="font-serif text-2xl text-forest-900">Child-profile emails</h2>
        <button type="button" className="btn-secondary" disabled={busy || loading} onClick={() => void refresh()}>Refresh delivery status</button>
      </div>
      <p className="mt-2 text-sm text-ink-muted">Latest 100 records, with pending and failed deliveries first. Sent means accepted by SMTP, not guaranteed inbox delivery. Preview means development log only.</p>
      <Notice className="mt-3">Sending records may have an uncertain outcome after an interruption. Check the mail provider before any manual recovery; they are not automatically retried.</Notice>
      <InlineError message={error} className="mt-3" />
      {result ? <p role="status" className="mt-3 text-sm text-ink">{result}</p> : null}
      {loading ? <p role="status" className="mt-3">Loading delivery records...</p> : null}
      {!loading && !error && !deliveries.length ? <p className="mt-3 text-sm text-ink-muted">No child-profile emails recorded yet.</p> : null}
      <ul className="mt-4 divide-y divide-parchment-200">
        {deliveries.map((delivery) => (
          <li key={delivery.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
            <div className="min-w-0 break-words text-sm text-ink">
              <p className="font-semibold">{delivery.kind}: {delivery.parent_name} / {delivery.child_name}</p>
              <p>{delivery.status} - {delivery.attempts} attempt(s)</p>
            </div>
            {delivery.status === "Pending" || delivery.status === "Failed" ? (
              <button type="button" className="btn-secondary" disabled={busy || loading} aria-label={`Retry ${delivery.kind.toLowerCase()} email for ${delivery.child_name}`} onClick={() => void retry(delivery.id)}>Queue retry</button>
            ) : null}
          </li>
        ))}
      </ul>
      <h3 className="mt-6 font-semibold text-forest-900">Account, reservation, profile-decision, and ministry emails</h3>
      <p className="mt-2 text-sm text-ink-muted">The immediate backend worker delivers pending emails and retries failures with backoff. Skipped means expired or no longer eligible. Message contents and security links are not displayed.</p>
      <ul className="mt-3 divide-y divide-parchment-200">
        {immediate.map((delivery) => (
          <li key={delivery.id} className="py-3 text-sm text-ink">
            <p className="font-semibold">{delivery.kind}: {delivery.parent_name}</p>
            <p>{delivery.status} - {delivery.attempts} attempt(s)</p>
          </li>
        ))}
      </ul>
      <h3 className="mt-6 font-semibold text-forest-900">Automated announcements and reminders</h3>
      <p className="mt-2 text-sm text-ink-muted">The hourly job retries failed deliveries. Skipped means not currently eligible. Sending needs operator review before recovery.</p>
      <ul className="mt-3 divide-y divide-parchment-200">
        {automated.map((delivery) => (
          <li key={delivery.id} className="py-3 text-sm text-ink">
            <p className="font-semibold">{delivery.kind}: {delivery.parent_name} / {delivery.event_name || delivery.season_name}</p>
            <p>{delivery.status} - {delivery.attempts} attempt(s)</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
