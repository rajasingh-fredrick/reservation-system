import { isValidElement, type ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { api } from "@/lib/client";
import { AdminEmailComposer } from "./AdminEmailComposer";

const hooks = vi.hoisted(() => ({ values: [] as unknown[], index: 0, toast: vi.fn() }));
vi.mock("@/lib/client", async (original) => ({
  ...await original<typeof import("@/lib/client")>(), api: vi.fn(),
}));
vi.mock("@/components/ui/Feedback", async (original) => ({
  ...await original<typeof import("@/components/ui/Feedback")>(), useToast: () => hooks.toast,
}));
vi.mock("react", async (original) => ({
  ...await original<typeof import("react")>(),
  useEffect: vi.fn(),
  useMemo: (factory: () => unknown) => factory(),
  useState: (initial: unknown) => {
    const index = hooks.index++;
    if (!(index in hooks.values)) hooks.values[index] = initial;
    return [hooks.values[index], (value: unknown) => { hooks.values[index] = value; }];
  },
}));
type Props = { children?: ReactNode; onConfirm?: () => Promise<void> };
function elements(node: ReactNode): Props[] {
  if (Array.isArray(node)) return node.flatMap(elements);
  if (!isValidElement<Props>(node)) return [];
  return [node.props, ...elements(node.props.children)];
}
function confirmation() {
  hooks.index = 0;
  return elements(AdminEmailComposer()).find((props) => props.onConfirm)!.onConfirm!;
}
beforeEach(() => {
  hooks.values = [[{ id: "parent", name: "Parent", email: "parent@example.test" }],
    false, null, "", ["parent"], false, "Subject", "Message", null, true];
  hooks.toast.mockReset();
  vi.mocked(api).mockReset();
});

describe("administrator queued email feedback", () => {
  it("reports queued acceptance without claiming the email was sent", async () => {
    vi.mocked(api).mockResolvedValue({ queuedCount: 1, totalCount: 1 });
    await confirmation()();
    expect(api).toHaveBeenCalledWith("/api/admin/notifications/email", {
      method: "POST", json: { allParents: false, recipientIds: ["parent"], subject: "Subject", message: "Message" },
    });
    expect(hooks.toast).toHaveBeenCalledWith("success", "Email queued for 1 parent.");
    expect(hooks.values[4]).toEqual([]);
    expect(hooks.values[8]).toContain("queued");
    expect(hooks.values[8]).not.toContain("Email sent");
  });

  it("retains selected recipients and propagates enqueue errors to the confirmation dialog", async () => {
    vi.mocked(api).mockRejectedValue(new Error("Queue unavailable"));
    await expect(confirmation()()).rejects.toThrow("Queue unavailable");
    expect(hooks.toast).not.toHaveBeenCalled();
    expect(hooks.values[4]).toEqual(["parent"]);
    expect(hooks.values[8]).toBeNull();
  });
});
