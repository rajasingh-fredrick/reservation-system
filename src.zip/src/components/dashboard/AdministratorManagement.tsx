"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import { KeyRound, RefreshCw, ShieldCheck, UserRoundMinus } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { useAdmin } from "@/components/shell/AdminProvider";
import { ConfirmDialog } from "@/components/ui/Confirm";
import { EmptyState, PageHeader } from "@/components/ui/Bits";
import { InlineError, Notice } from "@/components/ui/Feedback";

type Administrator = { id: string; name: string; email: string; email_verified: boolean; granted_at: string };

export function AdministratorManagement() {
  const { user } = useAdmin();
  const [administrators, setAdministrators] = useState<Administrator[]>([]);
  const [email, setEmail] = useState("");
  const [revokeTarget, setRevokeTarget] = useState<Administrator | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const refresh = useCallback(async (signal?: AbortSignal) => {
    const result = await api<{ administrators: Administrator[] }>("/api/admin/administrators", { signal });
    setAdministrators(result.administrators);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void refresh(controller.signal).catch((err: unknown) => {
      if (err instanceof DOMException && err.name === "AbortError") return;
      setError(errorMessage(err));
    }).finally(() => setLoading(false));
    return () => controller.abort();
  }, [refresh]);

  async function grant(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api("/api/admin/administrators", { method: "POST", json: { email: email.trim() } });
      setEmail("");
      setNotice("Administrator access granted and recorded.");
      await refresh();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function revoke() {
    if (!revokeTarget) return;
    await api(`/api/admin/administrators/${revokeTarget.id}`, { method: "DELETE", json: {} });
    await refresh();
    setRevokeTarget(null);
  }

  return (
    <div>
      <PageHeader eyebrow="Security" title="Administrator access" description="Grant access only to existing accounts with verified email addresses. Changes are recorded in the activity log." />
      {notice ? <Notice tone="success" className="mb-4">{notice}</Notice> : null}
      <InlineError message={error} className="mb-4" />
      <form onSubmit={grant} className="mb-7 rounded-2xl border border-parchment-300 bg-parchment-50 p-4 shadow-[var(--shadow-card)] sm:p-5">
        <label htmlFor="admin-email" className="field-label">Verified account email</label>
        <div className="flex flex-col gap-2 sm:flex-row"><input id="admin-email" type="email" className="input min-w-0 flex-1" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={320} disabled={busy} /><button type="submit" className="btn-primary min-h-11 shrink-0" disabled={busy} aria-busy={busy}><ShieldCheck className="h-4 w-4" aria-hidden="true" />{busy ? "Granting…" : "Grant administrator access"}</button></div>
        <p className="field-hint">New users must register and verify their email before they can be granted administrator access.</p>
      </form>
      {loading ? <p className="card p-5 text-sm text-ink-muted" role="status">Loading administrators…</p> : null}
      {!loading && !administrators.length ? <EmptyState art={<KeyRound className="h-9 w-9 text-forest-700" aria-hidden="true" />} title="No administrators">This should only occur before initial administrator setup.</EmptyState> : null}
      <ul className="space-y-3">
        {administrators.map((administrator) => <li key={administrator.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-parchment-300 bg-parchment-50 p-4 shadow-[var(--shadow-card)]">
          <div className="min-w-0"><p className="truncate font-semibold text-forest-900">{administrator.name}{administrator.id === user?.id ? " · You" : ""}</p><p className="truncate text-sm text-ink-soft">{administrator.email}</p><p className="mt-1 text-xs text-ink-muted">Granted {new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(new Date(administrator.granted_at))} · verified</p></div>
          <button type="button" className="btn-danger-ghost min-h-11" onClick={() => setRevokeTarget(administrator)}><UserRoundMinus className="h-4 w-4" aria-hidden="true" />Revoke</button>
        </li>)}
      </ul>
      <ConfirmDialog open={Boolean(revokeTarget)} onClose={() => setRevokeTarget(null)} title="Revoke administrator access?" confirmLabel="Revoke access" busyLabel="Revoking…" onConfirm={revoke}>
        <p>Remove administrator access from {revokeTarget?.name} ({revokeTarget?.email})? The last active administrator cannot be removed.</p>
      </ConfirmDialog>
    </div>
  );
}