"use client";

import { useCallback, useEffect, useState } from "react";
import { Check, RefreshCw, ShieldAlert, UserRoundX } from "lucide-react";
import { api, errorMessage, formatDateTime, safeTz } from "@/lib/client";
import { EmptyState } from "@/components/ui/Bits";
import { InlineError, Notice } from "@/components/ui/Feedback";

type ReviewReservation = {
  id: string;
  review_reason: string | null;
  instrument: string;
  spot_number: number;
  child_name: string;
  parent_name: string;
  parent_email: string;
  season_name: string;
  timezone: string;
  event_name: string;
  starts_at: string;
  song_title: string;
};

export function ReservationReviewQueue() {
  const [reservations, setReservations] = useState<ReviewReservation[]>([]);
  const [explanations, setExplanations] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notificationWarning, setNotificationWarning] = useState(false);

  const refresh = useCallback(async (signal?: AbortSignal) => {
    const result = await api<{ reservations: ReviewReservation[] }>("/api/admin/reservations/review", { signal });
    setReservations(result.reservations);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void refresh(controller.signal).catch((err: unknown) => {
      if (err instanceof DOMException && err.name === "AbortError") return;
      setError(errorMessage(err));
    }).finally(() => setLoading(false));
    return () => controller.abort();
  }, [refresh]);

  async function decide(item: ReviewReservation, action: "keep" | "cancel") {
    const explanation = explanations[item.id]?.trim() ?? "";
    if (action === "cancel" && !explanation) {
      setError("Explain the cancellation before removing a confirmed reservation.");
      return;
    }
    setBusyId(item.id);
    setError(null);
    setNotificationWarning(false);
    try {
      const result = await api<{ notificationQueued: boolean }>(`/api/admin/reservations/review/${item.id}`, {
        method: "PATCH",
        json: { action, ...(action === "cancel" ? { explanation } : {}) },
      });
      if (!result.notificationQueued) setNotificationWarning(true);
      await refresh();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section className="mt-10" aria-labelledby="reservation-review-title">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div><p className="eyebrow">Coordinator review</p><h2 id="reservation-review-title" className="mt-1 font-serif text-2xl text-forest-900">Reservations to review</h2><p className="mt-1 text-sm text-ink-soft">These bookings were preserved after a child profile change or archive.</p></div>
        <button type="button" className="btn-secondary min-h-11" onClick={() => void refresh()} disabled={loading || Boolean(busyId)}><RefreshCw className="h-4 w-4" aria-hidden="true" />Refresh</button>
      </div>
      {notificationWarning ? <Notice tone="warn" className="mb-4">The review decision was saved, but the family notification was not queued.</Notice> : null}
      <InlineError message={error} className="mb-4" />
      {loading ? <p className="card p-5 text-sm text-ink-muted" role="status">Loading reservations for review…</p> : null}
      {!loading && !reservations.length ? <EmptyState art={<Check className="h-9 w-9 text-forest-700" aria-hidden="true" />} title="No reservations need review">All confirmed reservations are up to date.</EmptyState> : null}
      <div className="space-y-3">
        {reservations.map((item) => <article key={item.id} className="rounded-2xl border border-amber-accent/40 bg-parchment-50 p-4 shadow-[var(--shadow-card)] sm:p-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
                <div><p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-amber-deep"><ShieldAlert className="h-4 w-4" aria-hidden="true" />Review required</p><h3 className="mt-1 font-serif text-lg text-forest-900">{item.child_name} · {item.instrument}</h3><p className="mt-1 text-sm text-ink-soft">{item.season_name} · {item.event_name} · {formatDateTime(item.starts_at, safeTz(item.timezone))}</p><p className="mt-1 text-sm text-ink-muted">{item.song_title} · spot {item.spot_number}</p></div>
            <div className="text-sm"><p className="font-medium text-ink">{item.parent_name}</p><a className="text-forest-800 underline-offset-4 hover:underline" href={`mailto:${item.parent_email}`}>{item.parent_email}</a></div>
          </div>
          {item.review_reason ? <p className="mt-3 rounded-xl bg-amber-soft/50 px-3 py-2 text-sm text-amber-deep">{item.review_reason}</p> : null}
          <div className="mt-4 border-t border-parchment-200 pt-3">
            <label htmlFor={`cancel-reason-${item.id}`} className="field-label">Cancellation explanation <span className="font-normal text-ink-muted">(required only if cancelling)</span></label>
            <textarea id={`cancel-reason-${item.id}`} className="input min-h-16 resize-y" maxLength={1000} value={explanations[item.id] ?? ""} onChange={(event) => setExplanations((current) => ({ ...current, [item.id]: event.target.value }))} disabled={busyId === item.id} />
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" className="btn-primary min-h-11" onClick={() => void decide(item, "keep")} disabled={Boolean(busyId)}>{busyId === item.id ? <RefreshCw className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Check className="h-4 w-4" aria-hidden="true" />}Keep reservation</button>
              <button type="button" className="btn-danger-ghost min-h-11" onClick={() => void decide(item, "cancel")} disabled={Boolean(busyId)}><UserRoundX className="h-4 w-4" aria-hidden="true" />Cancel with explanation</button>
            </div>
          </div>
        </article>)}
      </div>
    </section>
  );
}