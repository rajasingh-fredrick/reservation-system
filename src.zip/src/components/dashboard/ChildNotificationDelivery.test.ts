import { isValidElement, type ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { api } from "@/lib/client";
import { ChildNotificationDelivery } from "./ChildNotificationDelivery";

const hooks = vi.hoisted(() => ({
  values: [] as unknown[], index: 0,
  effects: [] as Array<() => void | (() => void)>,
}));
vi.mock("@/lib/client", async (original) => ({
  ...await original<typeof import("@/lib/client")>(), api: vi.fn(),
}));
vi.mock("react", async (original) => ({
  ...await original<typeof import("react")>(),
  useCallback: (callback: unknown) => callback,
  useEffect: (effect: () => void | (() => void)) => { hooks.effects.push(effect); },
  useState: (initial: unknown) => {
    const index = hooks.index++;
    if (!(index in hooks.values)) hooks.values[index] = initial;
    return [hooks.values[index], (value: unknown) => { hooks.values[index] = value; }];
  },
}));
type Props = {
  children?: ReactNode; message?: string | null; disabled?: boolean;
  "aria-label"?: string; onClick?: () => void;
};
function elements(node: ReactNode): Props[] {
  if (Array.isArray(node)) return node.flatMap(elements);
  if (!isValidElement<Props>(node)) return [];
  return [node.props, ...elements(node.props.children)];
}
function render() {
  hooks.index = 0;
  return elements(ChildNotificationDelivery());
}
function delivery(status: string) {
  return { id: status, kind: "Welcome", status, attempts: 1, parent_name: "Parent", child_name: `${status} Child` };
}
beforeEach(() => {
  hooks.values = [[], null, false, false, null];
  hooks.effects = [];
  vi.mocked(api).mockReset();
});

describe("child-profile delivery administration", () => {
  it("only offers retries for Pending and Failed records", () => {
    hooks.values[0] = ["Pending", "Failed", "Sending", "Sent", "Preview"].map(delivery);
    const controls = render().filter((props) => props["aria-label"]?.startsWith("Retry"));
    expect(controls.map((props) => props["aria-label"])).toEqual([
      "Retry welcome email for Pending Child", "Retry welcome email for Failed Child",
    ]);
  });

  it("retries the selected record, reloads status, and displays the actual outcome", async () => {
    hooks.values[0] = [delivery("Failed")];
    vi.mocked(api).mockResolvedValueOnce({ status: "Failed" })
      .mockResolvedValueOnce({ notifications: [delivery("Failed")] });
    render().find((props) => props["aria-label"] === "Retry welcome email for Failed Child")!.onClick!();
    expect(render().filter((props) => props["aria-label"]?.startsWith("Retry")).every((props) => props.disabled)).toBe(true);
    await vi.waitFor(() => expect(hooks.values[3]).toBe(false));
    expect(api).toHaveBeenNthCalledWith(1, "/api/admin/notifications/children", { method: "POST", json: { id: "Failed" } });
    expect(api).toHaveBeenNthCalledWith(2, "/api/admin/notifications/children", { signal: undefined });
    expect(render().some((props) => props.children === "Notification delivery status: Failed.")).toBe(true);
  });

  it("surfaces retry errors without claiming success", async () => {
    hooks.values[0] = [delivery("Failed")];
    vi.mocked(api).mockRejectedValueOnce(new Error("Retry unavailable"));
    render().find((props) => props["aria-label"]?.startsWith("Retry"))!.onClick!();
    await vi.waitFor(() => expect(hooks.values[3]).toBe(false));
    expect(render().some((props) => props.message === "Retry unavailable")).toBe(true);
    expect(hooks.values[4]).toBeNull();
  });

  it("surfaces initial loading errors and permits refresh", async () => {
    vi.mocked(api).mockRejectedValueOnce(new Error("Delivery status unavailable"))
      .mockResolvedValueOnce({ notifications: [delivery("Pending")] });
    render();
    hooks.effects[0]();
    await vi.waitFor(() => expect(hooks.values[1]).toBe("Delivery status unavailable"));
    render().find((props) => props.children === "Refresh delivery status")!.onClick!();
    await vi.waitFor(() => expect(hooks.values[0]).toEqual([delivery("Pending")]));
    expect(hooks.values[1]).toBeNull();
  });
});
