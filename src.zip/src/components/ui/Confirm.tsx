"use client";

import { useState, type ReactNode } from "react";
import { AlertTriangle, CalendarDays } from "lucide-react";
import type { Usage } from "@/lib/contracts";
import { browserTimeZone, errorMessage, formatDateTime, uniqueUsageEvents } from "@/lib/client";
import { Modal } from "./Modal";
import { BusyButton, InlineError } from "./Feedback";
import { StatusChip } from "./Bits";

export function ImpactList({ usages, title = "Affected events" }: { usages: Usage[]; title?: string }) {
  const events = uniqueUsageEvents(usages);
  if (events.length === 0) return null;
  return (
    <div className="mt-3 rounded-xl border border-amber-accent/40 bg-amber-soft/40 p-3">
      <p className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-amber-deep">
        <AlertTriangle className="h-4 w-4" aria-hidden="true" />
        {title} ({events.length})
      </p>
      <ul className="max-h-52 space-y-1.5 overflow-y-auto pr-1">
        {events.map((u) => (
          <li key={u.eventId} className="flex flex-wrap items-center gap-x-2 gap-y-1 rounded-lg bg-parchment-50/80 px-2.5 py-1.5 text-sm">
            <CalendarDays className="h-4 w-4 text-forest-700" aria-hidden="true" />
            <span className="font-medium text-ink">{u.eventName}</span>
            <span className="text-ink-muted">· {u.seasonName}</span>
            <span className="text-xs text-ink-muted">{formatDateTime(u.startsAt, browserTimeZone(), { dateStyle: "medium" })}</span>
            <StatusChip status={u.seasonStatus} className="ml-auto" />
          </li>
        ))}
      </ul>
    </div>
  );
}

export interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children?: ReactNode;
  confirmLabel: string;
  busyLabel?: string;
  tone?: "danger" | "primary";
  usages?: Usage[];
  /** Must throw on failure; dialog shows the message and stays open. */
  onConfirm: () => Promise<void>;
}

export function ConfirmDialog({ open, onClose, title, children, confirmLabel, busyLabel, tone = "danger", usages, onConfirm }: ConfirmDialogProps) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function confirm() {
    setBusy(true);
    setError(null);
    try {
      await onConfirm();
      onClose();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={() => {
        setError(null);
        onClose();
      }}
      title={title}
      size="sm"
      role="alertdialog"
      locked={busy}
      footer={
        <>
          <button type="button" className="btn-secondary" onClick={onClose} disabled={busy} data-autofocus>
            Cancel
          </button>
          <BusyButton type="button" busy={busy} busyLabel={busyLabel} className={tone === "danger" ? "btn-danger" : "btn-primary"} onClick={confirm}>
            {confirmLabel}
          </BusyButton>
        </>
      }
    >
      <div className="space-y-3 text-sm leading-relaxed text-ink-soft">
        {children}
        {usages && usages.length > 0 ? <ImpactList usages={usages} /> : null}
        <InlineError message={error} />
      </div>
    </Modal>
  );
}