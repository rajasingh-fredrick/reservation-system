"use client";

import type { ReactNode } from "react";
import clsx from "clsx";
import { Archive, CheckCircle2, CircleDashed, Globe2, Lock } from "lucide-react";
import type { SeasonStatus } from "@/lib/contracts";

const STATUS_STYLE: Record<SeasonStatus, { cls: string; Icon: typeof Globe2 }> = {
  Draft: { cls: "border-parchment-300 bg-parchment-100 text-ink-soft", Icon: CircleDashed },
  Published: { cls: "border-forest-300 bg-forest-50 text-forest-800", Icon: Globe2 },
  "Registration Closed": { cls: "border-amber-accent/50 bg-amber-soft text-amber-deep", Icon: Lock },
  Completed: { cls: "border-sage/50 bg-sage-soft text-forest-900", Icon: CheckCircle2 },
  Archived: { cls: "border-ink-muted/30 bg-parchment-200 text-ink-muted", Icon: Archive },
};

export function StatusChip({ status, className }: { status: SeasonStatus; className?: string }) {
  const s = STATUS_STYLE[status] ?? STATUS_STYLE.Draft;
  return (
    <span className={clsx("chip", s.cls, className)}>
      <s.Icon className="h-3.5 w-3.5" aria-hidden="true" />
      {status}
    </span>
  );
}

export function Tag({ children, tone = "neutral", icon, className }: { children: ReactNode; tone?: "neutral" | "forest" | "amber" | "sage" | "rose" | "muted"; icon?: ReactNode; className?: string }) {
  return (
    <span
      className={clsx(
        "chip",
        tone === "neutral" && "border-parchment-300 bg-parchment-50 text-ink-soft",
        tone === "forest" && "border-forest-300 bg-forest-50 text-forest-800",
        tone === "amber" && "border-amber-accent/50 bg-amber-soft text-amber-deep",
        tone === "sage" && "border-sage/50 bg-sage-soft text-forest-900",
        tone === "rose" && "border-rose-deep/30 bg-rose-soft text-rose-deep",
        tone === "muted" && "border-ink-muted/25 bg-parchment-200 text-ink-muted",
        className,
      )}
    >
      {icon}
      {children}
    </span>
  );
}

export function EmptyState({
  art,
  title,
  children,
  action,
  className,
}: {
  art?: ReactNode;
  title: string;
  children?: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx("card staff-lines relative overflow-hidden px-6 py-10 text-center sm:py-14", className)}>
      {art ? <div className="mx-auto mb-5 flex justify-center">{art}</div> : null}
      <h3 className="text-2xl font-semibold text-forest-900">{title}</h3>
      {children ? <div className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-ink-soft">{children}</div> : null}
      {action ? <div className="mt-6 flex flex-wrap justify-center gap-2">{action}</div> : null}
    </div>
  );
}

export function PageHeader({ eyebrow, title, description, actions }: { eyebrow?: string; title: ReactNode; description?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        {eyebrow ? <p className="eyebrow mb-1.5">{eyebrow}</p> : null}
        <h1 className="text-3xl font-semibold tracking-tight text-forest-900 sm:text-4xl">{title}</h1>
        {description ? <p className="mt-2 max-w-2xl text-[0.95rem] leading-relaxed text-ink-soft">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </div>
  );
}

export function StatCard({ label, value, hint, icon, tone = "forest" }: { label: string; value: ReactNode; hint?: ReactNode; icon: ReactNode; tone?: "forest" | "amber" | "sage" }) {
  return (
    <div className="card relative overflow-hidden p-4 sm:p-5">
      <div
        className={clsx(
          "mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl",
          tone === "forest" && "bg-forest-800 text-parchment-50",
          tone === "amber" && "bg-amber-soft text-amber-deep",
          tone === "sage" && "bg-sage-soft text-forest-800",
        )}
      >
        {icon}
      </div>
      <p className="font-serif text-3xl font-semibold leading-none text-forest-900">{value}</p>
      <p className="mt-1.5 text-sm font-medium text-ink-soft">{label}</p>
      {hint ? <p className="mt-1 text-xs text-ink-muted">{hint}</p> : null}
    </div>
  );
}

export function Field({
  label,
  htmlFor,
  hint,
  error,
  children,
  required,
  className,
}: {
  label: ReactNode;
  htmlFor: string;
  hint?: ReactNode;
  error?: string | null;
  children: ReactNode;
  required?: boolean;
  className?: string;
}) {
  return (
    <div className={clsx("flex flex-col gap-1.5", className)}>
      <label htmlFor={htmlFor} className="field-label">
        {label}
        {required ? <span className="ml-0.5 text-rose-deep" aria-hidden="true">*</span> : null}
      </label>
      {children}
      {error ? (
        <p id={`${htmlFor}-error`} className="text-xs font-medium text-rose-deep">
          {error}
        </p>
      ) : hint ? (
        <p id={`${htmlFor}-hint`} className="field-hint">
          {hint}
        </p>
      ) : null}
    </div>
  );
}

export function SkeletonBlock({ className }: { className?: string }) {
  return <div className={clsx("skeleton rounded-2xl", className)} aria-hidden="true" />;
}

export function WorkspaceSkeleton() {
  return (
    <div role="status" aria-label="Loading workspace" className="space-y-6">
      <SkeletonBlock className="h-10 w-64" />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <SkeletonBlock key={i} className="h-32" />
        ))}
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <SkeletonBlock key={i} className="h-44" />
        ))}
      </div>
    </div>
  );
}

