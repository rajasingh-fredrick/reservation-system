"use client";

import { useEffect, useId, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import clsx from "clsx";

const FOCUSABLE =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"]), summary';

let openCount = 0;

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  /** dialog = centered card, drawer = right sheet, left = left navigation sheet */
  variant?: "dialog" | "drawer" | "left";
  size?: "sm" | "md" | "lg" | "xl";
  /** Prevent closing (e.g. while a request is in flight). */
  locked?: boolean;
  initialFocus?: React.RefObject<HTMLElement | null>;
  role?: "dialog" | "alertdialog";
  eyebrow?: ReactNode;
}

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  variant = "dialog",
  size = "md",
  locked = false,
  initialFocus,
  role = "dialog",
  eyebrow,
}: ModalProps) {
  const panelRef = useRef<HTMLDivElement>(null);
  const restoreRef = useRef<HTMLElement | null>(null);
  const closeRef = useRef(onClose);
  const lockedRef = useRef(locked);
  closeRef.current = onClose;
  lockedRef.current = locked;
  const titleId = useId();
  const descId = useId();

  useEffect(() => {
    if (!open) return;
    restoreRef.current = document.activeElement as HTMLElement | null;
    openCount += 1;
    document.body.style.overflow = "hidden";
    const frame = requestAnimationFrame(() => {
      const panel = panelRef.current;
      if (!panel) return;
      const target =
        initialFocus?.current ??
        panel.querySelector<HTMLElement>("[data-autofocus]") ??
        panel.querySelector<HTMLElement>(FOCUSABLE);
      (target ?? panel).focus();
    });

    function onKey(e: KeyboardEvent) {
      const panel = panelRef.current;
      if (!panel) return;
      // Only the top-most modal reacts.
      const all = document.querySelectorAll("[data-harmony-modal]");
      if (all[all.length - 1] !== panel) return;
      if (e.key === "Escape") {
        e.stopPropagation();
        if (!lockedRef.current) closeRef.current();
        return;
      }
      if (e.key !== "Tab") return;
      const items = Array.from(panel.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
        (el) => el.offsetParent !== null || el === document.activeElement,
      );
      if (items.length === 0) {
        e.preventDefault();
        panel.focus();
        return;
      }
      const first = items[0];
      const last = items[items.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === panel)) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", onKey, true);
    return () => {
      cancelAnimationFrame(frame);
      document.removeEventListener("keydown", onKey, true);
      openCount -= 1;
      if (openCount <= 0) {
        openCount = 0;
        document.body.style.overflow = "";
      }
      const restore = restoreRef.current;
      if (restore && document.contains(restore)) restore.focus();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  if (!open || typeof document === "undefined") return null;

  const widths = { sm: "max-w-md", md: "max-w-xl", lg: "max-w-3xl", xl: "max-w-5xl" } as const;

  const panelClass = clsx(
    "relative flex max-h-full flex-col bg-parchment-50 shadow-2xl outline-none",
    variant === "dialog" && ["gradient-surface anim-pop w-full rounded-3xl border border-parchment-300 max-h-[min(92dvh,900px)]", widths[size]],
    variant === "drawer" && ["gradient-surface anim-slide ml-auto h-full w-full border-l border-parchment-300", widths[size]],
    variant === "left" && "anim-slide-left mr-auto h-full w-[min(86vw,320px)] sidebar-texture text-ink",
  );

  return createPortal(
    <div
      className={clsx(
        "fixed inset-0 z-50 flex",
        variant === "dialog" && "items-end justify-center p-3 sm:items-center sm:p-6",
      )}
    >
      <div
        className="anim-fade absolute inset-0 bg-forest-950/45 backdrop-blur-[2px]"
        aria-hidden="true"
        onMouseDown={() => {
          if (!locked) onClose();
        }}
      />
      <div
        ref={panelRef}
        data-harmony-modal=""
        role={role}
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descId : undefined}
        tabIndex={-1}
        className={panelClass}
      >
        <header
          className={clsx(
            "flex items-start gap-3 px-5 pb-3 pt-5 sm:px-6",
            variant !== "left" && "border-b border-parchment-200",
          )}
        >
          <div className="min-w-0 flex-1">
            {eyebrow ? <p className={clsx("eyebrow mb-1", variant === "left" && "text-ink")}>{eyebrow}</p> : null}
            <h2 id={titleId} className={clsx("text-xl font-semibold leading-tight sm:text-2xl", variant === "left" ? "text-ink" : "text-forest-900")}>
              {title}
            </h2>
            {description ? (
              <p id={descId} className={clsx("mt-1 text-sm", variant === "left" ? "text-ink" : "text-ink-soft")}>
                {description}
              </p>
            ) : null}
          </div>
          <button
            type="button"
            className={clsx("icon-btn -mr-1 shrink-0", variant === "left" && "text-ink hover:bg-white/10 hover:text-forest-900")}
            onClick={onClose}
            disabled={locked}
            aria-label="Close"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </header>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4 sm:px-6">{children}</div>
        {footer ? (
          <footer className="gradient-surface flex flex-wrap items-center justify-end gap-2 border-t border-parchment-200 px-5 py-3 sm:px-6">
            {footer}
          </footer>
        ) : null}
      </div>
    </div>,
    document.body,
  );
}