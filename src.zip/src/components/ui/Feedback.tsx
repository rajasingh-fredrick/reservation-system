"use client";

import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Info, Loader2, X } from "lucide-react";
import clsx from "clsx";

type ToastTone = "success" | "error" | "info";
interface Toast {
  id: number;
  tone: ToastTone;
  message: string;
}

const ToastContext = createContext<(tone: ToastTone, message: string) => void>(() => undefined);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const nextId = useRef(1);
  const dismiss = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const push = useCallback(
    (tone: ToastTone, message: string) => {
      const id = nextId.current++;
      setToasts((t) => [...t.slice(-3), { id, tone, message }]);
      window.setTimeout(() => dismiss(id), tone === "error" ? 9000 : 5000);
    },
    [dismiss],
  );
  return (
    <ToastContext.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-3 z-[70] flex flex-col items-center gap-2 px-3 sm:bottom-6 sm:items-end sm:px-6">
        <div role="status" aria-live="polite" className="contents">
          {toasts
            .filter((t) => t.tone !== "error")
            .map((t) => (
              <ToastCard key={t.id} toast={t} onDismiss={() => dismiss(t.id)} />
            ))}
        </div>
        <div role="alert" aria-live="assertive" className="contents">
          {toasts
            .filter((t) => t.tone === "error")
            .map((t) => (
              <ToastCard key={t.id} toast={t} onDismiss={() => dismiss(t.id)} />
            ))}
        </div>
      </div>
    </ToastContext.Provider>
  );
}

function ToastCard({ toast, onDismiss }: { toast: Toast; onDismiss: () => void }) {
  const Icon = toast.tone === "success" ? CheckCircle2 : toast.tone === "error" ? AlertTriangle : Info;
  return (
    <div
      className={clsx(
        "anim-pop pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-2xl border px-4 py-3 text-sm shadow-[var(--shadow-lift)]",
        toast.tone === "success" && "border-forest-300 gradient-tint text-forest-900",
        toast.tone === "error" && "border-rose-deep/30 bg-rose-soft text-rose-deep",
        toast.tone === "info" && "border-parchment-300 bg-parchment-50 text-ink",
      )}
    >
      <Icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
      <p className="flex-1 font-medium">{toast.message}</p>
      <button type="button" onClick={onDismiss} className="-m-1 rounded p-1 opacity-70 hover:opacity-100" aria-label="Dismiss notification">
        <X className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
  );
}

export function useToast() {
  return useContext(ToastContext);
}

export function InlineError({ message, className }: { message: string | null | undefined; className?: string }) {
  if (!message) return null;
  return (
    <div role="alert" className={clsx("flex items-start gap-2 rounded-xl border border-rose-deep/25 bg-rose-soft px-3 py-2.5 text-sm text-rose-deep", className)}>
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
      <span>{message}</span>
    </div>
  );
}

export function Notice({ children, tone = "info", className, icon }: { children: ReactNode; tone?: "info" | "warn" | "success"; className?: string; icon?: ReactNode }) {
  return (
    <div
      className={clsx(
        "flex items-start gap-2.5 rounded-xl border px-3.5 py-3 text-sm",
        tone === "info" && "border-forest-100 gradient-tint text-forest-900",
        tone === "warn" && "border-amber-accent/40 bg-amber-soft/60 text-amber-deep",
        tone === "success" && "border-forest-300 gradient-tint text-forest-800",
        className,
      )}
    >
      {icon ?? (tone === "warn" ? <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" /> : <Info className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />)}
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}

export function Spinner({ className, label }: { className?: string; label?: string }) {
  return (
    <>
      <Loader2 className={clsx("h-4 w-4 animate-spin", className)} aria-hidden="true" />
      {label ? <span className="sr-only">{label}</span> : null}
    </>
  );
}

export function BusyButton({
  busy,
  children,
  busyLabel,
  className = "btn-primary",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { busy?: boolean; busyLabel?: string }) {
  return (
    <button {...rest} className={className} disabled={busy || rest.disabled} aria-busy={busy || undefined}>
      {busy ? <Spinner /> : null}
      {busy && busyLabel ? busyLabel : children}
    </button>
  );
}

export function useAsyncAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const run = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    setBusy(true);
    setError(null);
    try {
      return await fn();
    } finally {
      setBusy(false);
    }
  }, []);
  return useMemo(() => ({ busy, error, setError, run }), [busy, error, run]);
}