import clsx from "clsx";

/** Original Harmony mark: a five-line staff carrying two beamed notes. */
export function HarmonyMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true" focusable="false">
      <rect width="48" height="48" rx="14" fill="#1d3a28" />
      <g stroke="#e9dcbf" strokeOpacity="0.35" strokeWidth="1.2">
        <path d="M8 16h32M8 21h32M8 26h32M8 31h32M8 36h32" />
      </g>
      <path d="M20 13v19.5M33 10v19.5" stroke="#e3a33b" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M20 13l13-3v4.2l-13 3z" fill="#e3a33b" />
      <ellipse cx="16.4" cy="33" rx="4.6" ry="3.4" transform="rotate(-22 16.4 33)" fill="#f5c46c" />
      <ellipse cx="29.4" cy="30" rx="4.6" ry="3.4" transform="rotate(-22 29.4 30)" fill="#f5c46c" />
    </svg>
  );
}

/** Flowing staff with scattered notes, used behind heroes. */
export function StaffFlourish({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 520 160" className={clsx("pointer-events-none", className)} aria-hidden="true" focusable="false" fill="none">
      <g stroke="currentColor" strokeWidth="1" opacity="0.35">
        {[0, 1, 2, 3, 4].map((i) => (
          <path key={i} d={`M0 ${50 + i * 12} C 130 ${20 + i * 12}, 260 ${100 + i * 12}, 520 ${46 + i * 12}`} />
        ))}
      </g>
      <g fill="currentColor" opacity="0.55">
        <ellipse cx="96" cy="66" rx="7" ry="5" transform="rotate(-20 96 66)" />
        <path d="M102 64V30" stroke="currentColor" strokeWidth="2" />
        <ellipse cx="214" cy="84" rx="7" ry="5" transform="rotate(-20 214 84)" />
        <ellipse cx="248" cy="74" rx="7" ry="5" transform="rotate(-20 248 74)" />
        <path d="M220 82V46M254 72V38M220 46l34-8v6l-34 8z" stroke="currentColor" strokeWidth="2" />
        <ellipse cx="380" cy="70" rx="7" ry="5" transform="rotate(-20 380 70)" />
        <path d="M386 68V34c6 4 14 8 12 18" stroke="currentColor" strokeWidth="2" />
      </g>
    </svg>
  );
}

/** Treble-clef inspired swirl (original drawing, not a font glyph). */
export function ClefSwirl({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 80 160" className={className} aria-hidden="true" focusable="false" fill="none">
      <path
        d="M44 150c-14 4-24-6-18-16 5-8 18-5 18 4 0 12-2 22-4 30M42 168V12c0-6 10-10 14 0 6 16-30 40-32 64-2 22 18 34 34 28 16-6 16-30-2-34-16-3-26 12-18 24"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/** Sheet-music page illustration for empty states. */
export function SheetStackArt({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 220 170" className={className} aria-hidden="true" focusable="false">
      <rect x="54" y="22" width="112" height="140" rx="10" fill="#efe4cb" transform="rotate(-8 110 92)" />
      <rect x="58" y="18" width="112" height="140" rx="10" fill="#f6eedc" stroke="#d9c79f" transform="rotate(5 114 88)" />
      <g transform="rotate(5 114 88)">
        <g stroke="#2a4d36" strokeOpacity="0.35" strokeWidth="1.2">
          <path d="M72 50h84M72 56h84M72 62h84M72 68h84M72 74h84" />
          <path d="M72 98h84M72 104h84M72 110h84M72 116h84M72 122h84" />
        </g>
        <g fill="#1d3a28">
          <ellipse cx="90" cy="68" rx="5" ry="3.6" transform="rotate(-20 90 68)" />
          <ellipse cx="112" cy="62" rx="5" ry="3.6" transform="rotate(-20 112 62)" />
          <path d="M94.5 67V44M116.5 61V38M94.5 44l22-6v4l-22 6z" stroke="#1d3a28" strokeWidth="1.6" />
          <ellipse cx="138" cy="113" rx="5" ry="3.6" transform="rotate(-20 138 113)" />
          <path d="M142.5 112V90" stroke="#1d3a28" strokeWidth="1.6" />
        </g>
      </g>
      <circle cx="176" cy="40" r="16" fill="#e3a33b" opacity="0.9" />
      <path d="M170 40h12M176 34v12" stroke="#fffaf0" strokeWidth="3" strokeLinecap="round" />
      <ellipse cx="38" cy="132" rx="7" ry="5" fill="#8fa98c" transform="rotate(-20 38 132)" />
      <path d="M44 130V104c5 3 10 7 8 15" stroke="#8fa98c" strokeWidth="2" fill="none" />
    </svg>
  );
}

/** Calendar with notes illustration for season empty states. */
export function CalendarArt({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 220 170" className={className} aria-hidden="true" focusable="false">
      <rect x="40" y="30" width="140" height="122" rx="14" fill="#f6eedc" stroke="#d9c79f" />
      <rect x="40" y="30" width="140" height="30" rx="14" fill="#1d3a28" />
      <rect x="40" y="46" width="140" height="14" fill="#1d3a28" />
      <path d="M70 22v18M150 22v18" stroke="#e3a33b" strokeWidth="5" strokeLinecap="round" />
      <g fill="#d9c79f">
        {[0, 1, 2, 3, 4].map((c) =>
          [0, 1, 2].map((r) => <rect key={`${c}-${r}`} x={54 + c * 24} y={72 + r * 24} width="16" height="14" rx="4" />),
        )}
      </g>
      <rect x="102" y="96" width="16" height="14" rx="4" fill="#e3a33b" />
      <ellipse cx="190" cy="120" rx="8" ry="6" fill="#8fa98c" transform="rotate(-20 190 120)" />
      <path d="M197 118V88" stroke="#8fa98c" strokeWidth="2.4" />
    </svg>
  );
}

export function QuietNotesArt({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 160 110" className={className} aria-hidden="true" focusable="false" fill="none">
      <g stroke="#2a4d36" strokeOpacity="0.25">
        <path d="M10 40h140M10 50h140M10 60h140M10 70h140M10 80h140" />
      </g>
      <rect x="66" y="46" width="12" height="5" fill="#2a4d36" opacity="0.7" />
      <rect x="86" y="50" width="12" height="5" fill="#2a4d36" opacity="0.7" />
      <ellipse cx="40" cy="70" rx="6" ry="4.4" fill="#e3a33b" transform="rotate(-20 40 70)" />
      <path d="M45.5 69V42" stroke="#e3a33b" strokeWidth="2" />
    </svg>
  );
}