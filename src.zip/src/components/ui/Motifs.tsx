import Image from "next/image";
import clsx from "clsx";

export function MusicIcon({ className }: { className?: string }) {
  return (
    <Image
      src="/music_icon.jpg"
      width={360}
      height={202}
      loading="eager"
      unoptimized
      className={clsx("music-artwork inline-block", className)}
      alt=""
      aria-hidden="true"
    />
  );
}

export function HarmonyMark({ className }: { className?: string }) {
  return <MusicIcon className={className} />;
}

export function StaffFlourish({ className }: { className?: string }) {
  return <MusicIcon className={clsx("pointer-events-none object-contain opacity-15 mix-blend-multiply", className)} />;
}

export function ClefSwirl({ className }: { className?: string }) {
  return <MusicIcon className={clsx("object-contain", className)} />;
}

export function SheetStackArt({ className }: { className?: string }) {
  return <MusicIcon className={clsx("object-contain", className)} />;
}

export function CalendarArt({ className }: { className?: string }) {
  return <MusicIcon className={clsx("object-contain", className)} />;
}

export function QuietNotesArt({ className }: { className?: string }) {
  return <MusicIcon className={clsx("object-contain", className)} />;
}
