import { readFileSync, readdirSync } from "node:fs";
import path from "node:path";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { CalendarArt, HarmonyMark, MusicIcon, QuietNotesArt, SheetStackArt, StaffFlourish, ClefSwirl } from "./Motifs";
import { StatusChip, Tag } from "./Bits";

const sourceDirectory = path.resolve("src");
const css = readFileSync(path.join(sourceDirectory, "app", "globals.css"), "utf8");

describe("shared visual theme", () => {
  it("uses shared solid surfaces without gradients while preserving rounded and beveled edges", () => {
    expect(css).not.toMatch(/(?:repeating-)?(?:linear|radial|conic)-gradient\(/);
    for (const selector of [".gradient-canvas", ".gradient-surface", ".gradient-brand", ".gradient-tint", ".card, .card-interactive", ".btn-primary", ".btn-accent", ".btn-secondary", ".btn-danger"]) {
      const start = css.indexOf(`\n  ${selector} {`);
      expect(start, selector).toBeGreaterThan(-1);
      const rule = css.slice(start).split("}")[0];
      expect(rule, selector).not.toContain("background-image:");
      expect(rule, selector).toMatch(/background-color:|@apply .*bg-/);
    }
    expect(css).toContain("@apply rounded-2xl border");
    expect(css).toContain("gap-2 rounded-xl");
    expect(css).toContain("box-shadow: var(--shadow-bevel)");
    expect(css).toContain("--shadow-bevel: inset 0 1px 0");
    expect(css).toContain("shadow-[var(--shadow-card)]");
    expect(css).toContain("@media (prefers-reduced-motion: reduce)");
  });

  it("keeps normal text at AA contrast on flat surfaces, buttons, and semantic badges", () => {
    function rgb(hex: string) {
      return [1, 3, 5].map((offset) => parseInt(hex.slice(offset, offset + 2), 16));
    }
    function luminance(channels: number[]) {
      return channels.reduce((sum, channel, index) => {
        const value = channel / 255;
        return sum + (value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4) * [0.2126, 0.7152, 0.0722][index];
      }, 0);
    }
    function color(token: string) {
      return luminance(rgb(token === "white" ? "#ffffff" : css.match(new RegExp(`--color-${token}: (#[a-f0-9]{6});`))![1]));
    }
    const pairs = [
      ...["parchment-50", "parchment-100", "parchment-200", "forest-50", "forest-100"].flatMap((background) =>
        ["ink", "ink-soft", "ink-muted", "forest-700", "forest-800", "forest-900"].map((foreground) => [foreground, background])),
      ...["forest-700", "forest-800", "forest-900", "rose-deep"].map((background) => ["white", background]),
      ["amber-deep", "amber-soft"], ["sage-deep", "sage-soft"], ["rose-deep", "rose-soft"],
    ];
    for (const [foreground, background] of pairs) {
      const first = color(foreground);
      const second = color(background);
      const contrast = (Math.max(first, second) + 0.05) / (Math.min(first, second) + 0.05);
      expect(contrast, `${foreground} on ${background}`).toBeGreaterThanOrEqual(4.5);
    }
  });

  it("uses the requested muted-indigo, lavender-white, and warm-amber palette including browser and install colors", () => {
    for (const [token, hex] of Object.entries({
      "parchment-100": "#f7f7fb", "parchment-50": "#ffffff", "forest-700": "#57549a",
      "forest-100": "#eeedf8", "ink": "#2d3042", "ink-muted": "#65677b",
      "parchment-300": "#dedfeb", "amber-accent": "#d9af62",
    })) {
      expect(css).toContain(`--color-${token}: ${hex};`);
    }
    expect(css).toContain("@apply bg-forest-700 text-white");
    expect(css).toContain("--ring: #57549a");
    for (const file of ["layout.tsx", "manifest.ts"]) {
      expect(readFileSync(path.join(sourceDirectory, "app", file), "utf8")).toContain('"#57549a"');
    }
    expect(readFileSync(path.join(sourceDirectory, "app", "manifest.ts"), "utf8")).toContain('"#f7f7fb"');
    expect(css).not.toMatch(/#919BFF|#133A94|145 155 255|19 58 148/i);
  });

  it("applies the shared canvas and surfaces to every public account screen", () => {
    for (const route of ["sign-in", "register", "setup", "verify-email", "reset-password", "sign-in/help"]) {
      const source = readFileSync(path.join(sourceDirectory, "app", route, "page.tsx"), "utf8");
      expect(source, route).toContain("gradient-canvas");
      expect(source, route).toContain("gradient-surface");
    }
    for (const component of ["ParentDashboard", "ParentSeasonBrowser"]) {
      const source = readFileSync(path.join(sourceDirectory, "components", "parent", `${component}.tsx`), "utf8");
      expect(source, component).toContain("gradient-canvas");
      expect(source, component).toContain("gradient-brand");
    }
  });

  it("defines every custom palette color used by pages and components", () => {
    const defined = new Set([...css.matchAll(/--color-([\w-]+)\s*:/g)].map((match) => match[1]));
    const missing: string[] = [];
    for (const file of readdirSync(sourceDirectory, { recursive: true, encoding: "utf8" })) {
      if (!file.endsWith(".tsx")) continue;
      const source = readFileSync(path.join(sourceDirectory, file), "utf8");
      for (const match of source.matchAll(/(?:bg|text|border|ring|accent|from|via|to|divide|outline|decoration)-(parchment-\d+|forest-\d+|amber-(?:accent|soft|deep)|sage(?:-soft|-deep)?|ink(?:-soft|-muted)?|rose-(?:soft|deep))\b/g)) {
        if (!defined.has(match[1])) missing.push(`${file}: ${match[1]}`);
      }
    }
    expect(missing).toEqual([]);
  });

  it.each([MusicIcon, HarmonyMark, CalendarArt, QuietNotesArt, SheetStackArt, StaffFlourish, ClefSwirl])(
    "%s uses the supplied music artwork with decorative image semantics",
    (Illustration) => {
      const html = renderToStaticMarkup(createElement(Illustration));
      expect(html).toContain("music_icon.jpg");
      expect(html).toContain('alt=""');
      expect(html).toContain('aria-hidden="true"');
      expect(html).toContain('loading="eager"');
      expect(html).not.toContain("<svg");
    },
  );

  it("ships the original image unchanged and uses it for browser and install icons", () => {
    expect(readFileSync(path.resolve("public", "music_icon.jpg"))).toEqual(readFileSync(path.resolve("music_icon.jpg")));
    for (const file of ["layout.tsx", "manifest.ts"]) {
      expect(readFileSync(path.join(sourceDirectory, "app", file), "utf8")).toContain('"/music_icon.jpg"');
    }
  });

  it("removes alternate music glyphs and solid blue brand panels across every page", () => {
    for (const file of readdirSync(sourceDirectory, { recursive: true, encoding: "utf8" })) {
      if (!file.endsWith(".tsx")) continue;
      const source = readFileSync(path.join(sourceDirectory, file), "utf8");
      expect(source, file).not.toMatch(/\b(?:Music2|FileMusic)\b|[🎵🎶]/u);
      expect(source, file).not.toMatch(/\bbg-(?:blue|indigo|sky)-\d+/);
      expect(source, file).not.toMatch(/\bbg-forest-(?:50|100|800|900)(?:\s|\/|")/);
      expect(source, file).not.toMatch(/\btext-parchment-\d+|\btext-amber-soft/);
    }
    expect(css).toContain("--font-sans: var(--font-plus-jakarta)");
    expect(css).toContain("--color-ink: #2d3042");
  });

  it("uses readable teal text for completed and supporting status chips", () => {
    expect(renderToStaticMarkup(createElement(StatusChip, { status: "Completed" }))).toContain("text-sage-deep");
    expect(renderToStaticMarkup(createElement(Tag, { tone: "sage", children: "Ready" }))).toContain("text-sage-deep");
  });
});
