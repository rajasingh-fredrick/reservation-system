"use client";

import { useMemo, useState } from "react";
import { CalendarDays, Copy, Pencil, Plus, RefreshCw, Sparkles, Trash2 } from "lucide-react";
import { SEASON_STATUSES, type MinistryEvent, type Season, type SeasonStatus } from "@/lib/contracts";
import { api, errorMessage, formatDateTime } from "@/lib/client";
import { useAdmin, useAdminData } from "@/components/shell/AdminProvider";
import { ConfirmDialog } from "@/components/ui/Confirm";
import { EmptyState, PageHeader, StatusChip } from "@/components/ui/Bits";
import { InlineError, Notice, useToast } from "@/components/ui/Feedback";
import { SeasonFormDialog } from "./SeasonForm";
import { CopySetupDialog, EventFormDialog, GenerateEventsDialog } from "./EventDialogs";
import { EventSongList } from "./EventSongs";

type PendingDelete = { type: "season" | "event"; id: string; label: string };
type EventDialogState = { type: "edit" | "add" | "generate" | "copy"; season: Season; event?: MinistryEvent } | null;

const DEFAULT_STATUSES: SeasonStatus[] = ["Draft", "Published"];

export function SeasonManagement() {
  const data = useAdminData();
  const { refresh } = useAdmin();
  const toast = useToast();
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<Season | null>(null);
  const [dialog, setDialog] = useState<EventDialogState>(null);
  const [deleteTarget, setDeleteTarget] = useState<PendingDelete | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [selectedStatuses, setSelectedStatuses] = useState<SeasonStatus[]>(DEFAULT_STATUSES);
  const seasons = useMemo(() => [...data.seasons].sort((a, b) => b.startDate.localeCompare(a.startDate)), [data.seasons]);
  const visibleSeasons = useMemo(() => seasons.filter((season) => selectedStatuses.includes(season.status)), [seasons, selectedStatuses]);

  const preview = seasons.find((season) => season.id === previewId);

  async function deleteItem() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      const endpoint = deleteTarget.type === "season"
        ? `/api/admin/seasons/${deleteTarget.id}`
        : `/api/admin/events/${deleteTarget.id}`;
      await api(endpoint, { method: "DELETE", json: {} });
      toast("success", `${deleteTarget.type === "season" ? "Season" : "Event"} removed.`);
      setDeleteTarget(null);
      try {
        await refresh();
      } catch (err) {
        toast("error", `Deleted, but the workspace could not refresh: ${errorMessage(err)} Reload the page to see the updated list.`);
      }
    } catch (err) {
      setError(errorMessage(err));
      throw err;
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Scheduling"
        title="Seasons and events"
        description="Create overlapping seasons, generate weekly dates, then configure each event’s song sheets and instrument capacities. Drafts are visible only to administrators."
        actions={<button type="button" className="btn-primary min-h-11" onClick={() => setCreating(true)}><Plus className="h-4 w-4" aria-hidden="true" />New season</button>}
      />
      <InlineError message={error} className="mb-5" />
      <div className="card mb-5 p-4 sm:p-5">
        <fieldset>
          <legend className="field-label">Filter seasons by status</legend>
          <div className="flex flex-wrap gap-x-5 gap-y-1">
            {SEASON_STATUSES.map((status) => (
              <label key={status} className="flex min-h-11 items-center gap-2 text-sm text-ink">
                <input
                  type="checkbox"
                  className="size-4 accent-forest-800"
                  checked={selectedStatuses.includes(status)}
                  onChange={(event) => {
                    const checked = event.target.checked;
                    setSelectedStatuses((current) => checked
                      ? [...current, status]
                      : current.filter((selected) => selected !== status));
                  }}
                />
                {status}
              </label>
            ))}
          </div>
        </fieldset>
        <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-parchment-200 pt-3">
          <button type="button" className="btn-secondary min-h-11" onClick={() => setSelectedStatuses([...SEASON_STATUSES])}>Show all</button>
          <button type="button" className="btn-ghost min-h-11" onClick={() => setSelectedStatuses(DEFAULT_STATUSES)}>Reset filters</button>
          <p className="text-sm text-ink-muted sm:ml-auto" role="status">Showing {visibleSeasons.length} of {seasons.length} seasons</p>
        </div>
      </div>
      {!seasons.length ? <EmptyState art={<CalendarDays className="h-10 w-10 text-forest-700" aria-hidden="true" />} title="No seasons yet" action={<button type="button" className="btn-primary" onClick={() => setCreating(true)}><Plus className="h-4 w-4" aria-hidden="true" />Create a season</button>}>Create a date range and registration window to begin planning the event schedule.</EmptyState> : null}
      {seasons.length > 0 && visibleSeasons.length === 0 ? <EmptyState title="No seasons match these filters" action={<button type="button" className="btn-secondary min-h-11" onClick={() => setSelectedStatuses([...SEASON_STATUSES])}>Show all seasons</button>}>Select another status or show all seasons to find what you need.</EmptyState> : null}
      <div className="space-y-5">
        {visibleSeasons.map((season) => (
          <section key={season.id} className="overflow-hidden rounded-2xl border border-parchment-300 bg-parchment-50 shadow-[var(--shadow-card)]">
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-parchment-200 bg-white/60 p-4 sm:p-5">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2"><h2 className="font-serif text-2xl text-forest-900">{season.name}</h2><StatusChip status={season.status} /></div>
                <p className="mt-1 text-sm text-ink-muted">{season.startDate} to {season.endDate} · {season.timezone.replace(/_/g, " ")}{season.location ? ` · ${season.location}` : ""}</p>
                <p className="mt-2 text-sm text-ink-soft">Registration: {formatDateTime(season.registrationOpensAt, season.timezone)} to {formatDateTime(season.registrationClosesAt, season.timezone)}</p>
                {season.description ? <p className="mt-2 max-w-3xl text-sm text-ink-soft">{season.description}</p> : null}
              </div>
              <div className="flex flex-wrap gap-2">
                <button type="button" className="btn-secondary min-h-11" onClick={() => setPreviewId(season.id)}><CalendarDays className="h-4 w-4" aria-hidden="true" />Preview</button>
                <button type="button" className="btn-secondary min-h-11" onClick={() => setEditing(season)}><Pencil className="h-4 w-4" aria-hidden="true" />Edit</button>
                <button type="button" className="btn-secondary min-h-11" onClick={() => setDialog({ type: "add", season })}><Plus className="h-4 w-4" aria-hidden="true" />Event</button>
                <button type="button" className="btn-secondary min-h-11" onClick={() => setDialog({ type: "generate", season })}><Sparkles className="h-4 w-4" aria-hidden="true" />Generate weekly</button>
                <button type="button" className="btn-danger-ghost min-h-11" disabled={deleting} onClick={() => { setError(null); setDeleteTarget({ type: "season", id: season.id, label: season.name }); }} aria-label={`Delete season ${season.name}`}><Trash2 className="h-4 w-4" aria-hidden="true" />Delete season</button>
              </div>
            </div>
            <div className="space-y-4 p-4 sm:p-5">
              {!season.events.length ? <p className="rounded-xl border border-dashed border-parchment-300 p-4 text-sm text-ink-muted">No events scheduled. Add an individual event or generate weekly dates.</p> : null}
              {season.events.map((event) => (
                <article key={event.id} className="rounded-2xl border border-parchment-200 bg-white/60 p-4 sm:p-5">
                  <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
                    <div><p className="eyebrow">{formatDateTime(event.startsAt, season.timezone)}</p><h3 className="mt-1 font-serif text-xl text-forest-900">{event.name}</h3><p className="mt-1 text-sm text-ink-muted">{event.location || season.location || "Location not set"}</p></div>
                    <div className="flex flex-wrap gap-2">
                      <button type="button" className="icon-btn" aria-label={`Edit ${event.name}`} onClick={() => setDialog({ type: "edit", season, event })}><Pencil className="h-4 w-4" aria-hidden="true" /></button>
                      <button type="button" className="icon-btn" aria-label={`Copy ${event.name} setup`} onClick={() => setDialog({ type: "copy", season, event })}><Copy className="h-4 w-4" aria-hidden="true" /></button>
                      {season.status === "Draft" ? <button type="button" className="icon-btn text-rose-deep" aria-label={`Delete ${event.name}`} onClick={() => setDeleteTarget({ type: "event", id: event.id, label: event.name })}><Trash2 className="h-4 w-4" aria-hidden="true" /></button> : null}
                    </div>
                  </div>
                  <EventSongList event={event} editable={season.status !== "Archived" && season.status !== "Completed"} />
                  <div className="mt-4 border-t border-parchment-200 pt-4">
                    <h4 className="font-semibold text-forest-900">Confirmed reservations ({event.reservations.length})</h4>
                    {event.reservations.length ? (
                      <div className="mt-2 overflow-x-auto">
                        <table className="w-full text-left text-sm">
                          <caption className="sr-only">Confirmed reservations for {event.name}</caption>
                          <thead className="text-ink-muted">
                            <tr>
                              <th scope="col" className="px-3 py-2">Child</th>
                              <th scope="col" className="px-3 py-2">Song</th>
                              <th scope="col" className="px-3 py-2">Instrument</th>
                              <th scope="col" className="px-3 py-2">Spot</th>
                            </tr>
                          </thead>
                          <tbody>
                            {event.reservations.map((reservation) => (
                              <tr key={reservation.id} className="border-t border-parchment-200 text-ink">
                                <td className="px-3 py-2 font-medium">{reservation.childName}</td>
                                <td className="px-3 py-2">{reservation.songTitle}</td>
                                <td className="px-3 py-2">{reservation.instrument}</td>
                                <td className="px-3 py-2">{reservation.spotNumber}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : <p className="mt-2 text-sm text-ink-muted">No confirmed reservations yet.</p>}
                  </div>
                </article>
              ))}
            </div>
          </section>
        ))}
      </div>

      <SeasonFormDialog open={creating} onClose={() => setCreating(false)} />
      <SeasonFormDialog open={Boolean(editing)} onClose={() => setEditing(null)} season={editing} />
      {dialog ? (
        dialog.type === "copy" ? <CopySetupDialog open onClose={() => setDialog(null)} source={dialog.event ?? null} season={dialog.season} />
          : dialog.type === "generate" ? <GenerateEventsDialog open onClose={() => setDialog(null)} season={dialog.season} />
            : <EventFormDialog open onClose={() => setDialog(null)} season={dialog.season} event={dialog.type === "edit" ? dialog.event : null} />
      ) : null}
      <ConfirmDialog open={Boolean(deleteTarget)} onClose={() => setDeleteTarget(null)} title={`Delete ${deleteTarget?.type === "season" ? "season" : "draft event"}?`} confirmLabel="Delete" busyLabel="Deleting…" onConfirm={deleteItem}>
        {deleteTarget?.type === "season" ? (
          <>
            <p>Permanently delete “{deleteTarget.label}” and all its events, song assignments, instrument requirements, and sheet selections? This cannot be undone.</p>
            <p>Seasons with any reservation history, including cancelled reservations, cannot be deleted. Use Edit to set the status to Archived instead.</p>
            <p>Library songs, music sheets, and files will be preserved.</p>
          </>
        ) : <p>Delete “{deleteTarget?.label}”? This is allowed only while the draft has no reservation history. Library songs and sheets are not deleted.</p>}
      </ConfirmDialog>
      {preview ? <div className="fixed inset-0 z-50 grid place-items-center bg-forest-950/55 p-4" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setPreviewId(null); }}>
        <section className="max-h-[90dvh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-parchment-300 bg-parchment-50 p-5 shadow-[var(--shadow-lift)] sm:p-7" role="dialog" aria-modal="true" aria-labelledby="season-preview-title">
          <div className="flex items-start justify-between gap-3"><div><p className="eyebrow">Parent-facing preview · {preview.status}</p><h2 id="season-preview-title" className="mt-1 font-serif text-2xl text-forest-900">{preview.name}</h2></div><button type="button" className="btn-secondary" onClick={() => setPreviewId(null)}>Close</button></div>
          <p className="mt-3 text-sm text-ink-soft">{preview.description || "No description set."}</p>
          <p className="mt-2 text-sm text-ink-muted">{preview.startDate} to {preview.endDate} · {preview.location || "Location not set"}</p>
          {preview.status === "Draft" ? <Notice tone="warn" className="mt-4">Draft seasons are visible only to administrators and are not shown in parent browsing.</Notice> : null}
          <div className="mt-5 space-y-3">{preview.events.map((event) => <div key={event.id} className="rounded-xl border border-parchment-200 p-4"><h3 className="font-semibold text-forest-900">{event.name}</h3><p className="mt-1 text-sm text-ink-muted">{formatDateTime(event.startsAt, preview.timezone)} · {event.location || preview.location}</p><ul className="mt-3 space-y-2">{event.songs.map((song) => <li key={song.id} className="text-sm text-ink-soft"><strong>{song.title}</strong>{song.allowExtra ? " · Extra song for this season" : ""}{song.requirements.length ? ` · ${song.requirements.map((req) => `${req.instrument} × ${req.capacity}`).join(", ")}` : " · No instrument spots"}</li>)}</ul></div>)}</div>
        </section>
      </div> : null}
    </div>
  );
}