import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import type { MinistryEvent } from "@/lib/contracts";
import { EventSlider } from "./EventSlider";

function event(id: string, startsAt: string): MinistryEvent {
  return { id, seasonId: "season", name: id, startsAt, endsAt: startsAt, location: "", songs: [], reservations: [] };
}

function render(events: MinistryEvent[]) {
  return renderToStaticMarkup(createElement(EventSlider, {
    events,
    timezone: "UTC",
    seasonName: "Summer",
    children: (item) => createElement("article", null, `Details for ${item.id}`),
  }));
}

describe("event slider", () => {
  it("renders only the earliest event, without mutating input order", () => {
    const events = [event("Later", "2026-07-12 10:00:00"), event("Earlier", "2026-07-05 10:00:00")];
    const html = render(events);
    expect(html).toContain("<article>Details for Earlier</article>");
    expect(html).not.toContain("Details for Later");
    expect(html.indexOf('value="Earlier"')).toBeLessThan(html.indexOf('value="Later"'));
    expect(events.map((item) => item.id)).toEqual(["Later", "Earlier"]);
    expect(html).toContain("Event 1 of 2:");
    const buttons = html.match(/<button\b[^>]*>/g) ?? [];
    expect(buttons).toHaveLength(2);
    expect(buttons[0]).toContain("disabled");
    expect(buttons[1]).not.toContain("disabled");
  });

  it("disables both navigation buttons for a single event and labels its controls", () => {
    const html = render([event("Only", "2026-07-05 10:00:00")]);
    expect(html.match(/<button\b[^>]*disabled[^>]*>/g)).toHaveLength(2);
    expect(html).toContain("Jump to event");
    expect(html).toContain('aria-label="Events for Summer"');
    expect(html).toContain('role="status"');
    expect(html).toContain('aria-roledescription="slide"');
    expect(html).toContain("Event 1 of 1:");
  });

  it("does not render navigation when no events exist", () => {
    expect(render([])).toBe("");
  });

  it("supports parent event details without requiring administrator data", () => {
    const events = [{
      id: "parent-event", name: "Family service", startsAt: "2026-07-05 10:00:00",
      songs: [{ title: "Morning song", availableSpots: [1, 2] }],
    }];
    const html = renderToStaticMarkup(createElement(EventSlider<(typeof events)[number]>, {
      events, timezone: "UTC", seasonName: "Family season",
      children: (item) => createElement("article", null, `${item.songs[0].title}: ${item.songs[0].availableSpots.length} available`),
    }));
    expect(html).toContain("Morning song: 2 available");
    expect(html).toContain("Event 1 of 1:");
  });
});
