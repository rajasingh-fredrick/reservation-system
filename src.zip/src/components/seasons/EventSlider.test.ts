import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { MinistryEvent } from "@/lib/contracts";
import { EventSlider } from "./EventSlider";

function event(id: string, startsAt: string): MinistryEvent {
  return { id, seasonId: "season", name: id, startsAt, endsAt: startsAt, location: "", songs: [], reservations: [] };
}

function render(events: MinistryEvent[]) {
  return renderToStaticMarkup(createElement(EventSlider, {
    events,
    timezone: "UTC",
    seasonName: "Summer",
    children: (item) => createElement("article", null, `Details for ${item.id}`),
  }));
}

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-07-01T12:00:00Z"));
});
afterEach(() => vi.useRealTimers());

describe("event slider", () => {
  it("renders only the earliest event, without mutating input order", () => {
    const events = [event("Later", "2026-07-12 10:00:00"), event("Earlier", "2026-07-05 10:00:00")];
    const html = render(events);
    expect(html).toContain("<article>Details for Earlier</article>");
    expect(html).not.toContain("Details for Later");
    expect(html.indexOf('value="Earlier"')).toBeLessThan(html.indexOf('value="Later"'));
    expect(events.map((item) => item.id)).toEqual(["Later", "Earlier"]);
    expect(html).toContain("Event 1 of 2:");
    const buttons = html.match(/<button\b[^>]*>/g) ?? [];
    expect(buttons).toHaveLength(2);
    expect(buttons[0]).toContain("disabled");
    expect(buttons[1]).not.toContain("disabled");
  });

  it("disables both navigation buttons for a single event and labels its controls", () => {
    const html = render([event("Only", "2026-07-05 10:00:00")]);
    expect(html.match(/<button\b[^>]*disabled[^>]*>/g)).toHaveLength(2);
    expect(html).toContain("Jump to event");
    expect(html).toContain('aria-label="Events for Summer"');
    expect(html).toContain('role="status"');
    expect(html).toContain('aria-roledescription="slide"');
    expect(html).toContain("Event 1 of 1:");
  });

  it("does not render navigation when no events exist", () => {
    expect(render([])).toBe("");
  });

  it("defaults to the nearest upcoming event and keeps past events in the dropdown", () => {
    vi.setSystemTime(new Date("2026-07-06T12:00:00Z"));
    const html = render([
      event("Later", "2026-07-19T10:00:00Z"),
      event("Past", "2026-07-05T10:00:00Z"),
      event("Next", "2026-07-12T10:00:00Z"),
    ]);
    expect(html).toContain('<option value="Next" selected="">');
    expect(html).toContain('<option value="Past">');
    expect(html).toContain("<article>Details for Next</article>");
    expect(html).toContain("Event 2 of 3:");
    expect(html.match(/<button\b[^>]*disabled[^>]*>/g) ?? []).toHaveLength(0);
  });

  it("includes an event starting exactly now and compares timezone offsets as instants", () => {
    vi.setSystemTime(new Date("2026-07-12T14:00:00Z"));
    const html = render([
      event("Past", "2026-07-12T09:59:59-04:00"),
      event("Now", "2026-07-12T10:00:00-04:00"),
      event("Future", "2026-07-12T15:00:00Z"),
    ]);
    expect(html).toContain('<option value="Now" selected="">');
    expect(html).toContain("<article>Details for Now</article>");
  });

  it("defaults to the most recent past event when no upcoming event exists", () => {
    vi.setSystemTime(new Date("2026-08-01T12:00:00Z"));
    const html = render([
      event("Recent", "2026-07-12T10:00:00Z"),
      event("Earlier", "2026-07-05T10:00:00Z"),
    ]);
    expect(html).toContain('<option value="Recent" selected="">');
    expect(html).toContain("<article>Details for Recent</article>");
    expect(html).toContain("Event 2 of 2:");
    const buttons = html.match(/<button\b[^>]*>/g) ?? [];
    expect(buttons[0]).not.toContain("disabled");
    expect(buttons[1]).toContain("disabled");
  });

  it("supports parent event details without requiring administrator data", () => {
    const events = [{
      id: "parent-event", name: "Family service", startsAt: "2026-07-05 10:00:00",
      songs: [{ title: "Morning song", availableSpots: [1, 2] }],
    }];
    const html = renderToStaticMarkup(createElement(EventSlider<(typeof events)[number]>, {
      events, timezone: "UTC", seasonName: "Family season",
      children: (item) => createElement("article", null, `${item.songs[0].title}: ${item.songs[0].availableSpots.length} available`),
    }));
    expect(html).toContain("Morning song: 2 available");
    expect(html).toContain("Event 1 of 1:");
  });
});
