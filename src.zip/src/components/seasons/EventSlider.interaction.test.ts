import { isValidElement, type ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { EventSlider } from "./EventSlider";

const hooks = vi.hoisted(() => ({ selected: undefined as string | null | undefined }));
vi.mock("react", async (original) => ({
  ...await original<typeof import("react")>(),
  useId: () => "event-panel",
  useMemo: (factory: () => unknown) => factory(),
  useState: (initial: () => string | null) => {
    if (hooks.selected === undefined) hooks.selected = initial();
    return [hooks.selected, (value: string | null) => { hooks.selected = value; }];
  },
}));

type Props = {
  children?: ReactNode; value?: string; disabled?: boolean;
  onChange?: (event: { target: { value: string } }) => void; onClick?: () => void;
};
function elements(node: ReactNode): Array<{ type: unknown; props: Props }> {
  if (Array.isArray(node)) return node.flatMap(elements);
  if (!isValidElement<Props>(node)) return [];
  return [{ type: node.type, props: node.props }, ...elements(node.props.children)];
}
const events = [
  { id: "past", name: "Past", startsAt: "2026-07-05T10:00:00Z" },
  { id: "next", name: "Next", startsAt: "2026-07-12T10:00:00Z" },
  { id: "later", name: "Later", startsAt: "2026-07-19T10:00:00Z" },
];
function render(items = events) {
  return elements(EventSlider({
    events: items, timezone: "UTC", seasonName: "Summer",
    children: (event) => event.id,
  }));
}
function select(items = events) {
  return render(items).find((element) => element.type === "select")!.props;
}

beforeEach(() => {
  hooks.selected = undefined;
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-07-06T12:00:00Z"));
});
afterEach(() => vi.useRealTimers());

describe("event slider selection", () => {
  it("preserves manual selection across refreshes and supports previous/next navigation", () => {
    expect(select().value).toBe("next");
    select().onChange!({ target: { value: "past" } });
    expect(select([...events]).value).toBe("past");
    render().filter((element) => element.type === "button")[1].props.onClick!();
    expect(select().value).toBe("next");
    render().filter((element) => element.type === "button")[0].props.onClick!();
    expect(select().value).toBe("past");
  });

  it("uses the upcoming default after the selected event is removed or filtered out", () => {
    select().onChange!({ target: { value: "past" } });
    expect(select(events.slice(1)).value).toBe("next");
    expect(hooks.selected).toBe("next");
  });

  it("selects the upcoming event when events load after an empty result", () => {
    expect(render([])).toEqual([]);
    expect(select().value).toBe("next");
    expect(hooks.selected).toBe("next");
  });
});
