"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { SEASON_STATUSES, type Season, type SeasonStatus } from "@/lib/contracts";
import { api, browserTimeZone, errorMessage, formatDateTime, isoToZonedInput, isValidTimeZone, timeZoneOptions, zonedToIso } from "@/lib/client";
import { useAdmin } from "@/components/shell/AdminProvider";
import { Modal } from "@/components/ui/Modal";
import { BusyButton, InlineError, Notice, useToast } from "@/components/ui/Feedback";
import { Field } from "@/components/ui/Bits";

interface FormState {
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  timezone: string;
  registrationOpensAt: string;
  registrationClosesAt: string;
  location: string;
  instructions: string;
  cancellationHours: string;
  status: SeasonStatus;
}

function initial(season?: Season | null): FormState {
  if (season) {
    const tz = season.timezone;
    return {
      name: season.name,
      description: season.description,
      startDate: season.startDate.slice(0, 10),
      endDate: season.endDate.slice(0, 10),
      timezone: tz,
      registrationOpensAt: season.registrationOpensAt ? isoToZonedInput(season.registrationOpensAt, tz) : "",
      registrationClosesAt: season.registrationClosesAt ? isoToZonedInput(season.registrationClosesAt, tz) : "",
      location: season.location,
      instructions: season.instructions,
      cancellationHours: String(season.cancellationHours),
      status: season.status,
    };
  }
  return {
    name: "",
    description: "",
    startDate: "",
    endDate: "",
    timezone: browserTimeZone(),
    registrationOpensAt: "",
    registrationClosesAt: "",
    location: "",
    instructions: "",
    cancellationHours: "24",
    status: "Draft",
  };
}

export const STATUS_HELP: Record<SeasonStatus, string> = {
  Draft: "Only admins can see it. Events can be added, generated and deleted.",
  Published: "Visible to families; registration follows the window below.",
  "Registration Closed": "Visible, but no new reservations are accepted.",
  Completed: "The season has finished; kept for history.",
  Archived: "Hidden from day-to-day lists.",
};

export function SeasonFormDialog({
  open,
  onClose,
  season,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  season?: Season | null;
  onSaved?: (id: string | null) => void;
}) {
  const { refresh } = useAdmin();
  const toast = useToast();
  const [form, setForm] = useState<FormState>(() => initial(season));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scheduling, setScheduling] = useState(false);
  const [notificationTime, setNotificationTime] = useState("");
  const notificationRef = useRef<HTMLInputElement>(null);
  const zones = useMemo(() => timeZoneOptions(), []);
  const firstPublication = form.status === "Published" && !season?.firstPublishedAt;

  useEffect(() => {
    if (open) {
      setForm(initial(season));
      setError(null);
      setScheduling(false);
      setNotificationTime("");
    }
  }, [open, season]);

  useEffect(() => {
    if (scheduling) notificationRef.current?.focus();
  }, [scheduling]);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((f) => ({ ...f, [key]: value }));

  function validate(): string | null {
    if (!form.name.trim()) return "Give the season a name.";
    if (!form.startDate || !form.endDate) return "Choose start and end dates.";
    if (form.endDate < form.startDate) return "The end date must be on or after the start date.";
    if (!isValidTimeZone(form.timezone)) return "Choose a valid time zone.";
    if (!form.registrationOpensAt || !form.registrationClosesAt) return "Set when registration opens and closes.";
    if (form.registrationClosesAt <= form.registrationOpensAt) return "Registration must close after it opens.";
    const hours = Number(form.cancellationHours);
    if (!Number.isInteger(hours) || hours < 0) return "Cancellation notice must be a whole number of hours (0 or more).";
    return null;
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    const problem = validate();
    if (problem) {
      setError(problem);
      return;
    }
    if (firstPublication && !scheduling) {
      setError(null);
      setNotificationTime(form.registrationOpensAt);
      setScheduling(true);
      return;
    }
    let registrationNotificationAt: string | undefined;
    if (firstPublication) {
      try {
        registrationNotificationAt = zonedToIso(notificationTime, form.timezone);
        if (!notificationTime || isoToZonedInput(registrationNotificationAt, form.timezone) !== notificationTime) {
          setError("Choose a valid notification date and time in the season's timezone. This time may not exist during a daylight-saving change.");
          return;
        }
        if (Date.parse(registrationNotificationAt) <= Date.now()) {
          setError("Choose a future date and time for the registration notification.");
          return;
        }
      } catch {
        setError("Choose a valid notification date and time in the season's timezone.");
        return;
      }
    }
    setBusy(true);
    setError(null);
    let newId: string | null = season?.id ?? null;
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        startDate: form.startDate,
        endDate: form.endDate,
        timezone: form.timezone,
        registrationOpensAt: zonedToIso(form.registrationOpensAt, form.timezone),
        registrationClosesAt: zonedToIso(form.registrationClosesAt, form.timezone),
        location: form.location.trim(),
        instructions: form.instructions.trim(),
        cancellationHours: Number(form.cancellationHours),
        status: form.status,
        ...(registrationNotificationAt ? { registrationNotificationAt } : {}),
      };
      if (season) {
        await api(`/api/admin/seasons/${season.id}`, { method: "PATCH", json: payload });
      } else {
        const res = await api<{ id?: string; season?: { id?: string } } | null>("/api/admin/seasons", { method: "POST", json: payload });
        newId = res?.id ?? res?.season?.id ?? null;
      }
    } catch (err) {
      setError(errorMessage(err));
      setBusy(false);
      return;
    }
    setBusy(false);
    toast("success", registrationNotificationAt ? "Season published and parent notification scheduled. Email delivery is handled by the separate sender." : season ? "Season updated." : `“${form.name.trim()}” created.`);
    onClose();
    try {
      await refresh();
    } catch (err) {
      toast("error", `Saved, but the workspace could not refresh: ${errorMessage(err)}`);
    }
    onSaved?.(newId);
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size="lg"
      eyebrow={season ? "Edit season" : "New season"}
      title={scheduling ? "Schedule parent notification" : season ? season.name : "Plan a new season"}
      description={scheduling ? `Choose when to announce the new registration to parents. Timezone: ${form.timezone}.` : "Dates and times are entered in the season’s own time zone."}
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          {scheduling ? <button type="button" className="btn-secondary" disabled={busy} onClick={() => { setScheduling(false); setError(null); }}>Back to season</button> : null}
          <BusyButton type="submit" form="season-form" className="btn-primary" busy={busy} busyLabel="Saving…">
            {scheduling ? "Publish and schedule" : season ? "Save season" : "Create season"}
          </BusyButton>
        </>
      }
    >
      <form id="season-form" onSubmit={submit} className="grid gap-4 sm:grid-cols-2" noValidate>
        {scheduling ? (
          <div className="space-y-4 sm:col-span-2">
            <Notice tone="warn">This is the first publication of this season. Nothing is saved until you confirm the notification schedule. A separate process will send the announcement; publishing does not send email immediately.</Notice>
            <Field label="Send registration notification at" htmlFor="season-notification-time" required hint={`Date and time in ${form.timezone}.`}>
              <input ref={notificationRef} id="season-notification-time" data-autofocus type="datetime-local" className="input" value={notificationTime} onChange={(event) => setNotificationTime(event.target.value)} disabled={busy} required />
            </Field>
          </div>
        ) : <>
        <Field label="Season name" htmlFor="season-name" required className="sm:col-span-2">
          <input id="season-name" data-autofocus className="input" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Spring Strings 2026" required />
        </Field>
        <Field label="Description" htmlFor="season-description" className="sm:col-span-2" hint="Shown to families on the season page.">
          <textarea id="season-description" className="input min-h-20" value={form.description} onChange={(e) => set("description", e.target.value)} />
        </Field>
        <Field label="First day" htmlFor="season-start" required>
          <input id="season-start" type="date" className="input" value={form.startDate} onChange={(e) => set("startDate", e.target.value)} required />
        </Field>
        <Field label="Last day" htmlFor="season-end" required>
          <input id="season-end" type="date" className="input" value={form.endDate} min={form.startDate || undefined} onChange={(e) => set("endDate", e.target.value)} required />
        </Field>
        <Field label="Time zone" htmlFor="season-tz" required className="sm:col-span-2" hint="Event times and the registration window use this zone.">
          <select id="season-tz" className="input" value={form.timezone} onChange={(e) => set("timezone", e.target.value)}>
            {!zones.includes(form.timezone) ? <option value={form.timezone}>{form.timezone}</option> : null}
            {zones.map((z) => (
              <option key={z} value={z}>
                {z.replace(/_/g, " ")}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Registration opens" htmlFor="season-reg-open" required>
          <input id="season-reg-open" type="datetime-local" className="input" value={form.registrationOpensAt} onChange={(e) => set("registrationOpensAt", e.target.value)} required />
        </Field>
        <Field label="Registration closes" htmlFor="season-reg-close" required>
          <input id="season-reg-close" type="datetime-local" className="input" value={form.registrationClosesAt} onChange={(e) => set("registrationClosesAt", e.target.value)} required />
        </Field>
        <Field label="Status" htmlFor="season-status" hint={STATUS_HELP[form.status]}>
          <select id="season-status" className="input" value={form.status} onChange={(e) => set("status", e.target.value as SeasonStatus)}>
            {SEASON_STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Cancellation notice (hours)" htmlFor="season-cancel" hint="Families can cancel up to this many hours before an event.">
          <input id="season-cancel" type="number" min={0} step={1} inputMode="numeric" className="input" value={form.cancellationHours} onChange={(e) => set("cancellationHours", e.target.value)} />
        </Field>
        <Field label="Default location" htmlFor="season-location" className="sm:col-span-2" hint="Used for new events unless you change it.">
          <input id="season-location" className="input" value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="Fellowship Hall" />
        </Field>
        <Field label="Notes & instructions for families" htmlFor="season-instructions" className="sm:col-span-2">
          <textarea id="season-instructions" className="input min-h-24" value={form.instructions} onChange={(e) => set("instructions", e.target.value)} placeholder="Arrive 15 minutes early to tune…" />
        </Field>
        {season && season.status !== form.status && form.status !== "Draft" && season.status === "Draft" ? (
          <div className="sm:col-span-2">
            <Notice tone="warn">Publishing makes this season and its events visible to families.</Notice>
          </div>
        ) : null}
        {season?.registrationNotificationAt ? <div className="sm:col-span-2"><Notice tone="info">{season.registrationNotificationSentAt ? "Parent notification sent" : "Parent notification scheduled"}: {formatDateTime(season.registrationNotificationSentAt ?? season.registrationNotificationAt, season.registrationNotificationTimezone ?? season.timezone)} ({season.registrationNotificationTimezone ?? season.timezone}). This first-publication schedule is retained when the season is edited or republished.</Notice></div> : null}
        </>}
        <div className="sm:col-span-2">
          <InlineError message={error} />
        </div>
      </form>
    </Modal>
  );
}