"use client";

import { useEffect, useState, type FormEvent } from "react";
import type { MinistryEvent, Season, SongRole } from "@/lib/contracts";
import { api, errorMessage, formatDateTime, isImpactError, isoToZonedInput, plural, zonedToIso } from "@/lib/client";
import { useAdmin } from "@/components/shell/AdminProvider";
import { Modal } from "@/components/ui/Modal";
import { BusyButton, InlineError, Notice, useToast } from "@/components/ui/Feedback";
import { Field } from "@/components/ui/Bits";
import { ChevronDown, Plus, Trash2 } from "lucide-react";
import { getScheduleDates, type SchedulePattern } from "@/lib/schedule";
import { CapacityGrid, SheetChecklist, SongDetails, SongRoleField, capsTo, type Caps } from "./EventSongs";

type SongDraft = { key: string; songId: string; sheetIds: string[]; notes: string; caps: Caps; songRole?: SongRole | null };

const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function addMinutesLocal(local: string, minutes: number): string {
  const [d, t] = local.split("T");
  if (!d || !t) return local;
  const [y, mo, da] = d.split("-").map(Number);
  const [h, mi] = t.split(":").map(Number);
  const dt = new Date(Date.UTC(y, mo - 1, da, h, mi + minutes));
  return dt.toISOString().slice(0, 16);
}

export function EventFormDialog({
  open,
  onClose,
  season,
  event,
}: {
  open: boolean;
  onClose: () => void;
  season: Season;
  event?: MinistryEvent | null;
}) {
  const { data, refresh } = useAdmin();
  const toast = useToast();
  const tz = season.timezone;
  const [name, setName] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [location, setLocation] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [needsConfirm, setNeedsConfirm] = useState<string | null>(null);
  const [songs, setSongs] = useState<SongDraft[]>([]);
  const librarySongs = (data?.songs ?? []).filter((song) => !song.archived).toSorted((left, right) => left.title.localeCompare(right.title));

  function updateSong(key: string, changes: Partial<SongDraft>) {
    setSongs((current) => current.map((song) => song.key === key ? { ...song, ...changes } : song));
  }

  useEffect(() => {
    if (!open) return;
    setError(null);
    setNeedsConfirm(null);
    setSongs(event ? [] : [{ key: crypto.randomUUID(), songId: "", sheetIds: [], notes: "", caps: {} }]);
    if (event) {
      setName(event.name);
      setStart(isoToZonedInput(event.startsAt, tz));
      setEnd(isoToZonedInput(event.endsAt, tz));
      setLocation(event.location);
    } else {
      setName(season.name ? `${season.name} rehearsal` : "Rehearsal");
      const day = season.startDate.slice(0, 10);
      setStart(day ? `${day}T10:00` : "");
      setEnd(day ? `${day}T11:00` : "");
      setLocation(season.location);
    }
  }, [open, event, season, tz]);

  async function save(confirmImpact: boolean) {
    if (!name.trim()) return setError("Give the event a name.");
    if (!start || !end) return setError("Choose a start and end time.");
    if (end <= start) return setError("The event must end after it starts.");
    if (!event && !songs.length) return setError("Add at least one song to the event.");
    const selections = [];
    for (const song of songs) {
      if (!song.songId) return setError("Choose a song for each entry, or remove the empty entry.");
      if (!song.sheetIds.length) return setError("Select at least one sheet for each song.");
      const requirements = capsTo(song.caps);
      if (typeof requirements === "string") return setError(requirements);
      selections.push({ songId: song.songId, sheetIds: song.sheetIds, notes: song.notes.trim(), requirements, songRole: song.songRole });
    }
    setBusy(true);
    setError(null);
    const body = {
      name: name.trim(),
      startsAt: zonedToIso(start, tz),
      endsAt: zonedToIso(end, tz),
      location: location.trim(),
    };
    try {
      if (event) {
        await api(`/api/admin/events/${event.id}`, { method: "PATCH", json: confirmImpact ? { ...body, confirmImpact: true } : body });
      } else {
        await api(`/api/admin/seasons/${season.id}/events`, { method: "POST", json: { ...body, songs: selections } });
      }
    } catch (err) {
      setBusy(false);
      if (event && !confirmImpact && isImpactError(err)) {
        setNeedsConfirm(errorMessage(err));
        return;
      }
      setError(errorMessage(err));
      return;
    }
    setBusy(false);
    toast("success", event ? "Event updated." : "Event added.");
    onClose();
    try {
      await refresh();
    } catch (err) {
      toast("error", `Saved, but refreshing failed: ${errorMessage(err)}`);
    }
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    void save(needsConfirm !== null);
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size={event ? "md" : "xl"}
      eyebrow={event ? "Edit event" : "New event"}
      title={event ? event.name : `Add an event to ${season.name}`}
      description={`Times are in ${tz.replace(/_/g, " ")}.`}
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form="event-form" className={needsConfirm ? "btn-danger" : "btn-primary"} busy={busy} busyLabel="Saving…">
            {needsConfirm ? "Confirm and save" : event ? "Save event" : "Add event"}
          </BusyButton>
        </>
      }
    >
      <form id="event-form" onSubmit={submit} className="grid gap-4 sm:grid-cols-2" noValidate>
        <Field label="Event name" htmlFor="event-name" required className="sm:col-span-2">
          <input id="event-name" data-autofocus className="input" value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Date and start time" htmlFor="event-start" required>
          <input
            id="event-start"
            type="datetime-local"
            className="input"
            value={start}
            onChange={(e) => {
              const v = e.target.value;
              if (start && end && v) {
                const diff = (Date.parse(`${end}:00Z`) - Date.parse(`${start}:00Z`)) / 60000;
                if (diff > 0) setEnd(addMinutesLocal(v, diff));
              }
              setStart(v);
            }}
          />
        </Field>
        <Field label="Ends" htmlFor="event-end" required>
          <input id="event-end" type="datetime-local" className="input" value={end} min={start || undefined} onChange={(e) => setEnd(e.target.value)} />
        </Field>
        <Field label="Location" htmlFor="event-location" className="sm:col-span-2">
          <input id="event-location" className="input" value={location} onChange={(e) => setLocation(e.target.value)} />
        </Field>
        {!event ? <fieldset className="min-w-0 space-y-5 sm:col-span-2" disabled={busy}>
          <legend className="field-label">Event songs</legend>
          {songs.map((draft, index) => {
            const song = librarySongs.find((item) => item.id === draft.songId);
            return <section key={draft.key} className="min-w-0 space-y-4 border-t border-parchment-300 pt-4" aria-label={`Song ${index + 1}`}>
              <div className="flex items-end gap-2">
                <Field label={`Song Name ${index + 1}`} htmlFor={`event-song-${draft.key}`} required className="min-w-0 flex-1">
                  <select id={`event-song-${draft.key}`} className="input" value={draft.songId} onChange={(event) => {
                    const selected = librarySongs.find((item) => item.id === event.target.value);
                    updateSong(draft.key, { songId: event.target.value, sheetIds: selected?.sheets.filter((sheet) => !sheet.archived).map((sheet) => sheet.id) ?? [], caps: {}, notes: "", songRole: season.events.flatMap((item) => item.songs).find((item) => item.songId === selected?.id)?.songRole ?? null });
                  }}>
                    <option value="">Select a song</option>
                    {librarySongs.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}
                  </select>
                </Field>
                <button type="button" className="btn-ghost shrink-0" aria-label={`Remove song ${index + 1}`} title={`Remove song ${index + 1}`} onClick={() => setSongs((current) => current.filter((item) => item.key !== draft.key))}><Trash2 className="size-4" aria-hidden /></button>
              </div>
              {song ? <>
                <SongDetails song={song} />
                <SongRoleField value={draft.songRole ?? null} onChange={(songRole) => {
                  setSongs((current) => current.map((item) => item.songId === draft.songId ? { ...item, songRole } : item));
                }} disabled={busy} />
                <SheetChecklist song={song} selected={draft.sheetIds} onChange={(sheetIds) => updateSong(draft.key, { sheetIds })} disabled={busy} />
                <CapacityGrid caps={draft.caps} onChange={(caps) => updateSong(draft.key, { caps })} disabled={busy} />
                <Field label="Notes for this event" htmlFor={`event-notes-${draft.key}`}>
                  <textarea id={`event-notes-${draft.key}`} className="input min-h-20" maxLength={5000} value={draft.notes} onChange={(event) => updateSong(draft.key, { notes: event.target.value })} />
                </Field>
              </> : null}
            </section>;
          })}
          {!librarySongs.length ? <Notice tone="info">No active library songs are available.</Notice> : null}
          <button type="button" className="btn-secondary" disabled={!librarySongs.length || songs.length >= 100} onClick={() => setSongs((current) => [...current, { key: crypto.randomUUID(), songId: "", sheetIds: [], notes: "", caps: {} }])}><Plus className="size-4" aria-hidden /> Add song</button>
        </fieldset> : null}
        {needsConfirm ? (
          <div className="sm:col-span-2">
            <Notice tone="warn">
              <strong className="font-semibold">This change affects families.</strong> {needsConfirm} Select “Confirm and save” to proceed.
            </Notice>
          </div>
        ) : null}
        <div className="sm:col-span-2">
          <InlineError message={error} />
        </div>
      </form>
    </Modal>
  );
}

export function GenerateEventsDialog({ open, onClose, season }: { open: boolean; onClose: () => void; season: Season }) {
  const { refresh } = useAdmin();
  const toast = useToast();
  const [weekday, setWeekday] = useState(0);
  const [recurrences, setRecurrences] = useState<string[]>(["weekly"]);
  const [repeatOpen, setRepeatOpen] = useState(false);
  const [time, setTime] = useState("10:00");
  const [duration, setDuration] = useState("60");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setError(null);
      setName(`${season.name} rehearsal`);
      setRecurrences(["weekly"]);
      setRepeatOpen(false);
      const d = season.startDate.slice(0, 10);
      if (d) setWeekday(new Date(`${d}T12:00:00Z`).getUTCDay());
    }
  }, [open, season]);

  const patterns: SchedulePattern[] = [];
  for (const recurrence of recurrences) {
    if (recurrence === "weekly") patterns.push({ frequency: "weekly" });
    else {
      const weekOfMonth = Number(recurrence.slice("monthly-".length));
      if (Number.isInteger(weekOfMonth) && weekOfMonth >= 1 && weekOfMonth <= 5) patterns.push({ frequency: "monthly", weekOfMonth });
    }
  }
  const count = getScheduleDates(season.startDate, season.endDate, weekday, patterns).length;

  async function submit(e: FormEvent) {
    e.preventDefault();
    const minutes = Number(duration);
    if (!name.trim()) return setError("Name the generated events.");
    if (!patterns.length) return setError("Select at least one repeat option.");
    if (!/^\d{2}:\d{2}$/.test(time)) return setError("Choose a start time.");
    if (!Number.isInteger(minutes) || minutes < 5 || minutes > 1440) return setError("Duration must be between 5 and 1440 minutes.");
    setBusy(true);
    setError(null);
    try {
      await api(`/api/admin/seasons/${season.id}/generate`, {
        method: "POST",
        json: {
          weekday,
          patterns: recurrences,
          time,
          durationMinutes: minutes,
          name: name.trim(),
        },
      });
    } catch (err) {
      setBusy(false);
      setError(errorMessage(err));
      return;
    }
    setBusy(false);
    toast("success", `${plural(count, "event")} generated as drafts.`);
    onClose();
    try {
      await refresh();
    } catch (err) {
      toast("error", `Generated, but refreshing failed: ${errorMessage(err)}`);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size="md"
      eyebrow="Event schedule"
      title="Generate events"
      description={`Creates draft events between the season’s first and last day, in ${season.timezone.replace(/_/g, " ")}. Monthly options select the chosen weekday’s numbered occurrence.`}
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form="generate-form" className="btn-primary" busy={busy} busyLabel="Generating…" disabled={!count}>
            Generate {count > 0 ? plural(count, "event") : "events"}
          </BusyButton>
        </>
      }
    >
      <form id="generate-form" onSubmit={submit} className="grid gap-4 sm:grid-cols-2" noValidate>
        <Field label="Event name" htmlFor="gen-name" required className="sm:col-span-2">
          <input id="gen-name" data-autofocus className="input" value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Day of the week" htmlFor="gen-weekday">
          <select id="gen-weekday" className="input" value={weekday} onChange={(e) => setWeekday(Number(e.target.value))}>
            {WEEKDAYS.map((d, i) => (
              <option key={d} value={i}>
                {d}
              </option>
            ))}
          </select>
        </Field>
        <div className="min-w-0 space-y-1">
          <label htmlFor="gen-repeat-toggle" className="field-label">Repeat</label>
          <button id="gen-repeat-toggle" type="button" className="input flex min-h-11 w-full items-center justify-between gap-2 text-left" aria-expanded={repeatOpen} aria-controls="gen-repeat-options" onClick={() => setRepeatOpen((open) => !open)}>
            <span className="truncate">{recurrences.length ? `${recurrences.length} option${recurrences.length === 1 ? "" : "s"} selected` : "Select repeat options"}</span>
            <ChevronDown className={`h-4 w-4 shrink-0 transition-transform ${repeatOpen ? "rotate-180" : ""}`} aria-hidden="true" />
          </button>
          {repeatOpen ? <fieldset id="gen-repeat-options" className="space-y-1 rounded-lg border border-parchment-300 bg-white p-2">
            <legend className="sr-only">Repeat options</legend>
            {[
              ["weekly", "Generate weekly"],
              ["monthly-1", "Every 1st week of the month"],
              ["monthly-2", "Every 2nd week of the month"],
              ["monthly-3", "Every 3rd week of the month"],
              ["monthly-4", "Every 4th week of the month"],
              ["monthly-5", "Every 5th week of the month"],
            ].map(([value, label]) => <label key={value} className="flex min-h-10 items-center gap-2 rounded px-2 text-sm text-ink hover:bg-parchment-50">
              <input type="checkbox" className="size-4 accent-forest-800" checked={recurrences.includes(value)} onChange={(event) => setRecurrences((current) => event.target.checked ? [...current, value] : current.filter((item) => item !== value))} />
              {label}
            </label>)}
          </fieldset> : null}
        </div>
        <Field label="Start time" htmlFor="gen-time">
          <input id="gen-time" type="time" className="input" value={time} onChange={(e) => setTime(e.target.value)} />
        </Field>
        <Field label="Duration (minutes)" htmlFor="gen-duration" className="sm:col-span-2">
          <input id="gen-duration" type="number" min={5} max={1440} step={5} className="input" value={duration} onChange={(e) => setDuration(e.target.value)} />
        </Field>
        <div className="sm:col-span-2">
          <Notice tone="info">
            Skipping a holiday or break? Generate the full run, then delete the individual draft events you don’t need.
          </Notice>
        </div>
        <div className="sm:col-span-2">
          <InlineError message={error} />
        </div>
      </form>
    </Modal>
  );
}

export function CopySetupDialog({
  open,
  onClose,
  source,
  season,
}: {
  open: boolean;
  onClose: () => void;
  source: MinistryEvent | null;
  season: Season;
}) {
  const { refresh, data } = useAdmin();
  const toast = useToast();
  const [target, setTarget] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setTarget("");
      setError(null);
    }
  }, [open]);

  const options = (data?.seasons ?? []).flatMap((s) =>
    s.events.filter((ev) => ev.id !== source?.id).map((ev) => ({ ev, season: s })),
  );
  const chosen = options.find((o) => o.ev.id === target);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!source) return;
    if (!target) return setError("Choose an event to copy the setup to.");
    setBusy(true);
    setError(null);
    try {
      await api(`/api/admin/events/${source.id}/copy`, { method: "POST", json: { targetEventId: target } });
    } catch (err) {
      setBusy(false);
      setError(errorMessage(err));
      return;
    }
    setBusy(false);
    toast("success", `Song setup copied to “${chosen?.ev.name ?? "event"}”.`);
    onClose();
    try {
      await refresh();
    } catch (err) {
      toast("error", `Copied, but refreshing failed: ${errorMessage(err)}`);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      locked={busy}
      size="md"
      eyebrow="Copy setup"
      title={source ? `Copy songs from “${source.name}”` : "Copy setup"}
      description="Copies songs, chosen sheets, notes and instrument capacities to another event."
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form="copy-form" className="btn-primary" busy={busy} busyLabel="Copying…" disabled={!target}>
            Copy setup
          </BusyButton>
        </>
      }
    >
      <form id="copy-form" onSubmit={submit} className="space-y-4" noValidate>
        {options.length === 0 ? (
          <Notice tone="info">There are no other events yet. Add or generate another event first.</Notice>
        ) : (
          <Field label="Target event" htmlFor="copy-target" required>
            <select id="copy-target" data-autofocus className="input" value={target} onChange={(e) => setTarget(e.target.value)}>
              <option value="">Choose an event…</option>
              {(data?.seasons ?? []).map((s) => {
                const evs = options.filter((o) => o.season.id === s.id);
                if (evs.length === 0) return null;
                return (
                  <optgroup key={s.id} label={s.id === season.id ? `${s.name} (this season)` : s.name}>
                    {evs.map(({ ev }) => (
                      <option key={ev.id} value={ev.id}>
                        {ev.name} — {formatDateTime(ev.startsAt, s.timezone)}
                        {ev.songs.length ? ` (has ${plural(ev.songs.length, "song")})` : ""}
                      </option>
                    ))}
                  </optgroup>
                );
              })}
            </select>
          </Field>
        )}
        {chosen && chosen.ev.songs.length > 0 ? (
          <Notice tone="warn">“{chosen.ev.name}” already has {plural(chosen.ev.songs.length, "song")}. The server decides whether copied songs replace or join them.</Notice>
        ) : null}
        <InlineError message={error} />
      </form>
    </Modal>
  );
}