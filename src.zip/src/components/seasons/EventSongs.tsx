"use client";

import { useEffect, useId, useMemo, useState, type FormEvent } from "react";
import { ArrowDown, ArrowUp, Pencil, Plus, Search, Trash2, Users } from "lucide-react";
import { INSTRUMENTS, SONG_ROLES, type SongRole, type EventSong, type MinistryEvent, type Requirement, type Song } from "@/lib/contracts";
import { api, errorMessage, isImpactError, plural, sheetDownloadUrl } from "@/lib/client";
import { useAdmin } from "@/components/shell/AdminProvider";
import { Modal } from "@/components/ui/Modal";
import { BusyButton, InlineError, Notice, useToast } from "@/components/ui/Feedback";
import { EmptyState, Field, Tag } from "@/components/ui/Bits";
import { MusicIcon, QuietNotesArt } from "@/components/ui/Motifs";
import { ConfirmDialog } from "@/components/ui/Confirm";
import { CreateSongDialog } from "@/components/library/SongDialogs";

export type Caps = Record<string, string>;

export function SongRoleField({ value, onChange, disabled }: { value: SongRole | null; onChange: (value: SongRole | null) => void; disabled?: boolean }) {
  const id = useId();
  return <Field label="Song role for this season" htmlFor={id} hint="Applies to this song at every event in this season only; the library and other seasons are unchanged.">
    <select id={id} className="input" value={value ?? ""} disabled={disabled} onChange={(event) => {
      onChange(SONG_ROLES.find((role) => role === event.target.value) ?? null);
    }}>
      <option value="">Not specified</option>
      {SONG_ROLES.map((role) => <option key={role} value={role}>{role}</option>)}
    </select>
  </Field>;
}

function capsFrom(reqs: Requirement[]): Caps {
  const c: Caps = {};
  for (const r of reqs) c[r.instrument] = String(r.capacity);
  return c;
}

export function capsTo(c: Caps): Requirement[] | string {
  const out: Requirement[] = [];
  for (const inst of INSTRUMENTS) {
    const raw = (c[inst] ?? "").trim();
    if (!raw) {
      if (Object.hasOwn(c, inst)) return `Enter a capacity for ${inst}.`;
      continue;
    }
    const n = Number(raw);
    if (!Number.isInteger(n) || n < 1 || n > 1000) return `${inst} capacity must be a whole number between 1 and 1000.`;
    if (n > 0) out.push({ instrument: inst, capacity: n } as Requirement);
  }
  return out;
}

export function CapacityGrid({ caps, onChange, disabled }: { caps: Caps; onChange: (c: Caps) => void; disabled?: boolean }) {
  const prefix = useId();
  return (
    <fieldset className="space-y-2" disabled={disabled}>
      <legend className="field-label">Instrument type</legend>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {INSTRUMENTS.map((inst) => {
          const id = `${prefix}-${inst.replace(/\s+/g, "-").toLowerCase()}`;
          const selected = Object.hasOwn(caps, inst) && caps[inst] !== undefined;
          return (
            <div key={inst} className="min-w-0 rounded-lg border border-parchment-300 p-3">
              <label className="flex items-center gap-2 text-sm font-medium text-ink-soft">
                <input type="checkbox" checked={selected} className="size-4 accent-[var(--color-forest-700)]" onChange={(event) => {
                  const next = { ...caps };
                  if (event.target.checked) next[inst] = "1";
                  else delete next[inst];
                  onChange(next);
                }} />
                {inst}
              </label>
              {selected ? <>
              <label htmlFor={id} className="mt-2 block text-xs text-ink-muted">{inst} spots</label>
              <input
                id={id}
                type="number"
                min={1}
                max={1000}
                step={1}
                inputMode="numeric"
                className="input mt-1 py-1.5"
                value={caps[inst] ?? ""}
                disabled={disabled}
                onChange={(e) => onChange({ ...caps, [inst]: e.target.value })}
              />
              </> : null}
            </div>
          );
        })}
      </div>
    </fieldset>
  );
}

export function SheetChecklist({ song, selected, onChange, disabled }: { song: Song; selected: string[]; onChange: (ids: string[]) => void; disabled?: boolean }) {
  const sheets = song.sheets;
  if (sheets.length === 0) return <Notice tone="warn">This song has no active PDF sheets. Add sheets in the library first.</Notice>;
  return (
    <fieldset className="space-y-2">
      <legend className="field-label">Sheets families will receive</legend>
      <ul className="space-y-2">
        {sheets.map((s) => {
          const checked = selected.includes(s.id);
          return (
            <li key={s.id}>
              <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-3 transition ${checked ? "border-forest-500 gradient-tint" : "border-parchment-300 bg-parchment-50 hover:border-forest-300"}`}>
                <input
                  type="checkbox"
                  className="mt-1 size-4 accent-[var(--color-forest-700)]"
                  checked={checked}
                  disabled={disabled || (s.archived && !checked)}
                  onChange={(e) => onChange(e.target.checked ? [...selected, s.id] : selected.filter((x) => x !== s.id))}
                />
                <span className="min-w-0">
                  <span className="block font-medium text-ink">{s.label}</span>
                  <span className="mt-1 flex flex-wrap gap-1.5">
                    <Tag tone={s.instrument ? "forest" : "muted"}>{s.instrument ?? "All instruments"}</Tag>
                    {s.arrangement ? <Tag tone="sage">{s.arrangement}</Tag> : null}
                    <Tag tone="muted">v{s.version}</Tag>
                    {s.archived ? <Tag tone="rose">Archived</Tag> : null}
                  </span>
                </span>
              </label>
              <a className="mt-1 inline-flex items-center gap-1 text-sm text-forest-700 underline" href={sheetDownloadUrl(s.id, s.version, true)} target="_blank" rel="noopener noreferrer"><MusicIcon className="size-4" aria-hidden />{s.fileName}</a>
            </li>
          );
        })}
      </ul>
    </fieldset>
  );
}

export function SongDetails({ song }: { song: Song }) {
  return (
    <div className="min-w-0 space-y-3 break-words">
      {song.composer ? <p className="text-sm text-ink-muted">{song.composer}</p> : null}
      <div><h4 className="field-label">Song notes</h4><p className="whitespace-pre-wrap text-sm text-ink-soft">{song.notes || "No song notes."}</p></div>
      <div><h4 className="field-label">Song links</h4>
        {song.links?.length ? <ul className="space-y-1">{song.links.map((link, index) => <li key={`${index}-${link}`}><a className="break-all text-sm text-forest-700 underline" href={link} target="_blank" rel="noopener noreferrer">{link}</a></li>)}</ul> : <p className="text-sm text-ink-muted">No song links.</p>}
      </div>
    </div>
  );
}

export function AddEventSongDialog({ open, onClose, event }: { open: boolean; onClose: () => void; event: MinistryEvent }) {
  const { data, refresh } = useAdmin();
  const toast = useToast();
  const [query, setQuery] = useState("");
  const [songId, setSongId] = useState<string | null>(null);
  const [sheetIds, setSheetIds] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [caps, setCaps] = useState<Caps>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [songRole, setSongRole] = useState<SongRole | null>(null);

  useEffect(() => {
    if (open) {
      setQuery("");
      setSongId(null);
      setSheetIds([]);
      setNotes("");
      setCaps({});
      setSongRole(null);
      setError(null);
    }
  }, [open]);

  const used = new Set(event.songs.map((s) => s.songId));
  const songs = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (data?.songs ?? [])
      .filter((s) => !s.archived)
      .filter((s) => !q || [s.title, s.composer, ...s.sheets.map((x) => `${x.label} ${x.instrument ?? ""} ${x.arrangement}`)].join(" ").toLowerCase().includes(q))
      .sort((a, b) => a.title.localeCompare(b.title));
  }, [data, query]);
  const song = (data?.songs ?? []).find((s) => s.id === songId) ?? null;

  function pick(s: Song) {
    setSongId(s.id);
    setSheetIds(s.sheets.filter((x) => !x.archived).map((x) => x.id));
    setCaps({});
    setError(null);
    setSongRole(data?.seasons.find((season) => season.id === event.seasonId)?.events.flatMap((item) => item.songs).find((item) => item.songId === s.id)?.songRole ?? null);
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!song) return setError("Choose a song from the library.");
    if (sheetIds.length === 0) return setError("Select at least one sheet.");
    const requirements = capsTo(caps);
    if (typeof requirements === "string") return setError(requirements);
    setBusy(true);
    setError(null);
    try {
      await api(`/api/admin/events/${event.id}/songs`, { method: "POST", json: { songId: song.id, sheetIds, notes: notes.trim(), requirements, songRole } });
    } catch (err) {
      setBusy(false);
      setError(errorMessage(err));
      return;
    }
    setBusy(false);
    toast("success", `“${song.title}” added to ${event.name}.`);
    onClose();
    try {
      await refresh();
    } catch (err) {
      toast("error", `Added, but refreshing failed: ${errorMessage(err)}`);
    }
  }

  return (
    <>
      <Modal
        open={open && !creating}
        onClose={onClose}
        locked={busy}
        size="lg"
        variant="drawer"
        eyebrow={event.name}
        title={song ? `Set up “${song.title}”` : "Add a song from the library"}
        description={song ? "Choose sheets, instrument capacities and notes for this event." : "Search the library and pick a song."}
        footer={
          <>
            {song ? (
              <button type="button" className="btn-ghost" onClick={() => setSongId(null)} disabled={busy}>
                Back to library
              </button>
            ) : (
              <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
                Cancel
              </button>
            )}
            <BusyButton type="submit" form="add-event-song" className="btn-primary" busy={busy} busyLabel="Adding…" disabled={!song}>
              Add to event
            </BusyButton>
          </>
        }
      >
        <form id="add-event-song" onSubmit={submit} className="space-y-5" noValidate>
          {!song ? (
            <>
              <div className="relative">
                <label htmlFor="picker-search" className="sr-only">
                  Search songs
                </label>
                <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-ink-muted" aria-hidden />
                <input id="picker-search" data-autofocus type="search" className="input pl-9" placeholder="Search title, composer, instrument…" value={query} onChange={(e) => setQuery(e.target.value)} />
              </div>
              {songs.length === 0 ? (
                <EmptyState art={<QuietNotesArt className="h-20 w-auto" />} title={query ? "No songs match" : "The library is empty"} action={
                  <button type="button" className="btn-secondary" onClick={() => setCreating(true)}>
                    <Plus className="size-4" aria-hidden /> Create a song
                  </button>
                }>
                  {query ? "Try another word, or create the song now." : "Upload your first song and its PDF sheets."}
                </EmptyState>
              ) : (
                <ul className="space-y-2" aria-label="Library songs">
                  {songs.map((s) => {
                    const active = s.sheets.filter((x) => !x.archived);
                    return (
                      <li key={s.id}>
                        <button type="button" onClick={() => pick(s)} className="card-interactive flex w-full items-center gap-3 p-3 text-left">
                          <span className="grid size-10 shrink-0 place-items-center rounded-xl gradient-tint text-forest-700">
                            <MusicIcon className="size-5" aria-hidden />
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-serif text-lg text-ink">{s.title}</span>
                            <span className="block truncate text-sm text-ink-muted">
                              {s.composer || "Composer unknown"} · {plural(active.length, "sheet")}
                            </span>
                          </span>
                          {used.has(s.id) ? <Tag tone="amber">Already in event</Tag> : null}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
              <button type="button" className="btn-ghost btn-sm" onClick={() => setCreating(true)}>
                <Plus className="size-4" aria-hidden /> New song not in the library?
              </button>
            </>
          ) : (
            <>
              {used.has(song.id) ? <Notice tone="warn">This song is already in this event. Adding it again creates a second entry.</Notice> : null}
              <SongDetails song={song} />
              <SongRoleField value={songRole} onChange={setSongRole} disabled={busy} />
              <SheetChecklist song={song} selected={sheetIds} onChange={setSheetIds} disabled={busy} />
              <CapacityGrid caps={caps} onChange={setCaps} disabled={busy} />
              <Field label="Notes for this event" htmlFor="es-notes" hint="E.g. “Verse 2 only” or “Bring a capo”.">
                <textarea id="es-notes" className="input min-h-20" value={notes} onChange={(e) => setNotes(e.target.value)} disabled={busy} />
              </Field>
            </>
          )}
          <InlineError message={error} />
        </form>
      </Modal>
      <CreateSongDialog
        open={open && creating}
        onClose={() => setCreating(false)}
        onCreated={(id) => {
          setCreating(false);
          if (id) {
            const created = (data?.songs ?? []).find((s) => s.id === id);
            if (created) pick(created);
            else setSongId(id);
          }
        }}
      />
    </>
  );
}

export function EditEventSongDialog({ open, onClose, item }: { open: boolean; onClose: () => void; item: EventSong | null }) {
  const { data, refresh } = useAdmin();
  const toast = useToast();
  const [sheetIds, setSheetIds] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [caps, setCaps] = useState<Caps>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [impact, setImpact] = useState<string | null>(null);
  const [songRole, setSongRole] = useState<SongRole | null>(null);

  useEffect(() => {
    if (open && item) {
      setSheetIds(item.sheets.map((s) => s.id));
      setNotes(item.notes);
      setCaps(capsFrom(item.requirements));
      setSongRole(item.songRole);
      setError(null);
      setImpact(null);
    }
  }, [open, item]);

  const song = (data?.songs ?? []).find((s) => s.id === item?.songId) ?? null;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!item) return;
    if (sheetIds.length === 0) return setError("Select at least one sheet.");
    const requirements = capsTo(caps);
    if (typeof requirements === "string") return setError(requirements);
    setBusy(true);
    setError(null);
    const body: Record<string, unknown> = { sheetIds, notes: notes.trim(), requirements };
    if (songRole !== item.songRole) body.songRole = songRole;
    if (impact) body.confirmImpact = true;
    try {
      await api(`/api/admin/event-songs/${item.id}`, { method: "PATCH", json: body });
    } catch (err) {
      setBusy(false);
      if (!impact && isImpactError(err)) {
        setImpact(errorMessage(err));
        return;
      }
      setError(errorMessage(err));
      return;
    }
    setBusy(false);
    toast("success", "Song setup saved.");
    onClose();
    try {
      await refresh();
    } catch (err) {
      toast("error", `Saved, but refreshing failed: ${errorMessage(err)}`);
    }
  }

  return (
    <Modal
      open={open && !!item}
      onClose={onClose}
      locked={busy}
      size="lg"
      variant="drawer"
      eyebrow="Event song"
      title={item ? item.title : "Edit song"}
      footer={
        <>
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>
            Cancel
          </button>
          <BusyButton type="submit" form="edit-event-song" className={impact ? "btn-danger" : "btn-primary"} busy={busy} busyLabel="Saving…">
            {impact ? "Confirm and save" : "Save setup"}
          </BusyButton>
        </>
      }
    >
      <form id="edit-event-song" onSubmit={submit} className="space-y-5" noValidate>
        <SongRoleField value={songRole} onChange={setSongRole} disabled={busy} />
        {song ? (
          <>
            <SongDetails song={song} />
            <SheetChecklist song={song} selected={sheetIds} onChange={setSheetIds} disabled={busy} />
          </>
        ) : (
          <Notice tone="warn">The library song could not be found; sheets can’t be changed here.</Notice>
        )}
        <CapacityGrid caps={caps} onChange={setCaps} disabled={busy} />
        <Field label="Notes for this event" htmlFor="ees-notes">
          <textarea id="ees-notes" className="input min-h-20" value={notes} onChange={(e) => setNotes(e.target.value)} disabled={busy} />
        </Field>
        {impact ? (
          <Notice tone="warn">
            <strong className="font-semibold">Families may be affected.</strong> {impact}
          </Notice>
        ) : null}
        <InlineError message={error} />
      </form>
    </Modal>
  );
}

export function EventSongList({ event, editable = true }: { event: MinistryEvent; editable?: boolean }) {
  const { refresh } = useAdmin();
  const toast = useToast();
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<EventSong | null>(null);
  const [removing, setRemoving] = useState<EventSong | null>(null);
  const [removeImpact, setRemoveImpact] = useState(false);
  const [moving, setMoving] = useState<string | null>(null);
  const [extraTarget, setExtraTarget] = useState<EventSong | null>(null);
  const items = [...event.songs].sort((a, b) => a.position - b.position);

  async function changeExtra() {
    if (!extraTarget) return;
    await api(`/api/admin/seasons/${event.seasonId}/songs/${extraTarget.songId}`, {
      method: "PATCH", json: { allowExtra: !extraTarget.allowExtra, confirmImpact: true },
    });
    toast("success", "Extra-song registration updated for this season.");
    setExtraTarget(null);
    try {
      await refresh();
    } catch (err) {
      toast("error", `Saved, but refreshing failed: ${errorMessage(err)}`);
    }
  }

  async function move(item: EventSong, dir: -1 | 1) {
    const idx = items.findIndex((i) => i.id === item.id);
    const other = items[idx + dir];
    if (!other) return;
    setMoving(item.id);
    try {
      await api(`/api/admin/event-songs/${item.id}`, { method: "PATCH", json: { position: other.position } });
    } catch (err) {
      setMoving(null);
      toast("error", `Couldn’t reorder: ${errorMessage(err)}`);
      return;
    }
    try {
      await refresh();
    } catch (err) {
      toast("error", `Reordered, but refreshing failed: ${errorMessage(err)}`);
    } finally {
      setMoving(null);
    }
  }

  async function remove() {
    if (!removing) return;
    const url = `/api/admin/event-songs/${removing.id}${removeImpact ? "?confirmImpact=true" : ""}`;
    try {
      await api(url, { method: "DELETE" });
    } catch (err) {
      if (!removeImpact && isImpactError(err)) {
        setRemoveImpact(true);
        throw new Error(`${errorMessage(err)} Select “Remove anyway” to confirm.`);
      }
      throw err;
    }
    toast("success", `“${removing.title}” removed from ${event.name}.`);
    setRemoving(null);
    setRemoveImpact(false);
    try {
      await refresh();
    } catch (err) {
      toast("error", `Removed, but refreshing failed: ${errorMessage(err)}`);
    }
  }

  return (
    <div className="space-y-3">
      {items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-parchment-300 bg-parchment-50 p-5 text-center">
          <MusicIcon className="mx-auto size-6 text-ink-muted" aria-hidden />
          <p className="mt-2 font-serif text-lg text-ink">No songs yet</p>
          <p className="text-sm text-ink-muted">Pick songs from the library to set instrument capacities and the sheets families receive.</p>
        </div>
      ) : (
        <ol className="space-y-2">
          {items.map((item, i) => {
            const total = item.requirements.reduce((n, r) => n + r.capacity, 0);
            const reservations = event.reservations.filter((reservation) => reservation.eventSongId === item.id);
            return (
              <li key={item.id} className="rounded-2xl border border-parchment-300 bg-white/70 p-3 sm:p-4">
                <div className="flex items-start gap-3">
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-amber-soft font-serif text-sm font-semibold text-amber-deep" aria-hidden>
                    {i + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-serif text-lg leading-tight text-ink">{item.title}</p>
                    <p className="mt-1 text-sm text-ink-muted">{item.songRole ?? "Not specified"}</p>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {item.requirements.map((r) => (
                        <Tag key={r.instrument} tone="forest">
                          {r.instrument} × {r.capacity}
                        </Tag>
                      ))}
                      {item.requirements.length === 0 ? <Tag tone="muted">No instrument slots</Tag> : null}
                      <Tag tone="sage" icon={<Users className="size-3" aria-hidden />}>
                        {plural(total, "player")}
                      </Tag>
                      <Tag tone="muted" icon={<MusicIcon className="size-3" aria-hidden />}>
                        {plural(item.sheets.length, "sheet")}
                      </Tag>
                    </div>
                    {item.notes ? <p className="mt-2 text-sm text-ink-soft">{item.notes}</p> : null}
                    <label className="mt-3 flex items-start gap-2 text-sm font-medium text-forest-900">
                      <input type="checkbox" className="mt-0.5 size-4 accent-[var(--color-forest-700)]" checked={item.allowExtra} disabled={!editable} onChange={() => setExtraTarget(item)} />
                      Allow as extra song for this season
                    </label>
                    <p className="mt-1 text-xs text-ink-muted">Applies to this song at every event in this season only. Each child may book it once, in addition to one regular song.</p>
                  </div>
                  {editable ? (
                    <div className="flex shrink-0 flex-col gap-1 sm:flex-row">
                      <button type="button" className="icon-btn" aria-label={`Move ${item.title} up`} disabled={i === 0 || moving !== null} onClick={() => move(item, -1)}>
                        <ArrowUp className="size-4" aria-hidden />
                      </button>
                      <button type="button" className="icon-btn" aria-label={`Move ${item.title} down`} disabled={i === items.length - 1 || moving !== null} onClick={() => move(item, 1)}>
                        <ArrowDown className="size-4" aria-hidden />
                      </button>
                      <button type="button" className="icon-btn" aria-label={`Edit ${item.title} setup`} onClick={() => setEditing(item)}>
                        <Pencil className="size-4" aria-hidden />
                      </button>
                      <button type="button" className="icon-btn text-rose-deep" aria-label={`Remove ${item.title}`} onClick={() => { setRemoveImpact(false); setRemoving(item); }}>
                        <Trash2 className="size-4" aria-hidden />
                      </button>
                    </div>
                  ) : null}
                </div>
                <section className="mt-4 border-t border-parchment-200 pt-4" aria-label={`Confirmed reservations for ${item.title}`}>
                  <h4 className="font-semibold text-forest-900">Confirmed reservations ({reservations.length})</h4>
                  {reservations.length ? (
                    <div className="mt-2 overflow-x-auto">
                      <table className="w-full text-left text-sm">
                        <caption className="sr-only">Confirmed reservations for {item.title} at {event.name}</caption>
                        <thead className="text-ink-muted">
                          <tr>
                            <th scope="col" className="px-3 py-2">Child</th>
                            <th scope="col" className="px-3 py-2">Instrument</th>
                            <th scope="col" className="px-3 py-2">Spot</th>
                          </tr>
                        </thead>
                        <tbody>
                          {reservations.map((reservation) => (
                            <tr key={reservation.id} className="border-t border-parchment-200 text-ink">
                              <td className="px-3 py-2 font-medium">{reservation.childName}</td>
                              <td className="px-3 py-2">{reservation.instrument}</td>
                              <td className="px-3 py-2">{reservation.spotNumber}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <p className="mt-2 text-sm text-ink-muted">No confirmed reservations yet.</p>}
                </section>
              </li>
            );
          })}
        </ol>
      )}
      {editable ? (
        <button type="button" className="btn-secondary btn-sm" onClick={() => setAdding(true)}>
          <Plus className="size-4" aria-hidden /> Add song from library
        </button>
      ) : null}
      <AddEventSongDialog open={adding} onClose={() => setAdding(false)} event={event} />
      <EditEventSongDialog open={!!editing} onClose={() => setEditing(null)} item={editing} />
      <ConfirmDialog
        open={!!extraTarget}
        onClose={() => setExtraTarget(null)}
        title={`${extraTarget?.allowExtra ? "Disable" : "Enable"} extra-song registration?`}
        confirmLabel="Confirm setting"
        busyLabel="Saving..."
        tone="primary"
        onConfirm={changeExtra}
      >
        <p>Change registration eligibility for "{extraTarget?.title}" at every event in this season only. Other seasons and the library song are unchanged.</p>
        <p>Existing reservations remain confirmed. Disabling is blocked if a child would have more than one regular-song reservation.</p>
      </ConfirmDialog>
      <ConfirmDialog
        open={!!removing}
        onClose={() => { setRemoving(null); setRemoveImpact(false); }}
        title={removing ? `Remove “${removing.title}”?` : "Remove song"}
        confirmLabel={removeImpact ? "Remove anyway" : "Remove song"}
        busyLabel="Removing…"
        tone="danger"
        onConfirm={remove}
      >
        <p>The song stays in the library; only this event’s setup is removed.</p>
      </ConfirmDialog>
    </div>
  );
}