import { isValidElement, type ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Season } from "@/lib/contracts";
import { api } from "@/lib/client";
import { SeasonFormDialog } from "./SeasonForm";

const state = vi.hoisted(() => ({
  values: [] as unknown[], index: 0, close: vi.fn(), refresh: vi.fn(), toast: vi.fn(),
}));
vi.mock("react", async (original) => ({
  ...await original<typeof import("react")>(),
  useEffect: vi.fn(),
  useMemo: (factory: () => unknown) => factory(),
  useRef: () => ({ current: null }),
  useState: (initial: unknown) => {
    const index = state.index++;
    if (!(index in state.values)) state.values[index] = typeof initial === "function" ? initial() : initial;
    return [state.values[index], (value: unknown) => {
      state.values[index] = typeof value === "function" ? value(state.values[index]) : value;
    }];
  },
}));
vi.mock("@/lib/client", async (original) => ({
  ...await original<typeof import("@/lib/client")>(), api: vi.fn(),
}));
vi.mock("@/components/shell/AdminProvider", () => ({ useAdmin: () => ({ refresh: state.refresh }) }));
vi.mock("@/components/ui/Feedback", async (original) => ({
  ...await original<typeof import("@/components/ui/Feedback")>(), useToast: () => state.toast,
}));

const season: Season = {
  id: "season", name: "New season", description: "", startDate: "2031-01-01", endDate: "2031-12-31",
  timezone: "America/New_York", registrationOpensAt: "2031-01-01T15:00:00Z",
  registrationClosesAt: "2031-01-31T15:00:00Z", location: "", instructions: "", cancellationHours: 24,
  status: "Draft", events: [], firstPublishedAt: null, registrationNotificationAt: null,
  registrationNotificationTimezone: null, registrationNotificationSentAt: null,
};
type Props = {
  id?: string; children?: ReactNode; footer?: ReactNode; title?: string; message?: string | null;
  value?: string;
  onChange?: (event: { target: { value: string } }) => void;
  onClick?: () => void;
  onSubmit?: (event: { preventDefault: () => void }) => Promise<void>;
};
function elements(node: ReactNode): Props[] {
  if (Array.isArray(node)) return node.flatMap(elements);
  if (!isValidElement<Props>(node)) return [];
  return [node.props, ...elements(node.props.children), ...elements(node.props.footer)];
}
function render(current: Season | null = season) {
  state.index = 0;
  return elements(SeasonFormDialog({ open: true, onClose: state.close, season: current }));
}
function change(id: string, value: string, current: Season | null = season) {
  const control = render(current).find((props) => props.id === id);
  expect(control?.onChange).toBeTypeOf("function");
  control?.onChange?.({ target: { value } });
}
async function submit(current: Season | null = season) {
  await render(current).find((props) => props.id === "season-form")?.onSubmit?.({ preventDefault: vi.fn() });
}

beforeEach(() => {
  state.values = [];
  vi.mocked(api).mockReset().mockResolvedValue({});
  state.close.mockReset();
  state.refresh.mockReset().mockResolvedValue(undefined);
  state.toast.mockReset();
});

describe("first-publication scheduling prompt", () => {
  it("asks on Save rather than status selection and sends nothing until confirmed", async () => {
    change("season-status", "Published");
    expect(render().some((props) => props.id === "season-notification-time")).toBe(false);
    await submit();
    expect(render()[0].title).toBe("Schedule parent notification");
    expect(render().some((props) => props.id === "season-notification-time")).toBe(true);
    expect(api).not.toHaveBeenCalled();
    expect(state.close).not.toHaveBeenCalled();
  });

  it("converts the chosen season-local time to UTC before publishing", async () => {
    change("season-status", "Published");
    await submit();
    change("season-notification-time", "2031-07-01T10:00");
    await submit();
    expect(api).toHaveBeenCalledWith("/api/admin/seasons/season", {
      method: "PATCH",
      json: expect.objectContaining({ status: "Published", registrationNotificationAt: "2031-07-01T14:00:00.000Z" }),
    });
    expect(state.close).toHaveBeenCalledOnce();
  });

  it("defaults to registration opening time in the season timezone and submits that instant", async () => {
    change("season-status", "Published");
    await submit();
    expect(render().find((props) => props.id === "season-notification-time")?.value).toBe("2031-01-01T10:00");
    await submit();
    expect(api).toHaveBeenCalledWith("/api/admin/seasons/season", {
      method: "PATCH",
      json: expect.objectContaining({ registrationNotificationAt: "2031-01-01T15:00:00.000Z" }),
    });
  });

  it("uses unsaved registration changes, including changes made after going back", async () => {
    change("season-reg-open", "2031-01-02T09:30");
    change("season-status", "Published");
    await submit();
    expect(render().find((props) => props.id === "season-notification-time")?.value).toBe("2031-01-02T09:30");
    render().find((props) => props.children === "Back to season")?.onClick?.();
    change("season-reg-open", "2031-01-03T11:00");
    await submit();
    expect(render().find((props) => props.id === "season-notification-time")?.value).toBe("2031-01-03T11:00");
    expect(api).not.toHaveBeenCalled();
  });

  it("requires a future time when registration has already opened", async () => {
    change("season-reg-open", "2000-01-01T10:00");
    change("season-status", "Published");
    await submit();
    expect(render().find((props) => props.id === "season-notification-time")?.value).toBe("2000-01-01T10:00");
    await submit();
    expect(api).not.toHaveBeenCalled();
    expect(render().some((props) => props.message === "Choose a future date and time for the registration notification.")).toBe(true);
  });

  it.each(["", "2000-01-01T10:00", "2030-03-10T02:30"])("rejects empty, past and nonexistent daylight-saving times: %s", async (time) => {
    change("season-status", "Published");
    await submit();
    change("season-notification-time", time);
    await submit();
    expect(api).not.toHaveBeenCalled();
    expect(render().some((props) => typeof props.message === "string" && props.message.includes("date and time"))).toBe(true);
  });

  it("allows going back or cancelling without saving", async () => {
    change("season-status", "Published");
    await submit();
    render().find((props) => props.children === "Back to season")?.onClick?.();
    expect(render().some((props) => props.id === "season-status")).toBe(true);
    await submit();
    render().find((props) => props.children === "Cancel")?.onClick?.();
    expect(state.close).toHaveBeenCalledOnce();
    expect(api).not.toHaveBeenCalled();
  });

  it("does not prompt or resend a schedule when republishing", async () => {
    const published = { ...season, firstPublishedAt: "2030-01-01T00:00:00Z", registrationNotificationAt: "2031-01-01T14:00:00Z", registrationNotificationTimezone: "America/New_York" };
    change("season-status", "Published", published);
    await submit(published);
    expect(api).toHaveBeenCalledOnce();
    expect(vi.mocked(api).mock.calls[0][1]?.json).not.toHaveProperty("registrationNotificationAt");
  });

  it("saves Draft without a notification prompt", async () => {
    await submit();
    expect(api).toHaveBeenCalledOnce();
    expect(vi.mocked(api).mock.calls[0][1]?.json).toMatchObject({ status: "Draft" });
    expect(vi.mocked(api).mock.calls[0][1]?.json).not.toHaveProperty("registrationNotificationAt");
  });

  it("also prompts when creating a season directly as Published", async () => {
    render(null);
    for (const [id, value] of Object.entries({
      "season-name": "New published season", "season-start": "2031-01-01", "season-end": "2031-12-31",
      "season-tz": "America/New_York", "season-reg-open": "2031-01-01T10:00",
      "season-reg-close": "2031-01-31T10:00", "season-status": "Published",
    })) change(id, value, null);
    await submit(null);
    expect(api).not.toHaveBeenCalled();
    expect(render(null).find((props) => props.id === "season-notification-time")?.value).toBe("2031-01-01T10:00");
    change("season-notification-time", "2031-01-01T09:00", null);
    await submit(null);
    expect(api).toHaveBeenCalledWith("/api/admin/seasons", {
      method: "POST",
      json: expect.objectContaining({ registrationNotificationAt: "2031-01-01T14:00:00.000Z" }),
    });
  });

  it("keeps the scheduling step and reports a server failure instead of claiming publication", async () => {
    change("season-status", "Published");
    await submit();
    change("season-notification-time", "2031-07-01T10:00");
    vi.mocked(api).mockRejectedValueOnce(new Error("Schedule could not be saved"));
    await submit();
    expect(state.close).not.toHaveBeenCalled();
    expect(state.toast).not.toHaveBeenCalled();
    expect(render()[0].title).toBe("Schedule parent notification");
    expect(render().some((props) => props.message === "Schedule could not be saved")).toBe(true);
  });
});
