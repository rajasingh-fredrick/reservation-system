import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { SEASON_STATUSES, type AdminData, type MinistryEvent, type Season, type SeasonStatus } from "@/lib/contracts";
import { SeasonManagement } from "./SeasonManagement";

const state = vi.hoisted(() => ({ data: { songs: [], seasons: [], audit: [] } as AdminData }));

vi.mock("@/components/shell/AdminProvider", () => ({
  useAdminData: () => state.data,
  useAdmin: () => ({ refresh: vi.fn() }),
}));

vi.mock("./SeasonForm", () => ({ SeasonFormDialog: () => null }));
vi.mock("./EventDialogs", () => ({
  CopySetupDialog: () => null,
  EventFormDialog: () => null,
  GenerateEventsDialog: () => null,
}));

function season(status: SeasonStatus, startDate = "2026-01-01"): Season {
  return {
    id: `${status}-${startDate}`,
    name: `${status} music season ${startDate}`,
    description: "",
    startDate,
    endDate: "2026-12-31",
    registrationOpensAt: "2025-12-01 00:00:00",
    registrationClosesAt: "2025-12-31 00:00:00",
    timezone: "UTC",
    location: "",
    instructions: "",
    cancellationHours: 24,
    status,
    firstPublishedAt: status === "Draft" ? null : "2025-12-01T00:00:00Z",
    registrationNotificationAt: null,
    registrationNotificationTimezone: null,
    registrationNotificationSentAt: null,
    events: [],
  };
}

function render() {
  return renderToStaticMarkup(createElement(SeasonManagement));
}

describe("season status filters", () => {
  beforeEach(() => {
    state.data = { songs: [], seasons: [], audit: [] };
  });

  it("offers every status and initially selects only Draft and Published", () => {
    state.data.seasons = SEASON_STATUSES.map((status) => season(status));
    const html = render();
    const checkboxes = html.match(/<input[^>]*type="checkbox"[^>]*>/g) ?? [];

    expect(checkboxes).toHaveLength(SEASON_STATUSES.length);
    SEASON_STATUSES.forEach((status, index) => {
      expect(html).toContain(status);
      expect(checkboxes[index].includes('checked=""')).toBe(status === "Draft" || status === "Published");
      expect(html.includes(season(status).name)).toBe(status === "Draft" || status === "Published");
    });
    expect(html).toContain("Showing 2 of 5 seasons");
    expect(html).toContain("Show all");
    expect(html).toContain("Reset filters");
  });

  it("keeps matching seasons in descending start date order without changing the source", () => {
    const older = season("Draft", "2026-01-01");
    const newer = season("Published", "2026-06-01");
    state.data.seasons = [older, season("Archived"), newer];
    const original = [...state.data.seasons];
    const html = render();

    expect(html.indexOf(newer.name)).toBeLessThan(html.indexOf(older.name));
    expect(state.data.seasons).toEqual(original);
  });

  it("shows a filter-specific empty state when only hidden statuses exist", () => {
    state.data.seasons = [season("Completed"), season("Archived")];
    const html = render();

    expect(html).toContain("No seasons match these filters");
    expect(html).toContain("Show all seasons");
    expect(html).toContain("Showing 0 of 2 seasons");
    expect(html).not.toContain("No seasons yet");
  });

  it("keeps the create-season empty state when no seasons exist", () => {
    const html = render();

    expect(html).toContain("No seasons yet");
    expect(html).toContain("Create a season");
    expect(html).not.toContain("No seasons match these filters");
  });

  it("groups confirmed children under the exact event song, including identical titles and empty songs", () => {
    const current = season("Published");
    current.events = [{
      id: "event", seasonId: current.id, name: "Sunday music",
      startsAt: "2026-02-01 10:00:00", endsAt: "2026-02-01 11:00:00",
      location: "", songs: ["first-song", "second-song", "empty-song"].map((id, position) => ({
        id, songId: "library-song", title: "Shared song title", notes: "", position,
        allowExtra: false, songRole: null, requirements: [], sheets: [],
      })),
      reservations: [
        { id: "first", eventSongId: "first-song", childName: "Alex Example", songTitle: "Shared song title", instrument: "Violin", spotNumber: 1 },
        { id: "second", eventSongId: "second-song", childName: "Sam Example", songTitle: "Shared song title", instrument: "Piano", spotNumber: 2 },
      ],
    }, {
      id: "empty", seasonId: current.id, name: "Empty event",
      startsAt: "2026-02-08 10:00:00", endsAt: "2026-02-08 11:00:00",
      location: "", songs: [], reservations: [],
    }];
    state.data.seasons = [current];
    const html = render();
    const sections = [...html.matchAll(/<section\b[^>]*aria-label="Confirmed reservations[^"]*"[^>]*>([\s\S]*?)<\/section>/g)]
      .map((match) => match[1]);
    expect(sections).toHaveLength(3);
    expect(sections[0]).toContain("Confirmed reservations (1)");
    expect(sections[0]).toContain("Alex Example");
    expect(sections[0]).not.toContain("Sam Example");
    expect(sections[1]).toContain("Confirmed reservations (1)");
    expect(sections[1]).toContain("Sam Example");
    expect(sections[1]).not.toContain("Alex Example");
    expect(sections[2]).toContain("Confirmed reservations (0)");
    expect(sections[2]).toContain("No confirmed reservations yet.");
    expect(html).toContain("Confirmed reservations for Shared song title at Sunday music");
    for (const reservation of current.events[0].reservations) {
      expect(html).toContain(`<td class="px-3 py-2 font-medium">${reservation.childName}</td>`);
      for (const value of [reservation.instrument, reservation.spotNumber]) {
        expect(html).toContain(`<td class="px-3 py-2">${value}</td>`);
      }
    }
    expect(html).toContain("Event 1 of 2");
    current.events = [current.events[1]];
    const emptyHtml = render();
    expect(emptyHtml).not.toContain("Confirmed reservations");
    expect(emptyHtml).toContain("No songs yet");
  });

  it("shows only the first event card and independent navigation for each season", () => {
    state.data.seasons = [season("Published"), season("Draft")].map((current) => ({
      ...current,
      events: [1, 8, 15].map((day) => ({
        id: `${current.id}-${day}`,
        seasonId: current.id,
        name: `Weekly event ${day}`,
        startsAt: `2026-02-${String(day).padStart(2, "0")}T10:00:00Z`,
        endsAt: `2026-02-${String(day).padStart(2, "0")}T11:00:00Z`,
        location: "",
        songs: [],
        reservations: [],
      })),
    }));

    const articles = render().match(/<article\b[^>]*>/g) ?? [];
    expect(articles).toHaveLength(2);
    for (const article of articles) {
      expect(article).toContain("bg-white");
      expect(article).toContain("border-parchment-300");
    }
    expect(render().match(/Event 1 of 3:/g)).toHaveLength(2);
  });

  it("offers event deletion in published seasons unless reservation history exists", () => {
    const openSeason = season("Published", "2026-06-01");
    const reservedSeason = { ...season("Published", "2026-05-01"), id: "published-with-reservation", name: "Published season with reservation" };
    const event = (id: string, seasonId: string, name: string, reservations: MinistryEvent["reservations"]): MinistryEvent => ({
      id,
      seasonId,
      name,
      startsAt: "2026-06-01T10:00:00Z",
      endsAt: "2026-06-01T11:00:00Z",
      location: "",
      songs: [],
      reservations,
    });
    openSeason.events = [event("open", openSeason.id, "Open event", [])];
    reservedSeason.events = [event("reserved", reservedSeason.id, "Reserved event", [{
      id: "reservation", eventSongId: "song", childName: "Child", songTitle: "Song", instrument: "Piano", spotNumber: 1,
    }])];
    state.data.seasons = [openSeason, reservedSeason];

    const html = render();
    const openButton = html.match(/<button[^>]*aria-label="Delete Open event"[^>]*>/)?.[0];
    const reservedButton = html.match(/<button[^>]*aria-label="Delete Reserved event"[^>]*>/)?.[0];
    expect(openButton).toBeDefined();
    expect(openButton).not.toContain("disabled");
    expect(reservedButton).toContain("disabled");
  });
});
