import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { SEASON_STATUSES, type AdminData, type Season, type SeasonStatus } from "@/lib/contracts";
import { SeasonManagement } from "./SeasonManagement";

const state = vi.hoisted(() => ({ data: { songs: [], seasons: [], audit: [] } as AdminData }));

vi.mock("@/components/shell/AdminProvider", () => ({
  useAdminData: () => state.data,
  useAdmin: () => ({ refresh: vi.fn() }),
}));

vi.mock("./SeasonForm", () => ({ SeasonFormDialog: () => null }));
vi.mock("./EventDialogs", () => ({
  CopySetupDialog: () => null,
  EventFormDialog: () => null,
  GenerateEventsDialog: () => null,
}));

function season(status: SeasonStatus, startDate = "2026-01-01"): Season {
  return {
    id: `${status}-${startDate}`,
    name: `${status} music season ${startDate}`,
    description: "",
    startDate,
    endDate: "2026-12-31",
    registrationOpensAt: "2025-12-01T00:00:00Z",
    registrationClosesAt: "2025-12-31T00:00:00Z",
    timezone: "UTC",
    location: "",
    instructions: "",
    cancellationHours: 24,
    status,
    events: [],
  };
}

function render() {
  return renderToStaticMarkup(createElement(SeasonManagement));
}

describe("season status filters", () => {
  beforeEach(() => {
    state.data = { songs: [], seasons: [], audit: [] };
  });

  it("offers every status and initially selects only Draft and Published", () => {
    state.data.seasons = SEASON_STATUSES.map((status) => season(status));
    const html = render();
    const checkboxes = html.match(/<input[^>]*type="checkbox"[^>]*>/g) ?? [];

    expect(checkboxes).toHaveLength(SEASON_STATUSES.length);
    SEASON_STATUSES.forEach((status, index) => {
      expect(html).toContain(status);
      expect(checkboxes[index].includes('checked=""')).toBe(status === "Draft" || status === "Published");
      expect(html.includes(season(status).name)).toBe(status === "Draft" || status === "Published");
    });
    expect(html).toContain("Showing 2 of 5 seasons");
    expect(html).toContain("Show all");
    expect(html).toContain("Reset filters");
  });

  it("keeps matching seasons in descending start date order without changing the source", () => {
    const older = season("Draft", "2026-01-01");
    const newer = season("Published", "2026-06-01");
    state.data.seasons = [older, season("Archived"), newer];
    const original = [...state.data.seasons];
    const html = render();

    expect(html.indexOf(newer.name)).toBeLessThan(html.indexOf(older.name));
    expect(state.data.seasons).toEqual(original);
  });

  it("shows a filter-specific empty state when only hidden statuses exist", () => {
    state.data.seasons = [season("Completed"), season("Archived")];
    const html = render();

    expect(html).toContain("No seasons match these filters");
    expect(html).toContain("Show all seasons");
    expect(html).toContain("Showing 0 of 2 seasons");
    expect(html).not.toContain("No seasons yet");
  });

  it("keeps the create-season empty state when no seasons exist", () => {
    const html = render();

    expect(html).toContain("No seasons yet");
    expect(html).toContain("Create a season");
    expect(html).not.toContain("No seasons match these filters");
  });

  it("shows each event's children, songs, instruments, and spot numbers", () => {
    const current = season("Published");
    current.events = [{
      id: "event", seasonId: current.id, name: "Sunday music",
      startsAt: "2026-02-01T10:00:00Z", endsAt: "2026-02-01T11:00:00Z",
      location: "", songs: [],
      reservations: [
        { id: "first", childName: "Alex Example", songTitle: "Morning song", instrument: "Violin", spotNumber: 1 },
        { id: "second", childName: "Sam Example", songTitle: "Evening song", instrument: "Piano", spotNumber: 2 },
      ],
    }, {
      id: "empty", seasonId: current.id, name: "Empty event",
      startsAt: "2026-02-08T10:00:00Z", endsAt: "2026-02-08T11:00:00Z",
      location: "", songs: [], reservations: [],
    }];
    state.data.seasons = [current];
    const html = render();
    expect(html).toContain("Confirmed reservations (2)");
    expect(html).toContain("Confirmed reservations for Sunday music");
    for (const reservation of current.events[0].reservations) {
      expect(html).toContain(`<td class="px-3 py-2 font-medium">${reservation.childName}</td>`);
      for (const value of [reservation.songTitle, reservation.instrument, reservation.spotNumber]) {
        expect(html).toContain(`<td class="px-3 py-2">${value}</td>`);
      }
    }
    expect(html).toContain("Confirmed reservations (0)");
    expect(html).toContain("No confirmed reservations yet.");
  });
});
