import { isValidElement, type ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { SONG_ROLES, type EventSong, type MinistryEvent } from "@/lib/contracts";
import { api } from "@/lib/client";
import { EditEventSongDialog, EventSongList, SongRoleField } from "./EventSongs";

const hooks = vi.hoisted(() => ({
  values: [] as unknown[], index: 0, effects: [] as (() => void)[],
  refresh: vi.fn(), toast: vi.fn(), close: vi.fn(),
}));
vi.mock("@/lib/client", async (original) => ({ ...await original<typeof import("@/lib/client")>(), api: vi.fn() }));
vi.mock("@/components/shell/AdminProvider", () => ({ useAdmin: () => ({ refresh: hooks.refresh }) }));
vi.mock("@/components/ui/Feedback", async (original) => ({
  ...await original<typeof import("@/components/ui/Feedback")>(), useToast: () => hooks.toast,
}));
vi.mock("react", async (original) => ({
  ...await original<typeof import("react")>(),
  useId: () => "song-role",
  useEffect: (effect: () => void) => { hooks.effects.push(effect); },
  useState: (initial: unknown) => {
    const index = hooks.index++;
    if (!(index in hooks.values)) hooks.values[index] = initial;
    return [hooks.values[index], (value: unknown) => { hooks.values[index] = value; }];
  },
}));
type Props = {
  children?: ReactNode; value?: string | null; disabled?: boolean; message?: string | null;
  id?: string;
  onSubmit?: (event: { preventDefault: () => void }) => Promise<void>;
  onChange?: (event: { target: { value: string } }) => void;
};
function elements(node: ReactNode): Props[] {
  if (Array.isArray(node)) return node.flatMap(elements);
  if (!isValidElement<Props>(node)) return [];
  return [node.props, ...elements(node.props.children)];
}
const item: EventSong = {
  id: "appearance", songId: "library-song", title: "Test", notes: "", position: 1,
  allowExtra: true, songRole: "Opening Song", requirements: [], sheets: [{
    id: "sheet", songId: "library-song", label: "Score", instrument: null, arrangement: "",
    fileName: "score.pdf", size: 10, version: 1, selectedVersion: 1, archived: false, createdAt: "", usages: [],
  }],
};
const event: MinistryEvent = {
  id: "event", seasonId: "season", name: "Test", startsAt: "", endsAt: "", location: "", songs: [item], reservations: [],
};
function editor(current = item) {
  hooks.index = 0;
  hooks.effects = [];
  return EditEventSongDialog({ open: true, item: current, onClose: hooks.close });
}
function mount(current = item) {
  editor(current);
  hooks.effects.forEach((effect) => effect());
}
function roleField() {
  const tree = editor();
  const form = tree.props.children;
  return form.props.children[0];
}
async function submit() {
  await elements(editor()).find((props) => props.id === "edit-event-song")!.onSubmit!({ preventDefault: vi.fn() });
}
beforeEach(() => {
  hooks.values = [];
  hooks.refresh.mockReset().mockResolvedValue(undefined);
  hooks.toast.mockReset();
  hooks.close.mockReset();
  vi.mocked(api).mockReset().mockResolvedValue({ ok: true });
});

describe("season song role controls", () => {
  it("offers exactly the four requested roles and an unclassified option", () => {
    const props = elements(SongRoleField({ value: null, onChange: vi.fn() }));
    expect(props.filter((value) => value.value !== undefined).map((value) => value.value)).toEqual(["", "", ...SONG_ROLES]);
    expect(props.some((value) => value.children === "Not specified")).toBe(true);
  });

  it("returns a valid role or null when the field is cleared", () => {
    const onChange = vi.fn();
    const select = elements(SongRoleField({ value: "Opening Song", onChange })).find((props) => props.onChange)!;
    select.onChange!({ target: { value: "Offertory Song" } });
    select.onChange!({ target: { value: "" } });
    expect(onChange.mock.calls).toEqual([["Offertory Song"], [null]]);
  });

  it("displays the role as text on editable and read-only song listings", () => {
    for (const editable of [true, false]) {
      hooks.index = 0;
      const props = elements(EventSongList({ event, editable }));
      expect(props.some((value) => value.children === "Opening Song")).toBe(true);
      expect(props.some((value) => value.value === "Opening Song")).toBe(false);
    }
  });

  it("prefills the edit dropdown and saves a changed role together with setup only on submit", async () => {
    mount();
    expect(roleField().type).toBe(SongRoleField);
    expect(roleField().props.value).toBe("Opening Song");
    roleField().props.onChange("Closing Song");
    expect(api).not.toHaveBeenCalled();
    await submit();
    expect(api).toHaveBeenCalledWith("/api/admin/event-songs/appearance", {
      method: "PATCH", json: { sheetIds: ["sheet"], notes: "", requirements: [], songRole: "Closing Song" },
    });
    expect(hooks.refresh).toHaveBeenCalledOnce();
    expect(hooks.close).toHaveBeenCalledOnce();
  });

  it("clears the role from the edit dialog", async () => {
    mount();
    roleField().props.onChange(null);
    await submit();
    expect(api).toHaveBeenCalledWith(expect.any(String), expect.objectContaining({
      json: expect.objectContaining({ songRole: null }),
    }));
  });

  it("does not overwrite an unchanged role when saving other setup fields", async () => {
    mount();
    await submit();
    expect(api).toHaveBeenCalledWith(expect.any(String), {
      method: "PATCH", json: { sheetIds: ["sheet"], notes: "", requirements: [] },
    });
  });

  it("surfaces API errors without claiming success", async () => {
    vi.mocked(api).mockRejectedValueOnce(new Error("Role update failed"));
    mount();
    roleField().props.onChange(null);
    await submit();
    expect(elements(editor()).some((props) => props.message === "Role update failed")).toBe(true);
    expect(hooks.toast).not.toHaveBeenCalled();
    expect(hooks.refresh).not.toHaveBeenCalled();
    expect(hooks.close).not.toHaveBeenCalled();
  });

  it("distinguishes a saved role from a refresh failure", async () => {
    hooks.refresh.mockRejectedValueOnce(new Error("Offline"));
    mount();
    roleField().props.onChange("Special Song");
    await submit();
    expect(hooks.toast).toHaveBeenCalledWith("error", "Saved, but refreshing failed: Offline");
  });
});
