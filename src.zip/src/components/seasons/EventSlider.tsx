"use client";

import { useId, useMemo, useState, type ReactNode } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { formatDateTime } from "@/lib/client";

type SliderEvent = { id: string; name: string; startsAt: string };

export function EventSlider<Event extends SliderEvent>({ events, timezone, seasonName, children }: {
  events: Event[];
  timezone: string;
  seasonName: string;
  children: (event: Event, index: number) => ReactNode;
}) {
  const panelId = useId();
  const orderedEvents = useMemo(
    () => [...events].sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt)),
    [events],
  );
  const [selectedId, setSelectedId] = useState<string | null>(() => orderedEvents[0]?.id ?? null);
  const selectedIndex = orderedEvents.findIndex((event) => event.id === selectedId);
  const index = selectedIndex < 0 ? 0 : selectedIndex;
  const event = orderedEvents[index];

  if (selectedId !== (event?.id ?? null)) setSelectedId(event?.id ?? null);
  if (!event) return null;

  return (
    <section aria-label={`Events for ${seasonName}`} aria-roledescription="carousel" className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <label className="min-w-0 basis-full sm:flex-1 sm:basis-auto">
          <span className="field-label">Jump to event</span>
          <select className="input min-h-11" value={event.id} onChange={(change) => setSelectedId(change.target.value)} aria-controls={panelId}>
            {orderedEvents.map((item) => (
              <option key={item.id} value={item.id}>{formatDateTime(item.startsAt, timezone)} - {item.name}</option>
            ))}
          </select>
        </label>
        <div className="flex items-center gap-2">
          <button type="button" className="btn-secondary min-h-11" disabled={index === 0} onClick={() => setSelectedId(orderedEvents[index - 1].id)} aria-controls={panelId}>
            <ChevronLeft className="h-4 w-4" aria-hidden="true" />Previous
          </button>
          <button type="button" className="btn-secondary min-h-11" disabled={index === orderedEvents.length - 1} onClick={() => setSelectedId(orderedEvents[index + 1].id)} aria-controls={panelId}>
            Next<ChevronRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>
      <p className="text-sm text-ink-soft" role="status" aria-atomic="true">
        Event {index + 1} of {orderedEvents.length}: {formatDateTime(event.startsAt, timezone)} - {event.name}
      </p>
      <div id={panelId} role="group" aria-roledescription="slide" aria-label={`${index + 1} of ${orderedEvents.length}: ${event.name}`}>
        {children(event, index)}
      </div>
    </section>
  );
}
