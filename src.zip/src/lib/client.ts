import type { ApiError, Usage } from "./contracts";

export class ApiRequestError extends Error {
  status: number;
  code?: string;
  constructor(status: number, message: string, code?: string) {
    super(message);
    this.name = "ApiRequestError";
    this.status = status;
    this.code = code;
  }
}

function defaultMessage(status: number): string {
  if (status === 400 || status === 422) return "Some details were not accepted. Please review the form and try again.";
  if (status === 401) return "Your session has ended. Please sign in again.";
  if (status === 403) return "You do not have permission to do that. A verified administrator account is required.";
  if (status === 404) return "That item could not be found. It may have been removed by another administrator.";
  if (status === 409) return "This change conflicts with existing records.";
  if (status === 413) return "The upload is too large.";
  if (status === 429) return "Too many attempts. Please wait a moment and try again.";
  if (status >= 500) return "The server could not complete the request. Please try again shortly.";
  return `Request failed (${status}).`;
}

export interface RequestOptions {
  method?: "GET" | "POST" | "PATCH" | "DELETE" | "PUT";
  json?: unknown;
  form?: FormData;
  signal?: AbortSignal;
}

export async function api<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  let body: BodyInit | undefined;
  if (options.json !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(options.json);
  } else if (options.form) {
    body = options.form;
  }
  let res: Response;
  try {
    res = await fetch(path, {
      method: options.method ?? (body ? "POST" : "GET"),
      headers,
      body,
      credentials: "same-origin",
      cache: "no-store",
      signal: options.signal,
    });
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") throw err;
    throw new ApiRequestError(0, "Could not reach the server. Check your internet connection and try again.", "NETWORK");
  }
  const text = await res.text();
  let parsed: unknown = null;
  if (text) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = null;
    }
  }
  if (!res.ok) {
    const p = (parsed ?? {}) as Partial<ApiError> & { message?: string };
    const message = (typeof p.error === "string" && p.error) || (typeof p.message === "string" && p.message) || defaultMessage(res.status);
    throw new ApiRequestError(res.status, message, typeof p.code === "string" ? p.code : undefined);
  }
  return parsed as T;
}

export function errorMessage(err: unknown): string {
  if (err instanceof ApiRequestError) return err.message;
  if (err instanceof Error && err.message) return err.message;
  return "Something went wrong. Please try again.";
}

/** True when the server rejected a change because it needs explicit impact confirmation. */
export function isImpactError(err: unknown): err is ApiRequestError {
  if (!(err instanceof ApiRequestError) || err.status !== 409) return false;
  return /impact|confirm/i.test(`${err.code ?? ""} ${err.message}`);
}

/* ---------------- Time zone helpers ---------------- */

function partsIn(date: Date, timeZone: string) {
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const out: Record<string, number> = {};
  for (const p of dtf.formatToParts(date)) {
    if (p.type !== "literal") out[p.type] = Number(p.value);
  }
  return out as { year: number; month: number; day: number; hour: number; minute: number; second: number };
}

function offsetMs(date: Date, timeZone: string): number {
  const p = partsIn(date, timeZone);
  const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second);
  return asUtc - Math.floor(date.getTime() / 1000) * 1000;
}

export function isValidTimeZone(tz: string): boolean {
  if (!tz) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

export function browserTimeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
}

export function timeZoneOptions(): string[] {
  try {
    const list = Intl.supportedValuesOf("timeZone");
    if (list.length) return list;
  } catch {
    /* older engines fall through */
  }
  return [
    "America/New_York", "America/Chicago", "America/Denver", "America/Phoenix", "America/Los_Angeles",
    "America/Anchorage", "Pacific/Honolulu", "America/Toronto", "America/Mexico_City", "Europe/London",
    "Europe/Berlin", "Africa/Lagos", "Asia/Manila", "Asia/Seoul", "Australia/Sydney", "UTC",
  ];
}

/** Converts a wall-clock "YYYY-MM-DDTHH:mm" in `timeZone` into a UTC ISO string. */
export function zonedToIso(local: string, timeZone: string): string {
  const [d, t = "00:00"] = local.split("T");
  const [y, m, day] = d.split("-").map(Number);
  const [h, mi] = t.split(":").map(Number);
  const guess = Date.UTC(y, m - 1, day, h, mi);
  const first = offsetMs(new Date(guess), timeZone);
  let ts = guess - first;
  const second = offsetMs(new Date(ts), timeZone);
  if (second !== first) ts = guess - second;
  return new Date(ts).toISOString();
}

const pad = (n: number) => String(n).padStart(2, "0");

/** Converts an ISO timestamp into "YYYY-MM-DDTHH:mm" wall-clock in `timeZone` for inputs. */
export function isoToZonedInput(iso: string | null | undefined, timeZone: string): string {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const p = partsIn(date, safeTz(timeZone));
  return `${p.year}-${pad(p.month)}-${pad(p.day)}T${pad(p.hour % 24)}:${pad(p.minute)}`;
}

export function safeTz(tz: string | undefined | null): string {
  return tz && isValidTimeZone(tz) ? tz : "UTC";
}

export function formatDateTime(iso: string | null | undefined, timeZone: string, opts?: Intl.DateTimeFormatOptions): string {
  if (!iso) return "Not set";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "Invalid date";
  const defaults: Intl.DateTimeFormatOptions = opts?.dateStyle || opts?.timeStyle ? {} : {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  };
  return new Intl.DateTimeFormat("en-US", {
    timeZone: safeTz(timeZone),
    ...defaults,
    ...opts,
  }).format(date);
}

export function formatTime(iso: string, timeZone: string): string {
  return formatDateTime(iso, timeZone, { weekday: undefined, month: undefined, day: undefined, year: undefined });
}

export function formatEventDay(iso: string, timeZone: string): { weekday: string; day: string; month: string } {
  const date = new Date(iso);
  const tz = safeTz(timeZone);
  return {
    weekday: new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" }).format(date),
    day: new Intl.DateTimeFormat("en-US", { timeZone: tz, day: "numeric" }).format(date),
    month: new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "short" }).format(date),
  };
}

/** Season start/end are calendar dates; accept "YYYY-MM-DD" or an ISO timestamp. */
export function dateOnly(value: string | null | undefined): string {
  if (!value) return "";
  return value.slice(0, 10);
}

export function formatDateOnly(value: string | null | undefined, opts?: Intl.DateTimeFormatOptions): string {
  const d = dateOnly(value);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return "Not set";
  const [y, m, day] = d.split("-").map(Number);
  return new Intl.DateTimeFormat("en-US", {
    timeZone: "UTC",
    month: "short",
    day: "numeric",
    year: "numeric",
    ...opts,
  }).format(new Date(Date.UTC(y, m - 1, day, 12)));
}

export function formatDateRange(start: string, end: string): string {
  return `${formatDateOnly(start)} \u2013 ${formatDateOnly(end)}`;
}

export function zonedDateKey(iso: string, timeZone: string): string {
  return isoToZonedInput(iso, timeZone).slice(0, 10);
}

export function formatRelative(iso: string): string {
  const date = new Date(iso);
  const diff = Date.now() - date.getTime();
  const abs = Math.abs(diff);
  const rtf = new Intl.RelativeTimeFormat("en-US", { numeric: "auto" });
  const sign = diff > 0 ? -1 : 1;
  if (abs < 60_000) return "just now";
  if (abs < 3_600_000) return rtf.format(sign * Math.round(abs / 60_000), "minute");
  if (abs < 86_400_000) return rtf.format(sign * Math.round(abs / 3_600_000), "hour");
  if (abs < 7 * 86_400_000) return rtf.format(sign * Math.round(abs / 86_400_000), "day");
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(date);
}

export function formatBytes(size: number): string {
  if (!Number.isFinite(size) || size <= 0) return "0 KB";
  if (size < 1024 * 1024) return `${Math.max(1, Math.round(size / 1024))} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export function plural(n: number, one: string, many = `${one}s`): string {
  return `${n} ${n === 1 ? one : many}`;
}

export function uniqueUsageEvents(usages: Usage[]): Usage[] {
  const seen = new Set<string>();
  return usages.filter((u) => (seen.has(u.eventId) ? false : (seen.add(u.eventId), true)));
}

export function safeNextPath(value: string | null): string {
  if (!value || !value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) return "/";
  return value;
}

export function sheetDownloadUrl(sheetId: string, version?: number, preview = false): string {
  const base = `/api/admin/sheets/${encodeURIComponent(sheetId)}/download`;
  const params = new URLSearchParams();
  if (version) params.set("version", String(version));
  if (preview) params.set("preview", "true");
  const query = params.toString();
  return query ? `${base}?${query}` : base;
}