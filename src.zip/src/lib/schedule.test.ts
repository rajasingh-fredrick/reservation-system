import { describe, expect, it } from "vitest";
import { getScheduleDates } from "./schedule";

describe("event schedule dates", () => {
  it("keeps weekly generation on the selected weekday within the season", () => {
    expect(getScheduleDates("2026-01-07", "2026-01-27", 1, { frequency: "weekly" }))
      .toEqual(["2026-01-12", "2026-01-19", "2026-01-26"]);
  });

  it.each([1, 2, 3, 4])("selects the %sth occurrence of a weekday in each month", (weekOfMonth) => {
    expect(getScheduleDates("2026-01-01", "2026-03-31", 1, { frequency: "monthly", weekOfMonth }))
      .toEqual([1, 2, 3].map((month) => {
        const first = new Date(Date.UTC(2026, month - 1, 1));
        const day = 1 + ((1 - first.getUTCDay() + 7) % 7) + (weekOfMonth - 1) * 7;
        return `2026-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
      }));
  });

  it("skips months without a fifth occurrence and respects partial month boundaries", () => {
    expect(getScheduleDates("2026-03-01", "2026-05-31", 0, { frequency: "monthly", weekOfMonth: 5 }))
      .toEqual(["2026-03-29", "2026-05-31"]);
    expect(getScheduleDates("2026-02-01", "2026-02-28", 1, { frequency: "monthly", weekOfMonth: 1 }))
      .toEqual(["2026-02-02"]);
  });

  it("combines multiple repeat options on the same weekday without duplicate dates", () => {
    expect(getScheduleDates("2026-01-01", "2026-01-31", 1, [
      { frequency: "weekly" },
      { frequency: "monthly", weekOfMonth: 1 },
      { frequency: "monthly", weekOfMonth: 3 },
    ])).toEqual(["2026-01-05", "2026-01-12", "2026-01-19", "2026-01-26"]);
  });
});