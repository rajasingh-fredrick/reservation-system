export const INSTRUMENTS = [
  "Violin", "Piano", "Keyboard", "Drums", "Guitar", "Bass Guitar", "Saxophone",
] as const;
export type Instrument = (typeof INSTRUMENTS)[number];
export const MAX_PDF_BYTES = 15 * 1024 * 1024;
export const SEASON_STATUSES = [
  "Draft", "Published", "Registration Closed", "Completed", "Archived",
] as const;
export type SeasonStatus = (typeof SEASON_STATUSES)[number];
export const SONG_ROLES = ["Opening Song", "Closing Song", "Special Song", "Offertory Song"] as const;
export type SongRole = (typeof SONG_ROLES)[number];

export interface Usage {
  eventId: string;
  eventName: string;
  seasonId: string;
  seasonName: string;
  seasonStatus: SeasonStatus;
  startsAt: string;
}
export interface Sheet {
  id: string;
  songId: string;
  label: string;
  instrument: Instrument | null;
  arrangement: string;
  fileName: string;
  size: number;
  version: number;
  archived: boolean;
  createdAt: string;
  usages: Usage[];
}
export interface Song {
  id: string;
  title: string;
  composer: string;
  notes: string;
  links: string[];
  archived: boolean;
  createdAt: string;
  updatedAt: string;
  sheets: Sheet[];
  usages: Usage[];
}
export interface Requirement {
  instrument: Instrument;
  capacity: number;
}
export interface EventSong {
  id: string;
  songId: string;
  title: string;
  notes: string;
  position: number;
  allowExtra: boolean;
  songRole: SongRole | null;
  requirements: Requirement[];
  sheets: (Sheet & { selectedVersion: number })[];
}
export interface EventReservation {
  id: string;
  eventSongId: string;
  childName: string;
  songTitle: string;
  instrument: Instrument;
  spotNumber: number;
}
export interface MinistryEvent {
  id: string;
  seasonId: string;
  name: string;
  startsAt: string;
  endsAt: string;
  location: string;
  songs: EventSong[];
  reservations: EventReservation[];
}
export interface Season {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  registrationOpensAt: string;
  registrationClosesAt: string;
  timezone: string;
  location: string;
  instructions: string;
  cancellationHours: number;
  status: SeasonStatus;
  firstPublishedAt: string | null;
  registrationNotificationAt: string | null;
  registrationNotificationTimezone: string | null;
  registrationNotificationSentAt: string | null;
  events: MinistryEvent[];
}
export interface AuditEntry {
  id: string;
  action: string;
  description: string;
  actorName: string;
  createdAt: string;
}
export interface AdminData {
  songs: Song[];
  seasons: Season[];
  audit: AuditEntry[];
}
export interface AdminSession {
  user: { id: string; name: string; email: string };
}
export interface ApiError {
  error: string;
  code?: string;
}

/*
 * Shared HTTP contract:
 * GET /api/admin/data -> AdminData (no cache)
 * GET /api/setup -> { needsSetup: boolean }
 * POST /api/setup { token, name, email, password } -> { message: string }
 * Auth: Better Auth /api/auth/*; sign-in/email, sign-out, get-session.
 *
 * POST /api/admin/songs multipart: title, composer, notes, permission="true",
 *   files (multiple PDFs), sheetLabels (JSON string array), sheetInstruments
 *   (JSON (Instrument|null) array), sheetArrangements (JSON string array),
 *   links (optional JSON HTTP/HTTPS string array).
 * PATCH /api/admin/songs/:id JSON { title?,composer?,notes?,links?,archived?,confirmImpact? }
 * DELETE /api/admin/songs/:id -> { ok:true }; reject referenced records with 409.
 * POST /api/admin/songs/:id/sheets multipart: same files/labels/instruments/
 *   arrangements and permission, confirmImpact="true" when referenced.
 * PATCH /api/admin/sheets/:id multipart: label?,instrument?,arrangement?,
 *   archived? ("true"/"false"), file? (replacement PDF), permission,
 *   confirmImpact="true" when referenced. Retain old file versions.
 * DELETE /api/admin/sheets/:id -> { ok:true }; reject referenced records.
 * GET /api/admin/sheets/:id/download?version=N -> authorized PDF.
 *
 * POST /api/admin/seasons JSON all Season scalar fields except id; status optional.
 * PATCH /api/admin/seasons/:id JSON partial scalar fields.
 * PATCH /api/admin/seasons/:id/songs/:songId JSON {allowExtra?:boolean,songRole?:SongRole|null,confirmImpact?:boolean}.
 *   Season-scoped setting shared by all appearances of this library song.
 * DELETE /api/admin/seasons/:id (any status without reservation history; removes events, library untouched).
 * POST /api/admin/seasons/:id/events JSON {name,startsAt,endsAt,location,
 *   songs:{songId,sheetIds:string[],notes,requirements:Requirement[]}[]}.
 * POST /api/admin/seasons/:id/generate JSON {weekday:0..6,patterns?:
 *   ("weekly"|"monthly-1"|"monthly-2"|"monthly-3"|"monthly-4"|"monthly-5")[],
 *   time:"HH:mm",durationMinutes:number,name:string}; dates in season's timezone.
 * PATCH /api/admin/events/:id JSON {name?,startsAt?,endsAt?,location?,confirmImpact?}.
 * DELETE /api/admin/events/:id (no reservation history; non-draft seasons require confirmImpact=true).
 * POST /api/admin/events/:id/copy JSON {targetEventId:string}.
 * POST /api/admin/events/:id/songs JSON {songId,sheetIds:string[],notes,
 *   requirements:Requirement[]}.
 * PATCH /api/admin/event-songs/:id JSON {sheetIds?,notes?,requirements?,
 *   position?,songRole?:SongRole|null,confirmImpact?}. Role changes apply to the season/song pair.
 *   Changing sheet selection pins its current version.
 * DELETE /api/admin/event-songs/:id?confirmImpact=true.
 *
 * All writes return JSON; UI refetches data after success. Errors: ApiError
 * with meaningful HTTP status. All /api/admin endpoints require a verified
 * administrator session. All state-changing requests require same-origin checks.
 */
