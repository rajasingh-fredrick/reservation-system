export type SchedulePattern =
  | { frequency: "weekly" }
  | { frequency: "monthly"; weekOfMonth: number };

export function getScheduleDates(startDate: string, endDate: string, weekday: number, selectedPatterns: SchedulePattern | SchedulePattern[]) {
  const start = startDate.slice(0, 10);
  const end = endDate.slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end) || start > end || weekday < 0 || weekday > 6) return [];

  const dates = new Set<string>();
  for (const pattern of Array.isArray(selectedPatterns) ? selectedPatterns : [selectedPatterns]) {
    if (pattern.frequency === "weekly") {
      const cursor = new Date(`${start}T00:00:00Z`);
      cursor.setUTCDate(cursor.getUTCDate() + ((weekday - cursor.getUTCDay() + 7) % 7));
      while (cursor.toISOString().slice(0, 10) <= end) {
        dates.add(cursor.toISOString().slice(0, 10));
        cursor.setUTCDate(cursor.getUTCDate() + 7);
      }
      continue;
    }

    if (!Number.isInteger(pattern.weekOfMonth) || pattern.weekOfMonth < 1 || pattern.weekOfMonth > 5) continue;
    const [startYear, startMonth] = start.split("-").map(Number);
    const [endYear, endMonth] = end.split("-").map(Number);
    for (let monthIndex = startYear * 12 + startMonth - 1; monthIndex <= endYear * 12 + endMonth - 1; monthIndex++) {
      const year = Math.floor(monthIndex / 12);
      const month = monthIndex % 12 + 1;
      const first = new Date(Date.UTC(year, month - 1, 1));
      const day = 1 + ((weekday - first.getUTCDay() + 7) % 7) + (pattern.weekOfMonth - 1) * 7;
      const date = new Date(Date.UTC(year, month - 1, day));
      if (date.getUTCMonth() !== month - 1) continue;
      const localDate = date.toISOString().slice(0, 10);
      if (localDate >= start && localDate <= end) dates.add(localDate);
    }
  }
  return [...dates].sort();
}