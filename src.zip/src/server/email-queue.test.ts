import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({ query: vi.fn(), send: vi.fn(), child: vi.fn() }));
vi.mock("./db", () => ({
  query: (...args: unknown[]) => state.query(...args),
  transaction: (work: (tx: { query: typeof state.query }) => Promise<unknown>) => work({ query: state.query }),
}));
vi.mock("./mail", () => ({ sendMail: (...args: unknown[]) => state.send(...args) }));
vi.mock("./child-notifications", () => ({ deliverChildNotification: (...args: unknown[]) => state.child(...args) }));

import { deliverQueuedEmail, processImmediateNotifications, queueEmail } from "./email-queue";

const now = new Date("2026-11-03T22:00:00Z");
let task: {
  id: string; user_id: string; kind: string; subject: string; body: string | null;
  status: string; expected_email: string | null; expires_at: Date | null; next_attempt_at: Date; attempts: number;
};
let recipient: { email: string; email_verified: boolean; parent_registered: boolean; subscribed: boolean } | undefined;

beforeEach(() => {
  vi.useFakeTimers({ toFake: ["Date"] });
  vi.setSystemTime(now);
  vi.stubEnv("NODE_ENV", "production");
  task = {
    id: "email", user_id: "parent", kind: "ParentTransactional", subject: "Approved", body: "Profile approved for Anna",
    status: "Pending", expected_email: null, expires_at: null, next_attempt_at: now, attempts: 0,
  };
  recipient = { email: "current@example.test", email_verified: true, parent_registered: true, subscribed: true };
  state.send.mockReset().mockResolvedValue(undefined);
  state.child.mockReset().mockResolvedValue("Sent");
  state.query.mockReset().mockImplementation(async (sql: string, params: unknown[] = []) => {
    if (sql.startsWith("SELECT *")) return { rows: [{ ...task }] };
    if (sql.startsWith("SELECT u.email")) return { rows: recipient ? [recipient] : [] };
    if (sql.includes("SET status='Sending'")) task.status = "Sending";
    if (sql.includes("SET status=$1")) task.status = String(params[0]);
    return { rows: [], rowCount: 1 };
  });
  vi.spyOn(console, "error").mockImplementation(() => {});
});
afterEach(() => { vi.useRealTimers(); vi.unstubAllEnvs(); vi.restoreAllMocks(); });

describe("durable immediate email queue", () => {
  it("only persists a message when enqueuing, without sending SMTP", async () => {
    const tx = { query: state.query };
    const id = await queueEmail(tx, {
      userId: "parent", kind: "ParentTransactional", subject: "Approved", text: "Profile approved for Anna",
    });
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("INSERT INTO email_notifications"),
      [id, "parent", "ParentTransactional", null, "Approved", "Profile approved for Anna", null]);
    expect(state.send).not.toHaveBeenCalled();
  });

  it("delivers to the current registered verified parent, then removes the body and never resends", async () => {
    expect(await deliverQueuedEmail("email", now)).toBe("Sent");
    expect(state.send).toHaveBeenCalledExactlyOnceWith("current@example.test", "Approved", "Profile approved for Anna");
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("sent_at=$2,body=NULL"), ["Sent", now, "email"]);
    expect(await deliverQueuedEmail("email", now)).toBe("Sent");
    expect(state.send).toHaveBeenCalledTimes(1);
  });

  it.each(["Sending", "Sent", "Preview", "Skipped"])("does not resend %s messages", async (status) => {
    task.status = status;
    expect(await deliverQueuedEmail("email", now)).toBe(status);
    expect(state.send).not.toHaveBeenCalled();
  });

  it.each(["missing", "unregistered", "unverified", "unsubscribed"])("skips a ministry message for a %s recipient", async (reason) => {
    task.kind = "MinistryMessage";
    if (reason === "missing") recipient = undefined;
    if (reason === "unregistered") recipient!.parent_registered = false;
    if (reason === "unverified") recipient!.email_verified = false;
    if (reason === "unsubscribed") recipient!.subscribed = false;
    expect(await deliverQueuedEmail("email", now)).toBe("Skipped");
    expect(state.send).not.toHaveBeenCalled();
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("status='Skipped',body=NULL"), ["email"]);
  });

  it("preserves transactional mail for unsubscribed registered parents", async () => {
    recipient!.subscribed = false;
    expect(await deliverQueuedEmail("email", now)).toBe("Sent");
  });

  it("allows verification for an existing unverified non-parent account", async () => {
    task.kind = "AccountSecurity";
    task.expected_email = recipient!.email;
    task.expires_at = new Date(now.getTime() + 60_000);
    recipient!.email_verified = false;
    recipient!.parent_registered = false;
    expect(await deliverQueuedEmail("email", now)).toBe("Sent");
  });

  it.each(["expired", "changed-address"])("does not deliver %s security links", async (reason) => {
    task.kind = "AccountSecurity";
    task.expected_email = reason === "changed-address" ? "old@example.test" : recipient!.email;
    task.expires_at = reason === "expired" ? now : new Date(now.getTime() + 60_000);
    expect(await deliverQueuedEmail("email", now)).toBe("Skipped");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("rejects account mail without address binding and expiry", async () => {
    await expect(queueEmail({ query: state.query }, {
      userId: "parent", kind: "AccountSecurity", subject: "Verify", text: "link",
    })).rejects.toThrow("bound address and expiration");
    expect(state.query).not.toHaveBeenCalled();
  });

  it("backs off SMTP failures and logs identifiers without message contents", async () => {
    state.send.mockRejectedValue(new Error("secret-token"));
    expect(await deliverQueuedEmail("email", now)).toBe("Failed");
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("status='Failed',next_attempt_at=$1"), [new Date(now.getTime() + 60_000), "email"]);
    expect(console.error).toHaveBeenCalledExactlyOnceWith("Queued email delivery failed", { notificationId: "email" });
  });

  it("starts failure backoff after a slow SMTP attempt finishes", async () => {
    state.send.mockImplementation(async () => {
      vi.setSystemTime(now.getTime() + 120_000);
      throw new Error("SMTP timeout");
    });
    expect(await deliverQueuedEmail("email", now)).toBe("Failed");
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("status='Failed',next_attempt_at=$1"), [new Date(now.getTime() + 180_000), "email"]);
  });

  it("rechecks token expiry at each delivery rather than using a stale batch-start time", async () => {
    const lateTask = { ...task, id: "late", kind: "AccountSecurity", expected_email: recipient!.email,
      expires_at: new Date(now.getTime() + 1000) };
    const original = state.query.getMockImplementation()!;
    state.query.mockImplementation(async (sql: string, params: unknown[]) => {
      if (sql.startsWith("SELECT id FROM email_notifications")) return { rows: [{ id: "email" }, { id: "late" }] };
      if (sql.startsWith("SELECT *") && params[0] === "late") return { rows: [lateTask] };
      return original(sql, params);
    });
    state.send.mockImplementation(async () => { vi.setSystemTime(now.getTime() + 2000); });
    expect(await processImmediateNotifications(now)).toMatchObject({ Sent: 1, Skipped: 1 });
    expect(state.send).toHaveBeenCalledTimes(1);
  });

  it("does not attempt a retry before its scheduled backoff", async () => {
    task.status = "Failed";
    task.next_attempt_at = new Date(now.getTime() + 60_000);
    expect(await deliverQueuedEmail("email", now)).toBe("Failed");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("records Preview rather than Sent outside production", async () => {
    vi.stubEnv("NODE_ENV", "development");
    expect(await deliverQueuedEmail("email", now)).toBe("Preview");
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("sent_at=$2,body=NULL"), ["Preview", null, "email"]);
  });

  it("processes a bounded due batch, prioritizes account mail, and includes child notifications", async () => {
    const original = state.query.getMockImplementation()!;
    state.query.mockImplementation(async (sql: string, params: unknown[]) => {
      if (sql.startsWith("SELECT id FROM email_notifications")) return { rows: [{ id: "email" }] };
      if (sql.startsWith("SELECT id FROM child_profile_notifications")) return { rows: [{ id: "child" }] };
      return original(sql, params);
    });
    expect(await processImmediateNotifications(now)).toMatchObject({ Sent: 2, Failed: 0 });
    expect(state.child).toHaveBeenCalledExactlyOnceWith("child");
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("kind='AccountSecurity' THEN 0"), [now]);
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("INTERVAL 1 HOUR"), [now]);
  });
});
