import { beforeEach, describe, expect, it, vi } from "vitest";
import type { BetterAuthOptions } from "better-auth";

const state = vi.hoisted(() => ({
  options: undefined as BetterAuthOptions | undefined, queue: vi.fn(), tx: { query: vi.fn() },
}));
vi.mock("better-auth", () => ({
  betterAuth: (options: BetterAuthOptions) => { state.options = options; return { api: {} }; },
}));
vi.mock("better-auth/adapters/drizzle", () => ({ drizzleAdapter: vi.fn() }));
vi.mock("./db", () => ({
  db: { drizzle: {} },
  transaction: (work: (tx: typeof state.tx) => Promise<unknown>) => work(state.tx),
}));
vi.mock("./email-queue", () => ({ queueEmail: state.queue }));
import { getAuth } from "./auth";

beforeEach(() => {
  state.queue.mockReset().mockResolvedValue("queued");
  getAuth();
});

describe("authentication email queue callbacks", () => {
  const user = {
    id: "account", name: "Account", email: "account@example.test", emailVerified: false,
    createdAt: new Date(), updatedAt: new Date(),
  };
  it("queues verification for the existing account with expiry and address binding", async () => {
    const url = "https://ministry.example.test/verify?token=example";
    await state.options!.emailVerification!.sendVerificationEmail!({ user, url, token: "example" });
    expect(state.queue).toHaveBeenCalledWith(state.tx, {
      userId: user.id, kind: "AccountSecurity", expectedEmail: user.email,
      expiresAt: expect.any(Date), subject: "Verify your email",
      text: `Verify your email address using this one-time link:\n${url}`,
    });
    expect(state.options!.emailVerification!.expiresIn).toBe(86400);
  });

  it("queues password recovery with a one-hour expiry instead of calling SMTP", async () => {
    const url = "https://ministry.example.test/reset?token=example";
    await state.options!.emailAndPassword!.sendResetPassword!({ user, url, token: "example" });
    expect(state.queue).toHaveBeenCalledWith(state.tx, {
      userId: user.id, kind: "AccountSecurity", expectedEmail: user.email,
      expiresAt: expect.any(Date), subject: "Reset your password",
      text: `Use this one-time link to reset your password:\n${url}`,
    });
    expect(state.options!.emailAndPassword!.resetPasswordTokenExpiresIn).toBe(3600);
  });

  it("propagates enqueue failure rather than claiming delivery success", async () => {
    state.queue.mockRejectedValue(new Error("Queue unavailable"));
    await expect(state.options!.emailVerification!.sendVerificationEmail!({
      user, url: "https://ministry.example.test/verify", token: "example",
    })).rejects.toThrow("Queue unavailable");
  });
});
