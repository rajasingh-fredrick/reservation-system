import path from "node:path";
import { drizzle, type MySql2Database } from "drizzle-orm/mysql2";
import { createMysqlPool, initializeMysql, mysqlExecutor, mysqlTransaction } from "./mysql";
import * as schema from "./schema";

export type QueryResult<T = Record<string, unknown>> = { rows: T[]; rowCount: number };
export type Executor = {
  query<T = Record<string, unknown>>(text: string, params?: unknown[]): Promise<QueryResult<T>>;
};
type DatabaseState = {
  ready: Promise<void>;
  executor: Executor;
  transaction<T>(fn: (tx: Executor) => Promise<T>): Promise<T>;
  drizzle: MySql2Database<typeof schema>;
};
declare global {
  // eslint-disable-next-line no-var
  var __reservationDb: DatabaseState | undefined;
}

export const dataDirectory = path.resolve(process.env.DATA_DIR || path.join(process.cwd(), ".data"));
export const uploadDirectory = path.resolve(process.env.UPLOAD_DIR || path.join(dataDirectory, "uploads"));

function getState(): DatabaseState {
  if (!globalThis.__reservationDb) {
    const pool = createMysqlPool();
    let ready: Promise<void> | undefined;
    globalThis.__reservationDb = {
      executor: mysqlExecutor(pool),
      drizzle: drizzle(pool, { schema, mode: "default" }),
      get ready() { return ready ??= initializeMysql(pool); },
      async transaction<T>(fn: (tx: Executor) => Promise<T>) {
        await this.ready;
        return mysqlTransaction(pool, fn);
      },
    };
  }
  return globalThis.__reservationDb;
}

export const db: DatabaseState = {
  get ready() { return getState().ready; },
  get executor() { return getState().executor; },
  get drizzle() { return getState().drizzle; },
  transaction<T>(fn: (tx: Executor) => Promise<T>) { return getState().transaction(fn); },
};

export async function query<T = Record<string, unknown>>(text: string, params?: unknown[]) {
  await db.ready;
  return db.executor.query<T>(text, params);
}
export async function transaction<T>(fn: (tx: Executor) => Promise<T>) {
  return db.transaction(fn);
}
