import { mkdirSync } from "node:fs";
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres, { type Sql } from "postgres";
import { PGlite } from "@electric-sql/pglite";
import { drizzle as drizzlePglite } from "drizzle-orm/pglite";
import * as schema from "./schema";

type QueryResult<T = Record<string, unknown>> = { rows: T[]; rowCount: number };
export type Executor = {
  query<T = Record<string, unknown>>(text: string, params?: unknown[]): Promise<QueryResult<T>>;
};
type DatabaseState = {
  ready: Promise<void>;
  executor: Executor;
  transaction<T>(fn: (tx: Executor) => Promise<T>): Promise<T>;
  drizzle: ReturnType<typeof drizzle> | ReturnType<typeof drizzlePglite>;
};
declare global {
  // eslint-disable-next-line no-var
  var __reservationDb: DatabaseState | undefined;
}

const migrationDirectory = path.join(process.cwd(), "src", "server", "migrations");
export const dataDirectory = path.resolve(process.env.DATA_DIR || path.join(process.cwd(), ".data"));
export const uploadDirectory = path.resolve(process.env.UPLOAD_DIR || path.join(dataDirectory, "uploads"));
const databasePath = path.join(dataDirectory, "db");
function getState() {
  if (!globalThis.__reservationDb) globalThis.__reservationDb = createDatabase();
  return globalThis.__reservationDb;
}

export const db: DatabaseState = {
  get ready() { return getState().ready; },
  get executor() { return getState().executor; },
  get drizzle() { return getState().drizzle; },
  transaction<T>(fn: (tx: Executor) => Promise<T>) { return getState().transaction(fn); },
};

function createDatabase(): DatabaseState {
  const databaseUrl = process.env.DATABASE_URL;
  if (databaseUrl) {
    const client: Sql = postgres(databaseUrl, { max: 10, idle_timeout: 20, connect_timeout: 10 });
    const orm = drizzle(client, { schema });
    let ready: Promise<void> | undefined;
    const executor: Executor = {
      async query<T>(text: string, params: unknown[] = []) {
        const rows = await client.unsafe(text, params as never[]) as unknown as T[];
        return { rows, rowCount: rows.length };
      },
    };
    return {
      executor,
      drizzle: orm,
      get ready() {
        return (ready ??= initializePostgres(client));
      },
      async transaction<T>(fn: (tx: Executor) => Promise<T>) {
        await this.ready;
        return client.begin(async (sql) => fn({
          async query<R>(text: string, params: unknown[] = []) {
            const rows = await sql.unsafe(text, params as never[]) as unknown as R[];
            return { rows, rowCount: rows.length };
          },
        })) as Promise<T>;
      },
    };
  }
  const queue: Array<() => void> = [];
  let locked = false;
  const serialized = <T>(work: () => Promise<T>) => new Promise<T>((resolve, reject) => {
    const run = async () => {
      locked = true;
      try { resolve(await work()); } catch (error) { reject(error); }
      finally {
        locked = false;
        const next = queue.shift();
        if (next) next();
      }
    };
    if (locked) queue.push(run);
    else void run();
  });
  mkdirSync(dataDirectory, { recursive: true });
  const pg = new PGlite(databasePath);
  const orm = drizzlePglite(pg, { schema });
  let ready: Promise<void> | undefined;
  const direct: Executor = {
    async query<T>(text: string, params: unknown[] = []) {
      const result = await pg.query<T>(text, params as never[]);
      return { rows: result.rows, rowCount: result.affectedRows ?? result.rows.length };
    },
  };
  const executor: Executor = {
    query<T>(text: string, params?: unknown[]) {
      return serialized(() => direct.query<T>(text, params));
    },
  };
  return {
    executor,
    drizzle: orm,
    get ready() {
      return (ready ??= serialized(async () => {
        await pg.exec("CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())");
        const names = (await readdir(migrationDirectory)).filter((name) => name.endsWith(".sql")).sort();
        for (const name of names) {
          const found = await pg.query("SELECT 1 FROM schema_migrations WHERE name=$1", [name]);
          if (found.rows.length) continue;
          await pg.exec("BEGIN");
          try {
            const migration = await readFile(path.join(migrationDirectory, name), "utf8");
            for (const statement of migration.split(";").map((item) => item.trim()).filter(Boolean)) await pg.exec(statement);
            await pg.query("INSERT INTO schema_migrations (name) VALUES ($1)", [name]);
            await pg.exec("COMMIT");
          } catch (error) {
            await pg.exec("ROLLBACK");
            throw error;
          }
        }
      }));
    },
    transaction<T>(fn: (tx: Executor) => Promise<T>) {
      return serialized(async () => {
        await pg.exec("BEGIN");
        try {
          const result = await fn(direct);
          await pg.exec("COMMIT");
          return result;
        } catch (error) {
          await pg.exec("ROLLBACK");
          throw error;
        }
      });
    },
  };
}

async function initializePostgres(client: Sql) {
  await client.unsafe("CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())");
  const names = (await readdir(migrationDirectory)).filter((name) => name.endsWith(".sql")).sort();
  for (const name of names) {
    const found = await client.unsafe("SELECT 1 FROM schema_migrations WHERE name=$1", [name]);
    if (found.length) continue;
    const migration = await readFile(path.join(migrationDirectory, name), "utf8");
    await client.begin(async (sql) => {
      for (const statement of migration.split(";").map((item) => item.trim()).filter(Boolean)) await sql.unsafe(statement);
      await sql.unsafe("INSERT INTO schema_migrations (name) VALUES ($1)", [name]);
    });
  }
}

export async function query<T = Record<string, unknown>>(text: string, params?: unknown[]) {
  await db.ready;
  return db.executor.query<T>(text, params);
}
export async function transaction<T>(fn: (tx: Executor) => Promise<T>) {
  return db.transaction(fn);
}
