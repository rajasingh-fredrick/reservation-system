import { NextResponse, type NextRequest } from "next/server";
import { randomUUID } from "node:crypto";
import { db, query, type Executor } from "./db";
import { getAuth } from "./auth";

export class HttpError extends Error {
  constructor(public status: number, message: string, public code?: string) {
    super(message);
  }
}

export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

export function fail(error: unknown) {
  if (error instanceof HttpError) return json({ error: error.message, ...(error.code ? { code: error.code } : {}) }, error.status);
  console.error("Request failed", error instanceof Error ? error.message : "unknown");
  return json({ error: "The request could not be completed." }, 500);
}

export async function handle(work: () => Promise<Response>) {
  try { return await work(); } catch (error) { return fail(error); }
}

export function assertSameOrigin(request: NextRequest) {
  const origin = request.headers.get("origin");
  if (!origin) throw new HttpError(403, "A same-origin request is required.", "ORIGIN_REQUIRED");
  try {
    if (new URL(origin).origin !== new URL(request.url).origin) throw new Error("mismatch");
  } catch {
    throw new HttpError(403, "Cross-origin writes are not allowed.", "CROSS_ORIGIN");
  }
  const fetchSite = request.headers.get("sec-fetch-site");
  if (fetchSite && fetchSite !== "same-origin" && fetchSite !== "none") {
    throw new HttpError(403, "Cross-origin writes are not allowed.", "CROSS_ORIGIN");
  }
}

const attempts = new Map<string, { count: number; resetsAt: number }>();
export function rateLimit(key: string, limit = 8, windowMs = 60_000) {
  const now = Date.now();
  const record = attempts.get(key);
  if (!record || record.resetsAt <= now) {
    attempts.set(key, { count: 1, resetsAt: now + windowMs });
    return;
  }
  if (record.count >= limit) throw new HttpError(429, "Too many attempts. Please try again later.", "RATE_LIMITED");
  record.count += 1;
}

export async function requireAdmin(request: NextRequest) {
  await db.ready;
  const session = await getAuth().api.getSession({ headers: request.headers });
  if (!session?.user) throw new HttpError(401, "Sign in to continue.", "UNAUTHENTICATED");
  const rows = await query<{ email_verified: boolean; is_admin: boolean }>(
    `SELECT u."emailVerified" AS email_verified,
       EXISTS (SELECT 1 FROM admin_users a WHERE a.user_id = u.id) AS is_admin
     FROM "user" u WHERE u.id = $1`,
    [session.user.id],
  );
  if (!rows.rows[0]?.email_verified || !rows.rows[0].is_admin) {
    throw new HttpError(403, "A verified administrator account is required.", "FORBIDDEN");
  }
  return { id: session.user.id, name: session.user.name, email: session.user.email };
}

export async function requireVerifiedUser(request: NextRequest) {
  await db.ready;
  const session = await getAuth().api.getSession({ headers: request.headers });
  if (!session?.user) throw new HttpError(401, "Sign in to continue.", "UNAUTHENTICATED");
  const rows = await query<{ email_verified: boolean }>(
    'SELECT "emailVerified" AS email_verified FROM "user" WHERE id = $1',
    [session.user.id],
  );
  if (!rows.rows[0]?.email_verified) {
    throw new HttpError(403, "Verify your email address before managing child profiles.", "EMAIL_NOT_VERIFIED");
  }
  return { id: session.user.id, name: session.user.name, email: session.user.email };
}

export async function requireAdminWrite(request: NextRequest) {
  assertSameOrigin(request);
  return requireAdmin(request);
}

export async function recordAudit(actorId: string, action: string, description: string, executor?: Executor) {
  const run = executor?.query.bind(executor) ?? query;
  await run(
    "INSERT INTO audit_log (id, action, description, actor_id) VALUES ($1,$2,$3,$4)",
    [randomUUID(), action, description, actorId],
  );
}

export function parseJson<T = Record<string, unknown>>(value: unknown): T {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new HttpError(400, "A JSON object is required.", "INVALID_BODY");
  }
  return value as T;
}

export function asString(value: unknown, field: string, max = 2000) {
  if (typeof value !== "string" || value.length > max) throw new HttpError(400, `${field} must be a string of at most ${max} characters.`, "INVALID_FIELD");
  return value;
}

export function requiredString(value: unknown, field: string, max = 2000) {
  const result = asString(value, field, max).trim();
  if (!result) throw new HttpError(400, `${field} is required.`, "INVALID_FIELD");
  return result;
}

export function positiveInt(value: unknown, field: string) {
  if (!Number.isSafeInteger(value) || Number(value) < 1) throw new HttpError(400, `${field} must be a positive whole number.`, "INVALID_FIELD");
  return Number(value);
}

export function idParam(value: string) {
  if (!/^[0-9a-f-]{36}$/i.test(value)) throw new HttpError(400, "Invalid identifier.", "INVALID_ID");
  return value;
}
