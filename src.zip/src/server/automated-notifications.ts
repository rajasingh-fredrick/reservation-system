import { createHash, randomUUID } from "node:crypto";
import { query, transaction, type Executor } from "./db.ts";
import { sendMail } from "./mail.ts";
import { processImmediateNotifications } from "./email-queue.ts";

type Status = "Pending" | "Sending" | "Sent" | "Failed" | "Preview" | "Skipped";
type Kind = "SeasonAnnouncement" | "PerformanceReminder";
type Task = {
  id: string; kind: Kind; status: Status; parent_user_id: string; season_id: string; event_id: string | null;
};
type Recipient = { name: string; email: string };
type Season = {
  id: string; name: string; status: string; timezone: string; start_date: string; end_date: string;
  registration_opens_at: Date; registration_closes_at: Date; location: string;
};
type Event = { id: string; name: string; starts_at: Date; location: string };
type Participation = { child_name: string; song_title: string; instrument: string };

function localDate(value: Date, timezone: string) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(value);
  const get = (type: string) => parts.find((part) => part.type === type)!.value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}

export function calendarDaysBefore(value: Date, days: number, timezone: string) {
  const date = new Date(`${localDate(value, timezone)}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() - days);
  return date.toISOString().slice(0, 10);
}

export function reminderIsDue(startsAt: Date, now: Date, timezone: string) {
  return startsAt > now && localDate(now, timezone) >= calendarDaysBefore(startsAt, 7, timezone);
}

function dateTime(value: Date, timezone: string) {
  return `${new Intl.DateTimeFormat("en-US", {
    timeZone: timezone, dateStyle: "full", timeStyle: "short",
  }).format(value)} (${timezone})`;
}

export function seasonAnnouncementEmail(parent: Recipient, season: Season) {
  return {
    subject: `Music ministry registration - ${season.name}`,
    text: `Dear ${parent.name},

${season.name} has been published at Tamil Gospel Church.

Season dates: ${season.start_date} to ${season.end_date}
Registration opens: ${dateTime(season.registration_opens_at, season.timezone)}
Registration closes: ${dateTime(season.registration_closes_at, season.timezone)}

Please review the available songs and instruments and register your approved children when registration is open, while spots remain. Availability is not guaranteed.
${new URL("/parent/seasons", process.env.APP_URL).href}

Mrs. Amy Priya Shibu
Ministry Coordinator
Tamil Gospel Church`,
  };
}

export function performanceReminderEmail(parent: Recipient, season: Season, event: Event, rows: Participation[], now: Date) {
  const deadline = calendarDaysBefore(event.starts_at, 3, season.timezone);
  const pastDeadline = localDate(now, season.timezone) > deadline;
  const location = event.location || season.location;
  return {
    subject: `Upcoming performance - practice recording due ${deadline}`,
    text: `Dear ${parent.name},

We look forward to your family's participation at Tamil Gospel Church!

Performance: ${event.name}
Date and time: ${dateTime(event.starts_at, season.timezone)}
${location ? `Location: ${location}\n` : ""}
Your family's confirmed participation:
${rows.map((row) => `- ${row.child_name} - ${row.song_title} - ${row.instrument}`).join("\n")}

Please send a practice recording for each listed song and instrument at least three days before the performance. Recording deadline: ${deadline}, by the end of that day (${season.timezone}).
${pastDeadline ? "The recording deadline has already passed. Please contact the ministry coordinator as soon as possible.\n" : ""}
${process.env.RECORDING_SUBMISSION_INSTRUCTIONS}

Mrs. Amy Priya Shibu will review the recordings and speak with you about any corrections.
Parent dashboard: ${new URL("/parent", process.env.APP_URL).href}

Thank you for helping your child prepare faithfully.
Mrs. Amy Priya Shibu
Ministry Coordinator
Tamil Gospel Church`,
  };
}

async function enqueue(executor: Executor, kind: Kind, parentId: string, seasonId: string, eventId: string | null) {
  const key = createHash("sha256").update(JSON.stringify([kind, eventId ?? seasonId, parentId])).digest("hex");
  await executor.query(
    `INSERT INTO automated_notifications (id,kind,parent_user_id,season_id,event_id,deduplication_key)
     VALUES ($1,$2,$3,$4,$5,$6) ON DUPLICATE KEY UPDATE deduplication_key=deduplication_key`,
    [randomUUID(), kind, parentId, seasonId, eventId, key],
  );
}

export async function discoverNotifications(now: Date) {
  const seasons = await query<{ id: string }>(
    `SELECT id FROM seasons WHERE status='Published' AND registration_notification_at <= $1
       AND registration_notification_queued_at IS NULL AND registration_notification_sent_at IS NULL
       AND registration_closes_at > $1 ORDER BY registration_notification_at,id`, [now],
  );
  for (const season of seasons.rows) {
    await transaction(async (tx) => {
      const current = await tx.query(
        `SELECT id FROM seasons WHERE id=$1 AND status='Published'
         AND registration_notification_at <= $2 AND registration_notification_queued_at IS NULL
         AND registration_notification_sent_at IS NULL AND registration_closes_at > $2 FOR UPDATE`,
        [season.id, now],
      );
      if (!current.rows.length) return;
      const parents = await tx.query<{ id: string }>(
        `SELECT u.id FROM "user" u JOIN parent_profiles pp ON pp.user_id=u.id
         WHERE u."emailVerified"=true AND pp.email_notifications_subscribed=true`,
      );
      for (const parent of parents.rows) await enqueue(tx, "SeasonAnnouncement", parent.id, season.id, null);
      await tx.query("UPDATE seasons SET registration_notification_queued_at=$1 WHERE id=$2", [now, season.id]);
    });
  }
  const events = await query<{ id: string; season_id: string; starts_at: Date; timezone: string }>(
    `SELECT e.id,e.season_id,e.starts_at,s.timezone FROM events e JOIN seasons s ON s.id=e.season_id
     WHERE s.status IN ('Published','Registration Closed') AND e.starts_at > $1
       AND e.starts_at < DATE_ADD($1,INTERVAL 9 DAY) ORDER BY e.starts_at,e.id`, [now],
  );
  for (const event of events.rows) {
    if (!reminderIsDue(event.starts_at, now, event.timezone)) continue;
    const parents = await query<{ id: string }>(
      `SELECT DISTINCT u.id FROM reservations r JOIN children c ON c.id=r.child_id
       JOIN "user" u ON u.id=c.parent_user_id JOIN parent_profiles pp ON pp.user_id=u.id
       WHERE r.event_id=$1 AND r.status='Confirmed' AND u."emailVerified"=true
         AND pp.email_notifications_subscribed=true`, [event.id],
    );
    for (const parent of parents.rows) await enqueue({ query }, "PerformanceReminder", parent.id, event.season_id, event.id);
  }
}

export async function deliverAutomatedNotification(id: string, now: Date): Promise<Status> {
  const claimed = await transaction<{ status: Status } | { email: { subject: string; text: string }; to: string }>(async (tx) => {
    const tasks = await tx.query<Task>("SELECT * FROM automated_notifications WHERE id=$1 FOR UPDATE", [id]);
    const task = tasks.rows[0];
    if (!task) throw new Error("Automated notification not found.");
    if (task.status !== "Pending" && task.status !== "Failed" && task.status !== "Skipped") return { status: task.status };
    const parents = await tx.query<Recipient>(
      `SELECT u.name,u.email FROM "user" u JOIN parent_profiles pp ON pp.user_id=u.id
       WHERE u.id=$1 AND u."emailVerified"=true AND pp.email_notifications_subscribed=true`, [task.parent_user_id],
    );
    const seasons = await tx.query<Season>("SELECT * FROM seasons WHERE id=$1", [task.season_id]);
    const parent = parents.rows[0];
    const season = seasons.rows[0];
    let email: { subject: string; text: string } | undefined;
    if (parent && season) {
      if (task.kind === "SeasonAnnouncement" && season.status === "Published" && season.registration_closes_at > now) {
        email = seasonAnnouncementEmail(parent, season);
      } else if (task.kind === "PerformanceReminder" && ["Published", "Registration Closed"].includes(season.status)) {
        const events = await tx.query<Event>("SELECT id,name,starts_at,location FROM events WHERE id=$1 AND season_id=$2", [task.event_id, task.season_id]);
        const event = events.rows[0];
        if (event && reminderIsDue(event.starts_at, now, season.timezone)) {
          const reservations = await tx.query<Participation>(
            `SELECT c.full_name AS child_name,so.title AS song_title,r.instrument
             FROM reservations r JOIN children c ON c.id=r.child_id
             JOIN event_songs es ON es.id=r.event_song_id JOIN songs so ON so.id=es.song_id
             WHERE r.event_id=$1 AND c.parent_user_id=$2 AND r.status='Confirmed'
             ORDER BY c.full_name,es.position,r.instrument`, [event.id, task.parent_user_id],
          );
          if (reservations.rows.length) email = performanceReminderEmail(parent, season, event, reservations.rows, now);
        }
      }
    }
    if (!email || !parent) {
      await tx.query("UPDATE automated_notifications SET status='Skipped' WHERE id=$1", [id]);
      return { status: "Skipped" as const };
    }
    await tx.query(
      "UPDATE automated_notifications SET status='Sending',attempts=attempts+1,last_attempt_at=$1 WHERE id=$2", [now, id],
    );
    return { email, to: parent.email };
  });
  if ("status" in claimed) return claimed.status;
  try {
    await sendMail(claimed.to, claimed.email.subject, claimed.email.text);
  } catch {
    console.error("Automated email delivery failed", { notificationId: id });
    await query("UPDATE automated_notifications SET status='Failed' WHERE id=$1 AND status='Sending'", [id]);
    return "Failed";
  }
  const status = process.env.NODE_ENV === "production" ? "Sent" : "Preview";
  await query("UPDATE automated_notifications SET status=$1,sent_at=$2 WHERE id=$3 AND status='Sending'",
    [status, status === "Sent" ? now : null, id]);
  return status;
}

export async function runNotificationJob(now = new Date()) {
  if (!process.env.APP_URL || !/^https?:$/.test(new URL(process.env.APP_URL).protocol)) {
    throw new Error("APP_URL must be an absolute HTTP(S) URL.");
  }
  if (!process.env.RECORDING_SUBMISSION_INSTRUCTIONS?.trim()) {
    throw new Error("RECORDING_SUBMISSION_INSTRUCTIONS is required for performance reminder emails.");
  }
  if (process.env.NODE_ENV === "production" && (!process.env.SMTP_HOST || !process.env.SMTP_FROM)) {
    throw new Error("SMTP_HOST and SMTP_FROM must be configured before running the production email job.");
  }
  await discoverNotifications(now);
  const totals = await processImmediateNotifications(now);
  // Snapshot IDs once so a failed delivery is attempted at most once in this run.
  const tasks = await query<{ id: string }>(
    `SELECT n.id FROM automated_notifications n LEFT JOIN events e ON e.id=n.event_id
     WHERE n.status IN ('Pending','Failed')
       OR (n.status='Skipped' AND n.kind='PerformanceReminder' AND e.starts_at > $1)
     ORDER BY n.created_at,n.id`, [now],
  );
  for (const task of tasks.rows) totals[await deliverAutomatedNotification(task.id, now)]++;
  await query(
    `UPDATE seasons s SET registration_notification_sent_at=$1
     WHERE s.registration_notification_queued_at IS NOT NULL AND s.registration_notification_sent_at IS NULL
       AND NOT EXISTS (SELECT 1 FROM automated_notifications n WHERE n.season_id=s.id
         AND n.kind='SeasonAnnouncement' AND n.status NOT IN ('Sent','Skipped'))`, [now],
  );
  const interrupted = await query<{ count: number }>(
    `SELECT (SELECT COUNT(*) FROM automated_notifications WHERE status='Sending')
       + (SELECT COUNT(*) FROM child_profile_notifications WHERE status='Sending')
       + (SELECT COUNT(*) FROM email_notifications WHERE status='Sending') AS count`,
  );
  totals.Sending = Number(interrupted.rows[0].count);
  return totals;
}
