import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { createPool, type Pool, type PoolConnection, type PoolOptions, type ResultSetHeader, type RowDataPacket } from "mysql2/promise";
import type { Executor } from "./db";

export function mysqlOptions(): PoolOptions {
  const url = process.env.DATABASE_URL ? new URL(process.env.DATABASE_URL) : undefined;
  if (url && url.protocol !== "mysql:") throw new Error("DATABASE_URL must use the mysql:// scheme.");
  const database = url ? decodeURIComponent(url.pathname.slice(1)) : process.env.MYSQL_DATABASE || "harmony";
  if (!/^[a-zA-Z0-9_]{1,64}$/.test(database)) throw new Error("MySQL database name must contain only letters, numbers, and underscores (maximum 64).");
  return {
    host: url?.hostname || process.env.MYSQL_HOST || "127.0.0.1",
    port: Number(url?.port || process.env.MYSQL_PORT || 3306),
    user: url ? decodeURIComponent(url.username) : process.env.MYSQL_USER || "appuser",
    password: url ? decodeURIComponent(url.password) : process.env.MYSQL_PASSWORD,
    database,
    charset: "utf8mb4",
    timezone: "Z",
    dateStrings: ["DATE"],
    decimalNumbers: true,
    connectionLimit: 10,
    connectTimeout: 10000,
    multipleStatements: false,
    typeCast(field, next) {
      if (field.type === "TINY" && field.length === 1) {
        const value = field.string();
        return value === null ? null : value === "1";
      }
      return next();
    },
  };
}

export function createMysqlPool(options: PoolOptions = mysqlOptions()): Pool {
  const pool = createPool(options);
  pool.on("connection", (connection) => {
    // ANSI_QUOTES retains the application's quoted identifiers; all timestamps are UTC.
    connection.query("SET SESSION time_zone='+00:00', sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,ONLY_FULL_GROUP_BY,ANSI_QUOTES'");
    connection.query("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED");
  });
  return pool;
}

// Keep numbered binds (including repeated/reordered binds) without interpolating values into SQL.
export function bindMysql(text: string, params: unknown[] = []) {
  const values: unknown[] = [];
  const sql = text.replace(/'(?:''|\\.|[^'])*'|"(?:\"\"|[^"])*"|`(?:``|[^`])*`|\$(\d+)/g, (match, index: string | undefined) => {
    if (!index) return match;
    const position = Number(index) - 1;
    if (position < 0 || position >= params.length) throw new Error(`Missing SQL parameter $${index}.`);
    const value = params[position];
    if (Array.isArray(value)) {
      values.push(...value);
      return value.length ? value.map(() => "?").join(",") : "NULL";
    }
    if (value === undefined) throw new Error(`SQL parameter $${index} is undefined.`);
    values.push(value);
    return "?";
  });
  return { sql, values };
}

export function mysqlExecutor(client: Pool | PoolConnection): Executor {
  return {
    async query<T>(text: string, params: unknown[] = []) {
      const { sql, values } = bindMysql(text, params);
      const [result] = await client.query<RowDataPacket[] | ResultSetHeader>(sql, values);
      return Array.isArray(result)
        ? { rows: result as T[], rowCount: result.length }
        : { rows: [], rowCount: result.affectedRows };
    },
  };
}

export async function mysqlTransaction<T>(pool: Pool, work: (tx: Executor) => Promise<T>) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const result = await work(mysqlExecutor(connection));
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function initializeMysql(pool: Pool) {
  const connection = await pool.getConnection();
  const executor = mysqlExecutor(connection);
  let lockName = "";
  let locked = false;
  try {
    const database = await executor.query<{ name: string }>("SELECT DATABASE() AS name");
    const { createHash } = await import("node:crypto");
    lockName = `harmony:migrate:${createHash("sha256").update(database.rows[0].name).digest("hex").slice(0,40)}`;
    const lock = await executor.query<{ acquired: number }>("SELECT GET_LOCK($1,60) AS acquired", [lockName]);
    if (lock.rows[0]?.acquired !== 1) throw new Error("Could not acquire the database migration lock.");
    locked = true;
    await executor.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      name varchar(255) PRIMARY KEY,
      checksum char(64) NOT NULL,
      applied_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
    ) ENGINE=InnoDB`);
    const directory = path.join(process.cwd(), "src", "server", "migrations");
    for (const name of (await readdir(directory)).filter((file) => file.endsWith(".sql")).sort()) {
      const migration = await readFile(path.join(directory, name), "utf8");
      const checksum = createHash("sha256").update(migration).digest("hex");
      const found = await executor.query<{ checksum: string }>("SELECT checksum FROM schema_migrations WHERE name=$1", [name]);
      if (found.rows.length) {
        if (found.rows[0].checksum !== checksum) throw new Error(`Applied migration ${name} has changed; restore it and add a new migration.`);
        continue;
      }
      // MySQL DDL commits implicitly. Do not pretend a failed migration can be rolled back.
      for (const statement of migration.split(";").map((part) => part.trim()).filter(Boolean)) {
        await executor.query(statement);
      }
      await executor.query("INSERT INTO schema_migrations (name,checksum) VALUES ($1,$2)", [name, checksum]);
    }
  } finally {
    try {
      if (locked) await executor.query("SELECT RELEASE_LOCK($1)", [lockName]);
    } finally {
      connection.release();
    }
  }
}
