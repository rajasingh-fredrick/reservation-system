import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { TestDatabase } from "./test-database";
import type { Executor } from "./db";

const state = vi.hoisted(() => ({ database: null as TestDatabase | null, send: vi.fn() }));
vi.mock("./db", () => ({
  query: <T>(sql: string, params?: unknown[]) => state.database!.query<T>(sql, params),
  transaction: <T>(work: (tx: Executor) => Promise<T>) => state.database!.transaction(work),
}));
vi.mock("./mail", () => ({ sendMail: (...args: unknown[]) => state.send(...args) }));
import { deliverQueuedEmail, processImmediateNotifications, queueEmail } from "./email-queue";

beforeAll(async () => {
  state.database = new TestDatabase();
  await state.database.initialize();
}, 120000);
beforeEach(async () => {
  vi.stubEnv("NODE_ENV", "production");
  state.send.mockReset().mockResolvedValue(undefined);
  await state.database!.exec(`
    RESET_TEST_DATABASE;
    INSERT INTO "user"(id,name,email,"emailVerified") VALUES
      ('parent','Parent','parent@example.test',true),('account','Account','account@example.test',false);
    INSERT INTO parent_profiles(user_id,authorized_child_registration,privacy_accepted_at,policies_accepted_at,email_notifications_subscribed)
      VALUES ('parent',true,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3),true);
  `);
});
afterEach(() => vi.unstubAllEnvs());
afterAll(async () => { await state.database?.destroy(); });

function enqueue(kind: "ParentTransactional" | "MinistryMessage" = "ParentTransactional") {
  return state.database!.transaction((tx) => queueEmail(tx, {
    userId: "parent", kind, subject: "Test email", text: "Child Anna approved",
  }));
}

describe("immediate email MySQL integration", () => {
  it("persists before sending and claims only once across concurrent workers", async () => {
    const id = await enqueue();
    expect(state.send).not.toHaveBeenCalled();
    await Promise.all([deliverQueuedEmail(id), deliverQueuedEmail(id)]);
    expect(state.send).toHaveBeenCalledTimes(1);
    expect((await state.database!.query(
      "SELECT status,attempts,body FROM email_notifications WHERE id=$1", [id],
    )).rows[0]).toMatchObject({ status: "Sent", attempts: 1, body: null });
    await processImmediateNotifications();
    expect(state.send).toHaveBeenCalledTimes(1);
  });

  it("rolls back notification insertion with its source transaction", async () => {
    await expect(state.database!.transaction(async (tx) => {
      await queueEmail(tx, { userId: "parent", kind: "ParentTransactional", subject: "Test", text: "Test" });
      throw new Error("Source transaction failed");
    })).rejects.toThrow("Source transaction failed");
    expect((await state.database!.query("SELECT id FROM email_notifications")).rows).toHaveLength(0);
  });

  it("rechecks subscription and registration at delivery", async () => {
    const ministry = await enqueue("MinistryMessage");
    await state.database!.query("UPDATE parent_profiles SET email_notifications_subscribed=false");
    expect(await deliverQueuedEmail(ministry)).toBe("Skipped");
    const transactional = await enqueue();
    expect(await deliverQueuedEmail(transactional)).toBe("Sent");
    const removed = await enqueue();
    await state.database!.query("DELETE FROM parent_profiles");
    expect(await deliverQueuedEmail(removed)).toBe("Skipped");
    expect(state.send).toHaveBeenCalledTimes(1);
  });

  it("keeps failed tasks durable, applies backoff, and leaves Sending untouched", async () => {
    const id = await enqueue();
    state.send.mockRejectedValueOnce(new Error("SMTP unavailable"));
    expect(await deliverQueuedEmail(id)).toBe("Failed");
    await processImmediateNotifications();
    expect(state.send).toHaveBeenCalledTimes(1);
    await state.database!.query("UPDATE email_notifications SET next_attempt_at=DATE_SUB(UTC_TIMESTAMP(3),INTERVAL 1 MINUTE)");
    await processImmediateNotifications();
    expect(state.send).toHaveBeenCalledTimes(2);
    const interrupted = await enqueue();
    await state.database!.query("UPDATE email_notifications SET status='Sending' WHERE id=$1", [interrupted]);
    expect(await deliverQueuedEmail(interrupted)).toBe("Sending");
    expect(state.send).toHaveBeenCalledTimes(2);
  });

  it("skips expired security messages without blocking a valid unverified account", async () => {
    const now = new Date();
    const queueAccount = (expiresAt: Date) => state.database!.transaction((tx) => queueEmail(tx, {
      userId: "account", kind: "AccountSecurity", expectedEmail: "account@example.test", expiresAt,
      subject: "Verify", text: "One-time link",
    }));
    expect(await deliverQueuedEmail(await queueAccount(now), now)).toBe("Skipped");
    expect(await deliverQueuedEmail(await queueAccount(new Date(now.getTime() + 60_000)), now)).toBe("Sent");
    expect(state.send).toHaveBeenCalledTimes(1);
  });
});
