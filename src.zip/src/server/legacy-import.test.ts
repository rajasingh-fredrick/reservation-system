import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { importLegacyRecords, legacyValue, type LegacyTable } from "./legacy-import";
import { TestDatabase } from "./test-database";

describe("legacy value conversion", () => {
  it("preserves JSON arrays, booleans, timestamps, and calendar dates", () => {
    expect(legacyValue([{ title: "Video", url: "https://example.test" }], { type: "json", columnType: "json" }))
      .toBe('[{"title":"Video","url":"https://example.test"}]');
    expect(legacyValue(true, { type: "tinyint", columnType: "tinyint(1)" })).toBe(1);
    expect(legacyValue("2026-10-30T14:00:00.123Z", { type: "datetime", columnType: "datetime(3)" }))
      .toEqual(new Date("2026-10-30T14:00:00.123Z"));
    expect(legacyValue("2026-10-30", { type: "date", columnType: "date" })).toBe("2026-10-30");
    expect(() => legacyValue(undefined, { type: "text", columnType: "text" })).toThrow("Missing");
  });
});

describe("legacy MySQL record import", () => {
  const database = new TestDatabase();
  beforeAll(async () => { await database.initialize(); });
  afterAll(async () => { await database.destroy(); });
  const tables: LegacyTable[] = [{
    name: "songs",
    columns: ["id", "title", "archived", "links", "created_at"],
    rows: [{ id: "legacy-song", title: "Preserved song", archived: false, links: [{ url: "https://example.test", label: "Video" }], created_at: new Date("2026-10-30T14:00:00.123Z") }],
  }];

  it("verifies and rolls back a rehearsal, then imports idempotently without losing existing rows", async () => {
    await database.query("INSERT INTO songs(id,title) VALUES ('new-song','Existing MySQL song')");
    const connection = await database.pool.getConnection();
    try {
      await connection.beginTransaction();
      expect((await importLegacyRecords(connection, tables))[0]).toMatchObject({ inserted: 1, existing: 1 });
      await connection.rollback();
      expect((await database.query("SELECT id FROM songs WHERE id='legacy-song'")).rows).toHaveLength(0);
      await connection.beginTransaction();
      await importLegacyRecords(connection, tables);
      await connection.commit();
      await connection.beginTransaction();
      expect((await importLegacyRecords(connection, tables))[0]).toMatchObject({ inserted: 0, unchanged: 1, existing: 2 });
      await connection.rollback();
      expect((await database.query("SELECT id FROM songs")).rows).toHaveLength(2);
    } finally { connection.release(); }
  });

  it("stops on conflicting records and rolls back earlier inserts", async () => {
    const connection = await database.pool.getConnection();
    try {
      await connection.beginTransaction();
      await expect(importLegacyRecords(connection, [{
        name: "songs", columns: ["id", "title"],
        rows: [{ id: "must-rollback", title: "Temporary" }, { id: "new-song", title: "Do not overwrite" }],
      }])).rejects.toThrow("Import conflict");
      await connection.rollback();
      expect((await database.query("SELECT id FROM songs WHERE id='must-rollback'")).rows).toHaveLength(0);
      expect((await database.query<{ title: string }>("SELECT title FROM songs WHERE id='new-song'")).rows[0].title).toBe("Existing MySQL song");
    } finally { connection.release(); }
  });

  it("keeps foreign keys enabled and rejects broken relationships", async () => {
    const connection = await database.pool.getConnection();
    try {
      await connection.beginTransaction();
      await expect(importLegacyRecords(connection, [{
        name: "admin_users", columns: ["user_id"], rows: [{ user_id: "missing-user" }],
      }])).rejects.toMatchObject({ code: "ER_NO_REFERENCED_ROW_2" });
      await connection.rollback();
    } finally { connection.release(); }
  });
});
