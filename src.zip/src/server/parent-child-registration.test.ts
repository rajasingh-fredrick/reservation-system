import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  userId: "admin" as string | null, verified: true, query: vi.fn(),
  queueParent: vi.fn(), queueAdmin: vi.fn(),
}));
vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: (...args: unknown[]) => state.query(...args),
  transaction: async (work: (tx: { query: typeof state.query }) => Promise<unknown>) =>
    work({ query: state.query }),
}));
vi.mock("./auth", () => ({
  getAuth: () => ({ api: { getSession: async () => state.userId
    ? { user: { id: state.userId, name: "Admin Parent", email: "admin@example.test" } } : null } }),
}));
vi.mock("./child-notifications", () => ({
  queueChildNotification: (...args: unknown[]) => state.queueParent(...args),
  queueChildAdminNotification: (...args: unknown[]) => state.queueAdmin(...args),
}));
import { POST } from "../app/api/parent/children/route";

function request() {
  return new NextRequest("http://localhost:3000/api/parent/children", {
    method: "POST",
    headers: { origin: "http://localhost:3000", "content-type": "application/json" },
    body: JSON.stringify({
      fullName: "Admin Child", birthMonth: 1, birthYear: 2015,
      instruments: [{ instrument: "Piano", yearsExperience: 2 }],
    }),
  });
}

beforeEach(() => {
  state.userId = "admin";
  state.verified = true;
  state.query.mockReset().mockImplementation(async (sql: string) => ({
    rows: sql.includes("AS email_verified") ? [{ email_verified: state.verified }] : [],
    rowCount: 1,
  }));
  state.queueParent.mockReset().mockResolvedValue("parent-notification");
  state.queueAdmin.mockReset().mockResolvedValue("admin-notification");
});

describe("parent profiles during child registration", () => {
  it.each(["admin", "parent"])("creates a missing parent profile for %s before queuing child notifications", async (userId) => {
    state.userId = userId;
    expect((await POST(request())).status).toBe(201);
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("SELECT $1 WHERE NOT EXISTS (SELECT 1 FROM parent_profiles WHERE user_id=$1)"),
      [userId],
    );
    const calls = state.query.mock.calls.map(([sql]) => String(sql));
    const profileIndex = calls.findIndex((sql) => sql.includes("INSERT INTO parent_profiles"));
    expect(profileIndex).toBeGreaterThan(calls.findIndex((sql) => sql.includes("FOR UPDATE")));
    expect(profileIndex).toBeLessThan(calls.findIndex((sql) => sql.includes("INSERT INTO children")));
    expect(calls[profileIndex]).not.toMatch(/UPDATE|privacy_accepted_at|policies_accepted_at|email_notifications_subscribed/);
    expect(state.queueParent).toHaveBeenCalledWith(expect.anything(), userId, expect.any(String), true);
    expect(state.query.mock.invocationCallOrder[profileIndex]).toBeLessThan(state.queueParent.mock.invocationCallOrder[0]);
    expect(calls.some((sql) => /(?:UPDATE|DELETE FROM) admin_users/.test(sql))).toBe(false);
  });

  it("does not create profiles or queue notifications for unverified or anonymous users", async () => {
    state.verified = false;
    expect((await POST(request())).status).toBe(403);
    state.userId = null;
    expect((await POST(request())).status).toBe(401);
    expect(state.query.mock.calls.some(([sql]) => String(sql).includes("INSERT INTO"))).toBe(false);
    expect(state.queueParent).not.toHaveBeenCalled();
    expect(state.queueAdmin).not.toHaveBeenCalled();
  });
});
