import { boolean, datetime, mysqlTable, text, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

const id = (name: string) => varchar(name, { length: 191 });
const date = (name: string) => datetime(name, { mode: "date", fsp: 3 });

export const users = mysqlTable("user", {
  id: id("id").primaryKey(),
  name: text("name").notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  emailVerified: boolean("emailVerified").notNull().default(false),
  image: text("image"),
  createdAt: date("createdAt").notNull(),
  updatedAt: date("updatedAt").notNull(),
}, (table) => [uniqueIndex("user_email_unique").on(table.email)]);

export const sessions = mysqlTable("session", {
  id: id("id").primaryKey(),
  expiresAt: date("expiresAt").notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  createdAt: date("createdAt").notNull(),
  updatedAt: date("updatedAt").notNull(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: id("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
});
export const accounts = mysqlTable("account", {
  id: id("id").primaryKey(),
  accountId: varchar("accountId", { length: 320 }).notNull(),
  providerId: id("providerId").notNull(),
  userId: id("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: date("accessTokenExpiresAt"),
  refreshTokenExpiresAt: date("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: date("createdAt").notNull(),
  updatedAt: date("updatedAt").notNull(),
});
export const verifications = mysqlTable("verification", {
  id: id("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: date("expiresAt").notNull(),
  createdAt: date("createdAt"),
  updatedAt: date("updatedAt"),
});
