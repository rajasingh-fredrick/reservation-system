import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { TestDatabase } from "./test-database";
import type { Executor } from "./db";

const state = vi.hoisted(() => ({ database: null as TestDatabase | null, send: vi.fn() }));
vi.mock("./db", () => ({
  query: <T>(sql: string, params?: unknown[]) => state.database!.query<T>(sql, params),
  transaction: <T>(work: (tx: Executor) => Promise<T>) => state.database!.transaction(work),
}));
vi.mock("./mail", () => ({ sendMail: (...args: unknown[]) => state.send(...args) }));
import { discoverNotifications, runNotificationJob } from "./automated-notifications";

const now = new Date("2026-11-03T16:00:00Z");
beforeAll(async () => {
  state.database = new TestDatabase();
  await state.database.initialize();
}, 120000);
beforeEach(async () => {
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("APP_URL", "https://ministry.example.test");
  vi.stubEnv("SMTP_HOST", "smtp.example.test");
  vi.stubEnv("SMTP_FROM", "ministry@example.test");
  vi.stubEnv("RECORDING_SUBMISSION_INSTRUCTIONS", "Contact the ministry coordinator for recording submission.");
  state.send.mockReset().mockResolvedValue(undefined);
  await state.database!.exec(`
    RESET_TEST_DATABASE;
    INSERT INTO "user"(id,name,email,"emailVerified") VALUES
      ('parent','Parent','parent@example.test',true),
      ('unsubscribed','Unsubscribed','unsubscribed@example.test',true),
      ('unverified','Unverified','unverified@example.test',false),
      ('not-parent','Not parent','not-parent@example.test',true);
    INSERT INTO parent_profiles(user_id,authorized_child_registration,privacy_accepted_at,policies_accepted_at,email_notifications_subscribed)
      VALUES ('parent',true,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3),true),
      ('unsubscribed',true,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3),false),
      ('unverified',true,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3),true);
    INSERT INTO seasons(id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status,first_published_at,registration_notification_at)
      VALUES ('season','Winter','2026-11-01','2026-12-31','2026-11-01 10:00:00','2026-11-20 10:00:00','America/New_York','Published','2026-10-01 10:00:00','2026-11-03 15:00:00');
    INSERT INTO events(id,season_id,name,starts_at,ends_at) VALUES
      ('event','season','Sunday','2026-11-10 15:00:00','2026-11-10 16:00:00');
    INSERT INTO children(id,parent_user_id,full_name,birth_month,birth_year,status) VALUES
      ('child','parent','Child One',1,2015,'Approved'),
      ('child-two','parent','Child Two',1,2016,'Approved');
    INSERT INTO songs(id,title) VALUES ('song','Song One'),('extra','Extra Song');
    INSERT INTO event_songs(id,event_id,song_id,position) VALUES ('appearance','event','song',1),('extra-appearance','event','extra',2);
    INSERT INTO reservations(id,child_id,season_id,event_id,event_song_id,instrument,spot_number,booking_group)
      VALUES ('reservation','child','season','event','appearance','Piano',1,'regular'),
      ('extra-reservation','child-two','season','event','extra-appearance','Violin',1,'extra');
  `);
});
afterEach(() => vi.unstubAllEnvs());
afterAll(async () => { await state.database?.destroy(); });

describe("hourly notification MySQL integration", () => {
  it("migrates the queue, consolidates a family, and never duplicates sends on repeated runs", async () => {
    expect(await runNotificationJob(now)).toMatchObject({ Sent: 2, Failed: 0 });
    expect(state.send).toHaveBeenCalledTimes(2);
    const reminder = state.send.mock.calls.find((call) => String(call[1]).startsWith("Upcoming performance"))!;
    expect(reminder[2]).toContain("Child One - Song One - Piano");
    expect(reminder[2]).toContain("Child Two - Extra Song - Violin");
    expect(state.send.mock.calls.every((call) => call[0] === "parent@example.test")).toBe(true);
    await runNotificationJob(now);
    expect(state.send).toHaveBeenCalledTimes(2);
    expect((await state.database!.query<{ sent: Date }>(
      "SELECT registration_notification_sent_at AS sent FROM seasons WHERE id='season'",
    )).rows[0].sent).toBeInstanceOf(Date);
  });

  it("rechecks opt-out and cancellations after discovery", async () => {
    await discoverNotifications(now);
    await state.database!.query("UPDATE parent_profiles SET email_notifications_subscribed=false WHERE user_id='parent'");
    expect(await runNotificationJob(now)).toMatchObject({ Skipped: 2, Sent: 0 });
    expect(state.send).not.toHaveBeenCalled();
    await state.database!.query("UPDATE parent_profiles SET email_notifications_subscribed=true WHERE user_id='parent'");
    await state.database!.query("UPDATE reservations SET status='Cancelled'");
    await runNotificationJob(now);
    expect(state.send).not.toHaveBeenCalled();
  });

  it("recalculates pending reminders after a reschedule", async () => {
    await discoverNotifications(now);
    await state.database!.query("UPDATE events SET starts_at='2026-12-10 15:00:00',ends_at='2026-12-10 16:00:00'");
    expect(await runNotificationJob(now)).toMatchObject({ Sent: 1, Skipped: 1 });
    await runNotificationJob(new Date("2026-12-03T16:00:00Z"));
    expect(state.send).toHaveBeenCalledTimes(2);
    expect(state.send.mock.calls[1][2]).toContain("2026-12-07");
  });
});
