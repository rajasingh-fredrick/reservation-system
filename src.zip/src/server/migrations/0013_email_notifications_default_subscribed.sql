ALTER TABLE parent_profiles
  MODIFY COLUMN email_notifications_subscribed boolean NOT NULL DEFAULT true;
