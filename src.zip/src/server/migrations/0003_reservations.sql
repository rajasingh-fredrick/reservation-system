ALTER TABLE events ADD CONSTRAINT events_id_season_unique UNIQUE (id, season_id);
ALTER TABLE event_songs ADD CONSTRAINT event_songs_id_event_unique UNIQUE (id, event_id);

CREATE TABLE reservations (
  id varchar(191) PRIMARY KEY,
  child_id varchar(191) NOT NULL,
  season_id varchar(191) NOT NULL,
  event_id varchar(191) NOT NULL,
  event_song_id varchar(191) NOT NULL,
  instrument varchar(191) NOT NULL
    CHECK (instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone')),
  spot_number integer NOT NULL CHECK (spot_number > 0),
  status varchar(320) NOT NULL DEFAULT 'Confirmed'
    CHECK (status IN ('Confirmed','Cancelled','Admin cancelled')),
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  cancelled_at datetime(3),
  cancellation_reason text,
  FOREIGN KEY (event_id, season_id) REFERENCES events(id, season_id) ON DELETE RESTRICT,
  FOREIGN KEY (event_song_id, event_id) REFERENCES event_songs(id, event_id) ON DELETE RESTRICT,
  FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE RESTRICT,
  FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

ALTER TABLE reservations ADD COLUMN active_booking tinyint GENERATED ALWAYS AS (CASE WHEN status='Confirmed' THEN 1 ELSE NULL END) STORED;

CREATE UNIQUE INDEX reservations_one_child_spot_per_season
  ON reservations(child_id, season_id, active_booking);
CREATE UNIQUE INDEX reservations_one_active_spot
  ON reservations(event_song_id, instrument, spot_number, active_booking);
CREATE INDEX reservations_child_idx ON reservations(child_id, created_at DESC);
CREATE INDEX reservations_event_idx ON reservations(event_id, status);