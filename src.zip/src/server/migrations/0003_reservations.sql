ALTER TABLE events ADD CONSTRAINT events_id_season_unique UNIQUE (id, season_id);
ALTER TABLE event_songs ADD CONSTRAINT event_songs_id_event_unique UNIQUE (id, event_id);

CREATE TABLE reservations (
  id text PRIMARY KEY,
  child_id text NOT NULL REFERENCES children(id) ON DELETE RESTRICT,
  season_id text NOT NULL REFERENCES seasons(id) ON DELETE RESTRICT,
  event_id text NOT NULL,
  event_song_id text NOT NULL,
  instrument text NOT NULL
    CHECK (instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone')),
  spot_number integer NOT NULL CHECK (spot_number > 0),
  status text NOT NULL DEFAULT 'Confirmed'
    CHECK (status IN ('Confirmed','Cancelled','Admin cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  cancelled_at timestamptz,
  cancellation_reason text,
  FOREIGN KEY (event_id, season_id) REFERENCES events(id, season_id) ON DELETE RESTRICT,
  FOREIGN KEY (event_song_id, event_id) REFERENCES event_songs(id, event_id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX reservations_one_child_spot_per_season
  ON reservations(child_id, season_id) WHERE status = 'Confirmed';
CREATE UNIQUE INDEX reservations_one_active_spot
  ON reservations(event_song_id, instrument, spot_number) WHERE status = 'Confirmed';
CREATE INDEX reservations_child_idx ON reservations(child_id, created_at DESC);
CREATE INDEX reservations_event_idx ON reservations(event_id, status);