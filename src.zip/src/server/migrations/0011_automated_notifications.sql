ALTER TABLE parent_profiles
  ADD COLUMN email_notifications_subscribed boolean NOT NULL DEFAULT false;

ALTER TABLE seasons
  ADD COLUMN registration_notification_queued_at datetime(3);

CREATE TABLE automated_notifications (
  id varchar(191) PRIMARY KEY,
  kind varchar(32) NOT NULL CHECK (kind IN ('SeasonAnnouncement','PerformanceReminder')),
  parent_user_id varchar(191) NOT NULL,
  season_id varchar(191) NOT NULL,
  event_id varchar(191),
  deduplication_key varchar(191) NOT NULL UNIQUE,
  status varchar(32) NOT NULL DEFAULT 'Pending'
    CHECK (status IN ('Pending','Sending','Sent','Failed','Preview','Skipped')),
  attempts integer NOT NULL DEFAULT 0,
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  last_attempt_at datetime(3),
  sent_at datetime(3),
  FOREIGN KEY (parent_user_id) REFERENCES "user"(id) ON DELETE CASCADE,
  FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  INDEX automated_notifications_status_idx (status,created_at)
) ENGINE=InnoDB;
