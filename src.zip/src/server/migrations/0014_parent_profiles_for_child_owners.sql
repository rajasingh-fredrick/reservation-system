ALTER TABLE parent_profiles
  MODIFY COLUMN authorized_child_registration boolean DEFAULT NULL,
  MODIFY COLUMN privacy_accepted_at datetime(3) DEFAULT NULL,
  MODIFY COLUMN policies_accepted_at datetime(3) DEFAULT NULL;

INSERT INTO parent_profiles (user_id)
SELECT DISTINCT c.parent_user_id
FROM children c
LEFT JOIN parent_profiles pp ON pp.user_id=c.parent_user_id
WHERE pp.user_id IS NULL;
