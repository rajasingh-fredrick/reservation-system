CREATE TABLE email_notifications (
  id varchar(191) PRIMARY KEY,
  user_id varchar(191) NOT NULL,
  kind varchar(32) NOT NULL CHECK (kind IN ('AccountSecurity','ParentTransactional','MinistryMessage')),
  expected_email varchar(320),
  subject varchar(255) NOT NULL,
  body mediumtext,
  expires_at datetime(3),
  status varchar(32) NOT NULL DEFAULT 'Pending'
    CHECK (status IN ('Pending','Sending','Sent','Failed','Preview','Skipped')),
  attempts integer NOT NULL DEFAULT 0,
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  next_attempt_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  last_attempt_at datetime(3),
  sent_at datetime(3),
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE,
  INDEX email_notifications_due_idx (status,next_attempt_at,created_at)
) ENGINE=InnoDB;
