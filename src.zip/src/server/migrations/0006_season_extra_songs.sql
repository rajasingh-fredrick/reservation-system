CREATE TABLE season_song_settings (
  season_id text NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
  song_id text NOT NULL REFERENCES songs(id) ON DELETE CASCADE,
  allow_extra boolean NOT NULL DEFAULT false,
  PRIMARY KEY (season_id, song_id)
);

ALTER TABLE reservations ADD COLUMN booking_group text NOT NULL DEFAULT 'regular';
DROP INDEX reservations_one_child_spot_per_season;
CREATE UNIQUE INDEX reservations_one_child_spot_per_season
  ON reservations(child_id, season_id, booking_group) WHERE status = 'Confirmed';
