CREATE TABLE season_song_settings (
  season_id varchar(191) NOT NULL,
  song_id varchar(191) NOT NULL,
  allow_extra boolean NOT NULL DEFAULT false,
  PRIMARY KEY (season_id, song_id),
  FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE CASCADE,
  FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE
) ENGINE=InnoDB;

ALTER TABLE reservations ADD COLUMN booking_group varchar(191) NOT NULL DEFAULT 'regular';
DROP INDEX reservations_one_child_spot_per_season ON reservations;
CREATE UNIQUE INDEX reservations_one_child_spot_per_season
  ON reservations(child_id, season_id, booking_group, active_booking);
