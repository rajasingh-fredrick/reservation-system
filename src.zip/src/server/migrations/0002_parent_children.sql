CREATE UNIQUE INDEX IF NOT EXISTS user_email_lower_unique ON "user" (lower(email));

CREATE TABLE IF NOT EXISTS parent_profiles (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,
  phone text NOT NULL DEFAULT '',
  authorized_child_registration boolean NOT NULL,
  privacy_accepted_at timestamptz NOT NULL,
  policies_accepted_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS children (
  id text PRIMARY KEY,
  parent_user_id text NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  full_name text NOT NULL CHECK (length(trim(full_name)) BETWEEN 1 AND 160),
  birth_month smallint NOT NULL CHECK (birth_month BETWEEN 1 AND 12),
  birth_year smallint NOT NULL CHECK (birth_year BETWEEN 1900 AND 9999),
  additional_information text NOT NULL DEFAULT '' CHECK (length(additional_information) <= 3000),
  status text NOT NULL DEFAULT 'Pending approval'
    CHECK (status IN ('Pending approval','Approved','Rejected','Archived')),
  status_reason text,
  reviewed_by text REFERENCES "user"(id) ON DELETE RESTRICT,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS child_instruments (
  child_id text NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  instrument text NOT NULL
    CHECK (instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone')),
  years_experience numeric(4,1) NOT NULL CHECK (
    years_experience BETWEEN 0 AND 30 AND years_experience * 2 = trunc(years_experience * 2)
  ),
  PRIMARY KEY (child_id, instrument)
);

CREATE INDEX IF NOT EXISTS children_parent_idx ON children(parent_user_id, created_at DESC);