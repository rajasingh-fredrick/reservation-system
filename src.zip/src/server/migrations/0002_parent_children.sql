
CREATE TABLE IF NOT EXISTS parent_profiles (
  user_id varchar(191) PRIMARY KEY,
  phone varchar(320) NOT NULL DEFAULT '',
  authorized_child_registration boolean NOT NULL,
  privacy_accepted_at datetime(3) NOT NULL,
  policies_accepted_at datetime(3) NOT NULL,
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS children (
  id varchar(191) PRIMARY KEY,
  parent_user_id varchar(191) NOT NULL,
  full_name varchar(320) NOT NULL CHECK (char_length(trim(full_name)) BETWEEN 1 AND 160),
  birth_month smallint NOT NULL CHECK (birth_month BETWEEN 1 AND 12),
  birth_year smallint NOT NULL CHECK (birth_year BETWEEN 1900 AND 9999),
  additional_information text NOT NULL DEFAULT ('') CHECK (char_length(additional_information) <= 3000),
  status varchar(320) NOT NULL DEFAULT 'Pending approval'
    CHECK (status IN ('Pending approval','Approved','Rejected','Archived')),
  status_reason text,
  reviewed_by varchar(191),
  reviewed_at datetime(3),
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  FOREIGN KEY (parent_user_id) REFERENCES "user"(id) ON DELETE RESTRICT,
  FOREIGN KEY (reviewed_by) REFERENCES "user"(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS child_instruments (
  child_id varchar(191) NOT NULL,
  instrument varchar(191) NOT NULL
    CHECK (instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone')),
  years_experience decimal(4,1) NOT NULL CHECK (
    years_experience BETWEEN 0 AND 30 AND years_experience * 2 = truncate(years_experience * 2,0)
  ),
  PRIMARY KEY (child_id, instrument),
  FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX children_parent_idx ON children(parent_user_id, created_at DESC);