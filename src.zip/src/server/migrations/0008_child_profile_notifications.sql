CREATE TABLE child_profile_notifications (
  id varchar(191) PRIMARY KEY,
  child_id varchar(191) NOT NULL UNIQUE,
  parent_user_id varchar(191) NOT NULL,
  kind varchar(32) NOT NULL CHECK (kind IN ('Welcome','Acknowledgement')),
  status varchar(32) NOT NULL DEFAULT 'Pending'
    CHECK (status IN ('Pending','Sending','Sent','Failed','Preview')),
  attempts integer NOT NULL DEFAULT 0,
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  last_attempt_at datetime(3),
  sent_at datetime(3),
  FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_user_id) REFERENCES "user"(id) ON DELETE CASCADE,
  INDEX child_notifications_status_idx (status,created_at)
) ENGINE=InnoDB;
