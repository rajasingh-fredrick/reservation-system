ALTER TABLE season_song_settings
  ADD COLUMN song_role varchar(32) NULL
  CHECK (song_role IS NULL OR song_role IN ('Opening Song','Closing Song','Special Song','Offertory Song'));
