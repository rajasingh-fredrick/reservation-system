CREATE TABLE IF NOT EXISTS "user" (
  id text PRIMARY KEY,
  name text NOT NULL,
  email text NOT NULL UNIQUE,
  "emailVerified" boolean NOT NULL DEFAULT false,
  image text,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS session (
  id text PRIMARY KEY,
  "expiresAt" timestamptz NOT NULL,
  token text NOT NULL UNIQUE,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now(),
  "ipAddress" text,
  "userAgent" text,
  "userId" text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS account (
  id text PRIMARY KEY,
  "accountId" text NOT NULL,
  "providerId" text NOT NULL,
  "userId" text NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  "accessToken" text,
  "refreshToken" text,
  "idToken" text,
  "accessTokenExpiresAt" timestamptz,
  "refreshTokenExpiresAt" timestamptz,
  scope text,
  password text,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now(),
  UNIQUE ("providerId", "accountId")
);
CREATE TABLE IF NOT EXISTS verification (
  id text PRIMARY KEY,
  identifier text NOT NULL,
  value text NOT NULL,
  "expiresAt" timestamptz NOT NULL,
  "createdAt" timestamptz DEFAULT now(),
  "updatedAt" timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS admin_users (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE CASCADE,
  granted_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS app_settings (
  key text PRIMARY KEY,
  value text NOT NULL
);
CREATE TABLE IF NOT EXISTS songs (
  id text PRIMARY KEY,
  title text NOT NULL,
  composer text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  archived boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sheets (
  id text PRIMARY KEY,
  song_id text NOT NULL REFERENCES songs(id) ON DELETE RESTRICT,
  label text NOT NULL,
  instrument text,
  arrangement text NOT NULL DEFAULT '',
  current_version integer NOT NULL DEFAULT 1 CHECK (current_version > 0),
  archived boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (instrument IS NULL OR instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone'))
);
CREATE TABLE IF NOT EXISTS sheet_versions (
  sheet_id text NOT NULL REFERENCES sheets(id) ON DELETE RESTRICT,
  version integer NOT NULL CHECK (version > 0),
  file_name text NOT NULL,
  storage_key text NOT NULL UNIQUE,
  size_bytes integer NOT NULL CHECK (size_bytes > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (sheet_id, version)
);
CREATE TABLE IF NOT EXISTS seasons (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  start_date date NOT NULL,
  end_date date NOT NULL,
  registration_opens_at timestamptz NOT NULL,
  registration_closes_at timestamptz NOT NULL,
  timezone text NOT NULL,
  location text NOT NULL DEFAULT '',
  instructions text NOT NULL DEFAULT '',
  cancellation_hours integer NOT NULL DEFAULT 0 CHECK (cancellation_hours >= 0),
  status text NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Published','Registration Closed','Completed','Archived')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (start_date <= end_date),
  CHECK (registration_opens_at <= registration_closes_at)
);
CREATE TABLE IF NOT EXISTS events (
  id text PRIMARY KEY,
  season_id text NOT NULL REFERENCES seasons(id) ON DELETE RESTRICT,
  name text NOT NULL,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  location text NOT NULL DEFAULT '',
  CHECK (starts_at < ends_at)
);
CREATE TABLE IF NOT EXISTS event_songs (
  id text PRIMARY KEY,
  event_id text NOT NULL REFERENCES events(id) ON DELETE RESTRICT,
  song_id text NOT NULL REFERENCES songs(id) ON DELETE RESTRICT,
  notes text NOT NULL DEFAULT '',
  position integer NOT NULL CHECK (position > 0),
  UNIQUE (event_id, position)
);
CREATE TABLE IF NOT EXISTS event_requirements (
  event_song_id text NOT NULL REFERENCES event_songs(id) ON DELETE RESTRICT,
  instrument text NOT NULL CHECK (instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone')),
  capacity integer NOT NULL CHECK (capacity > 0),
  PRIMARY KEY (event_song_id, instrument)
);
CREATE TABLE IF NOT EXISTS event_sheets (
  event_song_id text NOT NULL REFERENCES event_songs(id) ON DELETE RESTRICT,
  sheet_id text NOT NULL REFERENCES sheets(id) ON DELETE RESTRICT,
  selected_version integer NOT NULL CHECK (selected_version > 0),
  PRIMARY KEY (event_song_id, sheet_id),
  FOREIGN KEY (sheet_id, selected_version) REFERENCES sheet_versions(sheet_id, version) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS audit_log (
  id text PRIMARY KEY,
  action text NOT NULL,
  description text NOT NULL,
  actor_id text NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS events_season_idx ON events(season_id, starts_at);
CREATE INDEX IF NOT EXISTS event_songs_event_idx ON event_songs(event_id, position);
CREATE INDEX IF NOT EXISTS event_sheets_sheet_idx ON event_sheets(sheet_id);
CREATE INDEX IF NOT EXISTS audit_created_idx ON audit_log(created_at DESC);
