CREATE TABLE IF NOT EXISTS "user" (
  id varchar(191) PRIMARY KEY,
  name varchar(320) NOT NULL,
  email varchar(320) NOT NULL UNIQUE,
  "emailVerified" boolean NOT NULL DEFAULT false,
  image text,
  "createdAt" datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  "updatedAt" datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS session (
  id varchar(191) PRIMARY KEY,
  "expiresAt" datetime(3) NOT NULL,
  token varchar(255) NOT NULL UNIQUE,
  "createdAt" datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  "updatedAt" datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  "ipAddress" varchar(320),
  "userAgent" text,
  "userId" varchar(191) NOT NULL,
  FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS account (
  id varchar(191) PRIMARY KEY,
  "accountId" varchar(320) NOT NULL,
  "providerId" varchar(191) NOT NULL,
  "userId" varchar(191) NOT NULL,
  "accessToken" text,
  "refreshToken" text,
  "idToken" text,
  "accessTokenExpiresAt" datetime(3),
  "refreshTokenExpiresAt" datetime(3),
  scope varchar(320),
  password text,
  "createdAt" datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  "updatedAt" datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  UNIQUE ("providerId", "accountId"),
  FOREIGN KEY ("userId") REFERENCES "user"(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS verification (
  id varchar(191) PRIMARY KEY,
  identifier varchar(320) NOT NULL,
  value text NOT NULL,
  "expiresAt" datetime(3) NOT NULL,
  "createdAt" datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  "updatedAt" datetime(3) DEFAULT CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS admin_users (
  user_id varchar(191) PRIMARY KEY,
  granted_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS app_settings (
  "key" varchar(191) PRIMARY KEY,
  value text NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS songs (
  id varchar(191) PRIMARY KEY,
  title varchar(320) NOT NULL,
  composer varchar(320) NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT (''),
  archived boolean NOT NULL DEFAULT false,
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS sheets (
  id varchar(191) PRIMARY KEY,
  song_id varchar(191) NOT NULL,
  label varchar(320) NOT NULL,
  instrument varchar(191),
  arrangement varchar(320) NOT NULL DEFAULT '',
  current_version integer NOT NULL DEFAULT 1 CHECK (current_version > 0),
  archived boolean NOT NULL DEFAULT false,
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  CHECK (instrument IS NULL OR instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone')),
  FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS sheet_versions (
  sheet_id varchar(191) NOT NULL,
  version integer NOT NULL CHECK (version > 0),
  file_name varchar(320) NOT NULL,
  storage_key varchar(191) NOT NULL UNIQUE,
  size_bytes integer NOT NULL CHECK (size_bytes > 0),
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (sheet_id, version),
  FOREIGN KEY (sheet_id) REFERENCES sheets(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS seasons (
  id varchar(191) PRIMARY KEY,
  name varchar(320) NOT NULL,
  description text NOT NULL DEFAULT (''),
  start_date date NOT NULL,
  end_date date NOT NULL,
  registration_opens_at datetime(3) NOT NULL,
  registration_closes_at datetime(3) NOT NULL,
  timezone varchar(320) NOT NULL,
  location varchar(320) NOT NULL DEFAULT '',
  instructions text NOT NULL DEFAULT (''),
  cancellation_hours integer NOT NULL DEFAULT 0 CHECK (cancellation_hours >= 0),
  status varchar(320) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Published','Registration Closed','Completed','Archived')),
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  CHECK (start_date <= end_date),
  CHECK (registration_opens_at <= registration_closes_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS events (
  id varchar(191) PRIMARY KEY,
  season_id varchar(191) NOT NULL,
  name varchar(320) NOT NULL,
  starts_at datetime(3) NOT NULL,
  ends_at datetime(3) NOT NULL,
  location varchar(320) NOT NULL DEFAULT '',
  CHECK (starts_at < ends_at),
  FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS event_songs (
  id varchar(191) PRIMARY KEY,
  event_id varchar(191) NOT NULL,
  song_id varchar(191) NOT NULL,
  notes text NOT NULL DEFAULT (''),
  position integer NOT NULL CHECK (position > 0),
  UNIQUE (event_id, position),
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE RESTRICT,
  FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS event_requirements (
  event_song_id varchar(191) NOT NULL,
  instrument varchar(191) NOT NULL CHECK (instrument IN ('Violin','Piano','Keyboard','Drums','Guitar','Bass Guitar','Saxophone')),
  capacity integer NOT NULL CHECK (capacity > 0),
  PRIMARY KEY (event_song_id, instrument),
  FOREIGN KEY (event_song_id) REFERENCES event_songs(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS event_sheets (
  event_song_id varchar(191) NOT NULL,
  sheet_id varchar(191) NOT NULL,
  selected_version integer NOT NULL CHECK (selected_version > 0),
  PRIMARY KEY (event_song_id, sheet_id),
  FOREIGN KEY (sheet_id, selected_version) REFERENCES sheet_versions(sheet_id, version) ON DELETE RESTRICT,
  FOREIGN KEY (event_song_id) REFERENCES event_songs(id) ON DELETE RESTRICT,
  FOREIGN KEY (sheet_id) REFERENCES sheets(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS audit_log (
  id varchar(191) PRIMARY KEY,
  action varchar(320) NOT NULL,
  description text NOT NULL,
  actor_id varchar(191) NOT NULL,
  created_at datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  FOREIGN KEY (actor_id) REFERENCES "user"(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE INDEX events_season_idx ON events(season_id, starts_at);
CREATE INDEX event_songs_event_idx ON event_songs(event_id, position);
CREATE INDEX event_sheets_sheet_idx ON event_sheets(sheet_id);
CREATE INDEX audit_created_idx ON audit_log(created_at DESC);
