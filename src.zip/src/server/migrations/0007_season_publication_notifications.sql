ALTER TABLE seasons
  ADD COLUMN first_published_at datetime(3) NULL,
  ADD COLUMN registration_notification_at datetime(3) NULL,
  ADD COLUMN registration_notification_timezone varchar(100) NULL,
  ADD COLUMN registration_notification_sent_at datetime(3) NULL,
  ADD INDEX seasons_notification_due (status, registration_notification_sent_at, registration_notification_at);

UPDATE seasons SET first_published_at=updated_at WHERE status <> 'Draft';
