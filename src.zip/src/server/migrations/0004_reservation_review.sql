ALTER TABLE reservations ADD COLUMN review_required boolean NOT NULL DEFAULT false;
ALTER TABLE reservations ADD COLUMN review_reason text;
ALTER TABLE reservations ADD CONSTRAINT reservations_requirement_fk
  FOREIGN KEY (event_song_id, instrument)
  REFERENCES event_requirements(event_song_id, instrument)
  ON DELETE RESTRICT;