ALTER TABLE child_profile_notifications
  ADD COLUMN recipient varchar(32) NOT NULL DEFAULT 'Parent'
    CHECK (recipient IN ('Parent','Administrator')),
  ADD UNIQUE INDEX child_notifications_recipient_idx (child_id,recipient);

ALTER TABLE child_profile_notifications DROP INDEX child_id;
