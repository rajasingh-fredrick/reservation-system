import { randomUUID } from "node:crypto";
import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import type { Instrument, Sheet, Usage } from "../lib/contracts";
import { MAX_PDF_BYTES } from "../lib/contracts";
import { HttpError, recordAudit } from "./http";
import { query, transaction, uploadDirectory, type Executor } from "./db";

export { MAX_PDF_BYTES } from "../lib/contracts";

export type PdfUpload = { fileName: string; bytes: Buffer };
export type SheetInput = { file: PdfUpload; label: string; instrument: Instrument | null; arrangement: string };

export async function getPdfs(form: FormData): Promise<PdfUpload[]> {
  const entries = form.getAll("files");
  if (!entries.length) throw new HttpError(400, "Upload at least one PDF file.", "FILE_REQUIRED");
  const result: PdfUpload[] = [];
  for (const entry of entries) {
    if (!(entry instanceof File)) throw new HttpError(400, "Each uploaded file must be a PDF.", "INVALID_FILE");
    if (entry.size < 1 || entry.size > MAX_PDF_BYTES) throw new HttpError(400, "Each PDF must be between 1 byte and 15 MB.", "FILE_SIZE");
    const bytes = Buffer.from(await entry.arrayBuffer());
    if (entry.type !== "application/pdf" || bytes.subarray(0, 5).toString("ascii") !== "%PDF-") {
      throw new HttpError(400, "Only valid PDF files are accepted.", "INVALID_FILE_TYPE");
    }
    result.push({ fileName: path.basename(entry.name).slice(0, 240) || "sheet.pdf", bytes });
  }
  return result;
}

export async function writePdf(file: PdfUpload) {
  await mkdir(uploadDirectory, { recursive: true });
  const key = `${randomUUID()}.pdf`;
  const target = path.join(uploadDirectory, key);
  await writeFile(target, file.bytes, { flag: "wx", mode: 0o600 });
  return { key, target };
}

export async function removeFiles(paths: string[]) {
  await Promise.all(paths.map((target) => unlink(target).catch(() => undefined)));
}

export async function resolveSheetInputs(form: FormData): Promise<SheetInput[]> {
  const files = await getPdfs(form);
  const parseArray = (key: string) => {
    const value = form.get(key);
    if (typeof value !== "string") throw new HttpError(400, `${key} is required.`, "INVALID_FIELD");
    let parsed: unknown;
    try { parsed = JSON.parse(value); } catch { throw new HttpError(400, `${key} must contain valid JSON.`, "INVALID_FIELD"); }
    if (!Array.isArray(parsed) || parsed.length !== files.length) {
      throw new HttpError(400, `${key} must have one entry per file.`, "INVALID_FIELD");
    }
    return parsed;
  };
  const labels = parseArray("sheetLabels");
  const instruments = parseArray("sheetInstruments");
  const arrangements = parseArray("sheetArrangements");
  const allowed = new Set(["Violin", "Piano", "Keyboard", "Drums", "Guitar", "Bass Guitar", "Saxophone"]);
  return files.map((file, index) => {
    if (typeof labels[index] !== "string" || !labels[index].trim() || labels[index].length > 200) {
      throw new HttpError(400, "Each sheet label is required and must be at most 200 characters.", "INVALID_FIELD");
    }
    const instrument = instruments[index];
    if (instrument !== null && (typeof instrument !== "string" || !allowed.has(instrument))) {
      throw new HttpError(400, "A sheet instrument is not supported.", "INVALID_FIELD");
    }
    if (typeof arrangements[index] !== "string" || arrangements[index].length > 200) {
      throw new HttpError(400, "Each arrangement must be at most 200 characters.", "INVALID_FIELD");
    }
    return { file, label: labels[index].trim(), instrument: instrument as Instrument | null, arrangement: arrangements[index] };
  });
}

export async function usageForSong(songId: string) {
  const result = await query<{
    event_id: string; event_name: string; season_id: string; season_name: string; season_status: string; starts_at: unknown;
  }>(
    `SELECT e.id AS event_id, e.name AS event_name, s.id AS season_id, s.name AS season_name,
       s.status AS season_status, e.starts_at
     FROM event_songs es JOIN events e ON e.id = es.event_id JOIN seasons s ON s.id = e.season_id
     WHERE es.song_id = $1 ORDER BY e.starts_at`,
    [songId],
  );
  return result.rows;
}

export async function usageForSheet(sheetId: string) {
  const result = await query<{
    event_id: string; event_name: string; season_id: string; season_name: string; season_status: string; starts_at: unknown;
  }>(
    `SELECT DISTINCT e.id AS event_id, e.name AS event_name, s.id AS season_id, s.name AS season_name,
       s.status AS season_status, e.starts_at
     FROM event_sheets x JOIN event_songs es ON es.id = x.event_song_id
       JOIN events e ON e.id = es.event_id JOIN seasons s ON s.id = e.season_id
     WHERE x.sheet_id = $1 ORDER BY e.starts_at`,
    [sheetId],
  );
  return result.rows;
}

export function mapUsage(row: { event_id: string; event_name: string; season_id: string; season_name: string; season_status: string; starts_at: unknown }): Usage {
  return {
    eventId: row.event_id,
    eventName: row.event_name,
    seasonId: row.season_id,
    seasonName: row.season_name,
    seasonStatus: row.season_status as Usage["seasonStatus"],
    startsAt: iso(row.starts_at),
  };
}

export function iso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  const date = new Date(String(value));
  return Number.isNaN(date.valueOf()) ? String(value) : date.toISOString();
}

export async function currentSheet(sheetId: string, executor: Executor = { query }) {
  const result = await executor.query<{
    id: string; song_id: string; label: string; instrument: Instrument | null; arrangement: string; current_version: number; archived: boolean;
    file_name: string; size_bytes: number; created_at: unknown; storage_key: string;
  }>(
    `SELECT sh.id, sh.song_id, sh.label, sh.instrument, sh.arrangement, sh.current_version,
       sh.archived, v.file_name, v.size_bytes, sh.created_at, v.storage_key
     FROM sheets sh JOIN sheet_versions v ON v.sheet_id = sh.id AND v.version = sh.current_version WHERE sh.id = $1`,
    [sheetId],
  );
  return result.rows[0];
}

export function sheetAsContract(row: NonNullable<Awaited<ReturnType<typeof currentSheet>>>, usages: Usage[] = []): Sheet {
  return {
    id: row.id, songId: row.song_id, label: row.label, instrument: row.instrument, arrangement: row.arrangement,
    fileName: row.file_name, size: Number(row.size_bytes), version: Number(row.current_version), archived: row.archived,
    createdAt: iso(row.created_at), usages,
  };
}

export async function insertSheet(tx: Executor, songId: string, item: SheetInput, key: string) {
  const id = randomUUID();
  await tx.query(
    `INSERT INTO sheets (id,song_id,label,instrument,arrangement,current_version) VALUES ($1,$2,$3,$4,$5,1)`,
    [id, songId, item.label, item.instrument, item.arrangement],
  );
  await tx.query(
    `INSERT INTO sheet_versions (sheet_id,version,file_name,storage_key,size_bytes) VALUES ($1,1,$2,$3,$4)`,
    [id, item.file.fileName, key, item.file.bytes.length],
  );
  return id;
}

export async function addEventSelection(tx: Executor, eventSongId: string, sheetId: string) {
  const row = await currentSheet(sheetId, tx);
  if (!row) throw new HttpError(404, "Music sheet not found.", "NOT_FOUND");
  await tx.query(
    "INSERT INTO event_sheets (event_song_id,sheet_id,selected_version) VALUES ($1,$2,$3)",
    [eventSongId, sheetId, row.current_version],
  );
}

export async function auditSong(tx: Executor, actorId: string, action: string, title: string) {
  await recordAudit(actorId, action, title, tx);
}
