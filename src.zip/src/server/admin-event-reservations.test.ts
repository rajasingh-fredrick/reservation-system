import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { NextRequest } from "next/server";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import type { AdminData } from "../lib/contracts";

const state = vi.hoisted(() => ({
  database: null as PGlite | null,
  userId: "admin" as string | null,
}));

vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: async <T>(text: string, params: unknown[] = []) => {
    const result = await state.database!.query<T>(text, params);
    return { rows: result.rows, rowCount: result.affectedRows ?? result.rows.length };
  },
}));
vi.mock("./auth", () => ({
  getAuth: () => ({
    api: {
      getSession: async () => state.userId
        ? { user: { id: state.userId, name: "Test", email: "test@example.test" } }
        : null,
    },
  }),
}));

import { GET as getAdminData } from "../app/api/admin/data/route";
import { GET as getParentSeasons } from "../app/api/parent/seasons/route";

beforeAll(async () => {
  state.database = new PGlite();
  const directory = path.join(process.cwd(), "src", "server", "migrations");
  for (const name of (await readdir(directory)).filter((file) => file.endsWith(".sql")).sort()) {
    await state.database.exec(await readFile(path.join(directory, name), "utf8"));
  }
  await state.database.exec(`
    INSERT INTO "user" (id,name,email,"emailVerified") VALUES
      ('admin','Admin','admin@example.test',true),
      ('parent','Parent','parent@example.test',true),
      ('other','Other parent','other@example.test',true),
      ('unverified','Unverified','unverified@example.test',false);
    INSERT INTO admin_users(user_id) VALUES ('admin'),('unverified');
    INSERT INTO children(id,parent_user_id,full_name,birth_month,birth_year,status) VALUES
      ('child','parent','Own Child',1,2020,'Approved'),
      ('other-child','other','Private Child',1,2020,'Approved'),
      ('third-child','other','Another Child',1,2020,'Approved');
    INSERT INTO songs(id,title) VALUES ('song','Shared song');
    INSERT INTO seasons(id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status)
      VALUES ('season','Season','2030-01-01','2030-12-31','2029-01-01','2030-12-31','UTC','Published');
    INSERT INTO events(id,season_id,name,starts_at,ends_at) VALUES
      ('event','season','First event','2030-02-01 10:00Z','2030-02-01 11:00Z'),
      ('second','season','Second event','2030-03-01 10:00Z','2030-03-01 11:00Z'),
      ('empty','season','Empty event','2030-04-01 10:00Z','2030-04-01 11:00Z');
    INSERT INTO event_songs(id,event_id,song_id,position) VALUES
      ('assignment','event','song',1),('second-assignment','second','song',1);
    INSERT INTO event_requirements(event_song_id,instrument,capacity) VALUES
      ('assignment','Violin',2),('second-assignment','Piano',1);
    INSERT INTO reservations(id,child_id,season_id,event_id,event_song_id,instrument,spot_number,status) VALUES
      ('own','child','season','event','assignment','Violin',1,'Confirmed'),
      ('private','other-child','season','event','assignment','Violin',2,'Confirmed'),
      ('another','third-child','season','second','second-assignment','Piano',1,'Confirmed'),
      ('cancelled','child','season','event','assignment','Violin',2,'Cancelled'),
      ('admin-cancelled','child','season','event','assignment','Violin',2,'Admin cancelled');
  `);
}, 120000);

beforeEach(() => { state.userId = "admin"; });
afterAll(async () => { await state.database?.close(); });

describe("administrator event reservations", () => {
  it("groups only confirmed reservations under their events with child, song, instrument, and spot", async () => {
    const response = await getAdminData(new NextRequest("http://localhost:3000/api/admin/data"));
    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toBe("no-store");
    const data: AdminData = await response.json();
    const events = data.seasons[0].events;
    expect(events.find((event) => event.id === "event")?.reservations).toEqual([
      { id: "own", childName: "Own Child", songTitle: "Shared song", instrument: "Violin", spotNumber: 1 },
      { id: "private", childName: "Private Child", songTitle: "Shared song", instrument: "Violin", spotNumber: 2 },
    ]);
    expect(events.find((event) => event.id === "second")?.reservations).toEqual([
      { id: "another", childName: "Another Child", songTitle: "Shared song", instrument: "Piano", spotNumber: 1 },
    ]);
    expect(events.find((event) => event.id === "empty")?.reservations).toEqual([]);
  });

  it.each([
    [null, 401],
    ["parent", 403],
    ["unverified", 403],
  ] as const)("rejects non-administrator session %s", async (userId, status) => {
    state.userId = userId;
    const response = await getAdminData(new NextRequest("http://localhost:3000/api/admin/data"));
    expect(response.status).toBe(status);
    expect(await response.text()).not.toContain("Private Child");
  });

  it("does not expose other families' names through parent browsing", async () => {
    state.userId = "parent";
    const response = await getParentSeasons(new NextRequest("http://localhost:3000/api/parent/seasons"));
    expect(response.status).toBe(200);
    const body = await response.text();
    expect(body).toContain("Own Child");
    expect(body).not.toContain("Private Child");
    expect(body).not.toContain("Another Child");
    expect(body).toContain('"reserved":2');
  });

  it("reflects cancellations on the next administrator refresh", async () => {
    await state.database!.query("UPDATE reservations SET status='Cancelled' WHERE id='own'");
    try {
      const response = await getAdminData(new NextRequest("http://localhost:3000/api/admin/data"));
      const data: AdminData = await response.json();
      expect(data.seasons[0].events.find((event) => event.id === "event")?.reservations.map((row) => row.id)).toEqual(["private"]);
    } finally {
      await state.database!.query("UPDATE reservations SET status='Confirmed' WHERE id='own'");
    }
  });
});
