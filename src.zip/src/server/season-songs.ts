import type { Executor } from "./db";
import { HttpError, recordAudit } from "./http";

// Call after locking the season so bookings and setting changes use the same policy.
export async function songBookingGroup(tx: Executor, seasonId: string, songId: string) {
  const result = await tx.query<{ allow_extra: boolean }>(
    "SELECT allow_extra FROM season_song_settings WHERE season_id=$1 AND song_id=$2",
    [seasonId, songId],
  );
  return result.rows[0]?.allow_extra ? `song:${songId}` : "regular";
}

export async function setSeasonSongExtra(tx: Executor, input: {
  seasonId: string; songId: string; allowExtra: boolean; confirmImpact: boolean; actorId: string;
}) {
  const { seasonId, songId, allowExtra, confirmImpact, actorId } = input;
  const season = await tx.query<{ name: string; status: string }>(
    "SELECT name,status FROM seasons WHERE id=$1 FOR UPDATE", [seasonId],
  );
  if (!season.rows.length) throw new HttpError(404, "Season not found.", "NOT_FOUND");
  const song = await tx.query<{ title: string }>(
    `SELECT so.title FROM songs so WHERE so.id=$2 AND EXISTS (
      SELECT 1 FROM event_songs es JOIN events e ON e.id=es.event_id
      WHERE e.season_id=$1 AND es.song_id=so.id)`, [seasonId, songId],
  );
  if (!song.rows.length) throw new HttpError(404, "This song is not assigned to the season.", "NOT_FOUND");
  const previous = await songBookingGroup(tx, seasonId, songId);
  const next = allowExtra ? `song:${songId}` : "regular";
  if (previous === next) return;
  if (season.rows[0].status === "Published" && !confirmImpact) {
    throw new HttpError(409, "This changes registration eligibility for every appearance of this song in the published season. Existing reservations will be retained. Confirm the impact to continue.", "IMPACT_CONFIRMATION_REQUIRED");
  }
  if (!allowExtra) {
    const conflicts = await tx.query(
      `SELECT r.child_id FROM reservations r JOIN event_songs es ON es.id=r.event_song_id
       WHERE r.season_id=$1 AND r.status='Confirmed' AND (r.booking_group='regular' OR es.song_id=$2)
       GROUP BY r.child_id HAVING COUNT(*) > 1 LIMIT 1`, [seasonId, songId],
    );
    if (conflicts.rows.length) {
      throw new HttpError(409, "This song cannot become a regular song while a child would have multiple regular-song reservations. Resolve affected reservations first.", "EXTRA_SONG_HAS_CONFLICTS");
    }
  }
  await tx.query(
    `INSERT INTO season_song_settings (season_id,song_id,allow_extra) VALUES ($1,$2,$3)
     ON CONFLICT (season_id,song_id) DO UPDATE SET allow_extra=EXCLUDED.allow_extra`,
    [seasonId, songId, allowExtra],
  );
  await tx.query(
    `UPDATE reservations SET booking_group=$3,updated_at=now()
     WHERE season_id=$1 AND event_song_id IN (SELECT id FROM event_songs WHERE song_id=$2)`,
    [seasonId, songId, next],
  );
  await recordAudit(actorId, "season_song_extra_updated",
    `${allowExtra ? "Enabled" : "Disabled"} extra-song registration for "${song.rows[0].title}" in "${season.rows[0].name}".${confirmImpact ? " Published season impact confirmed." : ""}`, tx);
}
