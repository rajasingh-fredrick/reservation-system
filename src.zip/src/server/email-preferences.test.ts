import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  userId: "parent" as string | null, verified: true, registered: true, subscribed: false, query: vi.fn(),
}));
vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: (...args: unknown[]) => state.query(...args),
}));
vi.mock("./auth", () => ({
  getAuth: () => ({ api: { getSession: async () => state.userId
    ? { user: { id: state.userId, name: "Parent", email: "parent@example.test" } } : null } }),
}));
import { GET, PATCH } from "../app/api/parent/email-preferences/route";

function request(body?: unknown, origin = "http://localhost:3000") {
  return new NextRequest("http://localhost:3000/api/parent/email-preferences", {
    method: body === undefined ? "GET" : "PATCH",
    headers: { origin, "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}
beforeEach(() => {
  state.userId = "parent";
  state.verified = true;
  state.registered = true;
  state.subscribed = false;
  state.query.mockReset().mockImplementation(async (sql: string, params: unknown[]) => {
    if (sql.includes("AS email_verified")) return { rows: [{ email_verified: state.verified }], rowCount: 1 };
    if (sql.startsWith("SELECT")) return { rows: state.registered ? [{ subscribed: state.subscribed, user_id: "parent" }] : [], rowCount: state.registered ? 1 : 0 };
    if (sql.startsWith("UPDATE parent_profiles")) state.subscribed = Boolean(params[0]);
    return { rows: [], rowCount: 1 };
  });
});

describe("parent email preferences", () => {
  it("reads a parent's persisted opt-in and permits subscribing and unsubscribing", async () => {
    expect(await (await GET(request())).json()).toEqual({ subscribed: false });
    expect(await (await PATCH(request({ subscribed: true }))).json()).toEqual({ subscribed: true });
    expect(await (await GET(request())).json()).toEqual({ subscribed: true });
    expect(await (await PATCH(request({ subscribed: false }))).json()).toEqual({ subscribed: false });
  });

  it("always targets the authenticated parent rather than a supplied parent ID", async () => {
    await PATCH(request({ subscribed: true, userId: "someone-else" }));
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("UPDATE parent_profiles"), [true, "parent"],
    );
  });

  it.each([null, {}, { subscribed: "false" }, { subscribed: 1 }])("rejects invalid preference %j", async (body) => {
    expect((await PATCH(request(body))).status).toBe(400);
    expect(state.subscribed).toBe(false);
  });

  it("blocks unregistered users, unverified users, and anonymous users", async () => {
    state.registered = false;
    expect((await GET(request())).status).toBe(403);
    expect((await PATCH(request({ subscribed: true }))).status).toBe(403);
    state.verified = false;
    expect((await GET(request())).status).toBe(403);
    state.userId = null;
    expect((await GET(request())).status).toBe(401);
  });

  it("requires same-origin writes", async () => {
    expect((await PATCH(request({ subscribed: true }, "https://other.example.test"))).status).toBe(403);
    expect(state.query).not.toHaveBeenCalled();
  });
});
