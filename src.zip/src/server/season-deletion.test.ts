import { TestDatabase } from "./test-database";
import { NextRequest } from "next/server";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import type { Executor } from "./db";

const state = vi.hoisted(() => ({
  database: null as TestDatabase | null,
  userId: "admin" as string | null,
  failAudit: false,
}));

function executor(client: Pick<TestDatabase, "query">): Executor {
  return {
    async query<T>(text: string, params: unknown[] = []) {
      if (state.failAudit && text.includes("INSERT INTO audit_log")) throw new Error("Audit unavailable");
      const result = await client.query<T>(text, params);
      return result;
    },
  };
}

vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: <T>(text: string, params?: unknown[]) => executor(state.database!).query<T>(text, params),
  transaction: <T>(work: (tx: Executor) => Promise<T>) =>
    state.database!.transaction((tx) => work(executor(tx))),
}));

vi.mock("./auth", () => ({
  getAuth: () => ({
    api: {
      getSession: async () => state.userId
        ? { user: { id: state.userId, name: "Test", email: "test@example.test" } }
        : null,
    },
  }),
}));

import { DELETE as deleteSeason } from "../app/api/admin/seasons/[id]/route";
import { DELETE as deleteEvent } from "../app/api/admin/events/[id]/route";

const id = "00000000-0000-4000-8000-000000000001";
const otherId = "00000000-0000-4000-8000-000000000002";
const origin = "http://localhost:3000";

function remove(seasonId = id, requestOrigin = origin) {
  return deleteSeason(new NextRequest(`${origin}/api/admin/seasons/${seasonId}`, {
    method: "DELETE", headers: { origin: requestOrigin },
  }), { params: Promise.resolve({ id: seasonId }) });
}

function removeEvent(eventId = "event", confirmImpact = false) {
  return deleteEvent(new NextRequest(`${origin}/api/admin/events/${eventId}${confirmImpact ? "?confirmImpact=true" : ""}`, {
    method: "DELETE", headers: { origin },
  }), { params: Promise.resolve({ id: eventId }) });
}

async function count(table: string) {
  return (await state.database!.query<{ count: number }>(`SELECT count(*) AS count FROM ${table}`)).rows[0].count;
}

beforeAll(async () => {
  state.database = new TestDatabase();
  await state.database.initialize();
}, 120000);

beforeEach(async () => {
  state.userId = "admin";
  state.failAudit = false;
  await state.database!.exec(`
    RESET_TEST_DATABASE;
    INSERT INTO "user" (id,name,email,"emailVerified") VALUES
      ('admin','Admin','admin@example.test',true),
      ('parent','Parent','parent@example.test',true),
      ('unverified','Unverified','unverified@example.test',false);
    INSERT INTO admin_users(user_id) VALUES ('admin'),('unverified');
    INSERT INTO children(id,parent_user_id,full_name,birth_month,birth_year,status)
      VALUES ('child','parent','Child',1,2020,'Approved');
    INSERT INTO songs(id,title) VALUES ('song','Shared song');
    INSERT INTO sheets(id,song_id,label) VALUES ('sheet','song','Music sheet');
    INSERT INTO sheet_versions(sheet_id,version,file_name,storage_key,size_bytes)
      VALUES ('sheet',1,'music.pdf','retained-file',100);
    INSERT INTO seasons(id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status)
      VALUES ('${id}','Season to delete','2030-01-01','2030-12-31','2029-01-01','2030-12-31','UTC','Published'),
             ('${otherId}','Other season','2030-01-01','2030-12-31','2029-01-01','2030-12-31','UTC','Draft');
    INSERT INTO events(id,season_id,name,starts_at,ends_at)
      VALUES ('event','${id}','Performance','2030-02-01 10:00:00','2030-02-01 11:00:00'),
             ('other-event','${otherId}','Other performance','2030-03-01 10:00:00','2030-03-01 11:00:00');
    INSERT INTO event_songs(id,event_id,song_id,position)
      VALUES ('assignment','event','song',1),('other-assignment','other-event','song',1);
    INSERT INTO event_requirements(event_song_id,instrument,capacity)
      VALUES ('assignment','Violin',2),('other-assignment','Violin',2);
    INSERT INTO event_sheets(event_song_id,sheet_id,selected_version)
      VALUES ('assignment','sheet',1),('other-assignment','sheet',1);
    INSERT INTO season_song_settings(season_id,song_id,allow_extra) VALUES ('${id}','song',true);
  `);
});

afterAll(async () => { await state.database?.destroy(); });

describe("season deletion", () => {
  it.each(["Draft", "Published", "Registration Closed", "Completed", "Archived"])(
    "deletes a %s season and dependencies while preserving shared library and other seasons",
    async (status) => {
      await state.database!.query("UPDATE seasons SET status=$1 WHERE id=$2", [status, id]);
      const response = await remove();
      expect(response.status).toBe(200);
      expect(await response.json()).toEqual({ ok: true });
      expect(await count("seasons")).toBe(1);
      for (const table of ["events", "event_songs", "event_requirements", "event_sheets", "songs", "sheets", "sheet_versions"]) {
        expect(await count(table)).toBe(1);
      }
      expect(await count("season_song_settings")).toBe(0);
      expect((await state.database!.query("SELECT id FROM seasons")).rows).toEqual([{ id: otherId }]);
      expect((await state.database!.query("SELECT action FROM audit_log")).rows).toEqual([{ action: "season_deleted" }]);
    },
  );

  it.each(["Confirmed", "Cancelled", "Admin cancelled"])("protects %s reservation history without removing any records", async (status) => {
    await state.database!.query(
      `INSERT INTO reservations(id,child_id,season_id,event_id,event_song_id,instrument,spot_number,status)
       VALUES ('reservation','child',$1,'event','assignment','Violin',1,$2)`, [id, status],
    );
    const response = await remove();
    expect(response.status).toBe(409);
    expect(await response.json()).toMatchObject({ code: "SEASON_HAS_RESERVATIONS" });
    expect(await count("seasons")).toBe(2);
    expect(await count("event_sheets")).toBe(2);
    expect(await count("reservations")).toBe(1);
    expect(await count("audit_log")).toBe(0);
  });

  it("deletes all reservation records when deleting an Archived season and preserves the library", async () => {
    await state.database!.query("UPDATE seasons SET status='Archived' WHERE id=$1", [id]);
    await state.database!.query(
      `INSERT INTO reservations(id,child_id,season_id,event_id,event_song_id,instrument,spot_number,status)
       VALUES ('confirmed','child',$1,'event','assignment','Violin',1,'Confirmed'),
              ('cancelled','child',$1,'event','assignment','Violin',2,'Cancelled'),
              ('admin-cancelled','child',$1,'event','assignment','Piano',1,'Admin cancelled')`,
      [id],
    );

    const response = await remove();
    expect(response.status).toBe(200);
    expect(await count("reservations")).toBe(0);
    expect(await count("events")).toBe(1);
    expect(await count("event_songs")).toBe(1);
    expect(await count("event_sheets")).toBe(1);
    expect(await count("event_requirements")).toBe(1);
    expect(await count("songs")).toBe(1);
    expect(await count("sheets")).toBe(1);
    expect(await count("sheet_versions")).toBe(1);
    expect((await state.database!.query<{ details: string }>("SELECT details FROM audit_log WHERE action='season_deleted'")).rows[0].details)
      .toContain("3 reservation record(s)");
  });

  it("rolls back dependent deletions if the audit write fails", async () => {
    state.failAudit = true;
    expect((await remove()).status).toBe(500);
    expect(await count("seasons")).toBe(2);
    expect(await count("events")).toBe(2);
    expect(await count("event_sheets")).toBe(2);
    expect(await count("event_requirements")).toBe(2);
    expect(await count("season_song_settings")).toBe(1);
  });

  it.each([null, "parent", "unverified"])("rejects unauthorized user %s", async (userId) => {
    state.userId = userId;
    expect((await remove()).status).toBe(userId === null ? 401 : 403);
    expect(await count("seasons")).toBe(2);
  });

  it("rejects cross-origin requests", async () => {
    expect((await remove(id, "https://example.test")).status).toBe(403);
    expect(await count("seasons")).toBe(2);
  });

  it("rejects missing and malformed season IDs", async () => {
    expect((await remove("00000000-0000-4000-8000-000000000099")).status).toBe(404);
    expect((await remove("invalid")).status).toBe(400);
    expect(await count("seasons")).toBe(2);
  });
});

describe("individual event deletion", () => {
  it("requires impact confirmation for a non-draft season and then removes only the event setup", async () => {
    const unconfirmed = await removeEvent("event");
    expect(unconfirmed.status).toBe(409);
    expect(await unconfirmed.json()).toMatchObject({ code: "IMPACT_CONFIRMATION_REQUIRED" });
    expect(await count("events")).toBe(2);

    const confirmed = await removeEvent("event", true);
    expect(confirmed.status).toBe(200);
    expect(await confirmed.json()).toEqual({ ok: true });
    expect(await count("events")).toBe(1);
    expect(await count("event_songs")).toBe(1);
    expect(await count("event_requirements")).toBe(1);
    expect(await count("event_sheets")).toBe(1);
    expect(await count("songs")).toBe(1);
    expect((await state.database!.query<{ action: string; details: string }>("SELECT action,details FROM audit_log")).rows)
      .toEqual([expect.objectContaining({ action: "event_deleted", details: expect.stringContaining("Published season") })]);
  });

  it("allows draft-event deletion without impact confirmation", async () => {
    const response = await removeEvent("other-event");
    expect(response.status).toBe(200);
    expect(await count("events")).toBe(1);
  });

  it("blocks deleting an event with reservation history even with impact confirmation", async () => {
    await state.database!.query(
      "INSERT INTO reservations(id,child_id,season_id,event_id,event_song_id,instrument,spot_number,status) VALUES ('reservation','child',$1,'event','assignment','Violin',1,'Cancelled')",
      [id],
    );
    const response = await removeEvent("event", true);
    expect(response.status).toBe(409);
    expect(await response.json()).toMatchObject({ code: "EVENT_HAS_RESERVATIONS" });
    expect(await count("events")).toBe(2);
    expect(await count("event_sheets")).toBe(2);
  });
});
