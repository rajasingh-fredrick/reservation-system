import { randomUUID } from "node:crypto";
import { HttpError, recordAudit } from "./http";
import { query, type Executor } from "./db";
import type { Season } from "../lib/contracts";
import { addEventSelection } from "./library";
import type { z } from "zod";
import type { eventSongInputSchema } from "./validation";
import { setSeasonSongRole } from "./season-songs";

export function assertDateInSeason(timestamp: string, startDate: string, endDate: string, timezone: string) {
  const date = new Date(timestamp);
  if (Number.isNaN(date.valueOf())) throw new HttpError(400, "Invalid event timestamp.", "INVALID_DATE");
  const localDate = new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit",
  }).format(date);
  if (localDate < startDate || localDate > endDate) {
    throw new HttpError(400, "Events must fall within the season's date range in its configured timezone.", "EVENT_OUTSIDE_SEASON");
  }
}

export async function auditSchedule(executor: Executor, actorId: string, action: string, text: string) {
  await recordAudit(actorId, action, text, executor);
}

export async function getSeason(id: string, executor: Executor = { query }) {
  const result = await executor.query<{
    id: string; name: string; start_date: string; end_date: string; timezone: string; status: Season["status"];
  }>("SELECT id,name,start_date AS start_date,end_date AS end_date,timezone,status FROM seasons WHERE id=$1", [id]);
  return result.rows[0];
}

export async function getEvent(id: string, executor: Executor = { query }) {
  const result = await executor.query<{
    id: string; season_id: string; name: string; starts_at: unknown; ends_at: unknown; location: string; season_status: Season["status"];
    start_date: string; end_date: string; timezone: string;
  }>(
    `SELECT e.id,e.season_id,e.name,e.starts_at,e.ends_at,e.location,s.status AS season_status,
      s.start_date AS start_date,s.end_date AS end_date,s.timezone FROM events e JOIN seasons s ON s.id=e.season_id WHERE e.id=$1`,
    [id],
  );
  return result.rows[0];
}

export async function addEvent(executor: Executor, seasonId: string, input: {
  name: string; startsAt: string; endsAt: string; location?: string; songs?: z.infer<typeof eventSongInputSchema>[];
}) {
  await executor.query("SELECT id FROM seasons WHERE id=$1 FOR UPDATE", [seasonId]);
  const season = await getSeason(seasonId, executor);
  if (!season) throw new HttpError(404, "Season not found.", "NOT_FOUND");
  assertDateInSeason(input.startsAt, String(season.start_date).slice(0, 10), String(season.end_date).slice(0, 10), season.timezone);
  assertDateInSeason(input.endsAt, String(season.start_date).slice(0, 10), String(season.end_date).slice(0, 10), season.timezone);
  const id = randomUUID();
  await executor.query(
    "INSERT INTO events (id,season_id,name,starts_at,ends_at,location) VALUES ($1,$2,$3,$4,$5,$6)",
    [id, seasonId, input.name, new Date(input.startsAt), new Date(input.endsAt), input.location || ""],
  );
  for (const [position, selection] of (input.songs ?? []).entries()) {
    const song = await executor.query("SELECT id FROM songs WHERE id=$1 AND archived=false", [selection.songId]);
    if (!song.rows.length) throw new HttpError(400, "Choose an active library song.", "SONG_NOT_FOUND");
    const sheets = await executor.query("SELECT id FROM sheets WHERE song_id=$1 AND archived=false AND id IN ($2)", [selection.songId, selection.sheetIds]);
    if (sheets.rows.length !== selection.sheetIds.length) throw new HttpError(400, "Every selected sheet must belong to this active library song.", "INVALID_SHEET_SELECTION");
    const eventSongId = randomUUID();
    await executor.query("INSERT INTO event_songs (id,event_id,song_id,notes,position) VALUES ($1,$2,$3,$4,$5)", [eventSongId, id, selection.songId, selection.notes, position + 1]);
    for (const requirement of selection.requirements) {
      await executor.query("INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES ($1,$2,$3)", [eventSongId, requirement.instrument, requirement.capacity]);
    }
    for (const sheetId of selection.sheetIds) await addEventSelection(executor, eventSongId, sheetId);
    if (selection.songRole !== undefined) await setSeasonSongRole(executor, seasonId, selection.songId, selection.songRole);
  }
  return id;
}

export async function schedulePublication(
  executor: Executor,
  seasonId: string,
  firstPublishedAt: unknown,
  status: Season["status"],
  notificationAt: string | undefined,
  timezone: string,
) {
  const firstPublication = status === "Published" && firstPublishedAt == null;
  if (!firstPublication) {
    if (notificationAt !== undefined) {
      throw new HttpError(409, "A notification can only be scheduled at first publication. Reload the season to see its current schedule.", "NOTIFICATION_ALREADY_SCHEDULED");
    }
    return;
  }
  if (!notificationAt || Date.parse(notificationAt) <= Date.now()) {
    throw new HttpError(400, "Choose a future date and time for the registration notification before publishing.", "NOTIFICATION_TIME_REQUIRED");
  }
  await executor.query(
    `UPDATE seasons SET first_published_at=CURRENT_TIMESTAMP(3),registration_notification_at=$1,
      registration_notification_timezone=$2 WHERE id=$3`,
    [new Date(notificationAt), timezone, seasonId],
  );
}

export const validSeasonColumns = {
  name: "name",
  description: "description",
  startDate: "start_date",
  endDate: "end_date",
  registrationOpensAt: "registration_opens_at",
  registrationClosesAt: "registration_closes_at",
  timezone: "timezone",
  location: "location",
  instructions: "instructions",
  cancellationHours: "cancellation_hours",
  status: "status",
} as const;
