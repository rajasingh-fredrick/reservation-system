import { HttpError } from "./http";

export function localDateTimeToIso(date: string, time: string, timezone: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  const clock = /^(\d{2}):(\d{2})$/.exec(time);
  if (!match || !clock) throw new HttpError(400, "Invalid local event date or time.", "INVALID_DATE");
  const parts = { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]), hour: Number(clock[1]), minute: Number(clock[2]) };
  if (parts.hour > 23 || parts.minute > 59) throw new HttpError(400, "Invalid local event time.", "INVALID_DATE");
  let utc = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute);
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  });
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const values = Object.fromEntries(formatter.formatToParts(new Date(utc)).map((part) => [part.type, Number(part.value)]));
    const represented = Date.UTC(values.year, values.month - 1, values.day, values.hour, values.minute);
    const adjustment = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute) - represented;
    utc += adjustment;
    if (adjustment === 0) break;
  }
  const result = new Date(utc);
  if (Number.isNaN(result.valueOf())) throw new HttpError(400, "Invalid local event date or time.", "INVALID_DATE");
  return result.toISOString();
}
