import nodemailer from "nodemailer";

export async function sendMail(to: string, subject: string, text: string) {
  if (process.env.NODE_ENV !== "production") {
    console.info(`[mail-dev] to=${to} subject=${subject}\n${text}`);
    return;
  }
  if (!process.env.SMTP_HOST || !process.env.SMTP_FROM) {
    throw new Error("SMTP_HOST and SMTP_FROM must be configured in production.");
  }
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    connectionTimeout: 30_000,
    greetingTimeout: 30_000,
    socketTimeout: 60_000,
    auth: process.env.SMTP_USER ? {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASSWORD,
    } : undefined,
  });
  await transport.sendMail({ from: process.env.SMTP_FROM, to, subject, text });
}
