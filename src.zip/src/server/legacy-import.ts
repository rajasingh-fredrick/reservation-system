import type { PoolConnection, RowDataPacket } from "mysql2/promise";

export const LEGACY_TABLES = [
  "user", "account", "session", "verification", "admin_users", "app_settings",
  "parent_profiles", "children", "child_instruments", "songs", "sheets",
  "sheet_versions", "seasons", "events", "event_songs", "event_requirements",
  "event_sheets", "season_song_settings", "reservations", "audit_log",
] as const;

export type LegacyTable = {
  name: string;
  columns: string[];
  rows: Record<string, unknown>[];
};

type Column = RowDataPacket & {
  name: string;
  type: string;
  columnType: string;
  key: string;
  extra: string;
};

export type ImportCount = { table: string; source: number; existing: number; inserted: number; unchanged: number };

function identifier(value: string) {
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(value)) throw new Error("Unsupported database identifier.");
  return `\`${value}\``;
}

function stableJson(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value !== null && typeof value === "object") {
    const object = value as Record<string, unknown>;
    return `{${Object.keys(object).sort().map((key) => `${JSON.stringify(key)}:${stableJson(object[key])}`).join(",")}}`;
  }
  const result = JSON.stringify(value);
  if (result === undefined) throw new Error("Unsupported JSON value in legacy data.");
  return result;
}

export function legacyValue(value: unknown, column: Pick<Column, "type" | "columnType">): unknown {
  if (value === undefined) throw new Error("Missing legacy column value.");
  if (value === null) return null;
  if (column.type === "json") return stableJson(typeof value === "string" ? JSON.parse(value) : value);
  if (column.type === "datetime" || column.type === "timestamp") {
    const date = value instanceof Date ? value : new Date(String(value));
    if (Number.isNaN(date.valueOf())) throw new Error("Invalid legacy timestamp.");
    return date;
  }
  if (column.type === "date") return value instanceof Date ? value.toISOString().slice(0, 10) : String(value);
  if (/^(tinyint|smallint|mediumint|int|bigint|decimal|float|double)$/.test(column.type)) {
    const number = Number(value);
    if (!Number.isFinite(number)) throw new Error("Invalid legacy numeric value.");
    return number;
  }
  if (typeof value !== "string") throw new Error(`Unsupported legacy value for MySQL ${column.type}.`);
  return value;
}

function sameValue(left: unknown, right: unknown) {
  return left instanceof Date && right instanceof Date ? left.getTime() === right.getTime() : left === right;
}

export async function importLegacyRecords(connection: PoolConnection, tables: LegacyTable[]): Promise<ImportCount[]> {
  const report: ImportCount[] = [];
  for (const table of tables) {
    if (!LEGACY_TABLES.some((name) => name === table.name)) throw new Error("Unrecognized legacy table.");
    const [metadata] = await connection.query<Column[]>(
      `SELECT COLUMN_NAME AS name, DATA_TYPE AS type, COLUMN_TYPE AS columnType,
       COLUMN_KEY AS \`key\`, EXTRA AS extra FROM information_schema.columns
       WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? ORDER BY ORDINAL_POSITION`, [table.name],
    );
    const writable = metadata.filter((column) => !/\b(VIRTUAL|STORED) GENERATED\b/i.test(column.extra));
    const columns = table.columns.map((name) => {
      const column = writable.find((candidate) => candidate.name === name);
      if (!column) throw new Error(`Legacy ${table.name}.${name} has no writable MySQL equivalent.`);
      return column;
    });
    const primary = writable.filter((column) => column.key === "PRI").map((column) => column.name);
    if (!primary.length || !primary.every((key) => table.columns.includes(key))) {
      throw new Error(`Legacy ${table.name} is missing a primary key.`);
    }
    const normalize = (row: Record<string, unknown>) => Object.fromEntries(
      columns.map((column) => [column.name, legacyValue(row[column.name], column)]),
    );
    const rowKey = (row: Record<string, unknown>) => stableJson(primary.map((key) => row[key]));
    const projection = columns.map((column) => identifier(column.name)).join(",");
    const [existing] = await connection.query<RowDataPacket[]>(`SELECT ${projection} FROM ${identifier(table.name)} FOR UPDATE`);
    const existingByKey = new Map(existing.map((row) => {
      const normalized = normalize(row);
      return [rowKey(normalized), normalized];
    }));
    let inserted = 0;
    let unchanged = 0;
    for (const source of table.rows) {
      const normalized = normalize(source);
      const found = existingByKey.get(rowKey(normalized));
      if (found) {
        const different = columns.filter((column) => !sameValue(found[column.name], normalized[column.name]));
        if (different.length) {
          throw new Error(`Import conflict in ${table.name} (${different.map((column) => column.name).join(", ")}). No existing records will be overwritten.`);
        }
        unchanged++;
        continue;
      }
      await connection.query(
        `INSERT INTO ${identifier(table.name)} (${projection}) VALUES (${columns.map(() => "?").join(",")})`,
        columns.map((column) => normalized[column.name]),
      );
      existingByKey.set(rowKey(normalized), normalized);
      inserted++;
    }
    const [persisted] = await connection.query<RowDataPacket[]>(`SELECT ${projection} FROM ${identifier(table.name)}`);
    const persistedByKey = new Map(persisted.map((row) => {
      const normalized = normalize(row);
      return [rowKey(normalized), normalized];
    }));
    if (persisted.length !== existing.length + inserted) throw new Error(`Row count verification failed for ${table.name}.`);
    for (const source of table.rows) {
      const normalized = normalize(source);
      const found = persistedByKey.get(rowKey(normalized));
      if (!found || columns.some((column) => !sameValue(found[column.name], normalized[column.name]))) {
        throw new Error(`Imported value verification failed for ${table.name}.`);
      }
    }
    report.push({ table: table.name, source: table.rows.length, existing: existing.length, inserted, unchanged });
  }
  return report;
}
