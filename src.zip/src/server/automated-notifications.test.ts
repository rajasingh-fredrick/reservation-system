import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  query: vi.fn(), send: vi.fn(), child: vi.fn(),
  status: "Pending", eligible: true, confirmed: true, startsAt: new Date("2026-11-10T15:00:00Z"),
  seasonStatus: "Published", kind: "PerformanceReminder",
}));
vi.mock("./db", () => ({
  query: (...args: unknown[]) => state.query(...args),
  transaction: async (work: (tx: { query: typeof state.query }) => Promise<unknown>) => work({ query: state.query }),
}));
vi.mock("./mail", () => ({ sendMail: (...args: unknown[]) => state.send(...args) }));
vi.mock("./child-notifications", () => ({ deliverChildNotification: (...args: unknown[]) => state.child(...args) }));

import {
  calendarDaysBefore, deliverAutomatedNotification, discoverNotifications,
  performanceReminderEmail, reminderIsDue, runNotificationJob, seasonAnnouncementEmail,
} from "./automated-notifications";

const now = new Date("2026-11-03T16:00:00Z");
const parent = { name: "Parent", email: "parent@example.test" };
const season = {
  id: "season", name: "Winter", status: "Published", timezone: "America/New_York",
  start_date: "2026-11-01", end_date: "2026-12-31", location: "",
  registration_opens_at: new Date("2026-11-01T15:00:00Z"),
  registration_closes_at: new Date("2026-11-20T15:00:00Z"),
};
const event = { id: "event", name: "Sunday worship", starts_at: new Date("2026-11-10T15:00:00Z"), location: "Church" };
const participation = [
  { child_name: "Child A", song_title: "Song A", instrument: "Piano" },
  { child_name: "Child B", song_title: "Extra Song", instrument: "Violin" },
];

beforeEach(() => {
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("APP_URL", "https://ministry.example.test");
  vi.stubEnv("RECORDING_SUBMISSION_INSTRUCTIONS", "Contact the coordinator for the approved recording submission method.");
  vi.stubEnv("SMTP_HOST", "smtp.example.test");
  vi.stubEnv("SMTP_FROM", "ministry@example.test");
  state.status = "Pending";
  state.eligible = true;
  state.confirmed = true;
  state.startsAt = event.starts_at;
  state.seasonStatus = "Published";
  state.kind = "PerformanceReminder";
  state.send.mockReset().mockResolvedValue(undefined);
  state.child.mockReset().mockResolvedValue("Sent");
  state.query.mockReset().mockImplementation(async (sql: string, params: unknown[] = []) => {
    let rows: unknown[] = [];
    if (sql.startsWith("SELECT * FROM automated_notifications")) {
      rows = [{ id: "task", status: state.status, kind: state.kind, parent_user_id: "parent", season_id: "season", event_id: "event" }];
    } else if (sql.startsWith("SELECT u.name,u.email")) {
      rows = state.eligible ? [parent] : [];
    } else if (sql.startsWith("SELECT * FROM seasons")) {
      rows = [{ ...season, status: state.seasonStatus }];
    } else if (sql.startsWith("SELECT id,name,starts_at")) {
      rows = [{ ...event, starts_at: state.startsAt }];
    } else if (sql.includes("AS child_name,so.title")) {
      rows = state.confirmed ? participation : [];
    } else if (sql.includes(" AS count")) {
      rows = [{ count: 0 }];
    } else if (sql.includes("SET status='Sending'")) {
      state.status = "Sending";
    } else if (sql.includes("SET status='Failed'")) {
      state.status = "Failed";
    } else if (sql.includes("SET status='Skipped'")) {
      state.status = "Skipped";
    } else if (sql.includes("SET status=$1")) {
      state.status = String(params[0]);
    }
    return { rows, rowCount: rows.length };
  });
  vi.spyOn(console, "error").mockImplementation(() => {});
});
afterEach(() => { vi.unstubAllEnvs(); vi.restoreAllMocks(); });

describe("notification calendar and templates", () => {
  it("uses church calendar days across daylight saving changes", () => {
    const starts = new Date("2026-11-03T04:30:00Z"); // November 2 in New York.
    expect(calendarDaysBefore(starts, 7, "America/New_York")).toBe("2026-10-26");
    expect(calendarDaysBefore(starts, 3, "America/New_York")).toBe("2026-10-30");
    expect(reminderIsDue(starts, new Date("2026-10-26T04:00:00Z"), "America/New_York")).toBe(true);
    expect(reminderIsDue(starts, new Date("2026-10-26T03:59:59Z"), "America/New_York")).toBe(false);
    expect(reminderIsDue(starts, starts, "America/New_York")).toBe(false);
  });

  it("includes registration dates, timezone, and a real link without a week count", () => {
    const email = seasonAnnouncementEmail(parent, season);
    for (const phrase of ["Winter", "2026-11-01", "2026-12-31", "Registration opens:",
      "Registration closes:", "America/New_York", "Availability is not guaranteed", "https://ministry.example.test/parent/seasons"]) {
      expect(email.text).toContain(phrase);
    }
    expect(email.text).not.toMatch(/week|{{/i);
  });

  it("consolidates children, instruments, extra songs, deadline, and instructions", () => {
    const email = performanceReminderEmail(parent, season, event, participation, now);
    for (const phrase of ["Child A - Song A - Piano", "Child B - Extra Song - Violin",
      "2026-11-07", "by the end of that day", "Church", "approved recording submission method"]) expect(email.text).toContain(phrase);
    expect(email.text).not.toContain("{{");
    expect(email.text).not.toContain("already passed");
    expect(performanceReminderEmail(parent, season, { ...event, location: "" }, participation, now).text).not.toContain("Location:");
    expect(performanceReminderEmail(parent, { ...season, location: "Main sanctuary" },
      { ...event, location: "" }, participation, now).text).toContain("Location: Main sanctuary");
  });

  it("flags a missed deadline for a late registration or overdue retry", () => {
    expect(performanceReminderEmail(parent, season, event, participation, new Date("2026-11-09T15:00:00Z")).text)
      .toContain("recording deadline has already passed");
  });
});

describe("durable automated delivery", () => {
  it("sends a single consolidated reminder and does not resend on another run", async () => {
    expect(await deliverAutomatedNotification("task", now)).toBe("Sent");
    expect(await deliverAutomatedNotification("task", now)).toBe("Sent");
    expect(state.send).toHaveBeenCalledTimes(1);
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("r.status='Confirmed'"), ["event", "parent"],
    );
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("pp.email_notifications_subscribed=true"), ["parent"]);
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("sent_at=$2"), ["Sent", now, "task"]);
  });

  it.each(["unsubscribed", "unverified", "unregistered"])("skips an ineligible %s recipient at delivery time", async () => {
    state.eligible = false;
    expect(await deliverAutomatedNotification("task", now)).toBe("Skipped");
    expect(state.send).not.toHaveBeenCalled();
    const sql = state.query.mock.calls.find(([sql]) => sql.startsWith("SELECT u.name,u.email"))![0] as string;
    expect(sql).toContain('u."emailVerified"=true');
    expect(sql).toContain("JOIN parent_profiles");
    expect(sql).toContain("pp.email_notifications_subscribed=true");
  });

  it("excludes cancelled reservations by rebuilding the content immediately before send", async () => {
    state.confirmed = false;
    expect(await deliverAutomatedNotification("task", now)).toBe("Skipped");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("recalculates a rescheduled pending reminder instead of sending the old schedule", async () => {
    state.startsAt = new Date("2026-12-10T15:00:00Z");
    expect(await deliverAutomatedNotification("task", now)).toBe("Skipped");
    expect(state.send).not.toHaveBeenCalled();
    expect(await deliverAutomatedNotification("task", new Date("2026-12-03T16:00:00Z"))).toBe("Sent");
    expect(state.send.mock.calls[0][2]).toContain("2026-12-07");
  });

  it.each(["Draft", "Archived", "Completed"])("does not remind families about a %s season", async (status) => {
    state.seasonStatus = status;
    expect(await deliverAutomatedNotification("task", now)).toBe("Skipped");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("allows upcoming published events after registration closes", async () => {
    state.seasonStatus = "Registration Closed";
    expect(await deliverAutomatedNotification("task", now)).toBe("Sent");
  });

  it("does not announce a closed season", async () => {
    state.kind = "SeasonAnnouncement";
    expect(await deliverAutomatedNotification("task", new Date("2026-11-21T00:00:00Z"))).toBe("Skipped");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("tracks SMTP failures and allows a later retry", async () => {
    state.send.mockRejectedValueOnce(new Error("provider rejected the message"));
    expect(await deliverAutomatedNotification("task", now)).toBe("Failed");
    expect(console.error).toHaveBeenCalledWith("Automated email delivery failed", { notificationId: "task" });
    expect(await deliverAutomatedNotification("task", now)).toBe("Sent");
    expect(state.send).toHaveBeenCalledTimes(2);
  });

  it("never automatically reclaims an interrupted Sending record", async () => {
    state.status = "Sending";
    expect(await deliverAutomatedNotification("task", now)).toBe("Sending");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("marks development deliveries Preview rather than Sent", async () => {
    vi.stubEnv("NODE_ENV", "development");
    expect(await deliverAutomatedNotification("task", now)).toBe("Preview");
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("sent_at=$2"), ["Preview", null, "task"]);
  });
});

describe("hourly job", () => {
  it("discovers only due publications and snapshots their eligible audience once", async () => {
    state.query.mockReset().mockImplementation(async (sql: string) => {
      if (sql.startsWith("SELECT id FROM seasons")) return { rows: [{ id: "season" }], rowCount: 1 };
      if (sql.startsWith("SELECT u.id")) return { rows: [{ id: "parent" }], rowCount: 1 };
      return { rows: [], rowCount: 0 };
    });
    await discoverNotifications(now);
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("registration_notification_queued_at IS NULL"), [now]);
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("ON DUPLICATE KEY UPDATE"),
      [expect.any(String), "SeasonAnnouncement", "parent", "season", null, expect.any(String)],
    );
    expect(state.query).toHaveBeenCalledWith(
      "UPDATE seasons SET registration_notification_queued_at=$1 WHERE id=$2", [now, "season"],
    );
  });

  it("processes pending and failed child emails only once per run", async () => {
    const original = state.query.getMockImplementation()!;
    state.query.mockImplementation(async (sql: string, params?: unknown[]) => {
      if (sql.startsWith("SELECT id FROM child_profile_notifications")) return { rows: [{ id: "child-task" }], rowCount: 1 };
      return original(sql, params);
    });
    state.child.mockResolvedValue("Failed");
    expect(await runNotificationJob(now)).toMatchObject({ Failed: 1, Sent: 0 });
    expect(state.child).toHaveBeenCalledExactlyOnceWith("child-task");
  });

  it("does not mark a season completed while delivery is failed or uncertain", async () => {
    await runNotificationJob(now);
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("n.status NOT IN ('Sent','Skipped')"), [now],
    );
  });

  it.each(["APP_URL", "RECORDING_SUBMISSION_INSTRUCTIONS", "SMTP_HOST", "SMTP_FROM"])("fails before discovery when %s is missing", async (key) => {
    vi.stubEnv(key, "");
    await expect(runNotificationJob(now)).rejects.toThrow();
    expect(state.send).not.toHaveBeenCalled();
    expect(state.query).not.toHaveBeenCalled();
  });
});
