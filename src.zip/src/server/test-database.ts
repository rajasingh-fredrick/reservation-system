import { randomUUID } from "node:crypto";
import type { Pool } from "mysql2/promise";
import { createMysqlPool, initializeMysql, mysqlExecutor, mysqlOptions, mysqlTransaction } from "./mysql";
import type { Executor } from "./db";

export class TestDatabase {
  readonly name: string;
  readonly pool: Pool;

  constructor(name = `harmony_test_${randomUUID().replaceAll("-", "")}`) {
    if (!/^harmony_test_[a-z0-9]+$/.test(name)) throw new Error("Tests must use an isolated harmony_test_* database.");
    this.name = name;
    this.pool = createMysqlPool({ ...mysqlOptions(), database: name });
  }

  async initialize() {
    const admin = createMysqlPool({ ...mysqlOptions(), database: undefined, connectionLimit: 1 });
    try {
      await admin.query(`CREATE DATABASE \`${this.name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_ci`);
    } finally {
      await admin.end();
    }
    await initializeMysql(this.pool);
  }

  async query<T = Record<string, unknown>>(text: string, params: unknown[] = []) {
    return mysqlExecutor(this.pool).query<T>(text, params);
  }

  async exec(text: string) {
    for (const statement of text.split(";").map((part) => part.trim()).filter(Boolean)) {
      if (statement === "RESET_TEST_DATABASE") await this.reset();
      else await this.query(statement);
    }
  }

  transaction<T>(work: (tx: Executor) => Promise<T>) {
    return mysqlTransaction(this.pool, work);
  }

  private async reset() {
    const connection = await this.pool.getConnection();
    try {
      await connection.query("SET FOREIGN_KEY_CHECKS=0");
      const [tables] = await connection.query<Array<{ TABLE_NAME: string } & import("mysql2").RowDataPacket>>(
        "SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA=? AND TABLE_NAME <> 'schema_migrations'", [this.name],
      );
      for (const table of tables) await connection.query(`TRUNCATE TABLE \`${table.TABLE_NAME}\``);
    } finally {
      try { await connection.query("SET FOREIGN_KEY_CHECKS=1"); }
      finally { connection.release(); }
    }
  }

  async close() { await this.pool.end(); }

  async destroy() {
    await this.close();
    const admin = createMysqlPool({ ...mysqlOptions(), database: undefined, connectionLimit: 1 });
    try { await admin.query(`DROP DATABASE IF EXISTS \`${this.name}\``); }
    finally { await admin.end(); }
  }
}
