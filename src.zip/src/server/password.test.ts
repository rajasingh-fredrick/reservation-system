import { describe, expect, it } from "vitest";
import argon2 from "argon2";
import { hashPassword as hashLegacyPassword } from "better-auth/crypto";
import { hashPassword, verifyPassword } from "./password";

describe("password hashing", () => {
  it("creates and verifies Argon2id hashes", async () => {
    const hash = await hashPassword("correct horse battery staple");

    expect(hash.startsWith("$argon2id$")).toBe(true);
    expect(await argon2.needsRehash(hash, { memoryCost: 19_456, timeCost: 2, parallelism: 1 })).toBe(false);
    await expect(verifyPassword({ hash, password: "correct horse battery staple" })).resolves.toBe(true);
    await expect(verifyPassword({ hash, password: "wrong password" })).resolves.toBe(false);
  });

  it("continues to verify existing Better Auth password hashes", async () => {
    const password = "existing account password";
    const hash = await hashLegacyPassword(password);

    await expect(verifyPassword({ hash, password })).resolves.toBe(true);
    await expect(verifyPassword({ hash, password: "wrong password" })).resolves.toBe(false);
  });
});