import { NextRequest } from "next/server";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { TestDatabase } from "./test-database";
import type { Executor } from "./db";

const state = vi.hoisted(() => ({
  database: null as TestDatabase | null,
  userId: "parent" as string | null,
  failInsert: false,
  send: vi.fn(),
}));
function executor(tx: Executor): Executor {
  return {
    async query<T>(sql: string, params?: unknown[]) {
      if (state.failInsert && sql.includes("INSERT INTO child_profile_notifications")) throw new Error("Queue unavailable");
      return tx.query<T>(sql, params);
    },
  };
}
vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: <T>(sql: string, params?: unknown[]) => state.database!.query<T>(sql, params),
  transaction: <T>(work: (tx: Executor) => Promise<T>) =>
    state.database!.transaction((tx) => work(executor(tx))),
}));
vi.mock("./auth", () => ({
  getAuth: () => ({ api: { getSession: async () => state.userId
    ? { user: { id: state.userId, name: "Session parent", email: "stale@example.test" } }
    : null } }),
}));
vi.mock("./mail", () => ({ sendMail: (...args: unknown[]) => state.send(...args) }));

import { POST as createChild } from "../app/api/parent/children/route";
import { GET as listNotifications, POST as retry } from "../app/api/admin/notifications/children/route";
import { deliverChildNotification } from "./child-notifications";
import { processImmediateNotifications } from "./email-queue";
import { GET as getEmailPreferences, PATCH as updateEmailPreferences } from "../app/api/parent/email-preferences/route";

const origin = "http://localhost:3000";
function request(path: string, body?: unknown, requestOrigin = origin) {
  return new NextRequest(`${origin}${path}`, {
    method: body ? "POST" : "GET",
    headers: { origin: requestOrigin, "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
}
function submit(name = "First Child", requestOrigin = origin) {
  return createChild(request("/api/parent/children", {
    fullName: name, birthMonth: 3, birthYear: 2016, additionalInformation: "",
    instruments: [{ instrument: "Piano", yearsExperience: 2 }],
  }, requestOrigin));
}
type Delivery = { id: string; kind: string; status: string; attempts: number; sent_at: Date | null };
async function deliveries() {
  return (await state.database!.query<Delivery>("SELECT * FROM child_profile_notifications WHERE recipient='Parent' ORDER BY kind DESC")).rows;
}

beforeAll(async () => {
  state.database = new TestDatabase();
  await state.database.initialize();
}, 120000);
beforeEach(async () => {
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("APP_URL", "https://ministry.example.test");
  state.userId = "parent";
  state.failInsert = false;
  state.send.mockReset().mockResolvedValue(undefined);
  vi.spyOn(console, "error").mockImplementation(() => {});
  await state.database!.exec(`
    RESET_TEST_DATABASE;
    INSERT INTO "user"(id,name,email,"emailVerified") VALUES
      ('parent','Parent One','current@example.test',true),
      ('admin','Admin','admin@example.test',true),
      ('unverified','Unverified','unverified@example.test',false);
    INSERT INTO admin_users(user_id) VALUES ('admin');
    INSERT INTO parent_profiles(user_id,authorized_child_registration,privacy_accepted_at,policies_accepted_at)
      VALUES ('parent',true,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3));
  `);
});
afterEach(() => {
  vi.unstubAllEnvs();
  vi.restoreAllMocks();
});
afterAll(async () => { await state.database?.destroy(); });

describe("child profile welcome delivery", () => {
  it("rolls back a newly created administrator parent profile when child registration fails", async () => {
    state.userId = "admin";
    state.failInsert = true;
    expect((await submit("Admin Child")).status).toBe(500);
    expect((await state.database!.query("SELECT user_id FROM parent_profiles WHERE user_id='admin'")).rows).toHaveLength(0);
    expect((await state.database!.query("SELECT id FROM children WHERE parent_user_id='admin'")).rows).toHaveLength(0);
    expect((await state.database!.query("SELECT user_id FROM admin_users WHERE user_id='admin'")).rows).toHaveLength(1);
  });

  it("registers an administrator's own family with working preferences and parent email delivery", async () => {
    state.userId = "admin";
    expect((await submit("Admin Child")).status).toBe(201);
    expect(await (await getEmailPreferences(request("/api/parent/email-preferences"))).json())
      .toEqual({ subscribed: true });
    const preferenceRequest = new NextRequest(`${origin}/api/parent/email-preferences`, {
      method: "PATCH", headers: { origin, "Content-Type": "application/json" },
      body: JSON.stringify({ subscribed: false }),
    });
    expect(await (await updateEmailPreferences(preferenceRequest)).json()).toEqual({ subscribed: false });
    expect((await submit("Second Admin Child")).status).toBe(201);
    expect(await (await getEmailPreferences(request("/api/parent/email-preferences"))).json())
      .toEqual({ subscribed: false });
    await processImmediateNotifications();
    expect(state.send).toHaveBeenCalledWith(
      "admin@example.test", "Welcome to Tamil Gospel Church's Children's Music Ministry!", expect.stringContaining("Admin Child"),
    );
    expect((await state.database!.query("SELECT user_id FROM admin_users WHERE user_id='admin'")).rows).toHaveLength(1);
    expect((await listNotifications(request("/api/admin/notifications/children"))).status).toBe(200);
  });

  it("sends a personalized welcome only after child and instruments commit", async () => {
    state.send.mockImplementation(async (to) => {
      expect((await state.database!.query("SELECT * FROM children")).rowCount).toBe(1);
      expect((await state.database!.query("SELECT * FROM child_instruments")).rowCount).toBe(1);
      if (to === "current@example.test") expect((await deliveries())[0].status).toBe("Sending");
    });
    const response = await submit();
    expect(response.status).toBe(201);
    expect(await response.json()).toMatchObject({ notificationStatus: "Pending", adminNotificationStatus: "Pending" });
    expect(state.send).not.toHaveBeenCalled();
    await processImmediateNotifications();
    expect(state.send).toHaveBeenCalledWith(
      "current@example.test",
      "Welcome to Tamil Gospel Church's Children's Music Ministry!",
      expect.stringContaining("Dear Parent One,"),
    );
    const text = state.send.mock.calls.find((call) => call[0] === "current@example.test")![2] as string;
    for (const phrase of [
      "First Child", "does not yet reserve a performance spot", "profile is approved",
      "at least three days", "Mrs. Amy Priya Shibu", "Pastor Solomon Karunakaran",
      "https://ministry.example.test/parent",
    ]) expect(text).toContain(phrase);
    expect(text).not.toContain("one week");
    expect(text).not.toContain("{{");
    expect((await deliveries())[0]).toMatchObject({ kind: "Welcome", status: "Sent", attempts: 1, sent_at: expect.any(Date) });
    expect(state.send).toHaveBeenCalledWith(
      "kidsmusic-coord@tamilgospelchurch.org",
      "New child registration - Tamil Gospel Church",
      expect.stringContaining("Child: First Child"),
    );
  });

  it("sends only an acknowledgement for additional children, including an archived first child", async () => {
    await submit();
    await processImmediateNotifications();
    await state.database!.query("UPDATE children SET status='Archived'");
    await submit("Second Child");
    await processImmediateNotifications();
    expect(state.send).toHaveBeenCalledTimes(4);
    const parentEmails = state.send.mock.calls.filter((call) => call[0] === "current@example.test");
    expect(parentEmails[1][1]).toBe("Child profile received - Tamil Gospel Church");
    expect(parentEmails[1][2]).toContain("Second Child");
    expect(parentEmails[1][2]).not.toContain("Welcome to");
    expect(state.send.mock.calls.filter((call) => call[0] === "kidsmusic-coord@tamilgospelchurch.org")).toHaveLength(2);
    expect((await deliveries()).map((row) => row.kind).sort()).toEqual(["Acknowledgement", "Welcome"]);
  });

  it("serializes concurrent first-child submissions so only one gets a welcome", async () => {
    const responses = await Promise.all([submit("Child A"), submit("Child B")]);
    expect(responses.map((response) => response.status)).toEqual([201, 201]);
    expect(state.send).not.toHaveBeenCalled();
    await processImmediateNotifications();
    expect((await deliveries()).map((row) => row.kind).sort()).toEqual(["Acknowledgement", "Welcome"]);
    expect(state.send.mock.calls.filter((call) => String(call[1]).startsWith("Welcome"))).toHaveLength(1);
  });

  it("keeps a valid profile on SMTP failure and retries without resending success", async () => {
    state.send.mockImplementation(async (to) => {
      if (to === "current@example.test") throw new Error("SMTP unavailable");
    });
    expect((await submit()).status).toBe(201);
    await processImmediateNotifications();
    expect((await state.database!.query("SELECT * FROM children")).rowCount).toBe(1);
    const [delivery] = await deliveries();
    expect(delivery).toMatchObject({ status: "Failed", attempts: 1, sent_at: null });
    expect(console.error).toHaveBeenCalledWith("Child profile email delivery failed", { notificationId: delivery.id });
    state.userId = "admin";
    const list = await listNotifications(request("/api/admin/notifications/children"));
    expect(await list.json()).toMatchObject({ notifications: expect.arrayContaining([expect.objectContaining({ status: "Failed", child_name: "First Child" })]) });
    state.send.mockResolvedValue(undefined);
    expect((await retry(request("/api/admin/notifications/children", { id: delivery.id }))).status).toBe(202);
    expect((await deliveries())[0]).toMatchObject({ status: "Pending", attempts: 1 });
    await processImmediateNotifications();
    expect((await deliveries())[0]).toMatchObject({ status: "Sent", attempts: 2 });
    await deliverChildNotification(delivery.id);
    expect(state.send).toHaveBeenCalledTimes(3);
  });

  it("claims a delivery once across concurrent retries", async () => {
    state.send.mockImplementation(async (to) => {
      if (to === "current@example.test") throw new Error("SMTP unavailable");
    });
    await submit();
    await processImmediateNotifications();
    const [delivery] = await deliveries();
    state.send.mockClear().mockResolvedValue(undefined);
    await Promise.all([deliverChildNotification(delivery.id), deliverChildNotification(delivery.id)]);
    expect(state.send).toHaveBeenCalledTimes(1);
    expect((await deliveries())[0]).toMatchObject({ status: "Sent", attempts: 2 });
  });

  it("retries an administrator failure independently without resending the parent's successful email", async () => {
    state.send.mockImplementation(async (to) => {
      if (to === "kidsmusic-coord@tamilgospelchurch.org") throw new Error("SMTP unavailable");
    });
    const response = await submit();
    expect(response.status).toBe(201);
    expect(await response.json()).toMatchObject({ notificationStatus: "Pending", adminNotificationStatus: "Pending" });
    await processImmediateNotifications();
    const result = await state.database!.query<Delivery>(
      "SELECT * FROM child_profile_notifications WHERE recipient='Administrator'",
    );
    expect(result.rows).toHaveLength(1);
    expect(result.rows[0]).toMatchObject({ status: "Failed", attempts: 1 });
    state.send.mockClear().mockResolvedValue(undefined);
    state.userId = "admin";
    expect((await retry(request("/api/admin/notifications/children", { id: result.rows[0].id }))).status).toBe(202);
    expect(state.send).not.toHaveBeenCalled();
    await processImmediateNotifications();
    expect(state.send).toHaveBeenCalledExactlyOnceWith(
      "kidsmusic-coord@tamilgospelchurch.org",
      "New child registration - Tamil Gospel Church",
      expect.stringContaining("First Child"),
    );
    expect((await deliveries())[0]).toMatchObject({ status: "Sent", attempts: 1 });
  });

  it("does not resend uncertain interrupted Sending work", async () => {
    await submit();
    const [delivery] = await deliveries();
    await state.database!.query("UPDATE child_profile_notifications SET status='Sending' WHERE id=$1", [delivery.id]);
    state.send.mockClear();
    expect(await deliverChildNotification(delivery.id)).toBe("Sending");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("does not send to a parent whose email is no longer verified on retry", async () => {
    state.send.mockImplementation(async (to) => {
      if (to === "current@example.test") throw new Error("SMTP unavailable");
    });
    await submit();
    await state.database!.query('UPDATE "user" SET "emailVerified"=false WHERE id=$1', ["parent"]);
    state.send.mockClear();
    expect(await deliverChildNotification((await deliveries())[0].id)).toBe("Failed");
    expect(state.send).not.toHaveBeenCalled();
  });

  it("records development logging as Preview instead of delivery", async () => {
    vi.stubEnv("NODE_ENV", "development");
    expect(await (await submit()).json()).toMatchObject({ notificationStatus: "Pending" });
    await processImmediateNotifications();
    const [delivery] = await deliveries();
    expect(delivery).toMatchObject({ status: "Preview", sent_at: null });
    await deliverChildNotification(delivery.id);
    expect(state.send).toHaveBeenCalledTimes(2);
  });

  it("rolls back child and instruments when durable queue insertion fails", async () => {
    state.failInsert = true;
    expect((await submit()).status).toBe(500);
    expect((await state.database!.query("SELECT * FROM children")).rowCount).toBe(0);
    expect((await state.database!.query("SELECT * FROM child_instruments")).rowCount).toBe(0);
    expect(state.send).not.toHaveBeenCalled();
  });

  it("requires verified same-origin submissions and administrator-only retries", async () => {
    expect((await submit("Cross origin", "https://other.example.test")).status).toBe(403);
    state.userId = "unverified";
    expect((await submit()).status).toBe(403);
    state.userId = null;
    expect((await submit()).status).toBe(401);
    state.userId = "parent";
    expect((await listNotifications(request("/api/admin/notifications/children"))).status).toBe(403);
    expect((await retry(request("/api/admin/notifications/children", { id: "00000000-0000-4000-8000-000000000001" }))).status).toBe(403);
    expect(state.send).not.toHaveBeenCalled();
    expect(await deliveries()).toHaveLength(0);
  });

  it("does not queue or send invalid profile submissions", async () => {
    const response = await createChild(request("/api/parent/children", { fullName: "" }));
    expect(response.status).toBe(400);
    expect(state.send).not.toHaveBeenCalled();
    expect(await deliveries()).toHaveLength(0);
  });

  it("does not retroactively welcome families that already have a child", async () => {
    await state.database!.query(
      "INSERT INTO children(id,parent_user_id,full_name,birth_month,birth_year) VALUES ($1,$2,$3,1,2016)",
      ["existing", "parent", "Existing Child"],
    );
    await submit();
    expect((await deliveries())[0].kind).toBe("Acknowledgement");
    await processImmediateNotifications();
    expect(state.send.mock.calls.find((call) => call[0] === "current@example.test")![1]).not.toContain("Welcome");
  });
});
