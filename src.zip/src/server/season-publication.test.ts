import { NextRequest } from "next/server";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { TestDatabase } from "./test-database";
import type { Executor } from "./db";

const state = vi.hoisted(() => ({
  database: null as TestDatabase | null,
  userId: "admin" as string | null,
  failAudit: false,
}));

function executor(client: Pick<TestDatabase, "query">): Executor {
  return {
    async query<T>(text: string, params: unknown[] = []) {
      if (state.failAudit && text.includes("INSERT INTO audit_log")) throw new Error("Audit unavailable");
      return client.query<T>(text, params);
    },
  };
}

vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: <T>(text: string, params?: unknown[]) => executor(state.database!).query<T>(text, params),
  transaction: <T>(work: (tx: Executor) => Promise<T>) =>
    state.database!.transaction((tx) => work(executor(tx))),
}));
vi.mock("./auth", () => ({
  getAuth: () => ({
    api: {
      getSession: async () => state.userId
        ? { user: { id: state.userId, name: "Test", email: "test@example.test" } }
        : null,
    },
  }),
}));

import { POST } from "../app/api/admin/seasons/route";
import { PATCH } from "../app/api/admin/seasons/[id]/route";
import { adminData } from "./admin-data";

const origin = "http://localhost:3000";
const id = "00000000-0000-4000-8000-000000000001";
const notificationAt = "2031-01-01T15:00:00.000Z";
const fields = {
  name: "Registration season", startDate: "2031-01-01", endDate: "2031-12-31",
  registrationOpensAt: "2031-01-01T16:00:00.000Z",
  registrationClosesAt: "2031-01-31T16:00:00.000Z", timezone: "America/New_York",
};
function request(body: unknown, method: "POST" | "PATCH" = "PATCH", requestOrigin = origin) {
  return new NextRequest(`${origin}/api/admin/seasons${method === "PATCH" ? `/${id}` : ""}`, {
    method, headers: { origin: requestOrigin, "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
}
function update(body: unknown, requestOrigin = origin) {
  return PATCH(request(body, "PATCH", requestOrigin), { params: Promise.resolve({ id }) });
}
async function saved() {
  return (await state.database!.query<Record<string, unknown>>("SELECT * FROM seasons WHERE id=$1", [id])).rows[0];
}

beforeAll(async () => {
  state.database = new TestDatabase();
  await state.database.initialize();
}, 120000);
beforeEach(async () => {
  state.userId = "admin";
  state.failAudit = false;
  await state.database!.exec(`
    RESET_TEST_DATABASE;
    INSERT INTO "user"(id,name,email,"emailVerified") VALUES
      ('admin','Admin','admin@example.test',true),('parent','Parent','parent@example.test',true),
      ('unverified','Unverified','unverified@example.test',false);
    INSERT INTO admin_users(user_id) VALUES ('admin'),('unverified');
    INSERT INTO seasons(id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status)
      VALUES ('${id}','Draft season','2031-01-01','2031-12-31','2031-01-01 16:00:00','2031-01-31 16:00:00','America/New_York','Draft');
  `);
});
afterAll(async () => { await state.database?.destroy(); });

describe("first-publication notifications", () => {
  it("saves publication and the UTC notification schedule together and exposes it to admins", async () => {
    expect((await update({ status: "Published", registrationNotificationAt: notificationAt })).status).toBe(200);
    const row = await saved();
    expect(row.status).toBe("Published");
    expect(row.first_published_at).toBeInstanceOf(Date);
    expect(row.registration_notification_at).toEqual(new Date(notificationAt));
    expect(row.registration_notification_timezone).toBe("America/New_York");
    expect(row.registration_notification_sent_at).toBeNull();
    expect((await adminData()).seasons[0]).toMatchObject({
      registrationNotificationAt: notificationAt, registrationNotificationTimezone: "America/New_York",
      registrationNotificationSentAt: null, firstPublishedAt: expect.any(String),
    });
  });

  it.each([undefined, "2000-01-01T00:00:00Z", "not-a-date", null])("rejects a missing, past or invalid notification time: %s", async (time) => {
    const response = await update({ status: "Published", registrationNotificationAt: time });
    expect(response.status).toBe(400);
    expect(await saved()).toMatchObject({ status: "Draft", first_published_at: null, registration_notification_at: null });
  });

  it("requires a schedule for creation directly as Published, but not Draft", async () => {
    expect((await POST(request({ ...fields, status: "Published" }, "POST"))).status).toBe(400);
    expect((await POST(request({ ...fields, status: "Draft" }, "POST"))).status).toBe(201);
    const response = await POST(request({ ...fields, status: "Published", registrationNotificationAt: notificationAt }, "POST"));
    expect(response.status).toBe(201);
    const created = await response.json() as { id: string };
    const row = (await state.database!.query<Record<string, unknown>>("SELECT * FROM seasons WHERE id=$1", [created.id])).rows[0];
    expect(row.registration_notification_at).toEqual(new Date(notificationAt));
  });

  it("does not accept a notification schedule on a draft save", async () => {
    expect((await update({ status: "Draft", registrationNotificationAt: notificationAt })).status).toBe(409);
    expect((await saved()).registration_notification_at).toBeNull();
  });

  it("keeps the original schedule on edit, timezone change, unpublish and republish", async () => {
    await update({ status: "Published", registrationNotificationAt: notificationAt });
    const original = await saved();
    for (const body of [{ name: "Edited", timezone: "America/Chicago" }, { status: "Draft" }, { status: "Published" }]) {
      expect((await update(body)).status).toBe(200);
    }
    expect(await saved()).toMatchObject({
      first_published_at: original.first_published_at,
      registration_notification_at: new Date(notificationAt),
      registration_notification_timezone: "America/New_York",
    });
    expect((await update({ registrationNotificationAt: "2032-01-01T00:00:00Z" })).status).toBe(409);
  });

  it("does not require or generate a schedule for historical publications", async () => {
    await state.database!.query("UPDATE seasons SET first_published_at=now(),status='Published' WHERE id=$1", [id]);
    expect((await update({ name: "Historical season" })).status).toBe(200);
    expect((await saved()).registration_notification_at).toBeNull();
  });

  it("rolls back both publication and schedule if audit persistence fails", async () => {
    state.failAudit = true;
    expect((await update({ status: "Published", registrationNotificationAt: notificationAt })).status).toBe(500);
    expect(await saved()).toMatchObject({ status: "Draft", first_published_at: null, registration_notification_at: null });
  });

  it("serializes concurrent first-publication requests without overwriting the schedule", async () => {
    const responses = await Promise.all([
      update({ status: "Published", registrationNotificationAt: notificationAt }),
      update({ status: "Published", registrationNotificationAt: "2031-01-02T15:00:00.000Z" }),
    ]);
    expect(responses.map((response) => response.status).sort()).toEqual([200, 409]);
    const expected = responses[0].status === 200 ? notificationAt : "2031-01-02T15:00:00.000Z";
    expect((await saved()).registration_notification_at).toEqual(new Date(expected));
  });

  it.each([null, "parent", "unverified"])("rejects unauthorized publication by %s", async (userId) => {
    state.userId = userId;
    expect((await update({ status: "Published", registrationNotificationAt: notificationAt })).status).toBe(userId === null ? 401 : 403);
  });

  it("rejects cross-origin publication and client changes to publication history", async () => {
    expect((await update({ status: "Published", registrationNotificationAt: notificationAt }, "https://example.test")).status).toBe(403);
    expect((await update({ firstPublishedAt: notificationAt })).status).toBe(400);
    expect((await update({ registrationNotificationSentAt: notificationAt })).status).toBe(400);
  });
});
