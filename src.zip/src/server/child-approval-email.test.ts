import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({ query: vi.fn(), queueEmail: vi.fn() }));
vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  transaction: async (callback: (tx: { query: typeof state.query }) => Promise<unknown>) =>
    callback({ query: state.query }),
}));
vi.mock("./email-queue", () => ({ queueEmail: state.queueEmail }));
vi.mock("./http", async (importOriginal) => ({
  ...await importOriginal<typeof import("./http")>(),
  requireAdminWrite: async () => ({ id: "admin" }),
  recordAudit: vi.fn(),
}));

import { PATCH } from "../app/api/admin/children/[id]/route";

beforeEach(() => {
  state.queueEmail.mockReset().mockResolvedValue("queued");
  state.query.mockReset().mockImplementation(async (sql: string) => {
    if (sql.startsWith("SELECT parent_user_id")) {
      return { rows: [{ parent_user_id: "parent", full_name: "Anna Grace" }] };
    }
    if (sql.startsWith("SELECT email")) return { rows: [{ email: "parent@example.test" }] };
    return { rows: [], rowCount: 1 };
  });
});

describe("child-profile decision emails", () => {
  it("includes the saved child's full name in the approval email", async () => {
    const response = await PATCH(new NextRequest("http://localhost:3000/api/admin/children/child", {
      method: "PATCH",
      body: JSON.stringify({ status: "Approved", full_name: "Untrusted name" }),
    }), { params: Promise.resolve({ id: "11111111-1111-4111-8111-111111111111" }) });

    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ notificationQueued: true });
    expect(state.queueEmail).toHaveBeenCalledWith(
      { query: state.query }, {
        userId: "parent", kind: "ParentTransactional", subject: "Child profile approved",
        text: "The music ministry profile for Anna Grace has been approved. You can now review published seasons and registration availability.",
      });
  });

  it("includes the saved child's full name and preserves the rejection coordinator note", async () => {
    const response = await PATCH(new NextRequest("http://localhost:3000/api/admin/children/child", {
      method: "PATCH",
      body: JSON.stringify({ status: "Rejected", reason: "Please update the instruments.", full_name: "Untrusted name" }),
    }), { params: Promise.resolve({ id: "11111111-1111-4111-8111-111111111111" }) });

    expect(response.status).toBe(200);
    expect(state.queueEmail).toHaveBeenCalledWith(
      { query: state.query }, {
        userId: "parent", kind: "ParentTransactional", subject: "Child profile rejected",
        text: "The music ministry profile for Anna Grace needs an update before approval. Coordinator note: Please update the instruments.",
      });
  });
});
