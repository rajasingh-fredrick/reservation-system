import { z } from "zod";
import { INSTRUMENTS, SEASON_STATUSES, SONG_ROLES } from "../lib/contracts";
import { HttpError, requiredString } from "./http";

export function parseWith<T>(schema: z.ZodType<T>, input: unknown): T {
  const result = schema.safeParse(input);
  if (!result.success) {
    const message = result.error.issues.map((issue) => `${issue.path.join(".") || "request"}: ${issue.message}`).join("; ");
    throw new HttpError(400, message, "VALIDATION_ERROR");
  }
  return result.data;
}

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((value) => {
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
}, "must be a real calendar date");
const isoTimestamp = z.string().datetime({ offset: true });
const timezone = z.string().min(1).max(100).refine((value) => {
  try { new Intl.DateTimeFormat("en", { timeZone: value }); return true; } catch { return false; }
}, "must be a valid IANA timezone");

export const seasonFields = {
  name: z.string().trim().min(1).max(160),
  description: z.string().max(5000).default(""),
  startDate: isoDate,
  endDate: isoDate,
  registrationOpensAt: isoTimestamp,
  registrationClosesAt: isoTimestamp,
  timezone,
  location: z.string().max(300).default(""),
  instructions: z.string().max(5000).default(""),
  cancellationHours: z.number().int().min(0).max(8760).default(0),
  status: z.enum(SEASON_STATUSES).default("Draft"),
  registrationNotificationAt: isoTimestamp.optional(),
};
export const seasonCreateSchema = z.object(seasonFields).superRefine((value, ctx) => {
  if (value.startDate > value.endDate) ctx.addIssue({ code: "custom", path: ["endDate"], message: "must be on or after startDate" });
  if (value.registrationOpensAt > value.registrationClosesAt) ctx.addIssue({ code: "custom", path: ["registrationClosesAt"], message: "must be on or after registrationOpensAt" });
});
export const eventInputSchema = z.object({
  name: z.string().trim().min(1).max(160),
  startsAt: isoTimestamp,
  endsAt: isoTimestamp,
  location: z.string().max(300).default(""),
}).refine((value) => value.startsAt < value.endsAt, { path: ["endsAt"], message: "must be later than startsAt" });

export const requirementSchema = z.object({
  instrument: z.enum(INSTRUMENTS),
  capacity: z.number().int().positive().max(1000),
});
export const requirementsSchema = z.array(requirementSchema).max(INSTRUMENTS.length)
  .refine((items) => new Set(items.map((item) => item.instrument)).size === items.length, "instrument requirements must be unique");

export const eventSongInputSchema = z.object({
  songId: z.string().uuid(),
  songRole: z.enum(SONG_ROLES).nullable().optional(),
  sheetIds: z.array(z.string().uuid()).min(1).max(100)
    .refine((ids) => new Set(ids).size === ids.length, "sheets must be unique"),
  notes: z.string().max(5000).default(""),
  requirements: requirementsSchema,
});
export const eventCreateSchema = eventInputSchema.and(z.object({
  songs: z.array(eventSongInputSchema).min(1).max(100),
}));

export const songLinksSchema = z.array(z.string().trim().url().max(2000).refine((value) => {
  try {
    const protocol = new URL(value).protocol;
    return protocol === "http:" || protocol === "https:";
  } catch {
    return false;
  }
}, "only HTTP/HTTPS links are allowed")).max(30);

export const parentRegistrationSchema = z.object({
  name: z.string().trim().min(1).max(120),
  email: z.string().trim().toLowerCase().email().max(320),
  password: z.string().min(12).max(128),
  phone: z.string().trim().max(40).default(""),
  authorizedChildRegistration: z.literal(true),
  privacyAccepted: z.literal(true),
  policiesAccepted: z.literal(true),
});

export const childProfileSchema = z.object({
  fullName: z.string().trim().min(1).max(160),
  birthMonth: z.number().int().min(1).max(12),
  birthYear: z.number().int().min(1900).max(new Date().getFullYear()),
  additionalInformation: z.string().max(3000).default(""),
  instruments: z.array(z.object({
    instrument: z.enum(INSTRUMENTS),
    yearsExperience: z.number().min(0).max(30).multipleOf(0.5),
  })).min(1).max(INSTRUMENTS.length),
}).superRefine((value, ctx) => {
  const now = new Date();
  const month = now.getUTCMonth() + 1;
  if (value.birthYear === now.getUTCFullYear() && value.birthMonth > month) {
    ctx.addIssue({ code: "custom", path: ["birthMonth"], message: "cannot be in the future" });
  }
  const ageMonths = (now.getUTCFullYear() - value.birthYear) * 12 + month - value.birthMonth;
  const seen = new Set<string>();
  for (const [index, instrument] of value.instruments.entries()) {
    if (seen.has(instrument.instrument)) {
      ctx.addIssue({ code: "custom", path: ["instruments", index, "instrument"], message: "must be unique" });
    }
    seen.add(instrument.instrument);
    if (instrument.yearsExperience * 12 > ageMonths) {
      ctx.addIssue({ code: "custom", path: ["instruments", index, "yearsExperience"], message: "cannot exceed the child's age" });
    }
  }
});

export const adminEmailSchema = z.object({
  allParents: z.boolean(),
  recipientIds: z.array(z.string().uuid()).max(5000)
    .refine((ids) => new Set(ids).size === ids.length, "recipients must be unique"),
  subject: z.string().trim().min(1).max(200).refine((value) => !/[\r\n]/.test(value), "must be a single line"),
  message: z.string().trim().min(1).max(10000),
}).superRefine((value, ctx) => {
  if (value.allParents && value.recipientIds.length > 0) {
    ctx.addIssue({ code: "custom", path: ["recipientIds"], message: "must be empty when sending to all parents" });
  }
  if (!value.allParents && value.recipientIds.length === 0) {
    ctx.addIssue({ code: "custom", path: ["recipientIds"], message: "select at least one parent" });
  }
});

export function parseMultipartJson<T>(form: FormData, key: string, validate: (value: unknown) => T): T {
  const value = form.get(key);
  if (typeof value !== "string") throw new HttpError(400, `${key} must be a JSON string.`, "INVALID_FIELD");
  try { return validate(JSON.parse(value)); } catch (error) {
    if (error instanceof HttpError) throw error;
    throw new HttpError(400, `${key} must contain valid JSON.`, "INVALID_FIELD");
  }
}

export function requirePermission(form: FormData) {
  if (form.get("permission") !== "true") throw new HttpError(400, "Confirm you have permission to distribute these files.", "PERMISSION_REQUIRED");
}

export function stringField(value: FormDataEntryValue | null, field: string, optional = false, max = 500) {
  if (optional && value === null) return undefined;
  if (typeof value !== "string") throw new HttpError(400, `${field} is required.`, "INVALID_FIELD");
  return requiredString(value, field, max);
}
