import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  query: vi.fn(async (_sql: string, _values?: unknown[]) => ({ rows: [], rowCount: 1 })),
  audit: vi.fn(async () => undefined),
}));

vi.mock("./db", () => ({
  query: vi.fn(),
  transaction: (work: (tx: { query: typeof state.query }) => Promise<unknown>) => work({ query: state.query }),
}));
vi.mock("./seasons", () => ({
  getSeason: async () => ({ id: "00000000-0000-4000-8000-000000000001", start_date: "2026-01-01", end_date: "2026-01-31", timezone: "UTC" }),
}));
vi.mock("./http", async (original) => ({
  ...await original<typeof import("./http")>(),
  requireAdminWrite: async () => ({ id: "admin" }),
  recordAudit: state.audit,
}));

import { POST as generate } from "../app/api/admin/seasons/[id]/generate/route";

const seasonId = "00000000-0000-4000-8000-000000000001";

function request(body: unknown) {
  return new NextRequest(`http://localhost:3000/api/admin/seasons/${seasonId}/generate`, {
    method: "POST",
    headers: { origin: "http://localhost:3000", "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("event generation patterns", () => {
  beforeEach(() => {
    state.query.mockClear();
    state.audit.mockClear();
  });

  it("creates one event per selected monthly occurrence using the shared weekday", async () => {
    const response = await generate(request({
      weekday: 1,
      patterns: ["monthly-1", "monthly-3"],
      time: "10:00",
      durationMinutes: 60,
      name: "Music rehearsal",
    }), { params: Promise.resolve({ id: seasonId }) });

    expect(response.status).toBe(201);
    const insertCalls = state.query.mock.calls.filter(([sql]) => sql.startsWith("INSERT INTO events"));
    expect(insertCalls).toHaveLength(2);
    expect(insertCalls.map(([, values]) => (values![3] as Date).toISOString().slice(0, 10))).toEqual(["2026-01-05", "2026-01-19"]);
    expect(state.audit).toHaveBeenCalledWith("admin", "events_generated", expect.stringContaining("monthly week 1 and monthly week 3"), expect.any(Object));
  });
});