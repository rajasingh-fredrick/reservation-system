import { randomBytes } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { drizzle } from "drizzle-orm/mysql2";
import { bindMysql, initializeMysql } from "./mysql";
import { TestDatabase } from "./test-database";
import * as schema from "./schema";

describe("MySQL parameter binding", () => {
  it("binds reordered and repeated parameters without interpolating user input", () => {
    expect(bindMysql("SELECT $2,$1,$2,'$1'", ["' OR 1=1 --", "safe"])).toEqual({
      sql: "SELECT ?,?,?,'$1'", values: ["safe", "' OR 1=1 --", "safe"],
    });
  });

  it("expands list parameters and handles empty lists", () => {
    expect(bindMysql("SELECT id FROM songs WHERE id IN ($1)", [["one", "two"]])).toEqual({
      sql: "SELECT id FROM songs WHERE id IN (?,?)", values: ["one", "two"],
    });
    expect(bindMysql("SELECT id FROM songs WHERE id IN ($1)", [[]])).toEqual({
      sql: "SELECT id FROM songs WHERE id IN (NULL)", values: [],
    });
  });

  it("rejects missing values and preserves strings and Date parameters", () => {
    expect(() => bindMysql("SELECT $2", [1])).toThrow("Missing SQL parameter");
    expect(() => bindMysql("SELECT $1", [undefined])).toThrow("is undefined");
    const date = new Date("2030-01-01T10:00:00-05:00");
    expect(bindMysql("SELECT $1,$2", [date, "2030-01-01T10:00:00Z"]).values)
      .toEqual([date, "2030-01-01T10:00:00Z"]);
  });
});

describe("MySQL migrations, transactions, and authentication", () => {
  const database = new TestDatabase();
  beforeAll(async () => { await database.initialize(); });
  afterAll(async () => { await database.destroy(); });

  it("serializes concurrent migration checks without replaying applied DDL", async () => {
    await Promise.all([initializeMysql(database.pool), initializeMysql(database.pool)]);
    const result = await database.query<{ count: number }>("SELECT COUNT(*) AS count FROM schema_migrations");
    expect(result.rows[0].count).toBe(6);
  });

  it("rolls back writes when a transaction fails", async () => {
    await expect(database.transaction(async (tx) => {
      await tx.query("INSERT INTO songs(id,title) VALUES ('rollback','Rollback')");
      throw new Error("Intentional rollback");
    })).rejects.toThrow("Intentional rollback");
    expect((await database.query("SELECT id FROM songs WHERE id='rollback'")).rows).toEqual([]);
  });

  it("registers and signs in using Better Auth's MySQL adapter", async () => {
    const auth = betterAuth({
      baseURL: "http://localhost:3000",
      secret: randomBytes(32).toString("hex"),
      database: drizzleAdapter(drizzle(database.pool, { schema, mode: "default" }), {
        provider: "mysql",
        schema: { user: schema.users, session: schema.sessions, account: schema.accounts, verification: schema.verifications },
      }),
      emailAndPassword: { enabled: true },
    });
    const email = "mysql-auth@example.test";
    const password = randomBytes(24).toString("hex");
    const registered = await auth.api.signUpEmail({ body: { name: "MySQL test", email, password } });
    expect(registered.user.email).toBe(email);
    const signedIn = await auth.api.signInEmail({ body: { email, password } });
    expect(signedIn.token).toBeTruthy();
    const sessions = await database.query<{ userId: string }>('SELECT "userId" FROM session WHERE token=$1', [signedIn.token]);
    expect(sessions.rows[0].userId).toBe(registered.user.id);
  });
});
