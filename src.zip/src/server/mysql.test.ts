import { randomBytes } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { drizzle } from "drizzle-orm/mysql2";
import { bindMysql, initializeMysql } from "./mysql";
import { TestDatabase } from "./test-database";
import * as schema from "./schema";

describe("MySQL parameter binding", () => {
  it("binds reordered and repeated parameters without interpolating user input", () => {
    expect(bindMysql("SELECT $2,$1,$2,'$1'", ["' OR 1=1 --", "safe"])).toEqual({
      sql: "SELECT ?,?,?,'$1'", values: ["safe", "' OR 1=1 --", "safe"],
    });
  });

  it("expands list parameters and handles empty lists", () => {
    expect(bindMysql("SELECT id FROM songs WHERE id IN ($1)", [["one", "two"]])).toEqual({
      sql: "SELECT id FROM songs WHERE id IN (?,?)", values: ["one", "two"],
    });
    expect(bindMysql("SELECT id FROM songs WHERE id IN ($1)", [[]])).toEqual({
      sql: "SELECT id FROM songs WHERE id IN (NULL)", values: [],
    });
  });

  it("rejects missing values and preserves strings and Date parameters", () => {
    expect(() => bindMysql("SELECT $2", [1])).toThrow("Missing SQL parameter");
    expect(() => bindMysql("SELECT $1", [undefined])).toThrow("is undefined");
    const date = new Date("2030-01-01T10:00:00-05:00");
    expect(bindMysql("SELECT $1,$2", [date, "2030-01-01T10:00:00Z"]).values)
      .toEqual([date, "2030-01-01T10:00:00Z"]);
  });
});

describe("MySQL migrations, transactions, and authentication", () => {
  const database = new TestDatabase();
  beforeAll(async () => { await database.initialize(); });
  afterAll(async () => { await database.destroy(); });

  it("serializes concurrent migration checks without replaying applied DDL", async () => {
    await Promise.all([initializeMysql(database.pool), initializeMysql(database.pool)]);
    const result = await database.query<{ count: number }>("SELECT COUNT(*) AS count FROM schema_migrations");
    expect(result.rows[0].count).toBe(14);
  });

  it("repairs missing parent profiles for child owners without changing saved preferences or inventing consent", async () => {
    await database.query(
      `INSERT INTO "user"(id,name,email,"emailVerified") VALUES
       ('admin-parent','Admin Parent','admin-parent@example.test',true),
       ('existing-parent','Existing Parent','existing-parent@example.test',true),
       ('admin-only','Admin Only','admin-only@example.test',true)`,
    );
    await database.query("INSERT INTO admin_users(user_id) VALUES ('admin-parent'),('admin-only')");
    await database.query(
      `INSERT INTO parent_profiles(user_id,authorized_child_registration,privacy_accepted_at,policies_accepted_at,email_notifications_subscribed)
       VALUES ('existing-parent',true,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3),false)`,
    );
    await database.query(
      `INSERT INTO children(id,parent_user_id,full_name,birth_month,birth_year) VALUES
       ('admin-child','admin-parent','Admin Child',1,2015),
       ('admin-child-two','admin-parent','Admin Child Two',2,2016),
       ('existing-child','existing-parent','Existing Child',1,2015)`,
    );
    await database.query("DELETE FROM schema_migrations WHERE name='0014_parent_profiles_for_child_owners.sql'");
    await initializeMysql(database.pool);
    const profiles = await database.query<{
      user_id: string; email_notifications_subscribed: boolean;
      authorized_child_registration: boolean | null; privacy_accepted_at: Date | null; policies_accepted_at: Date | null;
    }>("SELECT * FROM parent_profiles WHERE user_id IN ('admin-parent','existing-parent','admin-only') ORDER BY user_id");
    expect(profiles.rows).toHaveLength(2);
    expect(profiles.rows[0]).toMatchObject({
      user_id: "admin-parent", authorized_child_registration: null, privacy_accepted_at: null, policies_accepted_at: null,
    });
    expect(Boolean(profiles.rows[0].email_notifications_subscribed)).toBe(true);
    expect(Boolean(profiles.rows[1].email_notifications_subscribed)).toBe(false);
    expect(profiles.rows[1].privacy_accepted_at).toBeInstanceOf(Date);
    expect(profiles.rows[1].policies_accepted_at).toBeInstanceOf(Date);
    await initializeMysql(database.pool);
    expect((await database.query("SELECT user_id FROM admin_users WHERE user_id='admin-parent'")).rows).toHaveLength(1);
  });

  it("subscribes new parent profiles by default", async () => {
    await database.query('INSERT INTO "user"(id,name,email,"emailVerified") VALUES ($1,$2,$3,true)',
      ["default-subscription", "New Parent", "new-parent@example.test"]);
    await database.query(
      `INSERT INTO parent_profiles(user_id,authorized_child_registration,privacy_accepted_at,policies_accepted_at)
       VALUES ($1,true,CURRENT_TIMESTAMP(3),CURRENT_TIMESTAMP(3))`,
      ["default-subscription"],
    );
    const result = await database.query<{ subscribed: boolean }>(
      "SELECT email_notifications_subscribed AS subscribed FROM parent_profiles WHERE user_id=$1",
      ["default-subscription"],
    );
    expect(Boolean(result.rows[0].subscribed)).toBe(true);
  });

  it("rolls back writes when a transaction fails", async () => {
    await expect(database.transaction(async (tx) => {
      await tx.query("INSERT INTO songs(id,title) VALUES ('rollback','Rollback')");
      throw new Error("Intentional rollback");
    })).rejects.toThrow("Intentional rollback");
    expect((await database.query("SELECT id FROM songs WHERE id='rollback'")).rows).toEqual([]);
  });

  it("registers and signs in using Better Auth's MySQL adapter", async () => {
    const auth = betterAuth({
      baseURL: "http://localhost:3000",
      secret: randomBytes(32).toString("hex"),
      database: drizzleAdapter(drizzle(database.pool, { schema, mode: "default" }), {
        provider: "mysql",
        schema: { user: schema.users, session: schema.sessions, account: schema.accounts, verification: schema.verifications },
      }),
      emailAndPassword: { enabled: true },
    });
    const email = "mysql-auth@example.test";
    const password = randomBytes(24).toString("hex");
    const registered = await auth.api.signUpEmail({ body: { name: "MySQL test", email, password } });
    expect(registered.user.email).toBe(email);
    const signedIn = await auth.api.signInEmail({ body: { email, password } });
    expect(signedIn.token).toBeTruthy();
    const sessions = await database.query<{ userId: string }>('SELECT "userId" FROM session WHERE token=$1', [signedIn.token]);
    expect(sessions.rows[0].userId).toBe(registered.user.id);
  });
});
