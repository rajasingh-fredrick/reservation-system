import { randomUUID } from "node:crypto";
import { query, transaction, type Executor } from "./db.ts";
import { sendMail } from "./mail.ts";
import { deliverChildNotification } from "./child-notifications.ts";

type Kind = "AccountSecurity" | "ParentTransactional" | "MinistryMessage";
type Status = "Pending" | "Sending" | "Sent" | "Failed" | "Preview" | "Skipped";
type Email = {
  userId: string; kind: Kind; subject: string; text: string;
  expectedEmail?: string; expiresAt?: Date;
};
type Task = {
  id: string; user_id: string; kind: Kind; subject: string; body: string | null;
  expected_email: string | null; expires_at: Date | null; status: Status;
  attempts: number; next_attempt_at: Date;
};

export async function queueEmail(tx: Executor, email: Email) {
  if (email.kind === "AccountSecurity" && (!email.expectedEmail || !email.expiresAt)) {
    throw new Error("Account security emails require a bound address and expiration.");
  }
  const id = randomUUID();
  await tx.query(
    `INSERT INTO email_notifications (id,user_id,kind,expected_email,subject,body,expires_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [id, email.userId, email.kind, email.expectedEmail ?? null, email.subject, email.text, email.expiresAt ?? null],
  );
  return id;
}

export async function deliverQueuedEmail(id: string, now = new Date()): Promise<Status> {
  const claimed = await transaction<
    { status: Status } | { to: string; subject: string; text: string; attempts: number }
  >(async (tx) => {
    const task = (await tx.query<Task>("SELECT * FROM email_notifications WHERE id=$1 FOR UPDATE", [id])).rows[0];
    if (!task) throw new Error("Email notification not found.");
    if (!["Pending", "Failed"].includes(task.status) || task.next_attempt_at > now) return { status: task.status };
    const recipient = (await tx.query<{
      email: string; email_verified: boolean; parent_registered: boolean; subscribed: boolean;
    }>(
      `SELECT u.email,u."emailVerified" AS email_verified,
         (pp.user_id IS NOT NULL) AS parent_registered,pp.email_notifications_subscribed AS subscribed
       FROM "user" u LEFT JOIN parent_profiles pp ON pp.user_id=u.id WHERE u.id=$1`, [task.user_id],
    )).rows[0];
    const eligible = recipient && (!task.expected_email || recipient.email === task.expected_email)
      && (task.kind === "AccountSecurity" || (recipient.parent_registered && recipient.email_verified))
      && (task.kind !== "MinistryMessage" || recipient.subscribed)
      && (!task.expires_at || task.expires_at > now);
    if (!eligible) {
      await tx.query("UPDATE email_notifications SET status='Skipped',body=NULL WHERE id=$1", [id]);
      return { status: "Skipped" as const };
    }
    if (task.body === null) throw new Error("Pending email notification has no message.");
    await tx.query(
      "UPDATE email_notifications SET status='Sending',attempts=attempts+1,last_attempt_at=$1 WHERE id=$2", [now, id],
    );
    return { to: recipient.email, subject: task.subject, text: task.body, attempts: task.attempts + 1 };
  });
  if ("status" in claimed) return claimed.status;
  try {
    await sendMail(claimed.to, claimed.subject, claimed.text);
  } catch {
    console.error("Queued email delivery failed", { notificationId: id });
    const next = new Date(Date.now() + Math.min(60, 2 ** Math.min(claimed.attempts - 1, 6)) * 60_000);
    await query(
      "UPDATE email_notifications SET status='Failed',next_attempt_at=$1 WHERE id=$2 AND status='Sending'", [next, id],
    );
    return "Failed";
  }
  const status = process.env.NODE_ENV === "production" ? "Sent" : "Preview";
  await query(
    "UPDATE email_notifications SET status=$1,sent_at=$2,body=NULL WHERE id=$3 AND status='Sending'",
    [status, status === "Sent" ? new Date() : null, id],
  );
  return status;
}

export async function processImmediateNotifications(now = new Date()) {
  const totals = { Sent: 0, Preview: 0, Failed: 0, Skipped: 0, Sending: 0, Pending: 0 };
  const tasks = await query<{ id: string }>(
    `SELECT id FROM email_notifications WHERE status IN ('Pending','Failed') AND next_attempt_at <= $1
     ORDER BY CASE WHEN kind='AccountSecurity' THEN 0 ELSE 1 END,created_at,id LIMIT 100`, [now],
  );
  for (const task of tasks.rows) totals[await deliverQueuedEmail(task.id)]++;
  const children = await query<{ id: string }>(
    `SELECT id FROM child_profile_notifications WHERE status='Pending'
       OR (status='Failed' AND (last_attempt_at IS NULL OR last_attempt_at <= DATE_SUB($1,INTERVAL 1 HOUR)))
     ORDER BY created_at,id LIMIT 100`, [now],
  );
  for (const task of children.rows) totals[await deliverChildNotification(task.id)]++;
  return totals;
}
