import type { AdminData, EventReservation, EventSong, MinistryEvent, Season, Sheet, Song, Usage } from "../lib/contracts";
import { query } from "./db";
import { iso, mapUsage, sheetAsContract, usageForSheet, usageForSong } from "./library";

type AnyRow = Record<string, unknown>;
const str = (row: AnyRow, key: string) => String(row[key] ?? "");
const bool = (row: AnyRow, key: string) => Boolean(row[key]);

export async function adminData(): Promise<AdminData> {
  const [songsResult, seasonsResult, eventsResult, eventSongsResult, requirementsResult, eventSheetsResult, auditResult, reservationsResult] = await Promise.all([
    query<AnyRow>("SELECT * FROM songs ORDER BY title"),
    query<AnyRow>("SELECT *,start_date::text AS start_date_text,end_date::text AS end_date_text FROM seasons ORDER BY start_date DESC, name"),
    query<AnyRow>("SELECT * FROM events ORDER BY starts_at"),
    query<AnyRow>(`SELECT es.*,COALESCE(ss.allow_extra,false) AS allow_extra FROM event_songs es
      JOIN events e ON e.id=es.event_id
      LEFT JOIN season_song_settings ss ON ss.season_id=e.season_id AND ss.song_id=es.song_id
      ORDER BY es.event_id, es.position`),
    query<AnyRow>("SELECT * FROM event_requirements"),
    query<AnyRow>(`SELECT x.event_song_id, sh.id, sh.song_id, sh.label, sh.instrument, sh.arrangement, sh.current_version,
      sh.archived, v.file_name, v.size_bytes, sh.created_at, x.selected_version
      FROM event_sheets x JOIN sheets sh ON sh.id = x.sheet_id
      JOIN sheet_versions v ON v.sheet_id = x.sheet_id AND v.version = x.selected_version`),
    query<AnyRow>(`SELECT a.id, a.action, a.description, u.name AS actor_name, a.created_at
      FROM audit_log a JOIN "user" u ON u.id = a.actor_id ORDER BY a.created_at DESC LIMIT 100`),
    query<EventReservation & { eventId: string }>(`SELECT r.id,r.event_id AS "eventId",
      c.full_name AS "childName",so.title AS "songTitle",r.instrument,r.spot_number AS "spotNumber"
      FROM reservations r JOIN children c ON c.id=r.child_id
      JOIN event_songs es ON es.id=r.event_song_id JOIN songs so ON so.id=es.song_id
      WHERE r.status='Confirmed'
      ORDER BY es.position,r.instrument,r.spot_number,c.full_name,r.id`),
  ]);
  const songs = await Promise.all(songsResult.rows.map(async (song): Promise<Song> => {
    const sheetRows = await query<AnyRow>("SELECT * FROM sheets WHERE song_id=$1 ORDER BY created_at,id", [song.id]);
    const usages = (await usageForSong(str(song, "id"))).map(mapUsage);
    const sheets = await Promise.all(sheetRows.rows.map(async (sheet) => {
      const joined = await query<AnyRow>(
        `SELECT sh.id,sh.song_id,sh.label,sh.instrument,sh.arrangement,sh.current_version,sh.archived,
          v.file_name,v.size_bytes,sh.created_at,v.storage_key
         FROM sheets sh JOIN sheet_versions v ON v.sheet_id=sh.id AND v.version=sh.current_version WHERE sh.id=$1`,
        [sheet.id],
      );
      const sheetUsage = (await usageForSheet(str(sheet, "id"))).map(mapUsage);
      return sheetAsContract(joined.rows[0] as never, sheetUsage);
    }));
    return {
      id: str(song, "id"), title: str(song, "title"), composer: str(song, "composer"), notes: str(song, "notes"),
      links: song.links as string[],
      archived: bool(song, "archived"), createdAt: iso(song.created_at), updatedAt: iso(song.updated_at), sheets, usages,
    };
  }));
  const sheetsByEventSong = new Map<string, (Sheet & { selectedVersion: number })[]>();
  for (const row of eventSheetsResult.rows) {
    const current = await query<AnyRow>(
      `SELECT sh.id,sh.song_id,sh.label,sh.instrument,sh.arrangement,sh.current_version,sh.archived,
        v.file_name,v.size_bytes,sh.created_at,v.storage_key
       FROM sheets sh JOIN sheet_versions v ON v.sheet_id=sh.id AND v.version=$2 WHERE sh.id=$1`,
      [row.id, row.selected_version],
    );
    const usage = (await usageForSheet(str(row, "id"))).map(mapUsage);
    const list = sheetsByEventSong.get(str(row, "event_song_id")) || [];
    list.push({ ...sheetAsContract(current.rows[0] as never, usage), selectedVersion: Number(row.selected_version) });
    sheetsByEventSong.set(str(row, "event_song_id"), list);
  }
  const requirementsBySong = new Map<string, { instrument: string; capacity: number }[]>();
  for (const row of requirementsResult.rows) {
    const list = requirementsBySong.get(str(row, "event_song_id")) || [];
    list.push({ instrument: str(row, "instrument"), capacity: Number(row.capacity) });
    requirementsBySong.set(str(row, "event_song_id"), list);
  }
  const songMap = new Map(songs.map((song) => [song.id, song]));
  const eventSongsByEvent = new Map<string, EventSong[]>();
  for (const row of eventSongsResult.rows) {
    const song = songMap.get(str(row, "song_id"));
    if (!song) continue;
    const list = eventSongsByEvent.get(str(row, "event_id")) || [];
    list.push({
      id: str(row, "id"), songId: song.id, title: song.title, notes: str(row, "notes"), position: Number(row.position),
      allowExtra: bool(row, "allow_extra"),
      requirements: (requirementsBySong.get(str(row, "id")) || []) as EventSong["requirements"],
      sheets: sheetsByEventSong.get(str(row, "id")) || [],
    });
    eventSongsByEvent.set(str(row, "event_id"), list);
  }
  const reservationsByEvent = new Map<string, EventReservation[]>();
  for (const { eventId, ...reservation } of reservationsResult.rows) {
    const list = reservationsByEvent.get(eventId) || [];
    list.push(reservation);
    reservationsByEvent.set(eventId, list);
  }
  const eventsBySeason = new Map<string, MinistryEvent[]>();
  for (const row of eventsResult.rows) {
    const event: MinistryEvent = {
      id: str(row, "id"), seasonId: str(row, "season_id"), name: str(row, "name"),
      startsAt: iso(row.starts_at), endsAt: iso(row.ends_at), location: str(row, "location"),
      songs: eventSongsByEvent.get(str(row, "id")) || [],
      reservations: reservationsByEvent.get(str(row, "id")) || [],
    };
    const list = eventsBySeason.get(event.seasonId) || [];
    list.push(event);
    eventsBySeason.set(event.seasonId, list);
  }
  const seasons: Season[] = seasonsResult.rows.map((row) => ({
    id: str(row, "id"), name: str(row, "name"), description: str(row, "description"),
    startDate: str(row, "start_date_text").slice(0, 10), endDate: str(row, "end_date_text").slice(0, 10),
    registrationOpensAt: iso(row.registration_opens_at), registrationClosesAt: iso(row.registration_closes_at),
    timezone: str(row, "timezone"), location: str(row, "location"), instructions: str(row, "instructions"),
    cancellationHours: Number(row.cancellation_hours), status: str(row, "status") as Season["status"],
    events: eventsBySeason.get(str(row, "id")) || [],
  }));
  const audit = auditResult.rows.map((row) => ({
    id: str(row, "id"), action: str(row, "action"), description: str(row, "description"),
    actorName: str(row, "actor_name"), createdAt: iso(row.created_at),
  }));
  return { songs, seasons, audit };
}
