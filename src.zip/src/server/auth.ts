import { randomBytes } from "node:crypto";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { users, sessions, accounts, verifications } from "./schema";
import { db } from "./db";
import { sendMail } from "./mail";

const authSecret = process.env.BETTER_AUTH_SECRET;
if (process.env.NODE_ENV === "production" && (!authSecret || authSecret.length < 32)) {
  throw new Error("Set BETTER_AUTH_SECRET to a random value of at least 32 characters.");
}
const baseURL = process.env.APP_URL || "http://localhost:3000";
const trustedOrigins = [baseURL];
if (process.env.NODE_ENV !== "production") {
  const localOrigin = new URL(baseURL);
  if (localOrigin.hostname === "localhost") localOrigin.hostname = "127.0.0.1";
  else if (localOrigin.hostname === "127.0.0.1") localOrigin.hostname = "localhost";
  if (localOrigin.origin !== baseURL) trustedOrigins.push(localOrigin.origin);
}

function createAuth() {
  return betterAuth({
      appName: "Harmony Ministry",
      baseURL,
      secret: authSecret || randomBytes(32).toString("hex"),
      database: drizzleAdapter(db.drizzle, {
        provider: "pg",
        schema: { user: users, session: sessions, account: accounts, verification: verifications },
      }),
      emailAndPassword: {
        enabled: true,
        requireEmailVerification: true,
        disableSignUp: true,
        sendResetPassword: async ({ user, url }) => {
          await sendMail(user.email, "Reset your password", `Use this one-time link to reset your password:\n${url}`);
        },
      },
      emailVerification: {
        sendOnSignUp: false,
        sendVerificationEmail: async ({ user, url }) => {
          await sendMail(user.email, "Verify your email", `Verify your email address using this one-time link:\n${url}`);
        },
      },
      rateLimit: {
        enabled: true,
        window: 60,
        max: 10,
        storage: "memory",
      },
      trustedOrigins,
  });
}

let authInstance: ReturnType<typeof createAuth> | undefined;

export function getAuth(): ReturnType<typeof createAuth> {
  return authInstance ??= createAuth();
}
