import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({ query: vi.fn(), role: vi.fn(), audit: vi.fn() }));
vi.mock("./db", () => ({
  transaction: async (work: (tx: { query: typeof state.query }) => Promise<unknown>) => work({ query: state.query }),
}));
vi.mock("./http", async (original) => ({
  ...await original<typeof import("./http")>(),
  requireAdminWrite: async () => ({ id: "admin" }),
  recordAudit: state.audit,
}));
vi.mock("./seasons", () => ({
  getEvent: async () => ({ season_id: "season", name: "Sunday", season_status: "Published" }),
}));
vi.mock("./season-songs", () => ({ setSeasonSongRole: state.role }));
vi.mock("./library", () => ({ addEventSelection: vi.fn(), currentSheet: vi.fn() }));
import { PATCH } from "../app/api/admin/event-songs/[id]/route";

const id = "00000000-0000-4000-8000-000000000001";
function patch(body: unknown) {
  return PATCH(new NextRequest(`http://localhost:3000/api/admin/event-songs/${id}`, {
    method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  }), { params: Promise.resolve({ id }) });
}
beforeEach(() => {
  state.query.mockReset().mockResolvedValue({ rows: [{ event_id: "event", song_id: "song", title: "Test" }] });
  state.role.mockReset().mockResolvedValue(undefined);
  state.audit.mockReset().mockResolvedValue(undefined);
});
describe("editing a song's season role through event setup", () => {
  it.each(["Closing Song", null])("saves %s using the existing season-scoped helper", async (songRole) => {
    expect((await patch({ songRole })).status).toBe(200);
    expect(state.role).toHaveBeenCalledWith({ query: state.query }, "season", "song", songRole, "admin");
  });

  it("rejects invalid roles without saving", async () => {
    expect((await patch({ songRole: "Invalid" })).status).toBe(400);
    expect(state.role).not.toHaveBeenCalled();
  });

  it("preserves published setup impact confirmation for combined edits", async () => {
    expect((await patch({ notes: "Verse two", songRole: "Special Song" })).status).toBe(409);
    expect(state.role).not.toHaveBeenCalled();
    expect((await patch({ notes: "Verse two", songRole: "Special Song", confirmImpact: true })).status).toBe(200);
    expect(state.role).toHaveBeenCalledOnce();
    expect(state.query).toHaveBeenCalledWith("UPDATE event_songs SET notes=$1 WHERE id=$2", ["Verse two", id]);
  });

  it("leaves the role alone when editing other fields", async () => {
    expect((await patch({ notes: "Verse two", confirmImpact: true })).status).toBe(200);
    expect(state.role).not.toHaveBeenCalled();
  });
});
