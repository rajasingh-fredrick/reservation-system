import { TestDatabase } from "./test-database";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { addEvent } from "./seasons";
import type { Executor } from "./db";
import { eventCreateSchema, requirementsSchema, songLinksSchema } from "./validation";

const db = new TestDatabase();

async function seedReservationGraph() {
  await db.exec(`
    INSERT INTO "user" (id,name,email) VALUES
      ('parent-1','Parent One','one@example.test'),
      ('parent-2','Parent Two','two@example.test');
    INSERT INTO children (id,parent_user_id,full_name,birth_month,birth_year) VALUES
      ('child-1','parent-1','Child One',1,2015),
      ('child-2','parent-2','Child Two',2,2016);
    INSERT INTO songs (id,title) VALUES ('song-1','Song One'),('song-2','Song Two');
    INSERT INTO seasons (id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status) VALUES
      ('season-1','Season One','2030-01-01','2030-12-31','2029-01-01 00:00:00','2030-12-31 00:00:00','UTC','Published'),
      ('season-2','Season Two','2030-01-01','2030-12-31','2029-01-01 00:00:00','2030-12-31 00:00:00','UTC','Published');
    INSERT INTO events (id,season_id,name,starts_at,ends_at) VALUES
      ('event-1','season-1','Event One','2030-02-01 10:00:00','2030-02-01 11:00:00'),
      ('event-2','season-1','Event Two','2030-02-08 10:00:00','2030-02-08 11:00:00'),
      ('event-3','season-2','Event Three','2030-02-01 10:00:00','2030-02-01 11:00:00');
    INSERT INTO event_songs (id,event_id,song_id,position) VALUES
      ('event-song-1','event-1','song-1',1),
      ('event-song-2','event-2','song-2',1),
      ('event-song-3','event-3','song-1',1);
    INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES
      ('event-song-1','Violin',1),
      ('event-song-2','Violin',1),
      ('event-song-3','Violin',1);
  `);
}

async function reserve(id: string, childId: string, seasonId: string, eventId: string, eventSongId: string, spot = 1, bookingGroup = "regular") {
  await db.query(
    `INSERT INTO reservations (id,child_id,season_id,event_id,event_song_id,instrument,spot_number,booking_group)
     VALUES ($1,$2,$3,$4,$5,'Violin',$6,$7)`,
    [id, childId, seasonId, eventId, eventSongId, spot, bookingGroup],
  );
}

beforeAll(async () => {
  await db.initialize();
});

beforeEach(async () => {
  await db.exec('RESET_TEST_DATABASE');
  await seedReservationGraph();
});

afterAll(async () => {
  await db.destroy();
});

describe("reservation database constraints", () => {
  it("rejects two confirmed reservations for the same instrument spot", async () => {
    await reserve("reservation-1", "child-1", "season-1", "event-1", "event-song-1");
    await expect(reserve("reservation-2", "child-2", "season-1", "event-1", "event-song-1"))
      .rejects.toMatchObject({ code: "ER_DUP_ENTRY" });
  });

  it("allows one confirmed reservation per child in each distinct season, but not twice in one season", async () => {
    await reserve("reservation-1", "child-1", "season-1", "event-1", "event-song-1");
    await expect(reserve("reservation-2", "child-1", "season-1", "event-2", "event-song-2"))
      .rejects.toMatchObject({ code: "ER_DUP_ENTRY" });
    await expect(reserve("reservation-3", "child-1", "season-2", "event-3", "event-song-3"))
      .resolves.toBeUndefined();
  });

  it("keeps a cancellation record and makes its spot available again", async () => {
    await reserve("reservation-1", "child-1", "season-1", "event-1", "event-song-1");
    await db.query("UPDATE reservations SET status='Cancelled',cancelled_at=now() WHERE id=$1", ["reservation-1"]);
    await reserve("reservation-2", "child-2", "season-1", "event-1", "event-song-1");
    const result = await db.query<{ status: string }>("SELECT status FROM reservations ORDER BY id");
    expect(result.rows.map((row) => row.status)).toEqual(["Cancelled", "Confirmed"]);
  });

  it("enforces independent regular and per-extra-song allowances in the database", async () => {
    await db.exec(`
      INSERT INTO event_songs (id,event_id,song_id,position) VALUES ('event-song-repeat','event-1','song-2',2);
      INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES ('event-song-repeat','Violin',1);
    `);
    await reserve("reservation-1", "child-1", "season-1", "event-1", "event-song-1");
    await reserve("reservation-2", "child-1", "season-1", "event-2", "event-song-2", 1, "song:song-2");
    await expect(reserve("reservation-3", "child-1", "season-1", "event-1", "event-song-repeat", 1, "song:song-2"))
      .rejects.toMatchObject({ code: "ER_DUP_ENTRY", sqlMessage: expect.stringContaining("reservations_one_child_spot_per_season") });
    await expect(reserve("reservation-4", "child-2", "season-1", "event-2", "event-song-2", 1, "song:song-2"))
      .rejects.toMatchObject({ code: "ER_DUP_ENTRY", sqlMessage: expect.stringContaining("reservations_one_active_spot") });
  });

  it("preserves a requirement referenced by cancelled reservation history and stores review flags", async () => {
    await reserve("reservation-1", "child-1", "season-1", "event-1", "event-song-1");
    await db.query(
      "UPDATE reservations SET review_required=true,review_reason=$1 WHERE id=$2",
      ["Child eligibility changed.", "reservation-1"],
    );
    await db.query("UPDATE reservations SET status='Cancelled',cancelled_at=now() WHERE id=$1", ["reservation-1"]);
    await expect(db.query("DELETE FROM event_requirements WHERE event_song_id=$1 AND instrument='Violin'", ["event-song-1"]))
      .rejects.toMatchObject({ code: "ER_ROW_IS_REFERENCED_2" });
    const result = await db.query<{ review_required: boolean; review_reason: string }>(
      "SELECT review_required,review_reason FROM reservations WHERE id=$1",
      ["reservation-1"],
    );
    expect(result.rows[0]).toEqual({ review_required: true, review_reason: "Child eligibility changed." });
  });
});

describe("event creation with library songs", () => {
  const executor: Executor = {
    async query<T>(text: string, params: unknown[] = []) {
      const result = await db.query<T>(text, params);
      return result;
    },
  };
  const eventInput = {
    name: "Multi-song event", startsAt: "2030-03-01T10:00:00Z", endsAt: "2030-03-01T11:00:00Z", location: "Church",
  };

  async function seedSheets() {
    await db.exec(`
      INSERT INTO sheets (id,song_id,label,current_version) VALUES
        ('sheet-1','song-1','Violin part',2),('sheet-2','song-2','Piano part',1);
      INSERT INTO sheet_versions (sheet_id,version,file_name,storage_key,size_bytes) VALUES
        ('sheet-1',2,'violin.pdf','violin.pdf',100),('sheet-2',1,'piano.pdf','piano.pdf',100);
    `);
  }

  it("saves multiple songs in order with independent notes, sheets, versions, and capacities", async () => {
    await seedSheets();
    const id = await db.transaction(async (tx) => addEvent({
      async query<T>(text: string, params: unknown[] = []) {
        const result = await tx.query<T>(text, params);
        return result;
      },
    }, "season-1", {
      ...eventInput,
      songs: [
        { songId: "song-1", sheetIds: ["sheet-1"], notes: "Verse one", requirements: [{ instrument: "Violin", capacity: 2 }, { instrument: "Guitar", capacity: 1 }] },
        { songId: "song-2", sheetIds: ["sheet-2"], notes: "Final chorus", requirements: [{ instrument: "Piano", capacity: 1 }] },
      ],
    }));
    const songs = await db.query<{ song_id: string; notes: string; position: number; selected_version: number }>(
      "SELECT es.song_id,es.notes,es.position,x.selected_version FROM event_songs es JOIN event_sheets x ON x.event_song_id=es.id WHERE es.event_id=$1 ORDER BY es.position", [id],
    );
    expect(songs.rows).toEqual([
      { song_id: "song-1", notes: "Verse one", position: 1, selected_version: 2 },
      { song_id: "song-2", notes: "Final chorus", position: 2, selected_version: 1 },
    ]);
    const requirements = await db.query("SELECT instrument,capacity FROM event_requirements WHERE event_song_id IN (SELECT id FROM event_songs WHERE event_id=$1) ORDER BY instrument", [id]);
    expect(requirements.rows).toEqual([{ instrument: "Guitar", capacity: 1 }, { instrument: "Piano", capacity: 1 }, { instrument: "Violin", capacity: 2 }]);
    expect((await db.query("SELECT id FROM songs")).rows).toHaveLength(2);
  });

  it("rolls back the entire event when a later song selects a sheet belonging to another song", async () => {
    await seedSheets();
    await expect(db.transaction(async (tx) => addEvent({
      async query<T>(text: string, params: unknown[] = []) {
        const result = await tx.query<T>(text, params);
        return result;
      },
    }, "season-1", {
      ...eventInput,
      songs: [
        { songId: "song-1", sheetIds: ["sheet-1"], notes: "", requirements: [] },
        { songId: "song-2", sheetIds: ["sheet-1"], notes: "", requirements: [] },
      ],
    }))).rejects.toMatchObject({ code: "INVALID_SHEET_SELECTION" });
    expect((await db.query("SELECT id FROM events WHERE name=$1", [eventInput.name])).rows).toEqual([]);
    expect((await db.query("SELECT id FROM event_songs")).rows).toHaveLength(3);
  });

  it("rejects archived library songs and event dates outside the season", async () => {
    await db.query("UPDATE songs SET archived=true WHERE id='song-1'");
    await expect(db.transaction(async (tx) => addEvent({
      async query<T>(text: string, params: unknown[] = []) {
        const result = await tx.query<T>(text, params);
        return result;
      },
    }, "season-1", { ...eventInput, songs: [{ songId: "song-1", sheetIds: [], notes: "", requirements: [] }] })))
      .rejects.toMatchObject({ code: "SONG_NOT_FOUND" });
    await expect(addEvent(executor, "season-1", { ...eventInput, startsAt: "2031-03-01T10:00:00Z" }))
      .rejects.toMatchObject({ code: "EVENT_OUTSIDE_SEASON" });
  });

  it("validates song entries, unique instruments, positive capacities, and safe links", () => {
    expect(eventCreateSchema.safeParse({ ...eventInput, songs: [] }).success).toBe(false);
    expect(eventCreateSchema.safeParse({ ...eventInput, songs: [{ songId: "invalid", sheetIds: [], requirements: [] }] }).success).toBe(false);
    expect(requirementsSchema.safeParse([{ instrument: "Piano", capacity: 0 }]).success).toBe(false);
    expect(requirementsSchema.safeParse([{ instrument: "Piano", capacity: 1 }, { instrument: "Piano", capacity: 2 }]).success).toBe(false);
    expect(songLinksSchema.safeParse(["https://example.test/music", "http://example.test/practice"]).success).toBe(true);
    expect(songLinksSchema.safeParse(["javascript:alert(1)"]).success).toBe(false);
    expect(songLinksSchema.safeParse(["not a link"]).success).toBe(false);
  });

  it("persists multiple song links without changing song notes", async () => {
    const links = ["https://example.test/score", "https://example.test/practice"];
    await db.query("UPDATE songs SET links=$1,notes='Shared notes' WHERE id='song-1'", [JSON.stringify(links)]);
    expect((await db.query("SELECT links,notes FROM songs WHERE id='song-1'")).rows[0]).toEqual({ links, notes: "Shared notes" });
  });
});