import { spawnSync } from "node:child_process";
import path from "node:path";
import { describe, expect, it } from "vitest";

const script = path.join(process.cwd(), "scripts", "send-notifications.ts");

describe("standalone hourly notification command", () => {
  it("runs its help entry point without connecting to a database", () => {
    const result = spawnSync(process.execPath, ["--experimental-strip-types", script, "--help"], {
      encoding: "utf8", timeout: 20000,
    });

    describe("continuous immediate notification worker", () => {
      const worker = path.join(process.cwd(), "scripts", "notification-worker.ts");
      it("provides help without connecting to a database", () => {
        const result = spawnSync(process.execPath, ["--experimental-strip-types", worker, "--help"], {
          encoding: "utf8", timeout: 20000,
        });
        expect(result.error).toBeUndefined();
        expect(result.status).toBe(0);
        expect(result.stdout).toContain("Polls immediate email queues every second");
      });

      it("exits nonzero on unavailable database without claiming worker readiness", () => {
        const result = spawnSync(process.execPath, ["--experimental-strip-types", worker, "--once"], {
          encoding: "utf8", timeout: 20000,
          env: {
            ...process.env, NODE_ENV: "test", DATABASE_URL: "",
            MYSQL_HOST: "127.0.0.1", MYSQL_PORT: "1", MYSQL_USER: "notification-cli-test",
            MYSQL_PASSWORD: "", MYSQL_DATABASE: "harmony_cli_test",
          },
        });
        expect(result.error).toBeUndefined();
        expect(result.status).toBe(1);
        expect(result.stderr).toContain("Immediate notification worker stopped");
        expect(result.stdout).not.toContain("worker ready");
      });
    });
    expect(result.error).toBeUndefined();
    expect(result.status).toBe(0);
    expect(result.stdout).toContain("Schedule hourly");
  });

  it("reports an unavailable database and exits nonzero rather than silently succeeding", () => {
    const result = spawnSync(process.execPath, ["--experimental-strip-types", script], {
      encoding: "utf8", timeout: 20000,
      env: {
        ...process.env, NODE_ENV: "test", DATABASE_URL: "",
        MYSQL_HOST: "127.0.0.1", MYSQL_PORT: "1", MYSQL_USER: "notification-cli-test",
        MYSQL_PASSWORD: "", MYSQL_DATABASE: "harmony_cli_test",
      },
    });
    expect(result.error).toBeUndefined();
    expect(result.status).toBe(1);
    expect(result.stderr).toContain("Notification job failed");
    expect(result.stdout).not.toContain("Notification job completed");
  });
});
