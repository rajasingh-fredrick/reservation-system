import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({ query: vi.fn(), queue: vi.fn() }));
vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  transaction: (work: (tx: { query: typeof state.query }) => Promise<unknown>) => work({ query: state.query }),
}));
vi.mock("./email-queue", () => ({ queueEmail: state.queue }));
vi.mock("./season-songs", () => ({ songBookingGroup: async () => "regular" }));
vi.mock("./http", async (original) => ({
  ...await original<typeof import("./http")>(),
  requireVerifiedUser: async () => ({ id: "parent", email: "parent@example.test" }),
  requireAdminWrite: async () => ({ id: "admin" }),
  recordAudit: vi.fn(),
}));
import { POST as book } from "../app/api/parent/reservations/route";
import { DELETE as cancel } from "../app/api/parent/reservations/[id]/route";
import { PATCH as review } from "../app/api/admin/reservations/review/[id]/route";

const id = "11111111-1111-4111-8111-111111111111";
function request(method: string, body?: unknown) {
  return new NextRequest("http://localhost:3000/api/parent/reservations", {
    method, headers: { origin: "http://localhost:3000", "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}
beforeEach(() => {
  state.queue.mockReset().mockResolvedValue("queued");
  state.query.mockReset().mockImplementation(async (sql: string) => {
    if (sql.startsWith("SELECT id,full_name")) return { rows: [{ id, full_name: "Anna", status: "Approved" }] };
    if (sql.includes("FROM child_instruments")) return { rows: [{ instrument: "Piano" }] };
    if (sql.includes("FROM event_songs es")) return { rows: [{
      season_id: id, season_name: "Winter", status: "Published", event_id: id, event_name: "Sunday",
      registration_opens_at: "2020-01-01", registration_closes_at: "2099-12-31",
      starts_at: "2099-12-31T10:00:00Z", ends_at: "2099-12-31T11:00:00Z", capacity: 2, reserved: 0, song_id: id,
    }] };
    if (sql.includes("SELECT r.id,c.full_name")) return { rows: [{ id, child_name: "Anna", instrument: "Piano" }] };
    if (sql.includes("SELECT c.parent_user_id")) return { rows: [{
      parent_user_id: "parent", child_name: "Anna", season_name: "Winter", event_name: "Sunday", instrument: "Piano",
    }] };
    return { rows: [], rowCount: 1 };
  });
});

describe("transactional reservation email producers", () => {
  it("queues booking confirmation inside the booking transaction", async () => {
    const response = await book(request("POST", {
      childId: id, eventId: id, eventSongId: id, instrument: "Piano", spotNumber: 1,
    }));
    expect(response.status).toBe(201);
    expect(await response.json()).toMatchObject({ notificationQueued: true });
    expect(state.queue).toHaveBeenCalledWith({ query: state.query }, {
      userId: "parent", kind: "ParentTransactional", subject: "Music ministry reservation confirmed",
      text: "Reservation confirmed for Anna: Winter, Sunday, Piano.",
    });
  });

  it("queues cancellation confirmation inside the cancellation transaction", async () => {
    expect((await cancel(request("DELETE"), { params: Promise.resolve({ id }) })).status).toBe(200);
    expect(state.queue).toHaveBeenCalledWith({ query: state.query }, {
      userId: "parent", kind: "ParentTransactional", subject: "Music ministry reservation cancelled",
      text: "The reservation for Anna (Piano) has been cancelled.",
    });
  });

  it.each(["keep", "cancel"])("queues the coordinator's %s decision in its transaction", async (action) => {
    const response = await review(request("PATCH", { action, explanation: "Event changed." }), { params: Promise.resolve({ id }) });
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ notificationQueued: true });
    expect(state.queue).toHaveBeenCalledWith({ query: state.query }, expect.objectContaining({
      userId: "parent", kind: "ParentTransactional",
      subject: action === "keep" ? "Reservation review complete" : "Reservation cancelled by the coordinator",
      text: expect.stringContaining("Anna"),
    }));
  });

  it("fails rather than claiming success when cancellation cannot persist email work", async () => {
    state.queue.mockRejectedValue(new Error("Queue unavailable"));
    const log = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      expect((await cancel(request("DELETE"), { params: Promise.resolve({ id }) })).status).toBe(500);
    } finally { log.mockRestore(); }
  });
});
