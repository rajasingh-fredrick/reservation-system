import { randomUUID } from "node:crypto";
import { mkdir, mkdtemp, readdir, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { TestDatabase } from "./test-database";
import { NextRequest } from "next/server";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import type { AdminData } from "../lib/contracts";
import { MAX_PDF_BYTES } from "../lib/contracts";
import { formatDateTime, formatTime } from "../lib/client";
import type { Executor } from "./db";

const state = vi.hoisted(() => ({
  database: null as TestDatabase | null,
  uploadDirectory: "",
  userId: "admin-one" as string | null,
}));

function executor(client: Pick<TestDatabase, "query">): Executor {
  return {
    async query<T>(text: string, params: unknown[] = []) {
      const result = await client.query<T>(text, params);
      return result;
    },
  };
}

vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  get uploadDirectory() { return state.uploadDirectory; },
  query: <T>(text: string, params?: unknown[]) => executor(state.database!).query<T>(text, params),
  transaction: <T>(work: (tx: Executor) => Promise<T>) => state.database!.transaction((tx) => work(executor(tx))),
}));

vi.mock("./auth", () => ({
  getAuth: () => ({
    api: {
      getSession: async () => state.userId ? { user: { id: state.userId, name: "Test user", email: `${state.userId}@example.test` } } : null,
    },
  }),
}));

vi.mock("./mail", () => ({ sendMail: vi.fn(async () => undefined) }));

import { GET as getLibrary } from "../app/api/admin/data/route";
import { POST as createSong } from "../app/api/admin/songs/route";
import { DELETE as deleteSong, PATCH as updateSong } from "../app/api/admin/songs/[id]/route";
import { POST as addSheets } from "../app/api/admin/songs/[id]/sheets/route";
import { DELETE as deleteSheet, PATCH as updateSheet } from "../app/api/admin/sheets/[id]/route";
import { GET as downloadSheet } from "../app/api/admin/sheets/[id]/download/route";
import { GET as parentSeasons } from "../app/api/parent/seasons/route";
import { GET as parentSheet } from "../app/api/sheets/[id]/download/route";
import { GET as parentReservations, POST as parentBook } from "../app/api/parent/reservations/route";
import { DELETE as parentCancel } from "../app/api/parent/reservations/[id]/route";
import { PATCH as setExtraSong } from "../app/api/admin/seasons/[id]/songs/[songId]/route";
import { POST as copyEvent } from "../app/api/admin/events/[id]/copy/route";

const origin = "http://localhost:3000";
const pdf = "%PDF-1.4\nLibrary test sheet\n%%EOF";
const links = ["https://example.test/score", "https://example.test/practice"];
let directory = "";
let databasePath = "";

function context(id: string) {
  return { params: Promise.resolve({ id }) };
}

function request(url: string, method = "GET", body?: FormData | Record<string, unknown>, requestOrigin = origin) {
  const headers: Record<string, string> = { origin: requestOrigin };
  if (body && !(body instanceof FormData)) headers["content-type"] = "application/json";
  return new NextRequest(`${origin}${url}`, { method, headers, body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined });
}

function songForm() {
  const form = new FormData();
  form.set("title", "Shared library song");
  form.set("notes", "Shared song notes");
  form.set("links", JSON.stringify(links));
  form.set("permission", "true");
  form.append("files", new File([pdf], "violin.pdf", { type: "application/pdf" }));
  form.append("files", new File([pdf], "piano.pdf", { type: "application/pdf" }));
  form.set("sheetLabels", JSON.stringify(["Violin part", "Piano part"]));
  form.set("sheetInstruments", JSON.stringify(["Violin", "Piano"]));
  form.set("sheetArrangements", JSON.stringify(["Beginner", "Full score"]));
  return form;
}

async function createLibrarySong() {
  const response = await createSong(request("/api/admin/songs", "POST", songForm()));
  expect(response.status).toBe(201);
  return (await response.json() as { id: string }).id;
}

async function library() {
  const response = await getLibrary(request("/api/admin/data"));
  expect(response.status).toBe(200);
  return response.json() as Promise<AdminData>;
}

beforeAll(async () => {
  directory = await mkdtemp(path.join(tmpdir(), "reservation-library-test-"));
  state.uploadDirectory = path.join(directory, "uploads");
  state.database = new TestDatabase();
  databasePath = state.database.name;
  await state.database.initialize();
});

beforeEach(async () => {
  state.userId = "admin-one";
  await state.database!.exec(`
    RESET_TEST_DATABASE;
    INSERT INTO "user" (id,name,email,"emailVerified") VALUES
      ('admin-one','First admin','admin-one@example.test',true),
      ('admin-two','Second admin','admin-two@example.test',true),
      ('parent','Parent','parent@example.test',true),
      ('unverified','Unverified admin','unverified@example.test',false);
    INSERT INTO admin_users (user_id) VALUES ('admin-one'),('admin-two'),('unverified');
  `);
  await rm(state.uploadDirectory, { recursive: true, force: true });
  await mkdir(state.uploadDirectory, { recursive: true });
});

afterAll(async () => {
  await state.database?.destroy();
  if (directory) await rm(directory, { recursive: true, force: true });
});

describe("shared reusable song library", () => {
  it("formats usage dates with date/time styles without conflicting with default components", () => {
    const timestamp = "2030-01-01T00:00:00Z";
    expect(formatDateTime(timestamp, "UTC", { dateStyle: "medium" })).toBe("Jan 1, 2030");
    expect(formatDateTime(timestamp, "UTC", { timeStyle: "short" })).toBe("12:00 AM");
    expect(() => formatDateTime(timestamp, "UTC", { dateStyle: "medium", timeStyle: "short" })).not.toThrow();
    expect(formatTime(timestamp, "UTC")).toBe("12:00 AM");
    expect(formatDateTime(timestamp, "UTC")).toContain("2030");
  });

  it("creates multiple labelled PDFs and links without a season and shares them with another administrator", async () => {
    const id = await createLibrarySong();
    state.userId = "admin-two";
    const data = await library();
    expect(data.seasons).toEqual([]);
    expect(data.songs).toHaveLength(1);
    expect(data.songs[0]).toMatchObject({ id, title: "Shared library song", notes: "Shared song notes", links, usages: [] });
    expect(data.songs[0].sheets).toEqual(expect.arrayContaining([
      expect.objectContaining({ label: "Violin part", instrument: "Violin", arrangement: "Beginner" }),
      expect.objectContaining({ label: "Piano part", instrument: "Piano", arrangement: "Full score" }),
    ]));
    expect(await readdir(state.uploadDirectory)).toHaveLength(2);
  });

  it("keeps song records and PDF files after reopening the database", async () => {
    const id = await createLibrarySong();
    await state.database!.close();
    state.database = new TestDatabase(databasePath);
    const song = (await library()).songs.find((item) => item.id === id)!;
    expect(song.links).toEqual(links);
    const response = await downloadSheet(request(`/api/admin/sheets/${song.sheets[0].id}/download`), context(song.sheets[0].id));
    expect(response.status).toBe(200);
    expect(await response.text()).toBe(pdf);
  });

  it("edits song details and links, adds sheets, and retains the old PDF when replacing a sheet", async () => {
    const id = await createLibrarySong();
    const songUpdate = await updateSong(request(`/api/admin/songs/${id}`, "PATCH", { title: "Updated song", notes: "Updated notes", links: [links[1]] }), context(id));
    expect(songUpdate.status).toBe(200);
    expect((await addSheets(request(`/api/admin/songs/${id}/sheets`, "POST", songForm()), context(id))).status).toBe(201);
    const song = (await library()).songs[0];
    expect(song).toMatchObject({ title: "Updated song", notes: "Updated notes", links: [links[1]] });
    expect(song.sheets).toHaveLength(4);
    const sheet = song.sheets[0];
    const form = new FormData();
    form.set("label", "Renamed part");
    form.set("instrument", "Guitar");
    form.set("arrangement", "Key of G");
    form.set("permission", "true");
    form.set("file", new File([`${pdf}\nReplacement`], "replacement.pdf", { type: "application/pdf" }));
    expect((await updateSheet(request(`/api/admin/sheets/${sheet.id}`, "PATCH", form), context(sheet.id))).status).toBe(200);
    const updated = (await library()).songs[0].sheets.find((item) => item.id === sheet.id)!;
    expect(updated).toMatchObject({ label: "Renamed part", instrument: "Guitar", arrangement: "Key of G", version: 2 });
    const old = await downloadSheet(request(`/api/admin/sheets/${sheet.id}/download?version=1`), context(sheet.id));
    expect(await old.text()).toBe(pdf);
    expect(await readdir(state.uploadDirectory)).toHaveLength(5);
  });

  it("deletes individual unused sheets and unused songs along with their stored files", async () => {
    const id = await createLibrarySong();
    const sheet = (await library()).songs[0].sheets[0];
    expect((await deleteSheet(request(`/api/admin/sheets/${sheet.id}`, "DELETE"), context(sheet.id))).status).toBe(200);
    expect((await library()).songs[0].sheets).toHaveLength(1);
    expect(await readdir(state.uploadDirectory)).toHaveLength(1);
    expect((await deleteSong(request(`/api/admin/songs/${id}`, "DELETE"), context(id))).status).toBe(200);
    expect((await library()).songs).toEqual([]);
    expect(await readdir(state.uploadDirectory)).toEqual([]);
  });

  it("shows event and season usage and blocks deletion of referenced songs and sheets", async () => {
    const id = await createLibrarySong();
    const sheet = (await library()).songs[0].sheets[0];
    const seasonId = randomUUID();
    const eventId = randomUUID();
    const eventSongId = randomUUID();
    await state.database!.query("INSERT INTO seasons (id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status) VALUES ($1,'Library season','2030-01-01','2030-12-31','2029-01-01 00:00:00','2030-12-31 00:00:00','UTC','Published')", [seasonId]);
    await state.database!.query("INSERT INTO events (id,season_id,name,starts_at,ends_at) VALUES ($1,$2,'Library event','2030-02-01 10:00:00','2030-02-01 11:00:00')", [eventId, seasonId]);
    await state.database!.query("INSERT INTO event_songs (id,event_id,song_id,position) VALUES ($1,$2,$3,1)", [eventSongId, eventId, id]);
    await state.database!.query("INSERT INTO event_sheets (event_song_id,sheet_id,selected_version) VALUES ($1,$2,1)", [eventSongId, sheet.id]);
    const song = (await library()).songs[0];
    expect(song.usages[0]).toMatchObject({ seasonName: "Library season", eventName: "Library event" });
    expect(song.sheets.find((item) => item.id === sheet.id)!.usages[0]).toMatchObject({ seasonId, eventId });
    expect((await deleteSong(request(`/api/admin/songs/${id}`, "DELETE"), context(id))).status).toBe(409);
    expect((await deleteSheet(request(`/api/admin/sheets/${sheet.id}`, "DELETE"), context(sheet.id))).status).toBe(409);
    expect((await updateSong(request(`/api/admin/songs/${id}`, "PATCH", { notes: "Changed" }), context(id))).status).toBe(409);
    expect((await updateSong(request(`/api/admin/songs/${id}`, "PATCH", { notes: "Changed", confirmImpact: true }), context(id))).status).toBe(200);
    expect(await readdir(state.uploadDirectory)).toHaveLength(2);
  });

  it.each(["javascript:alert(1)", "ftp://example.test/file", "not a URL"])("rejects unsafe or invalid links: %s", async (link) => {
    const form = songForm();
    form.set("links", JSON.stringify([link]));
    expect((await createSong(request("/api/admin/songs", "POST", form))).status).toBe(400);
    expect((await library()).songs).toEqual([]);
    expect(await readdir(state.uploadDirectory)).toEqual([]);
  });

  it("rejects invalid PDFs, oversized uploads, and uploads without distribution permission", async () => {
    const invalid = songForm();
    invalid.delete("files");
    invalid.append("files", new File(["not a PDF"], "invalid.pdf", { type: "application/pdf" }));
    expect((await createSong(request("/api/admin/songs", "POST", invalid))).status).toBe(400);
    const oversized = songForm();
    oversized.delete("files");
    oversized.append("files", new File([new Uint8Array(MAX_PDF_BYTES + 1)], "oversized.pdf", { type: "application/pdf" }));
    expect((await createSong(request("/api/admin/songs", "POST", oversized))).status).toBe(400);
    const unpermitted = songForm();
    unpermitted.delete("permission");
    expect((await createSong(request("/api/admin/songs", "POST", unpermitted))).status).toBe(400);
    expect((await library()).songs).toEqual([]);
    expect(await readdir(state.uploadDirectory)).toEqual([]);
  });

  it.each([null, "parent", "unverified"])("denies all library APIs to unauthorized user %s", async (userId) => {
    state.userId = userId;
    const id = randomUUID();
    const responses = [
      await getLibrary(request("/api/admin/data")),
      await createSong(request("/api/admin/songs", "POST", songForm())),
      await updateSong(request(`/api/admin/songs/${id}`, "PATCH", { title: "Forbidden" }), context(id)),
      await deleteSong(request(`/api/admin/songs/${id}`, "DELETE"), context(id)),
      await addSheets(request(`/api/admin/songs/${id}/sheets`, "POST", songForm()), context(id)),
      await updateSheet(request(`/api/admin/sheets/${id}`, "PATCH", new FormData()), context(id)),
      await deleteSheet(request(`/api/admin/sheets/${id}`, "DELETE"), context(id)),
      await downloadSheet(request(`/api/admin/sheets/${id}/download`), context(id)),
    ];
    expect(responses.map((response) => response.status)).toEqual(Array(8).fill(userId === null ? 401 : 403));
    expect(await readdir(state.uploadDirectory)).toEqual([]);
  });

  it("rejects cross-origin library writes", async () => {
    expect((await createSong(request("/api/admin/songs", "POST", songForm(), "https://other.example.test"))).status).toBe(403);
    expect((await library()).songs).toEqual([]);
  });
});

describe("parent song and instrument listing", () => {
  async function seedParentListing() {
    const songId = await createLibrarySong();
    const song = (await library()).songs[0];
    const sheet = song.sheets.find((item) => item.instrument === "Violin")!;
    const replacement = new FormData();
    replacement.set("permission", "true");
    replacement.set("file", new File([`${pdf}\nVersion two`], "new-version.pdf", { type: "application/pdf" }));
    expect((await updateSheet(request(`/api/admin/sheets/${sheet.id}`, "PATCH", replacement), context(sheet.id))).status).toBe(200);
    const seasonId = randomUUID();
    const eventId = randomUUID();
    const eventSongId = randomUUID();
    const unslottedSongId = randomUUID();
    const ownChildId = randomUUID();
    const otherChildId = randomUUID();
    const otherPianoChildId = randomUUID();
    const otherReservationId = randomUUID();
    await state.database!.query("INSERT INTO seasons (id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status,cancellation_hours) VALUES ($1,'Parent season','2099-01-01','2099-12-31','2020-01-01 00:00:00','2099-12-31 00:00:00','UTC','Published',24)", [seasonId]);
    await state.database!.query("INSERT INTO events (id,season_id,name,starts_at,ends_at) VALUES ($1,$2,'Parent performance','2099-02-01 10:00:00','2099-02-01 11:00:00')", [eventId, seasonId]);
    await state.database!.query("INSERT INTO event_songs (id,event_id,song_id,position,notes) VALUES ($1,$2,$3,1,'Event-only notes'),($4,$2,$3,2,'No instruments requested')", [eventSongId, eventId, songId, unslottedSongId]);
    await state.database!.query("INSERT INTO event_sheets (event_song_id,sheet_id,selected_version) VALUES ($1,$2,1),($3,$2,1)", [eventSongId, sheet.id, unslottedSongId]);
    await state.database!.query("INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES ($1,'Violin',2),($1,'Piano',1)", [eventSongId]);
    await state.database!.query("INSERT INTO children (id,parent_user_id,full_name,birth_month,birth_year,status) VALUES ($1,'parent','Own Child',1,2015,'Approved'),($2,'admin-two','Private Other Child',1,2015,'Approved'),($3,'admin-two','Private Piano Child',1,2015,'Approved')", [ownChildId, otherChildId, otherPianoChildId]);
    await state.database!.query("INSERT INTO child_instruments (child_id,instrument,years_experience) VALUES ($1,'Violin',1)", [ownChildId]);
    await state.database!.query("INSERT INTO reservations (id,child_id,season_id,event_id,event_song_id,instrument,spot_number) VALUES ($1,$2,$3,$4,$5,'Violin',1),($6,$7,$3,$4,$5,'Piano',1)", [otherReservationId, otherChildId, seasonId, eventId, eventSongId, randomUUID(), otherPianoChildId]);
    state.userId = "parent";
    return { seasonId, eventId, eventSongId, unslottedSongId, sheetId: sheet.id, ownChildId, otherReservationId };
  }

  async function seedExtraSongs() {
    const graph = await seedParentListing();
    const parentId = randomUUID();
    await state.database!.query('INSERT INTO "user" (id,name,email,"emailVerified") VALUES ($1,\'Extra song parent\',$2,true)', [parentId, `${parentId}@example.test`]);
    await state.database!.query("UPDATE children SET parent_user_id=$1 WHERE id=$2", [parentId, graph.ownChildId]);
    state.userId = parentId;
    const extraSongId = randomUUID();
    const extraEventSongId = randomUUID();
    const repeatEventSongId = randomUUID();
    const secondExtraSongId = randomUUID();
    const secondExtraEventSongId = randomUUID();
    const laterEventId = randomUUID();
    await state.database!.query("INSERT INTO songs (id,title) VALUES ($1,'Extra song'),($2,'Second extra song')", [extraSongId, secondExtraSongId]);
    await state.database!.query("INSERT INTO events (id,season_id,name,starts_at,ends_at) VALUES ($1,$2,'Later performance','2099-02-08 10:00:00','2099-02-08 11:00:00')", [laterEventId, graph.seasonId]);
    await state.database!.query(
      `INSERT INTO event_songs (id,event_id,song_id,position) VALUES
        ($1,$2,$3,3),($4,$5,$3,1),($6,$2,$7,4)`,
      [extraEventSongId, graph.eventId, extraSongId, repeatEventSongId, laterEventId, secondExtraEventSongId, secondExtraSongId],
    );
    await state.database!.query(
      "INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES ($1,'Violin',3),($2,'Violin',3),($3,'Violin',3),($4,'Violin',3)",
      [extraEventSongId, repeatEventSongId, secondExtraEventSongId, graph.unslottedSongId],
    );
    return { ...graph, extraSongId, extraEventSongId, repeatEventSongId, secondExtraSongId, secondExtraEventSongId, laterEventId };
  }

  async function configureExtra(seasonId: string, songId: string, allowExtra: boolean, confirmImpact = true) {
    const userId = state.userId;
    state.userId = "admin-one";
    try {
      return await setExtraSong(request(`/api/admin/seasons/${seasonId}/songs/${songId}`, "PATCH", { allowExtra, confirmImpact }),
        { params: Promise.resolve({ id: seasonId, songId }) });
    } finally {
      state.userId = userId;
    }
  }

  function bookSong(graph: { ownChildId: string; eventId: string }, eventSongId: string, spotNumber = 1) {
    return parentBook(request("/api/parent/reservations", "POST", {
      childId: graph.ownChildId, eventId: graph.eventId, eventSongId, instrument: "Violin", spotNumber,
    }));
  }

  it("defaults songs to regular and requires administrator authorization, valid input, assignment, and published impact confirmation", async () => {
    const graph = await seedExtraSongs();
    const params = { params: Promise.resolve({ id: graph.seasonId, songId: graph.extraSongId }) };
    const url = `/api/admin/seasons/${graph.seasonId}/songs/${graph.extraSongId}`;
    expect((await setExtraSong(request(url, "PATCH", { allowExtra: true }), params)).status).toBe(403);
    state.userId = "unverified";
    expect((await setExtraSong(request(url, "PATCH", { allowExtra: true }), params)).status).toBe(403);
    state.userId = null;
    expect((await setExtraSong(request(url, "PATCH", { allowExtra: true }), params)).status).toBe(401);
    state.userId = "admin-one";
    expect((await setExtraSong(request(url, "PATCH", { allowExtra: true }, "https://other.example.test"), params)).status).toBe(403);
    expect((await setExtraSong(request(url, "PATCH", { allowExtra: "true" }), params)).status).toBe(400);
    expect((await configureExtra(graph.seasonId, randomUUID(), true)).status).toBe(404);
    const before = (await library()).seasons[0].events.flatMap((event) => event.songs);
    expect(before.every((song) => !song.allowExtra)).toBe(true);
    const confirmation = await configureExtra(graph.seasonId, graph.extraSongId, true, false);
    expect(confirmation.status).toBe(409);
    expect(await confirmation.json()).toMatchObject({ code: "IMPACT_CONFIRMATION_REQUIRED" });
    expect((await state.database!.query("SELECT * FROM season_song_settings")).rows).toEqual([]);
    expect((await configureExtra(graph.seasonId, graph.extraSongId, true)).status).toBe(200);
    const after = await library();
    expect(after.seasons[0].events.flatMap((event) => event.songs).filter((song) => song.songId === graph.extraSongId).map((song) => song.allowExtra)).toEqual([true, true]);
    expect(after.songs.find((song) => song.id === graph.extraSongId)).not.toHaveProperty("allowExtra");
    expect(after.audit).toContainEqual(expect.objectContaining({ action: "season_song_extra_updated", actorName: "First admin" }));
  });

  it.each(["regular first", "extra first"])("allows a regular reservation plus each extra song at the same event, %s", async (order) => {
    const graph = await seedExtraSongs();
    expect((await configureExtra(graph.seasonId, graph.extraSongId, true)).status).toBe(200);
    expect((await configureExtra(graph.seasonId, graph.secondExtraSongId, true)).status).toBe(200);
    const targets: [string, number][] = order === "regular first"
      ? [[graph.eventSongId, 2], [graph.extraEventSongId, 1]]
      : [[graph.extraEventSongId, 1], [graph.eventSongId, 2]];
    for (const [songId, spot] of targets) expect((await bookSong(graph, songId, spot)).status).toBe(201);
    expect((await bookSong(graph, graph.secondExtraEventSongId)).status).toBe(201);
    const duplicateRegular = await bookSong(graph, graph.unslottedSongId);
    expect(duplicateRegular.status).toBe(409);
    expect(await duplicateRegular.json()).toMatchObject({ code: "CHILD_ALREADY_BOOKED" });
    const repeatedExtra = await bookSong({ ...graph, eventId: graph.laterEventId }, graph.repeatEventSongId, 2);
    expect(repeatedExtra.status).toBe(409);
    expect(await repeatedExtra.json()).toMatchObject({ code: "CHILD_ALREADY_BOOKED" });
    const listing = await (await parentSeasons(request("/api/parent/seasons"))).json();
    expect(listing.reservations.filter((reservation: { is_extra: boolean }) => reservation.is_extra)).toHaveLength(2);
    expect(listing.seasons[0].events[0].songs.find((song: { id: string }) => song.id === graph.extraEventSongId)).toMatchObject({ allowExtra: true, songId: graph.extraSongId });
  });

  it("reclassifies existing bookings on enable, blocks conflicting disable atomically, and allows disable after cancellation", async () => {
    const graph = await seedExtraSongs();
    expect((await bookSong(graph, graph.extraEventSongId)).status).toBe(201);
    expect((await configureExtra(graph.seasonId, graph.extraSongId, true)).status).toBe(200);
    expect((await bookSong(graph, graph.eventSongId, 2)).status).toBe(201);
    const disabled = await configureExtra(graph.seasonId, graph.extraSongId, false);
    expect(disabled.status).toBe(409);
    expect(await disabled.json()).toMatchObject({ code: "EXTRA_SONG_HAS_CONFLICTS" });
    expect((await state.database!.query<{ allow_extra: boolean }>("SELECT allow_extra FROM season_song_settings WHERE season_id=$1 AND song_id=$2", [graph.seasonId, graph.extraSongId])).rows[0].allow_extra).toBe(true);
    const reservations = await state.database!.query<{ id: string; booking_group: string }>("SELECT id,booking_group FROM reservations WHERE child_id=$1", [graph.ownChildId]);
    expect(reservations.rows.map((row) => row.booking_group)).toEqual(expect.arrayContaining(["regular", `song:${graph.extraSongId}`]));
    const regularId = reservations.rows.find((row) => row.booking_group === "regular")!.id;
    expect((await parentCancel(request(`/api/parent/reservations/${regularId}`, "DELETE"), context(regularId))).status).toBe(200);
    expect((await configureExtra(graph.seasonId, graph.extraSongId, false)).status).toBe(200);
    expect((await bookSong(graph, graph.eventSongId, 2)).status).toBe(409);
    const active = await state.database!.query("SELECT booking_group FROM reservations WHERE child_id=$1 AND status='Confirmed'", [graph.ownChildId]);
    expect(active.rows).toEqual([{ booking_group: "regular" }]);
  });

  it("releases an extra-song allowance on cancellation without releasing the regular-song allowance", async () => {
    const graph = await seedExtraSongs();
    expect((await configureExtra(graph.seasonId, graph.extraSongId, true)).status).toBe(200);
    expect((await bookSong(graph, graph.eventSongId, 2)).status).toBe(201);
    const extra = await bookSong(graph, graph.extraEventSongId);
    expect(extra.status).toBe(201);
    const extraId = (await extra.json()).reservation.id;
    expect((await parentCancel(request(`/api/parent/reservations/${extraId}`, "DELETE"), context(extraId))).status).toBe(200);
    expect((await bookSong({ ...graph, eventId: graph.laterEventId }, graph.repeatEventSongId)).status).toBe(201);
    expect((await bookSong(graph, graph.unslottedSongId)).status).toBe(409);
  });

  it("keeps extra-song settings within the season when copying an event and rejects cross-season time conflicts", async () => {
    const graph = await seedExtraSongs();
    expect((await configureExtra(graph.seasonId, graph.extraSongId, true)).status).toBe(200);
    const otherSeasonId = randomUUID();
    const otherEventId = randomUUID();
    await state.database!.query(
      `INSERT INTO seasons (id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status)
       VALUES ($1,'Other season','2099-01-01','2099-12-31','2020-01-01 00:00:00','2099-12-31 00:00:00','UTC','Published')`, [otherSeasonId],
    );
    await state.database!.query("INSERT INTO events (id,season_id,name,starts_at,ends_at) VALUES ($1,$2,'Other season performance','2099-02-01 10:00:00','2099-02-01 11:00:00')", [otherEventId, otherSeasonId]);
    const parentId = state.userId;
    state.userId = "admin-one";
    expect((await copyEvent(request(`/api/admin/events/${graph.eventId}/copy`, "POST", { targetEventId: otherEventId }), context(graph.eventId))).status).toBe(201);
    expect((await copyEvent(request(`/api/admin/events/${graph.eventId}/copy`, "POST", { targetEventId: graph.laterEventId }), context(graph.eventId))).status).toBe(201);
    const data = await library();
    expect(data.seasons.find((season) => season.id === otherSeasonId)!.events[0].songs.every((song) => !song.allowExtra)).toBe(true);
    expect(data.seasons.find((season) => season.id === graph.seasonId)!.events.flatMap((event) => event.songs).filter((song) => song.songId === graph.extraSongId).every((song) => song.allowExtra)).toBe(true);
    const otherExtra = data.seasons.find((season) => season.id === otherSeasonId)!.events[0].songs.find((song) => song.songId === graph.extraSongId)!;
    state.userId = parentId;
    expect((await bookSong(graph, graph.extraEventSongId)).status).toBe(201);
    const conflicting = await bookSong({ ...graph, eventId: otherEventId }, otherExtra.id);
    expect(conflicting.status).toBe(409);
    expect(await conflicting.json()).toMatchObject({ code: "EVENT_TIME_CONFLICT" });
    await state.database!.query("UPDATE events SET starts_at='2099-03-01 10:00:00',ends_at='2099-03-01 11:00:00' WHERE id=$1", [otherEventId]);
    expect((await bookSong({ ...graph, eventId: otherEventId }, otherExtra.id)).status).toBe(201);
  });

  it("still enforces child approval, instrument eligibility, open registration, and occupied spots for extra songs", async () => {
    const graph = await seedExtraSongs();
    expect((await configureExtra(graph.seasonId, graph.extraSongId, true)).status).toBe(200);
    await state.database!.query("UPDATE children SET status='Pending approval' WHERE id=$1", [graph.ownChildId]);
    expect(await (await bookSong(graph, graph.extraEventSongId)).json()).toMatchObject({ code: "CHILD_NOT_APPROVED" });
    await state.database!.query("UPDATE children SET status='Approved' WHERE id=$1", [graph.ownChildId]);
    await state.database!.query("DELETE FROM child_instruments WHERE child_id=$1", [graph.ownChildId]);
    expect(await (await bookSong(graph, graph.extraEventSongId)).json()).toMatchObject({ code: "INSTRUMENT_NOT_APPROVED" });
    await state.database!.query("INSERT INTO child_instruments (child_id,instrument,years_experience) VALUES ($1,'Violin',1)", [graph.ownChildId]);
    await state.database!.query("UPDATE seasons SET status='Registration Closed' WHERE id=$1", [graph.seasonId]);
    expect(await (await bookSong(graph, graph.extraEventSongId)).json()).toMatchObject({ code: "REGISTRATION_CLOSED" });
    await state.database!.query("UPDATE seasons SET status='Published' WHERE id=$1", [graph.seasonId]);
    expect(await (await bookSong(graph, graph.extraEventSongId, 4)).json()).toMatchObject({ code: "INVALID_SPOT" });
    await state.database!.query(
      `INSERT INTO reservations (id,child_id,season_id,event_id,event_song_id,instrument,spot_number,booking_group)
       VALUES ($1,$2,$3,$4,$5,'Violin',1,$6)`,
      [randomUUID(), graph.ownChildId, graph.seasonId, graph.eventId, graph.extraEventSongId, `song:${graph.extraSongId}`],
    );
    const duplicate = await bookSong(graph, graph.extraEventSongId, 2);
    expect(duplicate.status).toBe(409);
    expect(await duplicate.json()).toMatchObject({ code: "CHILD_ALREADY_BOOKED" });
    expect((await bookSong(graph, graph.eventSongId, 1)).status).toBe(409);
  });

  it("accepts only one of simultaneous extra-song booking attempts across events", async () => {
    const graph = await seedExtraSongs();
    expect((await configureExtra(graph.seasonId, graph.extraSongId, true)).status).toBe(200);
    const attempts = await Promise.all([
      bookSong(graph, graph.extraEventSongId),
      bookSong({ ...graph, eventId: graph.laterEventId }, graph.repeatEventSongId),
    ]);
    expect(attempts.map((response) => response.status).sort()).toEqual([201, 409]);
    expect((await state.database!.query("SELECT id FROM reservations WHERE child_id=$1 AND status='Confirmed'", [graph.ownChildId])).rows).toHaveLength(1);
  });

  it("includes every song, library metadata, and the event-pinned PDF version without other families' names", async () => {
    const graph = await seedParentListing();
    const response = await parentSeasons(request("/api/parent/seasons"));
    expect(response.status).toBe(200);
    const text = await response.text();
    expect(text).not.toContain("Private Other Child");
    expect(text).not.toContain("Private Piano Child");
    const data = JSON.parse(text);
    const songs = data.seasons[0].events[0].songs;
    expect(songs).toHaveLength(2);
    expect(songs[0]).toMatchObject({ libraryNotes: "Shared song notes", notes: "Event-only notes", links });
    expect(songs[0].sheets).toEqual([expect.objectContaining({ id: graph.sheetId, version: 1, fileName: "violin.pdf" })]);
    expect(songs[0].requirements).toEqual(expect.arrayContaining([
      { instrument: "Violin", capacity: 2, reserved: 1, available: 1, availableSpots: [2], reservedSpots: [] },
      { instrument: "Piano", capacity: 1, reserved: 1, available: 0, availableSpots: [], reservedSpots: [] },
    ]));
    expect(songs[1]).toMatchObject({ id: graph.unslottedSongId, requirements: [] });
    expect(data.reservations).toEqual([]);
    expect(data.children).toEqual([expect.objectContaining({ id: graph.ownChildId, full_name: "Own Child" })]);
  });

  it("previews and downloads only an authorized event-selected PDF version", async () => {
    const graph = await seedParentListing();
    const preview = await parentSheet(request(`/api/sheets/${graph.sheetId}/download?version=1&preview=true`), context(graph.sheetId));
    expect(preview.status).toBe(200);
    expect(preview.headers.get("content-disposition")).toContain("inline;");
    expect(await preview.text()).toBe(pdf);
    const download = await parentSheet(request(`/api/sheets/${graph.sheetId}/download?version=1`), context(graph.sheetId));
    expect(download.headers.get("content-disposition")).toContain("attachment;");
    expect((await parentSheet(request(`/api/sheets/${graph.sheetId}/download?version=2`), context(graph.sheetId))).status).toBe(404);
    state.userId = null;
    expect((await parentSheet(request(`/api/sheets/${graph.sheetId}/download?version=1&preview=true`), context(graph.sheetId))).status).toBe(401);
  });

  it("books a remaining spot, returns full own-reservation details, and releases it on cancellation", async () => {
    const graph = await seedParentListing();
    const booking = await parentBook(request("/api/parent/reservations", "POST", { childId: graph.ownChildId, eventId: graph.eventId, eventSongId: graph.eventSongId, instrument: "Violin", spotNumber: 2 }));
    expect(booking.status).toBe(201);
    await state.database!.query(
      "INSERT INTO season_song_settings(season_id,song_id,song_role) SELECT $1,song_id,$3 FROM event_songs WHERE id=$2",
      [graph.seasonId, graph.eventSongId, "Special Song"],
    );
    const reservationDetails = await (await parentReservations(request("/api/parent/reservations"))).json();
    expect(reservationDetails.reservations).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: (await booking.json()).reservation.id, song_role: "Special Song" }),
    ]));
    const booked = await (await parentSeasons(request("/api/parent/seasons"))).json();
    expect(booked.reservations).toEqual([expect.objectContaining({ child_name: "Own Child", season_name: "Parent season", event_name: "Parent performance", song_title: "Shared library song", song_role: "Special Song", instrument: "Violin", spot_number: 2, timezone: "UTC" })]);
    const ownReservationId = booked.reservations[0].id;
    expect(booked.seasons[0].events[0].songs[0].requirements).toContainEqual(expect.objectContaining({
      instrument: "Violin",
      reservedSpots: [{ spotNumber: 2, childName: "Own Child" }],
    }));
    expect((await parentCancel(request(`/api/parent/reservations/${graph.otherReservationId}`, "DELETE"), context(graph.otherReservationId))).status).toBe(404);
    expect((await parentCancel(request(`/api/parent/reservations/${ownReservationId}`, "DELETE"), context(ownReservationId))).status).toBe(200);
    const cancelled = await (await parentSeasons(request("/api/parent/seasons"))).json();
    expect(cancelled.reservations[0].status).toBe("Cancelled");
    expect(cancelled.seasons[0].events[0].songs[0].requirements).toContainEqual({ instrument: "Violin", capacity: 2, reserved: 1, available: 1, availableSpots: [2], reservedSpots: [] });
  });
});