import argon2 from "argon2";
import { verifyPassword as verifyLegacyPassword } from "better-auth/crypto";

export function hashPassword(password: string): Promise<string> {
  return argon2.hash(password, {
    type: argon2.argon2id,
    memoryCost: 19_456,
    timeCost: 2,
    parallelism: 1,
  });
}

export function verifyPassword({ hash, password }: { hash: string; password: string }): Promise<boolean> {
  if (hash.startsWith("$argon2id$")) return argon2.verify(hash, password);
  return verifyLegacyPassword({ hash, password });
}