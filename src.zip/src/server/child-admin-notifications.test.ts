import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  row: {
    status: "Pending", kind: "Acknowledgement", recipient: "Administrator",
    name: "Parent One", email: "parent@example.test", email_verified: true,
    child_name: "New Child",
  },
  query: vi.fn(),
  send: vi.fn(),
}));
vi.mock("./db", () => ({
  query: (...args: unknown[]) => state.query(...args),
  transaction: async (work: (tx: { query: typeof state.query }) => Promise<unknown>) =>
    work({ query: state.query }),
}));
vi.mock("./mail", () => ({ sendMail: (...args: unknown[]) => state.send(...args) }));

import { childRegistrationAdminEmail, deliverChildNotification, queueChildAdminNotification } from "./child-notifications";

beforeEach(() => {
  vi.stubEnv("NODE_ENV", "production");
  vi.stubEnv("APP_URL", "https://ministry.example.test");
  state.row = {
    status: "Pending", kind: "Acknowledgement", recipient: "Administrator",
    name: "Parent One", email: "parent@example.test", email_verified: true,
    child_name: "New Child",
  };
  state.query.mockReset().mockImplementation(async (sql: string) => ({
    rows: sql.startsWith("SELECT") ? [{ ...state.row }] : [], rowCount: 1,
  }));
  state.send.mockReset().mockResolvedValue(undefined);
  vi.spyOn(console, "error").mockImplementation(() => {});
});
afterEach(() => {
  vi.unstubAllEnvs();
  vi.restoreAllMocks();
});

describe("administrator child registration notifications", () => {
  it("queues a separate durable administrator recipient in the registration transaction", async () => {
    const tx = {
      async query<T>(sql: string, params?: unknown[]) {
        await state.query(sql, params);
        return { rows: [] as T[], rowCount: 1 };
      },
    };
    const id = await queueChildAdminNotification(tx, "parent-id", "child-id");
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("INSERT INTO child_profile_notifications"),
      [id, "child-id", "parent-id", "Acknowledgement", "Administrator"],
    );
    expect(state.send).not.toHaveBeenCalled();
  });

  it("sends the coordinator the child and parent details with the actual admin dashboard link", async () => {
    expect(await deliverChildNotification("admin-notification")).toBe("Sent");
    expect(state.send).toHaveBeenCalledExactlyOnceWith(
      "kidsmusic-coord@tamilgospelchurch.org",
      "New child registration - Tamil Gospel Church",
      childRegistrationAdminEmail("Parent One", "parent@example.test", "New Child").text,
    );
    const text = state.send.mock.calls[0][2] as string;
    for (const phrase of ["Child: New Child", "Parent One", "parent@example.test",
      "pending administrator approval", "https://ministry.example.test/dashboard"]) expect(text).toContain(phrase);
    expect(state.query).toHaveBeenCalledWith(expect.stringContaining("sent_at=$2"), ["Sent", expect.any(Date), "admin-notification"]);
  });

  it("retains a failed administrator delivery for retry and never resends after success", async () => {
    state.send.mockRejectedValueOnce(new Error("SMTP unavailable"));
    expect(await deliverChildNotification("admin-notification")).toBe("Failed");
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("SET status='Failed'"), ["admin-notification"],
    );
    expect(console.error).toHaveBeenCalledWith("Child profile email delivery failed", { notificationId: "admin-notification" });
    state.row.status = "Failed";
    expect(await deliverChildNotification("admin-notification")).toBe("Sent");
    state.row.status = "Sent";
    expect(await deliverChildNotification("admin-notification")).toBe("Sent");
    expect(state.send).toHaveBeenCalledTimes(2);
  });

  it("uses Preview in development without recording SMTP acceptance", async () => {
    vi.stubEnv("NODE_ENV", "development");
    expect(await deliverChildNotification("admin-notification")).toBe("Preview");
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("sent_at=$2"), ["Preview", null, "admin-notification"],
    );
  });

  it("preserves verified-parent delivery and does not redirect their acknowledgement", async () => {
    state.row.recipient = "Parent";
    expect(await deliverChildNotification("parent-notification")).toBe("Sent");
    expect(state.send).toHaveBeenCalledWith(
      "parent@example.test", "Child profile received - Tamil Gospel Church", expect.stringContaining("Dear Parent One,"),
    );
  });

  it("still notifies the coordinator if the parent's verification changes before retry", async () => {
    state.row.email_verified = false;
    expect(await deliverChildNotification("admin-notification")).toBe("Sent");
    expect(state.send.mock.calls[0][0]).toBe("kidsmusic-coord@tamilgospelchurch.org");
  });

  it("does not resend an interrupted administrator delivery", async () => {
    state.row.status = "Sending";
    expect(await deliverChildNotification("admin-notification")).toBe("Sending");
    expect(state.send).not.toHaveBeenCalled();
  });
});
