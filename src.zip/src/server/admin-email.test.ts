import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  userId: "00000000-0000-4000-8000-000000000001" as string | null,
  parents: [] as Array<{ id: string; name: string; email: string; verified: boolean; subscribed?: boolean }>,
  failures: new Set<string>(),
  deliveries: [] as Array<{ to: string; subject: string; text: string }>,
  auditDescriptions: [] as string[],
  query: vi.fn(),
}));

vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: <T>(text: string, params: unknown[] = []) => state.query(text, params) as Promise<{ rows: T[]; rowCount: number }>,
  transaction: <T>(work: (tx: { query: <R>(text: string, params?: unknown[]) => Promise<{ rows: R[]; rowCount: number }> }) => Promise<T>) =>
    work({
      query: <R>(text: string, params: unknown[] = []) =>
        state.query(text, params) as Promise<{ rows: R[]; rowCount: number }>,
    }),
}));

vi.mock("./auth", () => ({
  getAuth: () => ({
    api: {
      getSession: async () => state.userId ? { user: { id: state.userId, name: "Test admin", email: "admin@example.test" } } : null,
    },
  }),
}));

vi.mock("./email-queue", () => ({
  queueEmail: vi.fn(async (_tx: unknown, email: { userId: string; kind: string; subject: string; text: string }) => {
    const to = state.parents.find((parent) => parent.id === email.userId)!.email;
    state.deliveries.push({ to, subject: email.subject, text: email.text });
    if (state.failures.has(to)) throw new Error("Queue unavailable");
    return "queued";
  }),
}));

import { GET as listParents, POST as sendEmail } from "../app/api/admin/notifications/email/route";

const origin = "http://localhost:3000";
const adminId = "00000000-0000-4000-8000-000000000001";
const parentId = "00000000-0000-4000-8000-000000000002";
const parentTwoId = "00000000-0000-4000-8000-000000000003";
const unverifiedParentId = "00000000-0000-4000-8000-000000000004";

function request(url: string, method = "GET", body?: Record<string, unknown>, requestOrigin = origin) {
  return new NextRequest(`${origin}${url}`, {
    method,
    headers: {
      origin: requestOrigin,
      ...(body ? { "content-type": "application/json" } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
}

const emailBody = {
  allParents: false,
  recipientIds: [parentId],
  subject: "Season registration is open",
  message: "Please register your children while spots remain.",
};
let clock = Date.now();

beforeEach(() => {
  clock += 60_001;
  vi.spyOn(Date, "now").mockReturnValue(clock);
  state.userId = adminId;
  state.parents = [
    { id: parentId, name: "Parent One", email: "parent@example.test", verified: true },
    { id: parentTwoId, name: "Parent Two", email: "parent-two@example.test", verified: true },
    { id: unverifiedParentId, name: "Unverified Parent", email: "unverified@example.test", verified: false },
  ];
  state.failures.clear();
  state.deliveries.length = 0;
  state.auditDescriptions.length = 0;
  state.query.mockImplementation(async (text: string, params: unknown[] = []) => {
    if (text.includes('FROM "user" u WHERE u.id = $1')) {
      const user = state.parents.find((parent) => parent.id === params[0]);
      return {
        rows: [{
          email_verified: user?.verified ?? params[0] === adminId,
          is_admin: params[0] === adminId,
        }],
        rowCount: 1,
      };
    }
    if (text.includes("FROM parent_profiles pp JOIN")) {
      let parents = state.parents.filter((parent) => parent.verified && parent.subscribed !== false);
      if (text.includes("u.id IN ($1)")) {
        const ids = params[0] as string[];
        parents = parents.filter((parent) => ids.includes(parent.id));
      }
      return {
        rows: parents.map(({ id, name, email }) => ({ id, name, email })),
        rowCount: parents.length,
      };
    }
    if (text.includes("INSERT INTO audit_log")) {
      state.auditDescriptions.push(String(params[2]));
      return { rows: [], rowCount: 1 };
    }
    return { rows: [], rowCount: 0 };
  });
  afterEach(() => vi.restoreAllMocks());
});

describe("administrator parent email", () => {
  it("lists only verified parent accounts", async () => {
    const response = await listParents(request("/api/admin/notifications/email"));
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({
      parents: [
        { id: parentId, name: "Parent One", email: "parent@example.test" },
        { id: parentTwoId, name: "Parent Two", email: "parent-two@example.test" },
      ],
    });
  });

  it("requires an administrator to list recipients and send email", async () => {
    state.userId = parentId;
    expect((await listParents(request("/api/admin/notifications/email"))).status).toBe(403);
    expect((await sendEmail(request("/api/admin/notifications/email", "POST", emailBody))).status).toBe(403);
    expect(state.deliveries).toHaveLength(0);
  });

  it("queues a private email per selected parent and audits counts without message contents", async () => {
    const response = await sendEmail(request("/api/admin/notifications/email", "POST", {
      ...emailBody,
      recipientIds: [parentId, parentTwoId],
    }));
    expect(response.status).toBe(202);
    expect(await response.json()).toEqual({ queuedCount: 2, totalCount: 2 });
    expect(state.deliveries).toHaveLength(2);
    expect(state.deliveries.map((delivery) => delivery.to)).toEqual(["parent@example.test", "parent-two@example.test"]);
    expect(state.deliveries[0]).toMatchObject({ subject: emailBody.subject, text: emailBody.message });
    expect(state.auditDescriptions[0]).toBe("Queued an administrator email to 2 parents.");
    expect(state.auditDescriptions[0]).not.toContain(emailBody.message);
  });

  it("resolves all subscribed verified parents when queuing a broadcast", async () => {
    const response = await sendEmail(request("/api/admin/notifications/email", "POST", {
      allParents: true,
      recipientIds: [],
      subject: emailBody.subject,
      message: emailBody.message,
    }));
    expect(response.status).toBe(202);
    expect(await response.json()).toEqual({ queuedCount: 2, totalCount: 2 });
    expect(state.deliveries).toHaveLength(2);
  });

  it("does not claim acceptance when durable enqueue fails", async () => {
    state.failures.add("parent@example.test");
    vi.spyOn(console, "error").mockImplementation(() => {});
    expect((await sendEmail(request("/api/admin/notifications/email", "POST", emailBody))).status).toBe(500);
  });

  it("rejects stale or non-parent recipient IDs without sending", async () => {
    const response = await sendEmail(request("/api/admin/notifications/email", "POST", {
      ...emailBody,
      recipientIds: [unverifiedParentId],
    }));
    expect(response.status).toBe(400);
    expect(state.deliveries).toHaveLength(0);
  });

  it("rejects cross-origin email sends", async () => {
    const response = await sendEmail(request("/api/admin/notifications/email", "POST", emailBody, "https://attacker.example"));
    expect(response.status).toBe(403);
    expect(state.deliveries).toHaveLength(0);
  });

  it("excludes unsubscribed parents from lists and rejects an explicitly selected unsubscribed account", async () => {
    state.parents[0].subscribed = false;
    const response = await listParents(request("/api/admin/notifications/email"));
    expect(await response.json()).toMatchObject({ parents: [{ id: parentTwoId }] });
    expect((await sendEmail(request("/api/admin/notifications/email", "POST", emailBody))).status).toBe(400);
    expect(state.deliveries).toHaveLength(0);
    expect(state.query).toHaveBeenCalledWith(
      expect.stringContaining("pp.email_notifications_subscribed=true"), expect.any(Array),
    );
  });
});
