import { NextRequest } from "next/server";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { TestDatabase } from "./test-database";
import type { Executor } from "./db";
import { SONG_ROLES } from "../lib/contracts";

const state = vi.hoisted(() => ({ database: null as TestDatabase | null, userId: "admin" as string | null }));
vi.mock("./db", () => ({
  db: { ready: Promise.resolve() },
  query: <T>(sql: string, params?: unknown[]) => state.database!.query<T>(sql, params),
  transaction: <T>(work: (tx: Executor) => Promise<T>) => state.database!.transaction(work),
}));
vi.mock("./auth", () => ({
  getAuth: () => ({ api: { getSession: async () => state.userId
    ? { user: { id: state.userId, name: "Test", email: "test@example.test" } } : null } }),
}));

import { PATCH } from "../app/api/admin/seasons/[id]/songs/[songId]/route";
import { POST as addSong } from "../app/api/admin/events/[id]/songs/route";
import { POST as addEvent } from "../app/api/admin/seasons/[id]/events/route";
import { POST as copyEvent } from "../app/api/admin/events/[id]/copy/route";
import { GET as parentSeasons } from "../app/api/parent/seasons/route";
import { adminData } from "./admin-data";

const seasonId = "00000000-0000-4000-8000-000000000001";
const otherId = "00000000-0000-4000-8000-000000000002";
const songId = "00000000-0000-4000-8000-000000000003";
const eventId = "00000000-0000-4000-8000-000000000004";
const otherEvent = "00000000-0000-4000-8000-000000000005";
const sheetId = "00000000-0000-4000-8000-000000000006";
const origin = "http://localhost:3000";
function request(body?: unknown, requestOrigin = origin) {
  return new NextRequest(`${origin}/api/admin/seasons`, {
    method: body ? "POST" : "GET",
    headers: { origin: requestOrigin, "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
}
function set(body: unknown, season = seasonId, selectedSong = songId, requestOrigin = origin) {
  return PATCH(request(body, requestOrigin), { params: Promise.resolve({ id: season, songId: selectedSong }) });
}
async function role(season = seasonId) {
  return (await state.database!.query<{ song_role: string | null; allow_extra: boolean }>(
    "SELECT song_role,allow_extra FROM season_song_settings WHERE season_id=$1 AND song_id=$2", [season, songId],
  )).rows[0];
}
beforeAll(async () => { state.database = new TestDatabase(); await state.database.initialize(); }, 120000);
beforeEach(async () => {
  state.userId = "admin";
  await state.database!.exec(`
    RESET_TEST_DATABASE;
    INSERT INTO "user"(id,name,email,"emailVerified") VALUES
      ('admin','Admin','admin@example.test',true),('parent','Parent','parent@example.test',true);
    INSERT INTO admin_users(user_id) VALUES ('admin');
    INSERT INTO seasons(id,name,start_date,end_date,registration_opens_at,registration_closes_at,timezone,status) VALUES
      ('${seasonId}','Season one','2031-01-01','2031-12-31','2031-01-01','2031-12-31','UTC','Published'),
      ('${otherId}','Season two','2031-01-01','2031-12-31','2031-01-01','2031-12-31','UTC','Published');
    INSERT INTO songs(id,title) VALUES ('${songId}','Shared song');
    INSERT INTO sheets(id,song_id,label,current_version) VALUES ('${sheetId}','${songId}','Score',1);
    INSERT INTO sheet_versions(sheet_id,version,file_name,storage_key,size_bytes) VALUES ('${sheetId}',1,'score.pdf','role-test.pdf',10);
    INSERT INTO events(id,season_id,name,starts_at,ends_at) VALUES
      ('${eventId}','${seasonId}','First','2031-02-01 10:00:00','2031-02-01 11:00:00'),
      ('${otherEvent}','${otherId}','Second','2031-02-02 10:00:00','2031-02-02 11:00:00');
    INSERT INTO event_songs(id,event_id,song_id,position) VALUES ('existing','${eventId}','${songId}',1);
  `);
});
afterAll(async () => { await state.database?.destroy(); });

describe("season-specific song roles", () => {
  it.each(SONG_ROLES)("persists %s without changing library or other seasons", async (songRole) => {
    expect((await set({ songRole })).status).toBe(200);
    expect(await role()).toMatchObject({ song_role: songRole, allow_extra: false });
    expect(await role(otherId)).toBeUndefined();
    expect((await state.database!.query<{ title: string }>("SELECT title FROM songs WHERE id=$1", [songId])).rows[0].title).toBe("Shared song");
  });

  it("clears the role without resetting extra-song registration", async () => {
    expect((await set({ songRole: "Special Song", allowExtra: true, confirmImpact: true })).status).toBe(200);
    expect((await set({ songRole: null })).status).toBe(200);
    expect(await role()).toMatchObject({ song_role: null, allow_extra: true });
    await set({ allowExtra: false, confirmImpact: true });
    expect(await role()).toMatchObject({ song_role: null, allow_extra: false });
  });

  it("shares roles across appearances and exposes them to administrators and parents", async () => {
    await set({ songRole: "Opening Song" });
    expect((await addSong(request({ songId, sheetIds: [sheetId], notes: "", requirements: [] }), { params: Promise.resolve({ id: eventId }) })).status).toBe(201);
    const data = await adminData();
    expect(data.seasons.find((season) => season.id === seasonId)!.events[0].songs.map((song) => song.songRole)).toEqual(["Opening Song", "Opening Song"]);
    state.userId = "parent";
    const response = await parentSeasons(request());
    const listing = await response.json();
    expect(listing.seasons.find((season: { id: string }) => season.id === seasonId).events[0].songs.map((song: { songRole: string }) => song.songRole)).toEqual(["Opening Song", "Opening Song"]);
  });

  it("sets a role atomically when adding a song and inherits it on later additions", async () => {
    expect((await addSong(request({ songId, sheetIds: [sheetId], notes: "", requirements: [], songRole: "Closing Song" }), { params: Promise.resolve({ id: otherEvent }) })).status).toBe(201);
    expect(await role(otherId)).toMatchObject({ song_role: "Closing Song" });
    expect(await role()).toBeUndefined();
    expect((await addSong(request({ songId, sheetIds: [sheetId], requirements: [], songRole: "Invalid" }), { params: Promise.resolve({ id: otherEvent }) })).status).toBe(400);
    expect((await state.database!.query("SELECT id FROM event_songs WHERE event_id=$1", [otherEvent])).rowCount).toBe(1);
  });

  it("supports role selection in the new event flow", async () => {
    const response = await addEvent(request({
      name: "New event", startsAt: "2031-03-01T10:00:00Z", endsAt: "2031-03-01T11:00:00Z", location: "",
      songs: [{ songId, sheetIds: [sheetId], requirements: [], songRole: "Offertory Song" }],
    }), { params: Promise.resolve({ id: seasonId }) });
    expect(response.status).toBe(201);
    expect(await role()).toMatchObject({ song_role: "Offertory Song" });
  });

  it("does not copy the source season role into a different season", async () => {
    await set({ songRole: "Opening Song" });
    await state.database!.query("INSERT INTO season_song_settings(season_id,song_id,song_role) VALUES ($1,$2,$3)", [otherId, songId, "Special Song"]);
    const response = await copyEvent(request({ targetEventId: otherEvent }), { params: Promise.resolve({ id: eventId }) });
    expect(response.status).toBe(201);
    expect(await role(otherId)).toMatchObject({ song_role: "Special Song" });
    expect(await role()).toMatchObject({ song_role: "Opening Song" });
  });

  it("rejects invalid roles, empty changes, unassigned songs, and unauthorized writes", async () => {
    expect((await set({ songRole: "Other Song" })).status).toBe(400);
    expect((await set({})).status).toBe(400);
    expect((await set({ songRole: "Opening Song" }, otherId)).status).toBe(404);
    expect((await set({ songRole: "Opening Song" }, seasonId, songId, "https://other.example.test")).status).toBe(403);
    state.userId = "parent";
    expect((await set({ songRole: "Opening Song" })).status).toBe(403);
    state.userId = null;
    expect((await set({ songRole: "Opening Song" })).status).toBe(401);
  });
});
