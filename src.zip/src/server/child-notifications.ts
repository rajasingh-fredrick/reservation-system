import { randomUUID } from "node:crypto";
import { query, transaction, type Executor } from "./db";
import { sendMail } from "./mail";

type Kind = "Welcome" | "Acknowledgement";
type Recipient = "Parent" | "Administrator";
const administratorEmail = "kidsmusic-coord@tamilgospelchurch.org";
export type ChildNotificationStatus = "Pending" | "Sending" | "Sent" | "Failed" | "Preview";

export function childRegistrationAdminEmail(parentName: string, parentEmail: string, childName: string) {
  const dashboard = new URL("/dashboard", process.env.APP_URL || "http://localhost:3000").href;
  return {
    subject: "New child registration - Tamil Gospel Church",
    text: `A new child profile has been submitted for the children's music ministry.

Child: ${childName}
Parent or guardian: ${parentName}
Parent email: ${parentEmail}

The profile is pending administrator approval. Review the child's profile in the administrator workspace:
${dashboard}`,
  };
}

export function childProfileEmail(kind: Kind, parentName: string, childName: string) {
  const dashboard = new URL("/parent", process.env.APP_URL || "http://localhost:3000").href;
  if (kind === "Acknowledgement") {
    return {
      subject: "Child profile received - Tamil Gospel Church",
      text: `Dear ${parentName},

We have received the child profile for ${childName} for Tamil Gospel Church's children's music ministry. Our ministry team will review it and send a separate approval or rejection notification. Submitting a profile does not reserve a performance spot.

You can review your family's profiles and next steps on the parent dashboard:
${dashboard}

With warm regards,
Mrs. Amy Priya Shibu
Ministry Coordinator
Tamil Gospel Church`,
    };
  }
  return {
    subject: "Welcome to Tamil Gospel Church's Children's Music Ministry!",
    text: `Dear ${parentName},

Welcome to the children's music ministry at Tamil Gospel Church! We are delighted that your family is joining us as our children grow in their musical gifts and use them to worship and serve the Lord.

We have received the registration for ${childName}. Our ministry team will review the submitted profile, and you will receive a separate notification once it has been approved. Registering a child's profile does not yet reserve a performance spot.

What happens next?

- Once your child's profile is approved, sign in to view upcoming ministry events and available songs and instrument spots.
- Choose an available opportunity that matches your child's approved instruments.
- Use the music sheets and practice resources provided for the selected song.

For each performance, please send a practice recording at least three days before the performance date. This allows our ministry coordinator, Mrs. Amy Priya Shibu, to review the recording, speak with you about any corrections, and help your child feel prepared and confident.

Parent dashboard: ${dashboard}

Under the pastoral leadership of Pastor Solomon Karunakaran, we look forward to encouraging your child and serving the Lord together.

Thank you for your support and partnership!

With warm regards,
Mrs. Amy Priya Shibu
Ministry Coordinator
Tamil Gospel Church`,
  };
}

export async function queueChildNotification(tx: Executor, parentId: string, childId: string, firstChild: boolean) {
  const id = randomUUID();
  await tx.query(
    "INSERT INTO child_profile_notifications (id,child_id,parent_user_id,kind) VALUES ($1,$2,$3,$4)",
    [id, childId, parentId, firstChild ? "Welcome" : "Acknowledgement"],
  );
  return id;
}

export async function queueChildAdminNotification(tx: Executor, parentId: string, childId: string) {
  const id = randomUUID();
  await tx.query(
    "INSERT INTO child_profile_notifications (id,child_id,parent_user_id,kind,recipient) VALUES ($1,$2,$3,$4,$5)",
    [id, childId, parentId, "Acknowledgement", "Administrator"],
  );
  return id;
}

export async function deliverChildNotification(id: string): Promise<ChildNotificationStatus> {
  const claimed = await transaction<
    { status: ChildNotificationStatus } | { email: ReturnType<typeof childProfileEmail>; to: string }
  >(async (tx) => {
    const result = await tx.query<{
      status: ChildNotificationStatus; kind: Kind; recipient: Recipient; name: string; email: string;
      email_verified: boolean; child_name: string;
    }>(
      `SELECT n.status,n.kind,n.recipient,u.name,u.email,u."emailVerified" AS email_verified,c.full_name AS child_name
       FROM child_profile_notifications n JOIN "user" u ON u.id=n.parent_user_id
       JOIN children c ON c.id=n.child_id WHERE n.id=$1 FOR UPDATE`,
      [id],
    );
    const row = result.rows[0];
    if (!row) throw new Error("Child profile notification not found.");
    if (row.status !== "Pending" && row.status !== "Failed") return { status: row.status };
    if (row.recipient === "Parent" && !row.email_verified) {
      await tx.query("UPDATE child_profile_notifications SET status='Failed' WHERE id=$1", [id]);
      console.error("Child profile notification blocked: parent email is unverified", { notificationId: id });
      return { status: "Failed" };
    }
    const email = row.recipient === "Administrator"
      ? childRegistrationAdminEmail(row.name, row.email, row.child_name)
      : childProfileEmail(row.kind, row.name, row.child_name);
    await tx.query(
      "UPDATE child_profile_notifications SET status='Sending',attempts=attempts+1,last_attempt_at=UTC_TIMESTAMP(3) WHERE id=$1",
      [id],
    );
    return { email, to: row.recipient === "Administrator" ? administratorEmail : row.email };
  });
  if ("status" in claimed) return claimed.status;

  try {
    await sendMail(claimed.to, claimed.email.subject, claimed.email.text);
  } catch {
    // SMTP errors may contain recipient data; log only the durable notification ID.
    console.error("Child profile email delivery failed", { notificationId: id });
    await query("UPDATE child_profile_notifications SET status='Failed' WHERE id=$1 AND status='Sending'", [id]);
    return "Failed";
  }
  const status = process.env.NODE_ENV === "production" ? "Sent" : "Preview";
  await query(
    `UPDATE child_profile_notifications SET status=$1,sent_at=$2 WHERE id=$3 AND status='Sending'`,
    [status, status === "Sent" ? new Date() : null, id],
  );
  return status;
}
