"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowRight, MailCheck } from "lucide-react";
import { MusicIcon } from "@/components/ui/Motifs";
import { api, errorMessage } from "@/lib/client";
import { InlineError, Notice } from "@/components/ui/Feedback";

export default function VerifyEmailPage() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function resend(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const result = await api<{ message: string }>("/api/verification/resend", {
        method: "POST",
        json: { email: email.trim() },
      });
      setMessage(result.message);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="gradient-canvas flex min-h-dvh items-center justify-center px-4 py-10">
      <section className="gradient-surface w-full max-w-lg rounded-3xl border border-parchment-300 p-6 shadow-[var(--shadow-lift)] sm:p-9">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl gradient-brand text-ink"><MailCheck className="h-6 w-6" aria-hidden="true" /></div>
        <p className="eyebrow mt-6">Email verification</p>
        <h1 className="mt-1 font-serif text-3xl text-forest-900">Verify your account</h1>
        <p className="mt-3 text-sm leading-relaxed text-ink-soft">Use the single-use link sent to your email address. If the link has expired or you haven’t received it, request another below. For development accounts, check the notification worker terminal for the verification link.</p>
        {message ? <Notice className="mt-5" tone="success">{message}</Notice> : null}
        <form onSubmit={resend} className="mt-6 space-y-4">
          <div><label htmlFor="verification-email" className="field-label">Email address</label><input id="verification-email" type="email" autoComplete="email" className="input" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={320} disabled={busy} /></div>
          <InlineError message={error} />
          <button type="submit" className="btn-primary min-h-11 w-full justify-center" disabled={busy} aria-busy={busy}><MusicIcon className="h-4 w-4" aria-hidden="true" />{busy ? "Sending…" : "Resend verification email"}</button>
        </form>
        <p className="mt-6 border-t border-parchment-200 pt-5 text-sm text-ink-muted">Already verified? <Link href="/sign-in" className="font-medium text-forest-800 underline-offset-4 hover:underline">Sign in<ArrowRight className="ml-1 inline h-3.5 w-3.5" aria-hidden="true" /></Link></p>
      </section>
    </main>
  );
}