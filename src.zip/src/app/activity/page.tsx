import { AdminShell } from "@/components/shell/AdminShell";
import { ActivityView } from "@/components/activity/ActivityView";

export default function ActivityPage() {
  return (
    <AdminShell>
      <ActivityView />
    </AdminShell>
  );
}