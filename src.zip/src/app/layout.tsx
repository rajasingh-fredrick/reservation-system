import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-plus-jakarta",
});

export const metadata: Metadata = {
  title: { default: "Harmony \u00b7 Music Ministry", template: "%s \u00b7 Harmony" },
  description: "Family registrations and music ministry coordination for the children\u2019s program.",
  icons: { icon: "/music_icon.jpg", apple: "/music_icon.jpg" },
};

export const viewport: Viewport = {
  themeColor: "#57549a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={plusJakarta.variable}>
      <body>
        <a
          href="#main"
          className="sr-only-focusable fixed left-3 top-3 z-[100] rounded-lg gradient-brand px-4 py-2 text-sm font-semibold text-ink"
        >
          Skip to main content
        </a>
        {children}
      </body>
    </html>
  );
}