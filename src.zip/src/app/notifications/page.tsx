import { AdminEmailComposer } from "@/components/dashboard/AdminEmailComposer";
import { AdminShell } from "@/components/shell/AdminShell";

export default function NotificationsPage() {
  return (
    <AdminShell>
      <AdminEmailComposer />
    </AdminShell>
  );
}
