import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Harmony Music Ministry",
    short_name: "Harmony",
    description: "Family registrations and music ministry coordination.",
    start_url: "/sign-in",
    display: "standalone",
    background_color: "#f5f7ff",
    theme_color: "#312e81",
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" },
    ],
  };
}