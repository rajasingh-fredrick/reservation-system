import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Harmony Music Ministry",
    short_name: "Harmony",
    description: "Family registrations and music ministry coordination.",
    start_url: "/sign-in",
    display: "standalone",
    background_color: "#f7f7fb",
    theme_color: "#57549a",
    icons: [
      { src: "/music_icon.jpg", sizes: "360x202", type: "image/jpeg", purpose: "any" },
    ],
  };
}