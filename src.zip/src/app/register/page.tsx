"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowRight, Music2 } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { InlineError } from "@/components/ui/Feedback";
import { HarmonyMark, StaffFlourish } from "@/components/ui/Motifs";

export default function RegisterPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [policiesAccepted, setPoliciesAccepted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState(false);
  const [createdMessage, setCreatedMessage] = useState("");
  const [emailSent, setEmailSent] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await api<{ message: string; emailSent: boolean }>("/api/register", {
        method: "POST",
        json: {
          name: name.trim(), email: email.trim(), phone: phone.trim(), password,
          authorizedChildRegistration: authorized,
          privacyAccepted,
          policiesAccepted,
        },
      });
      setCreatedMessage(result.message);
      setEmailSent(result.emailSent);
      setCreated(true);
      setPassword("");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-parchment-100 px-4 py-10 sm:px-6">
      <StaffFlourish className="pointer-events-none absolute -right-24 top-12 hidden h-48 w-[38rem] text-forest-800/10 lg:block" />
      <section className="relative grid w-full max-w-5xl overflow-hidden rounded-3xl border border-parchment-300 bg-parchment-50 shadow-[var(--shadow-lift)] md:grid-cols-[0.9fr_1.1fr]">
        <div className="relative flex min-h-64 flex-col justify-between overflow-hidden bg-forest-900 p-7 text-parchment-50 sm:p-10">
          <StaffFlourish className="pointer-events-none absolute -bottom-3 -right-10 h-36 w-[30rem] text-amber-accent/20" />
          <Link href="/" className="relative inline-flex w-fit items-center gap-3 rounded-xl focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-amber-soft">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-amber-accent/15 ring-1 ring-amber-accent/40"><HarmonyMark className="h-7 w-7" /></span>
            <span><span className="block font-serif text-xl font-semibold">Harmony</span><span className="block text-[0.7rem] uppercase tracking-[0.18em] text-amber-soft/80">Music ministry</span></span>
          </Link>
          <div className="relative mt-10 max-w-md">
            <Music2 className="mb-4 h-7 w-7 text-amber-soft" aria-hidden="true" />
            <p className="eyebrow text-amber-soft">Family account</p>
            <h1 className="mt-2 font-serif text-3xl leading-tight sm:text-4xl">A place for every young musician.</h1>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-parchment-200">Create a parent account to manage your children’s profiles and ministry registrations.</p>
          </div>
        </div>

        <div className="p-6 sm:p-10">
          {created ? (
            <div className="space-y-5" role="status">
              <p className="eyebrow">One more step</p>
              <h2 className="font-serif text-2xl text-forest-900">Check your email</h2>
              <p className="text-sm leading-relaxed text-ink-soft">{createdMessage} Address: <strong>{email.trim().toLowerCase()}</strong>{emailSent && process.env.NODE_ENV !== "production" ? " In development, the verification link is printed in the server terminal." : ""}</p>
              {emailSent ? <Link href="/sign-in" className="btn-primary inline-flex">Continue to sign in<ArrowRight className="h-4 w-4" aria-hidden="true" /></Link> : <Link href="/verify-email" className="btn-primary inline-flex">Resend verification email<ArrowRight className="h-4 w-4" aria-hidden="true" /></Link>}
            </div>
          ) : (
            <>
              <div className="mb-6">
                <p className="eyebrow">Parent or guardian</p>
                <h2 className="mt-1 font-serif text-2xl text-forest-900">Create your account</h2>
                <p className="mt-2 text-sm text-ink-soft">Your email address will be your sign-in username.</p>
              </div>
              <form onSubmit={submit} className="space-y-4">
                <div><label htmlFor="parent-name" className="field-label">Full name</label><input id="parent-name" className="input" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} required maxLength={120} disabled={busy} /></div>
                <div><label htmlFor="parent-email" className="field-label">Email address</label><input id="parent-email" type="email" className="input" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={320} disabled={busy} /></div>
                <div><label htmlFor="parent-phone" className="field-label">Phone number <span className="font-normal text-ink-muted">(optional)</span></label><input id="parent-phone" type="tel" className="input" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} maxLength={40} disabled={busy} /></div>
                <div><label htmlFor="parent-password" className="field-label">Password</label><input id="parent-password" type="password" className="input" autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={12} maxLength={128} disabled={busy} /><p className="field-hint">Use at least 12 characters.</p></div>
                <fieldset className="space-y-3 rounded-xl border border-parchment-300 bg-parchment-100/60 p-4">
                  <legend className="px-1 text-sm font-semibold text-ink">Acknowledgments</legend>
                  <label className="flex min-h-11 items-start gap-3 text-sm leading-relaxed text-ink-soft"><input type="checkbox" className="mt-1 h-4 w-4 shrink-0 accent-forest-800" checked={authorized} onChange={(event) => setAuthorized(event.target.checked)} required disabled={busy} /><span>I am authorized to register the child or children in my care.</span></label>
                  <label className="flex min-h-11 items-start gap-3 text-sm leading-relaxed text-ink-soft"><input type="checkbox" className="mt-1 h-4 w-4 shrink-0 accent-forest-800" checked={privacyAccepted} onChange={(event) => setPrivacyAccepted(event.target.checked)} required disabled={busy} /><span>I acknowledge the privacy notice and understand that child profile details are restricted to my family and ministry administrators.</span></label>
                  <label className="flex min-h-11 items-start gap-3 text-sm leading-relaxed text-ink-soft"><input type="checkbox" className="mt-1 h-4 w-4 shrink-0 accent-forest-800" checked={policiesAccepted} onChange={(event) => setPoliciesAccepted(event.target.checked)} required disabled={busy} /><span>I agree to follow the church’s music ministry and registration policies.</span></label>
                </fieldset>
                <InlineError message={error} />
                <button type="submit" className="btn-primary w-full justify-center" disabled={busy} aria-busy={busy}>{busy ? "Creating account…" : "Create parent account"}<ArrowRight className="h-4 w-4" aria-hidden="true" /></button>
              </form>
              <p className="mt-6 border-t border-parchment-200 pt-5 text-sm text-ink-muted">Already registered? <Link href="/sign-in" className="font-medium text-forest-800 underline-offset-4 hover:underline">Sign in</Link></p>
            </>
          )}
        </div>
      </section>
    </main>
  );
}