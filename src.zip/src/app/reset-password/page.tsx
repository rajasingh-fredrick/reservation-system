"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowLeft, KeyRound } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { InlineError, Notice } from "@/components/ui/Feedback";

export default function ResetPasswordPage() {
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [complete, setComplete] = useState(false);

  useEffect(() => {
    setToken(new URLSearchParams(window.location.search).get("token") ?? "");
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/reset-password", { method: "POST", json: { token, newPassword: password } });
      setComplete(true);
      setPassword("");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="gradient-canvas flex min-h-dvh items-center justify-center px-4 py-10">
      <section className="gradient-surface w-full max-w-lg rounded-3xl border border-parchment-300 p-6 shadow-[var(--shadow-lift)] sm:p-9">
        <Link href="/sign-in" className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-forest-800 underline-offset-4 hover:underline"><ArrowLeft className="h-4 w-4" aria-hidden="true" />Back to sign in</Link>
        <span className="mt-6 grid h-12 w-12 place-items-center rounded-xl gradient-brand text-ink"><KeyRound className="h-6 w-6" aria-hidden="true" /></span>
        <p className="eyebrow mt-5">Password recovery</p>
        <h1 className="mt-1 font-serif text-3xl text-forest-900">Choose a new password</h1>
        {complete ? <Notice tone="success" className="mt-5">Your password has been changed. Sign in with the new password.</Notice> : !token ? <Notice tone="warn" className="mt-5">This reset link is invalid or expired. Request a new link from sign-in help.</Notice> : (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div><label htmlFor="new-password" className="field-label">New password</label><input id="new-password" type="password" className="input" autoComplete="new-password" minLength={12} maxLength={128} value={password} onChange={(event) => setPassword(event.target.value)} required disabled={busy} /><p className="field-hint">Use at least 12 characters.</p></div>
            <InlineError message={error} />
            <button type="submit" className="btn-primary min-h-11 w-full justify-center" disabled={busy} aria-busy={busy}><KeyRound className="h-4 w-4" aria-hidden="true" />{busy ? "Updating…" : "Update password"}</button>
          </form>
        )}
        <p className="mt-6 border-t border-parchment-200 pt-5 text-sm text-ink-muted">Need a fresh link? <Link href="/sign-in/help" className="font-medium text-forest-800 underline-offset-4 hover:underline">Request password reset</Link></p>
      </section>
    </main>
  );
}