import { AdminShell } from "@/components/shell/AdminShell";
import { LibraryView } from "@/components/library/LibraryView";

export default function HomePage() {
  return (
    <AdminShell>
      <LibraryView />
    </AdminShell>
  );
}