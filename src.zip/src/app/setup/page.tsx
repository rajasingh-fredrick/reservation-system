"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowLeft, KeyRound } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { InlineError } from "@/components/ui/Feedback";
import { HarmonyMark, StaffFlourish } from "@/components/ui/Motifs";

type SetupState = "checking" | "available" | "complete" | "created" | "error";

export default function SetupPage() {
  const [state, setState] = useState<SetupState>("checking");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  async function checkSetup() {
    setState("checking");
    setError(null);
    try {
      const result = await api<{ needsSetup: boolean }>("/api/setup");
      setState(result.needsSetup ? "available" : "complete");
    } catch (err) {
      setError(errorMessage(err));
      setState("error");
    }
  }

  useEffect(() => {
    void checkSetup();
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await api<{ message: string }>("/api/setup", {
        method: "POST",
        json: { name: name.trim(), email: email.trim(), token, password },
      });
      setMessage(result.message);
      setToken("");
      setPassword("");
      setState("created");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-parchment-100 px-4 py-10 sm:px-6">
      <StaffFlourish className="pointer-events-none absolute -right-24 top-12 hidden h-48 w-[38rem] text-forest-800/10 lg:block" />
      <section className="relative w-full max-w-xl rounded-3xl border border-parchment-300 bg-parchment-50 p-6 shadow-[var(--shadow-lift)] sm:p-10">
        <Link href="/sign-in" className="inline-flex items-center gap-2 text-sm font-medium text-forest-800 underline-offset-4 hover:underline"><ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back to sign in</Link>
        <div className="mt-7 flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-forest-900 text-amber-soft"><HarmonyMark className="h-7 w-7" /></span>
          <div><p className="eyebrow">Secure first-time setup</p><h1 className="font-serif text-2xl text-forest-900">Administrator account</h1></div>
        </div>

        {state === "checking" ? <p className="mt-7 text-sm text-ink-muted" role="status">Checking setup status…</p> : null}
        {state === "complete" ? (
          <div className="mt-7 space-y-4" role="status">
            <p className="rounded-xl border border-parchment-300 bg-parchment-100 p-4 text-sm text-ink-soft">Initial administrator setup has already been completed.</p>
            <Link href="/sign-in" className="btn-primary inline-flex">Go to sign in</Link>
          </div>
        ) : null}
        {state === "created" ? (
          <div className="mt-7 space-y-4" role="status">
            <p className="rounded-xl border border-forest-300 bg-forest-50 p-4 text-sm leading-relaxed text-forest-900">{message}</p>
            <Link href="/sign-in" className="btn-primary inline-flex">Continue to sign in</Link>
          </div>
        ) : null}
        {state === "error" ? (
          <div className="mt-7 space-y-4">
            <InlineError message={error} />
            <button type="button" className="btn-secondary" onClick={() => void checkSetup()}>Check again</button>
          </div>
        ) : null}
        {state === "available" ? (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <p className="text-sm leading-relaxed text-ink-soft">The initial administrator is created once. Get the one-time setup token from your server configuration or local development terminal.</p>
            <div><label htmlFor="setup-name" className="field-label">Administrator name</label><input id="setup-name" className="input mt-1" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} required maxLength={120} disabled={busy} /></div>
            <div><label htmlFor="setup-email" className="field-label">Email address</label><input id="setup-email" type="email" className="input mt-1" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={320} disabled={busy} /></div>
            <div><label htmlFor="setup-token" className="field-label">One-time setup token</label><input id="setup-token" type="password" className="input mt-1" autoComplete="off" value={token} onChange={(event) => setToken(event.target.value)} required disabled={busy} /></div>
            <div><label htmlFor="setup-password" className="field-label">Password</label><input id="setup-password" type="password" className="input mt-1" autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} required minLength={12} maxLength={128} disabled={busy} /><p className="mt-1 text-xs text-ink-muted">Use at least 12 characters.</p></div>
            <InlineError message={error} />
            <button type="submit" className="btn-primary w-full justify-center" disabled={busy} aria-busy={busy}>
              <KeyRound className="h-4 w-4" aria-hidden="true" /> {busy ? "Creating account…" : "Create administrator"}
            </button>
          </form>
        ) : null}
      </section>
    </main>
  );
}