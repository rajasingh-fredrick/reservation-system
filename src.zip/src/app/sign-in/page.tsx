"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, KeyRound } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { InlineError } from "@/components/ui/Feedback";
import { MusicIcon, HarmonyMark, StaffFlourish } from "@/components/ui/Motifs";

export default function SignInPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/sign-in/email", {
        method: "POST",
        json: { email: email.trim().toLowerCase(), password },
      });
      const requested = new URLSearchParams(window.location.search).get("next");
      const next = requested && requested.startsWith("/") && !requested.startsWith("//")
        ? requested
        : (await api<{ user: { isAdmin: boolean } | null }>("/api/session")).user?.isAdmin ? "/" : "/parent";
      router.replace(next);
      router.refresh();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  const signedOut = new URLSearchParams(typeof window === "undefined" ? "" : window.location.search).has("signedOut");
  const verified = new URLSearchParams(typeof window === "undefined" ? "" : window.location.search).has("verified");

  return (
    <main className="gradient-canvas relative flex min-h-dvh items-center justify-center overflow-hidden px-4 py-10 sm:px-6">
      <StaffFlourish className="pointer-events-none absolute -right-24 top-12 hidden h-48 w-[38rem] text-forest-800/10 lg:block" />
      <section className="gradient-surface relative grid w-full max-w-5xl overflow-hidden rounded-3xl border border-parchment-300 shadow-[var(--shadow-lift)] md:grid-cols-[1.05fr_0.95fr]">
        <div className="gradient-brand relative flex min-h-64 flex-col justify-between overflow-hidden p-7 text-ink sm:p-10">
          <StaffFlourish className="pointer-events-none absolute -bottom-3 -right-10 h-36 w-[30rem] text-amber-accent/20" />
          <Link href="/" className="relative inline-flex w-fit items-center gap-3 rounded-xl focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-amber-soft">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/60 ring-1 ring-white/70"><HarmonyMark className="h-7 w-7" /></span>
            <span><span className="block font-serif text-xl font-semibold">Harmony</span><span className="block text-[0.7rem] uppercase tracking-[0.18em] text-ink">Music ministry</span></span>
          </Link>
          <div className="relative mt-10 max-w-md">
            <MusicIcon className="mb-4 h-7 w-7 text-ink" aria-hidden="true" />
            <p className="eyebrow text-ink">Administrator workspace</p>
            <h1 className="mt-2 font-serif text-3xl leading-tight sm:text-4xl">Make every part ready to play.</h1>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-ink">Sign in to manage the shared song library, music sheets, seasons and events.</p>
          </div>
        </div>

        <div className="p-6 sm:p-10">
          <div className="mb-7">
            <p className="eyebrow">Welcome back</p>
            <h2 className="mt-1 font-serif text-2xl text-forest-900">Sign in</h2>
            <p className="mt-2 text-sm text-ink-soft">Use the verified email address for your administrator account.</p>
          </div>
          {signedOut ? <p className="mb-4 rounded-xl border border-forest-300 gradient-tint px-3 py-2 text-sm text-forest-900" role="status">You have signed out.</p> : null}
          {verified ? <p className="mb-4 rounded-xl border border-forest-300 gradient-tint px-3 py-2 text-sm text-forest-900" role="status">Email verified. You can sign in now.</p> : null}
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label htmlFor="email" className="field-label">Email address</label>
              <input id="email" name="email" type="email" autoComplete="username" className="input mt-1" value={email} onChange={(event) => setEmail(event.target.value)} required disabled={busy} />
            </div>
            <div>
              <label htmlFor="password" className="field-label">Password</label>
              <input id="password" name="password" type="password" autoComplete="current-password" className="input mt-1" value={password} onChange={(event) => setPassword(event.target.value)} required disabled={busy} />
            </div>
            <InlineError message={error} />
            <button type="submit" className="btn-primary w-full justify-center" disabled={busy} aria-busy={busy}>
              {busy ? "Signing in…" : "Sign in"}<ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </form>
          <div className="mt-6 border-t border-parchment-200 pt-5 text-sm">
            <Link href="/sign-in/help" className="inline-flex min-h-11 items-center gap-2 font-medium text-forest-800 underline-offset-4 hover:underline">
              <KeyRound className="h-4 w-4" aria-hidden="true" /> Forgot your username or password?
            </Link>
          </div>
          <div className="mt-5 border-t border-parchment-200 pt-5 text-sm">
            <p className="text-ink-muted">New to the ministry?</p>
            <Link href="/register" className="mt-2 inline-flex items-center gap-2 font-medium text-forest-800 underline-offset-4 hover:underline">
              <MusicIcon className="h-4 w-4" aria-hidden="true" /> Create a parent account
            </Link>
          </div>
          <div className="mt-5 border-t border-parchment-200 pt-5 text-sm">
            <p className="text-ink-muted">First administrator?</p>
            <Link href="/setup" className="mt-2 inline-flex items-center gap-2 font-medium text-forest-800 underline-offset-4 hover:underline">
              <KeyRound className="h-4 w-4" aria-hidden="true" /> Set up the administrator account
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}