"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowLeft, KeyRound, MailQuestion } from "lucide-react";
import { api, errorMessage } from "@/lib/client";
import { InlineError, Notice } from "@/components/ui/Feedback";

export default function SignInHelpPage() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/request-password-reset", {
        method: "POST",
        json: { email: email.trim().toLowerCase(), redirectTo: `${window.location.origin}/reset-password` },
      });
      setSent(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="gradient-canvas flex min-h-dvh items-center justify-center px-4 py-10">
      <section className="gradient-surface w-full max-w-lg rounded-3xl border border-parchment-300 p-6 shadow-[var(--shadow-lift)] sm:p-9">
        <Link href="/sign-in" className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-forest-800 underline-offset-4 hover:underline"><ArrowLeft className="h-4 w-4" aria-hidden="true" />Back to sign in</Link>
        <span className="mt-6 grid h-12 w-12 place-items-center rounded-xl gradient-brand text-ink"><MailQuestion className="h-6 w-6" aria-hidden="true" /></span>
        <p className="eyebrow mt-5">Sign-in help</p>
        <h1 className="mt-1 font-serif text-3xl text-forest-900">Your username is your email</h1>
        <p className="mt-3 text-sm leading-relaxed text-ink-soft">There is no separate username to retrieve. Enter the email address used for your account to request a password reset. For privacy, we’ll show the same response whether or not an account is associated with that address.</p>
        {sent ? <Notice tone="success" className="mt-5">If an account can receive a reset email, instructions will arrive shortly. Check your inbox and spam folder.</Notice> : (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div><label htmlFor="help-email" className="field-label">Email address</label><input id="help-email" type="email" className="input" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={320} disabled={busy} /></div>
            <InlineError message={error} />
            <button type="submit" className="btn-primary min-h-11 w-full justify-center" disabled={busy} aria-busy={busy}><KeyRound className="h-4 w-4" aria-hidden="true" />{busy ? "Requesting…" : "Request password reset"}</button>
          </form>
        )}
        <p className="mt-6 border-t border-parchment-200 pt-5 text-sm text-ink-muted">Need to verify your email? <Link href="/verify-email" className="font-medium text-forest-800 underline-offset-4 hover:underline">Resend verification</Link></p>
      </section>
    </main>
  );
}