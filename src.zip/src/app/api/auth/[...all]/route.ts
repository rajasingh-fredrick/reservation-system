import { toNextJsHandler } from "better-auth/next-js";
import type { NextRequest } from "next/server";
import { getAuth } from "@/server/auth";
import { db } from "@/server/db";

export const runtime = "nodejs";
let handlers: ReturnType<typeof toNextJsHandler> | undefined;
function getHandlers() {
	if (!handlers) handlers = toNextJsHandler(getAuth());
	return handlers;
}

export async function GET(request: NextRequest) {
	await db.ready;
	return getHandlers().GET(request);
}

export async function POST(request: NextRequest) {
	await db.ready;
	return getHandlers().POST(request);
}
