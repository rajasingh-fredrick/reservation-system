import { NextRequest } from "next/server";
import { getAuth } from "@/server/auth";
import { db, query } from "@/server/db";
import { handle, json } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  return handle(async () => {
    await db.ready;
    const session = await getAuth().api.getSession({ headers: request.headers });
    if (!session?.user) return json({ user: null });
    const result = await query<{ email_verified: boolean; is_admin: boolean }>(
      `SELECT u."emailVerified" AS email_verified,
        EXISTS (SELECT 1 FROM admin_users a WHERE a.user_id=u.id) AS is_admin
       FROM "user" u WHERE u.id=$1`,
      [session.user.id],
    );
    const row = result.rows[0];
    return json({
      user: {
        id: session.user.id,
        name: session.user.name,
        email: session.user.email,
        emailVerified: Boolean(row?.email_verified),
        isAdmin: Boolean(row?.is_admin),
      },
    });
  });
}