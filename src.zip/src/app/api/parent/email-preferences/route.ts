import { NextRequest } from "next/server";
import { query } from "@/server/db";
import { assertSameOrigin, handle, HttpError, json, requireVerifiedUser } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  return handle(async () => {
    const parent = await requireVerifiedUser(request);
    const result = await query<{ subscribed: boolean }>(
      "SELECT email_notifications_subscribed AS subscribed FROM parent_profiles WHERE user_id=$1", [parent.id],
    );
    if (!result.rows[0]) throw new HttpError(403, "A registered parent profile is required.", "PARENT_REQUIRED");
    return json({ subscribed: Boolean(result.rows[0].subscribed) });
  });
}

export async function PATCH(request: NextRequest) {
  return handle(async () => {
    assertSameOrigin(request);
    const parent = await requireVerifiedUser(request);
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || !("subscribed" in body) || typeof body.subscribed !== "boolean") {
      throw new HttpError(400, "Choose whether to subscribe to email notifications.", "INVALID_PREFERENCE");
    }
    const profile = await query("SELECT user_id FROM parent_profiles WHERE user_id=$1", [parent.id]);
    if (!profile.rows.length) throw new HttpError(403, "A registered parent profile is required.", "PARENT_REQUIRED");
    await query("UPDATE parent_profiles SET email_notifications_subscribed=$1,updated_at=UTC_TIMESTAMP(3) WHERE user_id=$2",
      [body.subscribed, parent.id]);
    return json({ subscribed: body.subscribed });
  });
}
