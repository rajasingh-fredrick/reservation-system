import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { queueEmail } from "@/server/email-queue";
import { assertSameOrigin, handle, HttpError, idParam, json, requireVerifiedUser } from "@/server/http";

export const runtime = "nodejs";
type ReservationContext = { params: Promise<{ id: string }> };

export async function DELETE(request: NextRequest, { params }: ReservationContext) {
  return handle(async () => {
    assertSameOrigin(request);
    const parent = await requireVerifiedUser(request);
    const reservationId = idParam((await params).id);
    await transaction(async (tx) => {
      const result = await tx.query<{
        id: string; child_name: string; instrument: string; parent_email: string;
      }>(
        `SELECT r.id,c.full_name AS child_name,r.instrument
         FROM reservations r JOIN children c ON c.id=r.child_id
         JOIN events e ON e.id=r.event_id JOIN seasons s ON s.id=r.season_id
         WHERE r.id=$1 AND c.parent_user_id=$2 AND r.status='Confirmed'
           AND now() <= DATE_SUB(e.starts_at, INTERVAL s.cancellation_hours HOUR)
         FOR UPDATE`,
        [reservationId, parent.id],
      );
      if (result.rows[0]) {
        await tx.query(
          "UPDATE reservations SET status='Cancelled',cancelled_at=now(),updated_at=now() WHERE id=$1",
          [reservationId],
        );
        await queueEmail(tx, {
          userId: parent.id, kind: "ParentTransactional", subject: "Music ministry reservation cancelled",
          text: `The reservation for ${result.rows[0].child_name} (${result.rows[0].instrument}) has been cancelled.`,
        });
        return result.rows[0];
      }
      const owned = await tx.query<{ status: string }>(
        `SELECT r.status FROM reservations r JOIN children c ON c.id=r.child_id
         WHERE r.id=$1 AND c.parent_user_id=$2`,
        [reservationId, parent.id],
      );
      if (!owned.rows.length) throw new HttpError(404, "Reservation not found.", "RESERVATION_NOT_FOUND");
      if (owned.rows[0].status !== "Confirmed") throw new HttpError(409, "This reservation is no longer active.", "RESERVATION_NOT_ACTIVE");
      throw new HttpError(409, "The cancellation cutoff has passed. Contact the ministry coordinator for help.", "CANCELLATION_CUTOFF_PASSED");
    });
    return json({ ok: true, notificationQueued: true });
  });
}