import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { sendMail } from "@/server/mail";
import { assertSameOrigin, handle, HttpError, idParam, json, requireVerifiedUser } from "@/server/http";

export const runtime = "nodejs";
type ReservationContext = { params: Promise<{ id: string }> };

export async function DELETE(request: NextRequest, { params }: ReservationContext) {
  return handle(async () => {
    assertSameOrigin(request);
    const parent = await requireVerifiedUser(request);
    const reservationId = idParam((await params).id);
    const cancelled = await transaction(async (tx) => {
      const result = await tx.query<{
        id: string; child_name: string; instrument: string; parent_email: string;
      }>(
        `UPDATE reservations AS r SET status='Cancelled',cancelled_at=now(),updated_at=now()
         FROM children c
         WHERE r.id=$1 AND r.child_id=c.id AND c.parent_user_id=$2 AND r.status='Confirmed'
           AND now() <= (SELECT e.starts_at FROM events e WHERE e.id=r.event_id)
             - make_interval(hours => (SELECT cancellation_hours FROM seasons WHERE id=r.season_id))
         RETURNING r.id,c.full_name AS child_name,r.instrument`,
        [reservationId, parent.id],
      );
      if (result.rows[0]) return result.rows[0];
      const owned = await tx.query<{ status: string }>(
        `SELECT r.status FROM reservations r JOIN children c ON c.id=r.child_id
         WHERE r.id=$1 AND c.parent_user_id=$2`,
        [reservationId, parent.id],
      );
      if (!owned.rows.length) throw new HttpError(404, "Reservation not found.", "RESERVATION_NOT_FOUND");
      if (owned.rows[0].status !== "Confirmed") throw new HttpError(409, "This reservation is no longer active.", "RESERVATION_NOT_ACTIVE");
      throw new HttpError(409, "The cancellation cutoff has passed. Contact the ministry coordinator for help.", "CANCELLATION_CUTOFF_PASSED");
    });
    try {
      await sendMail(parent.email, "Music ministry reservation cancelled", `The reservation for ${cancelled.child_name} (${cancelled.instrument}) has been cancelled.`);
    } catch (error) {
      console.error("Reservation cancellation email failed", error instanceof Error ? error.message : "unknown error");
    }
    return json({ ok: true });
  });
}