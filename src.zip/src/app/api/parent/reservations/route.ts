import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { z } from "zod";
import { transaction, query } from "@/server/db";
import { queueEmail } from "@/server/email-queue";
import { INSTRUMENTS } from "@/lib/contracts";
import { songBookingGroup } from "@/server/season-songs";
import { assertSameOrigin, handle, HttpError, json, parseJson, rateLimit, requireVerifiedUser } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const bookingSchema = z.object({
  childId: z.string().uuid(),
  eventId: z.string().uuid(),
  eventSongId: z.string().uuid(),
  instrument: z.enum(INSTRUMENTS),
  spotNumber: z.number().int().positive(),
});

type BookingResult = {
  id: string;
  season_name: string;
  event_name: string;
  starts_at: string;
  instrument: string;
  child_name: string;
};

export async function GET(request: NextRequest) {
  return handle(async () => {
    const parent = await requireVerifiedUser(request);
    const result = await query(
      `SELECT r.id,r.status,r.instrument,r.spot_number,r.created_at,r.review_required,r.review_reason,
        c.id AS child_id,c.full_name AS child_name,
        s.id AS season_id,s.name AS season_name,s.timezone,
        e.id AS event_id,e.name AS event_name,e.starts_at,e.ends_at,e.location,
        es.id AS event_song_id,es.song_id,so.title AS song_title,ss.song_role AS song_role,(r.booking_group <> 'regular') AS is_extra
       FROM reservations r
       JOIN children c ON c.id=r.child_id
       JOIN seasons s ON s.id=r.season_id
       JOIN events e ON e.id=r.event_id
       JOIN event_songs es ON es.id=r.event_song_id
       JOIN songs so ON so.id=es.song_id
      LEFT JOIN season_song_settings ss ON ss.season_id=r.season_id AND ss.song_id=es.song_id
       WHERE c.parent_user_id=$1
       ORDER BY e.starts_at DESC,r.created_at DESC`,
      [parent.id],
    );
    return json({ reservations: result.rows });
  });
}

export async function POST(request: NextRequest) {
  return handle(async () => {
    assertSameOrigin(request);
    const parent = await requireVerifiedUser(request);
    rateLimit(`booking:${parent.id}`, 12);
    const input = bookingSchema.parse(parseJson(await request.json()));
    let result: BookingResult;
    try {
      result = await transaction(async (tx) => {
        const childResult = await tx.query<{
          id: string; full_name: string; status: string;
        }>(
          "SELECT id,full_name,status FROM children WHERE id=$1 AND parent_user_id=$2 FOR UPDATE",
          [input.childId, parent.id],
        );
        const child = childResult.rows[0];
        if (!child) throw new HttpError(404, "Child profile not found.", "CHILD_NOT_FOUND");
        if (child.status !== "Approved") throw new HttpError(409, "Only approved children can reserve a spot.", "CHILD_NOT_APPROVED");
        const canPlay = await tx.query(
          "SELECT 1 FROM child_instruments WHERE child_id=$1 AND instrument=$2",
          [child.id, input.instrument],
        );
        if (!canPlay.rows.length) throw new HttpError(409, "This child is not approved for the selected instrument.", "INSTRUMENT_NOT_APPROVED");

        const slotResult = await tx.query<{
          season_id: string; season_name: string; status: string;
          registration_opens_at: string; registration_closes_at: string;
          event_id: string; event_name: string; starts_at: string; ends_at: string;
          instrument: string; capacity: number; reserved: number; song_id: string;
        }>(
          `SELECT s.id AS season_id,s.name AS season_name,s.status,s.registration_opens_at,s.registration_closes_at,
            e.id AS event_id,e.name AS event_name,e.starts_at,e.ends_at,
            er.instrument,er.capacity,es.song_id,
            (SELECT COUNT(*) FROM reservations r WHERE r.event_song_id=es.id AND r.instrument=er.instrument AND r.status='Confirmed') AS reserved
           FROM event_songs es
           JOIN events e ON e.id=es.event_id
           JOIN seasons s ON s.id=e.season_id
           JOIN event_requirements er ON er.event_song_id=es.id
           WHERE es.id=$1 AND e.id=$2 AND er.instrument=$3
           FOR UPDATE`,
          [input.eventSongId, input.eventId, input.instrument],
        );
        const slot = slotResult.rows[0];
        if (!slot) throw new HttpError(404, "The selected instrument spot does not exist.", "SPOT_NOT_FOUND");
        const now = Date.now();
        if (slot.status !== "Published"
          || now < new Date(slot.registration_opens_at).getTime()
          || now > new Date(slot.registration_closes_at).getTime()) {
          throw new HttpError(409, "Registration is not open for this season.", "REGISTRATION_CLOSED");
        }
        if (new Date(slot.starts_at).getTime() <= now) throw new HttpError(409, "This event has already started.", "EVENT_STARTED");
        if (input.spotNumber > Number(slot.capacity)) throw new HttpError(400, "That spot is outside the instrument capacity.", "INVALID_SPOT");
        if (Number(slot.reserved) >= Number(slot.capacity)) throw new HttpError(409, "This instrument is full. Refresh availability.", "SPOT_TAKEN");

        const bookingGroup = await songBookingGroup(tx, slot.season_id, slot.song_id);
        const existingSeason = await tx.query(
          "SELECT 1 FROM reservations WHERE child_id=$1 AND season_id=$2 AND booking_group=$3 AND status='Confirmed' LIMIT 1",
          [child.id, slot.season_id, bookingGroup],
        );
        if (existingSeason.rows.length) throw new HttpError(409,
          bookingGroup === "regular" ? "This child already has a confirmed regular-song spot in this season." : "This child already has a confirmed spot for this extra song in this season.",
          "CHILD_ALREADY_BOOKED");
        const overlap = await tx.query(
          `SELECT 1 FROM reservations r JOIN events e ON e.id=r.event_id
           WHERE r.child_id=$1 AND r.status='Confirmed' AND r.season_id<>$4 AND e.starts_at < $3 AND e.ends_at > $2 LIMIT 1`,
          [child.id, slot.starts_at, slot.ends_at, slot.season_id],
        );
        if (overlap.rows.length) throw new HttpError(409, "This performance time overlaps another confirmed reservation for this child.", "EVENT_TIME_CONFLICT");

        const reservationId = randomUUID();
        await tx.query(
          `INSERT INTO reservations (id,child_id,season_id,event_id,event_song_id,instrument,spot_number,booking_group)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [reservationId, child.id, slot.season_id, slot.event_id, input.eventSongId, input.instrument, input.spotNumber, bookingGroup],
        );
        await queueEmail(tx, {
          userId: parent.id, kind: "ParentTransactional",
          subject: "Music ministry reservation confirmed",
          text: `Reservation confirmed for ${child.full_name}: ${slot.season_name}, ${slot.event_name}, ${input.instrument}.`,
        });
        return {
          id: reservationId,
          season_name: slot.season_name,
          event_name: slot.event_name,
          starts_at: new Date(slot.starts_at).toISOString(),
          instrument: input.instrument,
          child_name: child.full_name,
        };
      });
    } catch (error) {
      if (error instanceof HttpError) throw error;
      if (typeof error === "object" && error !== null && "code" in error && error.code === "ER_DUP_ENTRY") {
        const constraint = "sqlMessage" in error ? String(error.sqlMessage) : "";
        if (constraint.includes("one_child_spot_per_season")) {
          throw new HttpError(409, "This child already has a confirmed spot for this season's regular-song or extra-song allowance.", "CHILD_ALREADY_BOOKED");
        }
        throw new HttpError(409, "This spot has just been taken. Refresh availability and choose another.", "SPOT_TAKEN");
      }
      throw error;
    }

    return json({ reservation: result, notificationQueued: true }, 201);
  });
}