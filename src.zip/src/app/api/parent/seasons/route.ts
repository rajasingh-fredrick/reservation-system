import { NextRequest } from "next/server";
import { query } from "@/server/db";
import { handle, json, requireVerifiedUser } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type SeasonRow = Record<string, unknown> & { id: string };

export async function GET(request: NextRequest) {
  return handle(async () => {
    const parent = await requireVerifiedUser(request);
    const [seasonResult, childrenResult, reservationResult] = await Promise.all([
      query<SeasonRow>(
        `SELECT id,name,description,start_date AS start_date,end_date AS end_date,
          registration_opens_at,registration_closes_at,timezone,location,instructions,cancellation_hours,status
         FROM seasons WHERE status IN ('Published','Registration Closed') ORDER BY start_date,name`,
      ),
      query<SeasonRow>(
        `SELECT c.id,c.full_name,c.status,ci.instrument
         FROM children c LEFT JOIN child_instruments ci ON ci.child_id=c.id
         WHERE c.parent_user_id=$1 ORDER BY c.created_at DESC,ci.instrument`,
        [parent.id],
      ),
      query<SeasonRow>(
        `SELECT r.id,r.status,r.instrument,r.spot_number,r.review_required,r.review_reason,
          c.id AS child_id,c.full_name AS child_name,
          s.id AS season_id,s.name AS season_name,s.timezone,
          e.id AS event_id,e.name AS event_name,e.starts_at,e.ends_at,e.location,
          es.id AS event_song_id,es.song_id,so.title AS song_title,ss.song_role AS song_role,(r.booking_group <> 'regular') AS is_extra
         FROM reservations r JOIN children c ON c.id=r.child_id
         JOIN seasons s ON s.id=r.season_id JOIN events e ON e.id=r.event_id
         JOIN event_songs es ON es.id=r.event_song_id JOIN songs so ON so.id=es.song_id
         LEFT JOIN season_song_settings ss ON ss.season_id=r.season_id AND ss.song_id=es.song_id
         WHERE c.parent_user_id=$1 ORDER BY e.starts_at DESC`,
        [parent.id],
      ),
    ]);
    const childMap = new Map<string, { id: string; full_name: string; status: string; instruments: string[] }>();
    for (const row of childrenResult.rows) {
      let child = childMap.get(String(row.id));
      if (!child) {
        child = { id: String(row.id), full_name: String(row.full_name), status: String(row.status), instruments: [] };
        childMap.set(child.id, child);
      }
      if (row.instrument) child.instruments.push(String(row.instrument));
    }
    const seasons = [];
    for (const season of seasonResult.rows) {
      const eventResult = await query<SeasonRow>(
        `SELECT id,name,starts_at,ends_at,location FROM events WHERE season_id=$1 ORDER BY starts_at`,
        [season.id],
      );
      const events = [];
      for (const event of eventResult.rows) {
        const songsResult = await query<SeasonRow>(
          `SELECT es.id AS event_song_id,es.song_id,es.notes,es.position,so.title,so.composer,so.notes AS library_notes,so.links,
            er.instrument,er.capacity,ss.song_role,COALESCE(ss.allow_extra,false) AS allow_extra,
            (SELECT COUNT(*) FROM reservations r WHERE r.event_song_id=es.id AND r.instrument=er.instrument AND r.status='Confirmed') AS reserved
           FROM event_songs es JOIN songs so ON so.id=es.song_id
           LEFT JOIN season_song_settings ss ON ss.season_id=$2 AND ss.song_id=es.song_id
           LEFT JOIN event_requirements er ON er.event_song_id=es.id
           WHERE es.event_id=$1 ORDER BY es.position,er.instrument`,
          [event.id, season.id],
        );
        const occupied = await query<{ event_song_id: string; instrument: string; spot_number: number; child_name: string | null }>(
          `SELECT r.event_song_id,r.instrument,r.spot_number,
             CASE WHEN c.parent_user_id=$2 THEN c.full_name ELSE NULL END AS child_name
           FROM reservations r JOIN children c ON c.id=r.child_id
           WHERE r.event_id=$1 AND r.status='Confirmed' ORDER BY r.spot_number`, [event.id, parent.id],
        );
        const occupiedSpots = new Set(occupied.rows.map((row) => `${row.event_song_id}:${row.instrument}:${row.spot_number}`));
        const eventSongs = new Map<string, Record<string, unknown> & { sheets: unknown[]; requirements: unknown[] }>();
        for (const row of songsResult.rows) {
          const eventSongId = String(row.event_song_id);
          let song = eventSongs.get(eventSongId);
          if (!song) {
            song = {
              id: eventSongId,
              songId: String(row.song_id),
              allowExtra: Boolean(row.allow_extra),
              songRole: row.song_role ?? null,
              title: String(row.title),
              composer: String(row.composer ?? ""),
              notes: String(row.notes ?? ""),
              libraryNotes: String(row.library_notes ?? ""),
              links: row.links ?? [],
              position: Number(row.position),
              sheets: [],
              requirements: [],
            };
            eventSongs.set(eventSongId, song);
          }
          if (row.instrument) {
            song.requirements.push({
              instrument: String(row.instrument),
              capacity: Number(row.capacity),
              reserved: Number(row.reserved),
              available: Math.max(0, Number(row.capacity) - Number(row.reserved)),
              availableSpots: Array.from({ length: Number(row.capacity) }, (_, index) => index + 1)
                .filter((spot) => !occupiedSpots.has(`${eventSongId}:${row.instrument}:${spot}`)),
              reservedSpots: occupied.rows
                .filter((spot) => spot.event_song_id === eventSongId && spot.instrument === row.instrument)
                .flatMap((spot) => spot.child_name === null ? [] : [{ spotNumber: Number(spot.spot_number), childName: spot.child_name }]),
            });
          }
          const selectedSheets = await query<SeasonRow>(
            `SELECT sh.id,sh.label,sh.instrument,sh.arrangement,x.selected_version AS version,v.file_name
             FROM event_sheets x JOIN sheets sh ON sh.id=x.sheet_id
             JOIN sheet_versions v ON v.sheet_id=x.sheet_id AND v.version=x.selected_version
             WHERE x.event_song_id=$1 ORDER BY sh.label`,
            [eventSongId],
          );
          song.sheets = selectedSheets.rows.map((sheet) => ({
            id: String(sheet.id), label: String(sheet.label), instrument: sheet.instrument,
            arrangement: String(sheet.arrangement ?? ""), version: Number(sheet.version), fileName: String(sheet.file_name),
          }));
        }
        events.push({
          id: String(event.id), name: String(event.name), startsAt: event.starts_at,
          endsAt: event.ends_at, location: String(event.location ?? ""), songs: [...eventSongs.values()],
        });
      }
      seasons.push({ ...season, events });
    }
    return json({ seasons, children: [...childMap.values()], reservations: reservationResult.rows });
  });
}