import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { transaction, query } from "@/server/db";
import { assertSameOrigin, handle, json, requireVerifiedUser } from "@/server/http";
import { parseWith, childProfileSchema } from "@/server/validation";
import { queueChildAdminNotification, queueChildNotification } from "@/server/child-notifications";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ChildRow = {
  id: string;
  full_name: string;
  birth_month: number;
  birth_year: number;
  additional_information: string;
  status: string;
  status_reason: string | null;
  instrument: string | null;
  years_experience: number | string | null;
};

async function listChildren(parentId: string) {
  const result = await query<ChildRow>(
    `SELECT c.id,c.full_name,c.birth_month,c.birth_year,c.additional_information,c.status,c.status_reason,
       ci.instrument,ci.years_experience
     FROM children c LEFT JOIN child_instruments ci ON ci.child_id = c.id
     WHERE c.parent_user_id = $1 ORDER BY c.created_at DESC, ci.instrument`,
    [parentId],
  );
  const children = new Map<string, {
    id: string; fullName: string; birthMonth: number; birthYear: number;
    additionalInformation: string; status: string; statusReason: string | null;
    instruments: Array<{ instrument: string; yearsExperience: number }>;
  }>();
  for (const row of result.rows) {
    let child = children.get(row.id);
    if (!child) {
      child = {
        id: row.id,
        fullName: row.full_name,
        birthMonth: Number(row.birth_month),
        birthYear: Number(row.birth_year),
        additionalInformation: row.additional_information,
        status: row.status,
        statusReason: row.status_reason,
        instruments: [],
      };
      children.set(row.id, child);
    }
    if (row.instrument) child.instruments.push({ instrument: row.instrument, yearsExperience: Number(row.years_experience) });
  }
  return [...children.values()];
}

export async function GET(request: NextRequest) {
  return handle(async () => {
    const parent = await requireVerifiedUser(request);
    return json({ children: await listChildren(parent.id) });
  });
}

export async function POST(request: NextRequest) {
  return handle(async () => {
    assertSameOrigin(request);
    const parent = await requireVerifiedUser(request);
    const input = parseWith(childProfileSchema, await request.json());
    const childId = randomUUID();
    await transaction(async (tx) => {
      await tx.query('SELECT id FROM "user" WHERE id=$1 FOR UPDATE', [parent.id]);
      await tx.query(
        `INSERT INTO parent_profiles (user_id)
         SELECT $1 WHERE NOT EXISTS (SELECT 1 FROM parent_profiles WHERE user_id=$1)`,
        [parent.id],
      );
      const existing = await tx.query<{ id: string }>(
        "SELECT id FROM children WHERE parent_user_id=$1 LIMIT 1", [parent.id],
      );
      await tx.query(
        `INSERT INTO children (id,parent_user_id,full_name,birth_month,birth_year,additional_information)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [childId, parent.id, input.fullName, input.birthMonth, input.birthYear, input.additionalInformation],
      );
      for (const instrument of input.instruments) {
        await tx.query(
          "INSERT INTO child_instruments (child_id,instrument,years_experience) VALUES ($1,$2,$3)",
          [childId, instrument.instrument, instrument.yearsExperience],
        );
      }
      return {
        parent: await queueChildNotification(tx, parent.id, childId, existing.rows.length === 0),
        administrator: await queueChildAdminNotification(tx, parent.id, childId),
      };
    });
    return json({ children: await listChildren(parent.id), notificationStatus: "Pending", adminNotificationStatus: "Pending" }, 201);
  });
}