import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { assertSameOrigin, handle, HttpError, idParam, json, requireVerifiedUser } from "@/server/http";
import { parseWith, childProfileSchema } from "@/server/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ChildRouteContext = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, { params }: ChildRouteContext) {
  return handle(async () => {
    assertSameOrigin(request);
    const parent = await requireVerifiedUser(request);
    const { id } = await params;
    const childId = idParam(id);
    const input = parseWith(childProfileSchema, await request.json());
    await transaction(async (tx) => {
      const currentResult = await tx.query<{
        full_name: string; birth_month: number; birth_year: number; status: string;
      }>(
        "SELECT full_name,birth_month,birth_year,status FROM children WHERE id=$1 AND parent_user_id=$2 FOR UPDATE",
        [childId, parent.id],
      );
      const current = currentResult.rows[0];
      if (!current) throw new HttpError(404, "Child profile not found.", "CHILD_NOT_FOUND");
      if (current.status === "Archived") throw new HttpError(409, "Archived profiles cannot be edited.", "CHILD_ARCHIVED");

      const existingInstruments = await tx.query<{ instrument: string; years_experience: number | string }>(
        "SELECT instrument,years_experience FROM child_instruments WHERE child_id=$1 ORDER BY instrument",
        [childId],
      );
      const oldInstruments = existingInstruments.rows.map((item) => `${item.instrument}:${Number(item.years_experience)}`).sort();
      const newInstruments = input.instruments.map((item) => `${item.instrument}:${item.yearsExperience}`).sort();
      const eligibilityChanged = current.full_name !== input.fullName
        || Number(current.birth_month) !== input.birthMonth
        || Number(current.birth_year) !== input.birthYear
        || oldInstruments.join("|") !== newInstruments.join("|");

      await tx.query(
        `UPDATE children SET full_name=$1,birth_month=$2,birth_year=$3,additional_information=$4,
         status=CASE WHEN $5 THEN 'Pending approval' ELSE status END,
         status_reason=CASE WHEN $5 THEN NULL ELSE status_reason END,
         reviewed_by=CASE WHEN $5 THEN NULL ELSE reviewed_by END,
         reviewed_at=CASE WHEN $5 THEN NULL ELSE reviewed_at END,updated_at=now()
         WHERE id=$6 AND parent_user_id=$7`,
        [input.fullName, input.birthMonth, input.birthYear, input.additionalInformation, eligibilityChanged, childId, parent.id],
      );
      if (eligibilityChanged) {
        await tx.query(
          `UPDATE reservations SET review_required=true,
             review_reason='Child eligibility details changed; coordinator review required.'
           WHERE child_id=$1 AND status='Confirmed'`,
          [childId],
        );
      }
      await tx.query("DELETE FROM child_instruments WHERE child_id=$1", [childId]);
      for (const instrument of input.instruments) {
        await tx.query(
          "INSERT INTO child_instruments (child_id,instrument,years_experience) VALUES ($1,$2,$3)",
          [childId, instrument.instrument, instrument.yearsExperience],
        );
      }
    });
    return json({ ok: true });
  });
}

export async function DELETE(request: NextRequest, { params }: ChildRouteContext) {
  return handle(async () => {
    assertSameOrigin(request);
    const parent = await requireVerifiedUser(request);
    const { id } = await params;
    const result = await transaction(async (tx) => {
      const archived = await tx.query<{ id: string }>(
        `UPDATE children SET status='Archived',updated_at=now()
         WHERE id=$1 AND parent_user_id=$2 AND status <> 'Archived' RETURNING id`,
        [idParam(id), parent.id],
      );
      if (archived.rows.length) {
        await tx.query(
          `UPDATE reservations SET review_required=true,
             review_reason='Child profile archived; coordinator review required.'
           WHERE child_id=$1 AND status='Confirmed'`,
          [idParam(id)],
        );
      }
      return archived;
    });
    if (!result.rows.length) throw new HttpError(404, "Child profile not found.", "CHILD_NOT_FOUND");
    return json({ ok: true, message: "Child profile archived. Historical records are preserved." });
  });
}