import { randomUUID } from "node:crypto";
import { hashPassword } from "better-auth/crypto";
import { NextRequest } from "next/server";
import { getAuth } from "@/server/auth";
import { transaction } from "@/server/db";
import { assertSameOrigin, handle, HttpError, json, rateLimit } from "@/server/http";
import { parseWith, parentRegistrationSchema } from "@/server/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  return handle(async () => {
    assertSameOrigin(request);
    rateLimit(`register:${request.headers.get("x-forwarded-for") || "unknown"}`, 5);
    const input = parseWith(parentRegistrationSchema, await request.json());
    if (process.env.NODE_ENV === "production" && (!process.env.SMTP_HOST || !process.env.SMTP_FROM)) {
      throw new HttpError(503, "Account registration is temporarily unavailable.", "MAIL_UNAVAILABLE");
    }

    const id = randomUUID();
    const passwordHash = await hashPassword(input.password);
    try {
      await transaction(async (tx) => {
        const existing = await tx.query('SELECT 1 FROM "user" WHERE lower(email) = $1 LIMIT 1', [input.email]);
        if (existing.rows.length) throw new HttpError(409, "An account with this email already exists.", "EMAIL_EXISTS");
        await tx.query(
          'INSERT INTO "user" (id,name,email,"emailVerified") VALUES ($1,$2,$3,false)',
          [id, input.name, input.email],
        );
        await tx.query(
          `INSERT INTO account (id,"accountId","providerId","userId",password)
           VALUES ($1,$2,'credential',$3,$4)`,
          [randomUUID(), input.email, id, passwordHash],
        );
        await tx.query(
          `INSERT INTO parent_profiles
            (user_id,phone,authorized_child_registration,privacy_accepted_at,policies_accepted_at)
           VALUES ($1,$2,true,now(),now())`,
          [id, input.phone],
        );
      });
    } catch (error) {
      if (error instanceof HttpError) throw error;
      if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
        throw new HttpError(409, "An account with this email already exists.", "EMAIL_EXISTS");
      }
      throw error;
    }

    let emailSent = true;
    try {
      await getAuth().api.sendVerificationEmail({
        body: {
          email: input.email,
          callbackURL: new URL("/sign-in?verified=1", process.env.APP_URL || "http://localhost:3000").toString(),
        },
      });
    } catch (error) {
      emailSent = false;
      console.error("Parent verification email delivery failed", error instanceof Error ? error.message : "unknown error");
    }
    return json({
      emailSent,
      message: emailSent
        ? "Account created. Verify your email before signing in."
        : "Account created, but the verification email could not be sent. Request another verification email before signing in.",
    }, 201);
  });
}