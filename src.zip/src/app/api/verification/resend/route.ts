import { NextRequest } from "next/server";
import { z } from "zod";
import { getAuth } from "@/server/auth";
import { db } from "@/server/db";
import { assertSameOrigin, handle, json, parseJson, rateLimit } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const requestSchema = z.object({ email: z.string().trim().toLowerCase().email().max(320) });
const responseMessage = "If the address can receive a verification email, one will be sent shortly.";

export async function POST(request: NextRequest) {
  return handle(async () => {
    assertSameOrigin(request);
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    rateLimit(`verification-resend:${ip}`, 3, 60 * 60 * 1000);
    let email: string | undefined;
    try {
      const input = requestSchema.parse(parseJson(await request.json()));
      email = input.email;
    } catch {
      return json({ message: responseMessage });
    }
    try {
      await db.ready;
      await getAuth().api.sendVerificationEmail({
        body: {
          email,
          callbackURL: new URL("/sign-in?verified=1", process.env.APP_URL || "http://localhost:3000").toString(),
        },
      });
    } catch (error) {
      console.error("Verification resend failed", error instanceof Error ? error.message : "unknown error");
    }
    return json({ message: responseMessage });
  });
}