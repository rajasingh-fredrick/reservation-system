import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextRequest, NextResponse } from "next/server";
import { query, uploadDirectory } from "@/server/db";
import { handle, HttpError, idParam, requireVerifiedUser } from "@/server/http";

export const runtime = "nodejs";
type SheetContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, { params }: SheetContext) {
  return handle(async () => {
    await requireVerifiedUser(request);
    const sheetId = idParam((await params).id);
    const search = new URL(request.url).searchParams;
    const version = Number(search.get("version"));
    const preview = search.get("preview") === "true";
    if (!Number.isSafeInteger(version) || version < 1) throw new HttpError(400, "A valid sheet version is required.", "INVALID_VERSION");
    const result = await query<{ storage_key: string; file_name: string }>(
      `SELECT v.storage_key,v.file_name
       FROM event_sheets x
       JOIN event_songs es ON es.id=x.event_song_id
       JOIN events e ON e.id=es.event_id
       JOIN seasons s ON s.id=e.season_id
       JOIN sheet_versions v ON v.sheet_id=x.sheet_id AND v.version=x.selected_version
       WHERE x.sheet_id=$1 AND x.selected_version=$2 AND s.status IN ('Published','Registration Closed')
       LIMIT 1`,
      [sheetId, version],
    );
    if (!result.rows.length) throw new HttpError(404, "This music sheet is not available for a published event.", "SHEET_NOT_AVAILABLE");
    let bytes: Buffer;
    try { bytes = await readFile(path.join(uploadDirectory, path.basename(result.rows[0].storage_key))); }
    catch { throw new HttpError(404, "The selected music sheet file is unavailable.", "FILE_NOT_FOUND"); }
    return new NextResponse(new Uint8Array(bytes), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `${preview ? "inline" : "attachment"}; filename="${result.rows[0].file_name.replace(/["\\\r\n]/g, "_")}"`,
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
      },
    });
  });
}