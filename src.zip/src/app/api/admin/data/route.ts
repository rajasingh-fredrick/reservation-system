import { NextRequest } from "next/server";
import { adminData } from "@/server/admin-data";
import { handle, json, requireAdmin } from "@/server/http";

export const runtime = "nodejs";
export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    return json(await adminData());
  });
}
