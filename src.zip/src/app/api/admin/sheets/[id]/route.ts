import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { query, transaction, uploadDirectory } from "@/server/db";
import path from "node:path";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { currentSheet, MAX_PDF_BYTES, removeFiles, usageForSheet, writePdf } from "@/server/library";
import { requirePermission } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const form = await request.formData();
    const oldSheet = await currentSheet(id);
    if (!oldSheet) throw new HttpError(404, "Music sheet not found.", "NOT_FOUND");
    const usages = await usageForSheet(id);
    const published = usages.filter((usage) => usage.season_status === "Published");
    const hasFile = form.get("file") !== null;
    if (hasFile) requirePermission(form);
    if (published.length && (form.get("confirmImpact") !== "true")) {
      throw new HttpError(409, "This sheet is used by published events. Review the impact and retry with confirmImpact=true.", "IMPACT_CONFIRMATION_REQUIRED");
    }
    const updates: Record<string, unknown> = {};
    for (const key of ["label", "arrangement"] as const) {
      const value = form.get(key);
      if (value !== null) {
        if (typeof value !== "string" || value.length > 200 || key === "label" && !value.trim()) throw new HttpError(400, `Invalid ${key}.`, "INVALID_FIELD");
        updates[key] = value.trim();
      }
    }
    const instrument = form.get("instrument");
    if (instrument !== null) {
      const allowed = ["Violin", "Piano", "Keyboard", "Drums", "Guitar", "Bass Guitar", "Saxophone"];
      if (instrument !== "" && !allowed.includes(String(instrument))) throw new HttpError(400, "Invalid instrument.", "INVALID_FIELD");
      updates.instrument = instrument === "" ? null : instrument;
    }
    const archived = form.get("archived");
    if (archived !== null) {
      if (archived !== "true" && archived !== "false") throw new HttpError(400, "archived must be true or false.", "INVALID_FIELD");
      updates.archived = archived === "true";
    }
    let written: Awaited<ReturnType<typeof writePdf>> | undefined;
    const file = form.get("file");
    if (file !== null) {
      if (!(file instanceof File) || file.size < 1 || file.size > MAX_PDF_BYTES || file.type !== "application/pdf") {
        throw new HttpError(400, "Upload a PDF of at most 15 MB.", "INVALID_FILE");
      }
      const bytes = Buffer.from(await file.arrayBuffer());
      if (bytes.subarray(0, 5).toString("ascii") !== "%PDF-") throw new HttpError(400, "Only valid PDF files are accepted.", "INVALID_FILE_TYPE");
      written = await writePdf({ fileName: path.basename(file.name).slice(0, 240) || "sheet.pdf", bytes });
    }
    if (!Object.keys(updates).length && !written) throw new HttpError(400, "No sheet fields to update.", "INVALID_FIELD");
    try {
      await transaction(async (tx) => {
        if (written) {
          const version = Number(oldSheet.current_version) + 1;
          const file = form.get("file") as File;
          await tx.query(
            "INSERT INTO sheet_versions (sheet_id,version,file_name,storage_key,size_bytes) VALUES ($1,$2,$3,$4,$5)",
            [id, version, path.basename(file.name).slice(0, 240) || "sheet.pdf", written!.key, file.size],
          );
          updates.current_version = version;
        }
        const mapping: Record<string, string> = { label: "label", arrangement: "arrangement", instrument: "instrument", archived: "archived", current_version: "current_version" };
        const entries = Object.entries(updates);
        const assignments = entries.map(([key], index) => `${mapping[key]}=$${index + 1}`);
        const values = entries.map(([, value]) => value);
        values.push(id);
        const updated = await tx.query(`UPDATE sheets SET ${assignments.join(",")} WHERE id=$${values.length}`, values);
        if (!updated.rowCount) throw new HttpError(404, "Music sheet not found.", "NOT_FOUND");
        await recordAudit(actor.id, written ? "sheet_replaced" : updates.archived ? "sheet_archived" : "sheet_updated",
          `Updated sheet “${oldSheet.label}” (sheet ${id}, current version ${updates.current_version ?? oldSheet.current_version}).${published.length ? ` Published event impact confirmed (${published.length} usage(s)); selected versions remain pinned.` : ""}`, tx);
      });
    } catch (error) {
      if (written) await removeFiles([written.target]);
      throw error;
    }
    return json({ ok: true });
  });
}

export async function DELETE(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const keys = await transaction(async (tx) => {
      const used = await tx.query("SELECT 1 FROM event_sheets WHERE sheet_id=$1 LIMIT 1", [id]);
      if (used.rows.length) throw new HttpError(409, "This sheet is referenced by an event or historical record and cannot be deleted. Archive it instead.", "RECORD_IN_USE");
      const sheet = await tx.query<{ label: string }>("SELECT label FROM sheets WHERE id=$1", [id]);
      if (!sheet.rows.length) throw new HttpError(404, "Music sheet not found.", "NOT_FOUND");
      const files = await tx.query<{ storage_key: string }>("SELECT storage_key FROM sheet_versions WHERE sheet_id=$1", [id]);
      await tx.query("DELETE FROM sheet_versions WHERE sheet_id=$1", [id]);
      await tx.query("DELETE FROM sheets WHERE id=$1", [id]);
      await recordAudit(actor.id, "sheet_deleted", `Deleted unused sheet “${sheet.rows[0].label}”.`, tx);
      return files.rows.map((row) => row.storage_key);
    });
    await removeFiles(keys.map((key) => path.join(uploadDirectory, key)));
    return json({ ok: true });
  });
}
