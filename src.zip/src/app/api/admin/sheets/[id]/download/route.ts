import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextRequest, NextResponse } from "next/server";
import { query, uploadDirectory } from "@/server/db";
import { handle, HttpError, idParam, requireAdmin } from "@/server/http";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function GET(request: NextRequest, context: Context) {
  return handle(async () => {
    await requireAdmin(request);
    const id = idParam((await context.params).id);
    const versionText = new URL(request.url).searchParams.get("version");
    const preview = new URL(request.url).searchParams.get("preview") === "true";
    const version = versionText === null ? undefined : Number(versionText);
    if (version !== undefined && (!Number.isSafeInteger(version) || version < 1)) throw new HttpError(400, "version must be a positive integer.", "INVALID_VERSION");
    const result = await query<{ storage_key: string; file_name: string }>(
      `SELECT v.storage_key,v.file_name FROM sheet_versions v WHERE v.sheet_id=$1 AND v.version=COALESCE($2,(SELECT current_version FROM sheets WHERE id=$1))`,
      [id, version ?? null],
    );
    if (!result.rows.length) throw new HttpError(404, "The requested music sheet version is unavailable.", "FILE_NOT_FOUND");
    let bytes: Buffer;
    try { bytes = await readFile(path.join(uploadDirectory, path.basename(result.rows[0].storage_key))); }
    catch { throw new HttpError(404, "The stored music sheet file is unavailable.", "FILE_NOT_FOUND"); }
    return new NextResponse(new Uint8Array(bytes), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `${preview ? "inline" : "attachment"}; filename="${result.rows[0].file_name.replace(/["\\\r\n]/g, "_")}"`,
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
      },
    });
  });
}
