import { NextRequest } from "next/server";
import { query } from "@/server/db";
import { handle, json, requireAdmin } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    const result = await query(
      `SELECT r.id,r.review_reason,r.created_at,r.instrument,r.spot_number,
        c.full_name AS child_name,p.name AS parent_name,p.email AS parent_email,
        s.name AS season_name,s.timezone,e.name AS event_name,e.starts_at,so.title AS song_title
       FROM reservations r
       JOIN children c ON c.id=r.child_id
       JOIN "user" p ON p.id=c.parent_user_id
       JOIN seasons s ON s.id=r.season_id
       JOIN events e ON e.id=r.event_id
       JOIN event_songs es ON es.id=r.event_song_id
       JOIN songs so ON so.id=es.song_id
       WHERE r.review_required=true AND r.status='Confirmed'
       ORDER BY r.updated_at DESC`,
    );
    return json({ reservations: result.rows });
  });
}
