import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { queueEmail } from "@/server/email-queue";
import { handle, HttpError, idParam, json, parseJson, recordAudit, requiredString, requireAdminWrite } from "@/server/http";

export const runtime = "nodejs";
type ReviewDecision = { action: "keep" | "cancel"; explanation?: string };
type ReviewContext = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, { params }: ReviewContext) {
  return handle(async () => {
    const admin = await requireAdminWrite(request);
    const id = idParam((await params).id);
    const body = parseJson<ReviewDecision>(await request.json());
    if (body.action !== "keep" && body.action !== "cancel") throw new HttpError(400, "Choose keep or cancel.", "INVALID_DECISION");
    const explanation = body.action === "cancel" ? requiredString(body.explanation, "explanation", 1000) : null;
    await transaction(async (tx) => {
      const existing = await tx.query<{
        parent_user_id: string; child_name: string; season_name: string; event_name: string; instrument: string;
      }>(
        `SELECT c.parent_user_id,c.full_name AS child_name,s.name AS season_name,e.name AS event_name,r.instrument
         FROM reservations r JOIN children c ON c.id=r.child_id
         JOIN seasons s ON s.id=r.season_id JOIN events e ON e.id=r.event_id
         WHERE r.id=$1 AND r.status='Confirmed' AND r.review_required=true FOR UPDATE`,
        [id],
      );
      const item = existing.rows[0];
      if (!item) throw new HttpError(404, "Reservation review not found.", "REVIEW_NOT_FOUND");
      if (body.action === "cancel") {
        await tx.query(
          `UPDATE reservations SET status='Admin cancelled',cancelled_at=now(),updated_at=now(),
            cancellation_reason=$1,review_required=false WHERE id=$2`,
          [explanation, id],
        );
      } else {
        await tx.query("UPDATE reservations SET review_required=false,review_reason=NULL,updated_at=now() WHERE id=$1", [id]);
      }
      await recordAudit(
        admin.id,
        body.action === "cancel" ? "reservation_admin_cancelled" : "reservation_review_kept",
        body.action === "cancel" ? `Cancelled a reservation after review. Explanation: ${explanation}` : "Confirmed a reservation after coordinator review.",
        tx,
      );
      const subject = body.action === "cancel" ? "Reservation cancelled by the coordinator" : "Reservation review complete";
      const text = body.action === "cancel"
        ? `The reservation for ${item.child_name} in ${item.season_name} was cancelled by the coordinator. Reason: ${explanation}`
        : `The reservation for ${item.child_name} in ${item.season_name} remains confirmed after review.`;
      await queueEmail(tx, { userId: item.parent_user_id, kind: "ParentTransactional", subject, text });
    });
    return json({ ok: true, action: body.action, notificationQueued: true });
  });
}