import { NextRequest, NextResponse } from "next/server";
import { query } from "@/server/db";
import { handle, HttpError, idParam, json, requireAdmin } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RosterRow = {
  id: string;
  status: string;
  instrument: string;
  spot_number: number;
  created_at: string;
  child_name: string;
  parent_name: string;
  parent_email: string;
  parent_phone: string;
  season_id: string;
  season_name: string;
  timezone: string;
  event_id: string;
  event_name: string;
  starts_at: string;
  ends_at: string;
  song_id: string;
  song_title: string;
};

function csvCell(value: unknown) {
  let text = String(value ?? "");
  if (/^[\s\u0000-\u001f]*[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    const params = new URL(request.url).searchParams;
    const season = params.get("season") || null;
    const eventDate = params.get("date") || null;
    const song = params.get("song") || null;
    const instrument = params.get("instrument") || null;
    const child = params.get("child")?.trim() || null;
    const parent = params.get("parent")?.trim() || null;
    const status = params.get("status") || null;
    if (season) idParam(season);
    if (song) idParam(song);
    if (eventDate && !/^\d{4}-\d{2}-\d{2}$/.test(eventDate)) throw new HttpError(400, "date must use YYYY-MM-DD.", "INVALID_DATE");
    if (instrument && !["Violin", "Piano", "Keyboard", "Drums", "Guitar", "Bass Guitar", "Saxophone"].includes(instrument)) {
      throw new HttpError(400, "Unknown instrument.", "INVALID_INSTRUMENT");
    }
    if (status && !["Confirmed", "Cancelled", "Admin cancelled"].includes(status)) throw new HttpError(400, "Unknown reservation status.", "INVALID_STATUS");

    const result = await query<RosterRow>(
      `SELECT r.id,r.status,r.instrument,r.spot_number,r.created_at,
        c.full_name AS child_name,p.name AS parent_name,p.email AS parent_email,pp.phone AS parent_phone,
        s.id AS season_id,s.name AS season_name,s.timezone,
        e.id AS event_id,e.name AS event_name,e.starts_at,e.ends_at,
        so.id AS song_id,so.title AS song_title
       FROM reservations r
       JOIN children c ON c.id=r.child_id
       JOIN "user" p ON p.id=c.parent_user_id
       LEFT JOIN parent_profiles pp ON pp.user_id=p.id
       JOIN seasons s ON s.id=r.season_id
       JOIN events e ON e.id=r.event_id
       JOIN event_songs es ON es.id=r.event_song_id
       JOIN songs so ON so.id=es.song_id
       WHERE ($1::text IS NULL OR r.season_id=$1)
         AND ($2::text IS NULL OR to_char(e.starts_at AT TIME ZONE s.timezone,'YYYY-MM-DD')=$2)
         AND ($3::text IS NULL OR so.id=$3)
         AND ($4::text IS NULL OR r.instrument=$4)
         AND ($5::text IS NULL OR c.full_name ILIKE '%' || $5 || '%')
         AND ($6::text IS NULL OR p.name ILIKE '%' || $6 || '%' OR p.email ILIKE '%' || $6 || '%')
         AND ($7::text IS NULL OR r.status=$7)
       ORDER BY e.starts_at DESC,p.name,c.full_name,so.title`,
      [season, eventDate, song, instrument, child, parent, status],
    );

    if (params.get("format") === "csv") {
      const headers = ["Child", "Parent", "Parent Email", "Parent Phone", "Season", "Event", "Starts At", "Song", "Instrument", "Spot", "Status", "Reserved At"];
      const lines = [headers, ...result.rows.map((row) => [
        row.child_name, row.parent_name, row.parent_email, row.parent_phone, row.season_name,
        row.event_name, new Intl.DateTimeFormat("en-US", { timeZone: row.timezone, dateStyle: "medium", timeStyle: "short" }).format(new Date(row.starts_at)),
        row.song_title, row.instrument, row.spot_number, row.status,
        new Intl.DateTimeFormat("en-US", { dateStyle: "medium", timeStyle: "short" }).format(new Date(row.created_at)),
      ])].map((line) => line.map(csvCell).join(",")).join("\r\n");
      return new NextResponse(lines, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": 'attachment; filename="harmony-reservations.csv"',
          "Cache-Control": "private, no-store",
          "X-Content-Type-Options": "nosniff",
        },
      });
    }
    return json({ reservations: result.rows });
  });
}