import { NextRequest } from "next/server";
import { query } from "@/server/db";
import { handle, json, requireAdmin } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ReviewRow = {
  id: string;
  full_name: string;
  birth_month: number;
  birth_year: number;
  additional_information: string;
  created_at: string;
  parent_name: string;
  parent_email: string;
  instrument: string | null;
  years_experience: number | string | null;
};

export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    const result = await query<ReviewRow>(
      `SELECT c.id,c.full_name,c.birth_month,c.birth_year,c.additional_information,c.created_at,
        u.name AS parent_name,u.email AS parent_email,ci.instrument,ci.years_experience
       FROM children c
       JOIN "user" u ON u.id = c.parent_user_id
       LEFT JOIN child_instruments ci ON ci.child_id = c.id
       WHERE c.status = 'Pending approval'
       ORDER BY c.created_at, c.id, ci.instrument`,
    );
    const profiles = new Map<string, {
      id: string; fullName: string; birthMonth: number; birthYear: number;
      additionalInformation: string; createdAt: string; parentName: string; parentEmail: string;
      instruments: Array<{ instrument: string; yearsExperience: number }>;
    }>();
    for (const row of result.rows) {
      let profile = profiles.get(row.id);
      if (!profile) {
        profile = {
          id: row.id,
          fullName: row.full_name,
          birthMonth: Number(row.birth_month),
          birthYear: Number(row.birth_year),
          additionalInformation: row.additional_information,
          createdAt: row.created_at,
          parentName: row.parent_name,
          parentEmail: row.parent_email,
          instruments: [],
        };
        profiles.set(row.id, profile);
      }
      if (row.instrument) profile.instruments.push({ instrument: row.instrument, yearsExperience: Number(row.years_experience) });
    }
    return json({ children: [...profiles.values()] });
  });
}