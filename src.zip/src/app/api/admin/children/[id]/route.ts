import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { sendMail } from "@/server/mail";
import { handle, HttpError, idParam, json, parseJson, recordAudit, requiredString, requireAdminWrite } from "@/server/http";

export const runtime = "nodejs";

type Decision = { status: "Approved" | "Rejected"; reason?: string };
type ChildRouteContext = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, { params }: ChildRouteContext) {
  return handle(async () => {
    const admin = await requireAdminWrite(request);
    const { id } = await params;
    const childId = idParam(id);
    const body = parseJson<Decision>(await request.json());
    if (body.status !== "Approved" && body.status !== "Rejected") {
      throw new HttpError(400, "Choose approve or reject.", "INVALID_DECISION");
    }
    const reason = body.status === "Rejected"
      ? requiredString(body.reason, "reason", 1000)
      : null;

    const child = await transaction(async (tx) => {
      const current = await tx.query<{ parent_user_id: string; full_name: string }>(
        "SELECT parent_user_id,full_name FROM children WHERE id=$1 AND status='Pending approval' FOR UPDATE",
        [childId],
      );
      if (!current.rows[0]) throw new HttpError(409, "This profile is no longer pending review.", "REVIEW_ALREADY_COMPLETED");
      await tx.query(
        `UPDATE children SET status=$1,status_reason=$2,reviewed_by=$3,reviewed_at=now(),updated_at=now()
         WHERE id=$4 AND status='Pending approval'`,
        [body.status, reason, admin.id, childId],
      );
      await recordAudit(admin.id, body.status === "Approved" ? "child_approved" : "child_rejected", `Child profile ${body.status.toLowerCase()}.`, tx);
      return current.rows[0];
    });

    const parent = await transaction(async (tx) => {
      const result = await tx.query<{ email: string }>('SELECT email FROM "user" WHERE id=$1', [child.parent_user_id]);
      return result.rows[0];
    });
    let notificationSent = false;
    if (parent) {
      try {
        const text = body.status === "Approved"
          ? "Your child's music ministry profile has been approved. You can now review published seasons and registration availability."
          : `Your child's music ministry profile needs an update before approval.${reason ? ` Coordinator note: ${reason}` : ""}`;
        await sendMail(parent.email, `Child profile ${body.status.toLowerCase()}`, text);
        notificationSent = true;
      } catch (error) {
        console.error("Child profile decision notification failed", error instanceof Error ? error.message : "unknown error");
      }
    }
    return json({ ok: true, status: body.status, notificationSent });
  });
}