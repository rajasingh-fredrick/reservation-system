import { NextRequest } from "next/server";
import { transaction, query } from "@/server/db";
import { handle, HttpError, json, parseJson, recordAudit, requireAdmin, requireAdminWrite } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    const result = await query(
      `SELECT u.id,u.name,u.email,u."emailVerified" AS email_verified,a.granted_at
       FROM admin_users a JOIN "user" u ON u.id=a.user_id ORDER BY a.granted_at,u.email`,
    );
    return json({ administrators: result.rows });
  });
}

export async function POST(request: NextRequest) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const body = parseJson<{ email: string }>(await request.json());
    if (typeof body.email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email.trim())) {
      throw new HttpError(400, "Enter a valid email address.", "INVALID_EMAIL");
    }
    const email = body.email.trim().toLowerCase();
    await transaction(async (tx) => {
      const user = await tx.query<{ id: string }>(
        'SELECT id FROM "user" WHERE lower(email)=$1 AND "emailVerified"=true FOR UPDATE',
        [email],
      );
      if (!user.rows[0]) throw new HttpError(404, "No verified account was found for that email.", "VERIFIED_USER_NOT_FOUND");
      const existing = await tx.query("SELECT 1 FROM admin_users WHERE user_id=$1", [user.rows[0].id]);
      if (existing.rows.length) throw new HttpError(409, "This account is already an administrator.", "ALREADY_ADMIN");
      await tx.query("INSERT INTO admin_users (user_id) VALUES ($1)", [user.rows[0].id]);
      await recordAudit(actor.id, "admin_access_granted", "Granted administrator access to a verified account.", tx);
    });
    return json({ ok: true });
  });
}