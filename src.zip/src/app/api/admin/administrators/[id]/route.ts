import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";

export const runtime = "nodejs";
type AdministratorContext = { params: Promise<{ id: string }> };

export async function DELETE(request: NextRequest, { params }: AdministratorContext) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const userId = idParam((await params).id);
    await transaction(async (tx) => {
      const administrators = await tx.query<{ user_id: string }>("SELECT user_id FROM admin_users FOR UPDATE");
      if (!administrators.rows.some((row) => row.user_id === userId)) throw new HttpError(404, "Administrator not found.", "ADMIN_NOT_FOUND");
      if (administrators.rows.length <= 1) throw new HttpError(409, "The last active administrator cannot be removed.", "LAST_ADMIN");
      await tx.query("DELETE FROM admin_users WHERE user_id=$1", [userId]);
      await recordAudit(actor.id, "admin_access_revoked", "Revoked administrator access.", tx);
    });
    return json({ ok: true });
  });
}