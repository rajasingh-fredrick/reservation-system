import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { addEventSelection, currentSheet } from "@/server/library";
import { asString, handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { getEvent } from "@/server/seasons";
import { parseWith, requirementsSchema } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function PATCH(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    const allowed = ["sheetIds", "notes", "requirements", "position", "confirmImpact"];
    if (!Object.keys(body).some((key) => allowed.includes(key)) || Object.keys(body).some((key) => !allowed.includes(key))) {
      throw new HttpError(400, "Provide supported event-song fields to update.", "INVALID_FIELD");
    }
    const existing = await transaction(async (tx) => {
      const rows = await tx.query<{ event_id: string; song_id: string; title: string }>(
        `SELECT es.event_id,es.song_id,s.title FROM event_songs es JOIN songs s ON s.id=es.song_id WHERE es.id=$1`, [id],
      );
      if (!rows.rows.length) throw new HttpError(404, "Event song not found.", "NOT_FOUND");
      return rows.rows[0];
    });
    const event = await getEvent(existing.event_id);
    if (!event) throw new HttpError(404, "Event not found.", "NOT_FOUND");
    const impact = event.season_status === "Published" && Object.keys(body).some((key) => key !== "confirmImpact");
    if (impact && body.confirmImpact !== true) throw new HttpError(409, "This song is assigned to a published event. Review impact and retry with confirmImpact=true.", "IMPACT_CONFIRMATION_REQUIRED");
    if (body.position !== undefined && (!Number.isSafeInteger(body.position) || Number(body.position) < 1)) {
      throw new HttpError(400, "position must be a positive whole number.", "INVALID_FIELD");
    }
    const notes = body.notes === undefined ? undefined : asString(body.notes, "notes", 5000);
    const requirements = body.requirements === undefined ? undefined : parseWith(requirementsSchema, body.requirements);
    let sheetIds: string[] | undefined;
    if (body.sheetIds !== undefined) {
      if (!Array.isArray(body.sheetIds) || body.sheetIds.some((item) => typeof item !== "string")) throw new HttpError(400, "sheetIds must be an array of identifiers.", "INVALID_FIELD");
      sheetIds = body.sheetIds.map((value) => idParam(String(value)));
      if (new Set(sheetIds).size !== sheetIds.length) throw new HttpError(400, "sheetIds cannot contain duplicates.", "INVALID_FIELD");
    }
    await transaction(async (tx) => {
      if (sheetIds) {
        const current = await tx.query<{ id: string }>("SELECT id FROM sheets WHERE song_id=$1 AND archived=false AND id=ANY($2)", [existing.song_id, sheetIds]);
        if (current.rows.length !== sheetIds.length) throw new HttpError(400, "Selected sheets must belong to this active library song.", "INVALID_SHEET_SELECTION");
        await tx.query("DELETE FROM event_sheets WHERE event_song_id=$1", [id]);
        for (const sheetId of sheetIds) await addEventSelection(tx, id, sheetId);
      }
      if (notes !== undefined) await tx.query("UPDATE event_songs SET notes=$1 WHERE id=$2", [notes, id]);
      if (requirements) {
        const currentRequirements = await tx.query<{ instrument: string; capacity: number }>(
          "SELECT instrument,capacity FROM event_requirements WHERE event_song_id=$1 FOR UPDATE",
          [id],
        );
        const nextInstruments = new Set<string>(requirements.map((requirement) => requirement.instrument));
        for (const requirement of requirements) {
          const current = currentRequirements.rows.find((item) => item.instrument === requirement.instrument);
          if (!current) {
            await tx.query("INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES ($1,$2,$3)", [id, requirement.instrument, requirement.capacity]);
            continue;
          }
          const count = await tx.query<{ count: number | string }>(
            "SELECT COUNT(*) AS count FROM reservations WHERE event_song_id=$1 AND instrument=$2 AND status='Confirmed'",
            [id, requirement.instrument],
          );
          if (requirement.capacity < Number(count.rows[0]?.count ?? 0)) {
            throw new HttpError(409, `${requirement.instrument} capacity cannot be reduced below the number of confirmed reservations. Resolve affected reservations first.`, "CAPACITY_BELOW_RESERVED");
          }
          await tx.query("UPDATE event_requirements SET capacity=$1 WHERE event_song_id=$2 AND instrument=$3", [requirement.capacity, id, requirement.instrument]);
        }
        for (const current of currentRequirements.rows) {
          if (nextInstruments.has(current.instrument)) continue;
          const references = await tx.query<{ count: number | string }>(
            "SELECT COUNT(*) AS count FROM reservations WHERE event_song_id=$1 AND instrument=$2",
            [id, current.instrument],
          );
          if (Number(references.rows[0]?.count ?? 0) > 0) {
            throw new HttpError(409, `${current.instrument} has reservation history. Resolve or retain those records before removing this requirement.`, "REQUIREMENT_HAS_HISTORY");
          }
          await tx.query("DELETE FROM event_requirements WHERE event_song_id=$1 AND instrument=$2", [id, current.instrument]);
        }
      }
      if (body.position !== undefined) {
        const rows = await tx.query<{ id: string }>("SELECT id FROM event_songs WHERE event_id=$1 ORDER BY position", [existing.event_id]);
        const ordered = rows.rows.map((row) => row.id).filter((songId) => songId !== id);
        ordered.splice(Math.min(Number(body.position) - 1, ordered.length), 0, id);
        const offset = ordered.length + 100;
        for (let i = 0; i < ordered.length; i += 1) await tx.query("UPDATE event_songs SET position=$1 WHERE id=$2", [offset + i, ordered[i]]);
        for (let i = 0; i < ordered.length; i += 1) await tx.query("UPDATE event_songs SET position=$1 WHERE id=$2", [i + 1, ordered[i]]);
      }
      await recordAudit(actor.id, "event_song_updated", `Updated event setup for “${existing.title}” in “${event.name}”.${impact ? " Published event impact confirmed." : ""}`, tx);
    });
    return json({ ok: true });
  });
}

export async function DELETE(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const confirmImpact = new URL(request.url).searchParams.get("confirmImpact") === "true";
    await transaction(async (tx) => {
      const rows = await tx.query<{ event_id: string; title: string; name: string; status: string }>(
        `SELECT es.event_id,s.title,e.name,sn.status FROM event_songs es JOIN songs s ON s.id=es.song_id
         JOIN events e ON e.id=es.event_id JOIN seasons sn ON sn.id=e.season_id WHERE es.id=$1`, [id],
      );
      if (!rows.rows.length) throw new HttpError(404, "Event song not found.", "NOT_FOUND");
      const item = rows.rows[0];
      if (item.status === "Published" && !confirmImpact) throw new HttpError(409, "This assignment belongs to a published event. Retry with confirmImpact=true after impact review.", "IMPACT_CONFIRMATION_REQUIRED");
      const reservations = await tx.query("SELECT 1 FROM reservations WHERE event_song_id=$1 LIMIT 1", [id]);
      if (reservations.rows.length) {
        throw new HttpError(409, "This song assignment has reservation history. Cancel or reassign those reservations before removing it.", "EVENT_SONG_HAS_RESERVATIONS");
      }
      await tx.query("DELETE FROM event_sheets WHERE event_song_id=$1", [id]);
      await tx.query("DELETE FROM event_requirements WHERE event_song_id=$1", [id]);
      await tx.query("DELETE FROM event_songs WHERE id=$1", [id]);
      await recordAudit(actor.id, "event_song_removed", `Removed “${item.title}” from event “${item.name}”. Library records were preserved.`, tx);
      const remaining = await tx.query<{ id: string }>("SELECT id FROM event_songs WHERE event_id=$1 ORDER BY position", [item.event_id]);
      for (let i = 0; i < remaining.rows.length; i += 1) await tx.query("UPDATE event_songs SET position=$1 WHERE id=$2", [10000 + i, remaining.rows[i].id]);
      for (let i = 0; i < remaining.rows.length; i += 1) await tx.query("UPDATE event_songs SET position=$1 WHERE id=$2", [i + 1, remaining.rows[i].id]);
    });
    return json({ ok: true });
  });
}
