import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { addEventSelection } from "@/server/library";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { getEvent } from "@/server/seasons";
import { parseWith, requirementsSchema } from "@/server/validation";
import { asString } from "@/server/http";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function POST(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const eventId = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    const songId = typeof body.songId === "string" ? idParam(body.songId) : "";
    if (!songId) throw new HttpError(400, "songId is required.", "INVALID_FIELD");
    if (!Array.isArray(body.sheetIds) || body.sheetIds.some((id) => typeof id !== "string")) throw new HttpError(400, "sheetIds must be an array of identifiers.", "INVALID_FIELD");
    const sheetIds = body.sheetIds.map((id) => idParam(String(id)));
    if (new Set(sheetIds).size !== sheetIds.length) throw new HttpError(400, "sheetIds cannot contain duplicates.", "INVALID_FIELD");
    const notes = body.notes === undefined ? "" : asString(body.notes, "notes", 5000);
    const requirements = parseWith(requirementsSchema, body.requirements);
    const event = await getEvent(eventId);
    if (!event) throw new HttpError(404, "Event not found.", "NOT_FOUND");
    const id = await transaction(async (tx) => {
      const song = await tx.query<{ title: string }>("SELECT title FROM songs WHERE id=$1 AND archived=false", [songId]);
      if (!song.rows.length) throw new HttpError(404, "An active library song is required.", "SONG_NOT_FOUND");
      const selected = await tx.query<{ id: string }>("SELECT id FROM sheets WHERE song_id=$1 AND archived=false AND id=ANY($2)", [songId, sheetIds]);
      if (selected.rows.length !== sheetIds.length) throw new HttpError(400, "Every selected sheet must belong to this active library song.", "INVALID_SHEET_SELECTION");
      const max = await tx.query<{ max: number | null }>("SELECT MAX(position) AS max FROM event_songs WHERE event_id=$1", [eventId]);
      const position = Number(max.rows[0]?.max || 0) + 1;
      const id = randomUUID();
      await tx.query("INSERT INTO event_songs (id,event_id,song_id,notes,position) VALUES ($1,$2,$3,$4,$5)", [id, eventId, songId, notes, position]);
      for (const requirement of requirements) {
        await tx.query("INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES ($1,$2,$3)", [id, requirement.instrument, requirement.capacity]);
      }
      for (const sheetId of sheetIds) await addEventSelection(tx, id, sheetId);
      await recordAudit(actor.id, "event_song_added", `Added “${song.rows[0].title}” to event “${event.name}” with ${requirements.length} instrument requirement(s).`, tx);
      return id;
    });
    return json({ id }, 201);
  });
}
