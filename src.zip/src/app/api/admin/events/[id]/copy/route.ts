import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { addEventSelection } from "@/server/library";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { getEvent } from "@/server/seasons";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function POST(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const sourceId = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    const targetId = typeof body.targetEventId === "string" ? idParam(body.targetEventId) : "";
    if (!targetId) throw new HttpError(400, "targetEventId is required.", "INVALID_FIELD");
    if (targetId === sourceId) throw new HttpError(400, "Choose a different target event.", "INVALID_FIELD");
    const [source, target] = await Promise.all([getEvent(sourceId), getEvent(targetId)]);
    if (!source || !target) throw new HttpError(404, "Source or target event was not found.", "NOT_FOUND");
    const copied = await transaction(async (tx) => {
      const rows = await tx.query<{ id: string; song_id: string; notes: string; position: number }>(
        "SELECT id,song_id,notes,position FROM event_songs WHERE event_id=$1 ORDER BY position", [sourceId],
      );
      const result: string[] = [];
      const max = await tx.query<{ max: number | null }>("SELECT MAX(position) AS max FROM event_songs WHERE event_id=$1", [targetId]);
      let position = Number(max.rows[0]?.max || 0) + 1;
      for (const song of rows.rows) {
        const id = crypto.randomUUID();
        await tx.query("INSERT INTO event_songs (id,event_id,song_id,notes,position) VALUES ($1,$2,$3,$4,$5)", [id, targetId, song.song_id, song.notes, position++]);
        const requirements = await tx.query<{ instrument: string; capacity: number }>("SELECT instrument,capacity FROM event_requirements WHERE event_song_id=$1", [song.id]);
        for (const requirement of requirements.rows) {
          await tx.query("INSERT INTO event_requirements (event_song_id,instrument,capacity) VALUES ($1,$2,$3)", [id, requirement.instrument, requirement.capacity]);
        }
        const sheets = await tx.query<{ sheet_id: string; selected_version: number }>("SELECT sheet_id,selected_version FROM event_sheets WHERE event_song_id=$1", [song.id]);
        for (const sheet of sheets.rows) {
          await tx.query("INSERT INTO event_sheets (event_song_id,sheet_id,selected_version) VALUES ($1,$2,$3)", [id, sheet.sheet_id, sheet.selected_version]);
        }
        result.push(id);
      }
      await recordAudit(actor.id, "event_setup_copied", `Copied ${result.length} song setup(s) from “${source.name}” to “${target.name}”.`, tx);
      return result;
    });
    return json({ ids: copied }, 201);
  });
}
