import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { getEvent, assertDateInSeason } from "@/server/seasons";
import { eventInputSchema, parseWith } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    const allowed = ["name", "startsAt", "endsAt", "location", "confirmImpact"];
    if (!Object.keys(body).some((key) => allowed.includes(key)) || Object.keys(body).some((key) => !allowed.includes(key))) {
      throw new HttpError(400, "Provide supported event fields to update.", "INVALID_FIELD");
    }
    const event = await getEvent(id);
    if (!event) throw new HttpError(404, "Event not found.", "NOT_FOUND");
    const updated = parseWith(eventInputSchema, {
      name: body.name ?? event.name,
      startsAt: body.startsAt ?? new Date(String(event.starts_at)).toISOString(),
      endsAt: body.endsAt ?? new Date(String(event.ends_at)).toISOString(),
      location: body.location ?? event.location,
    });
    const impact = event.season_status === "Published" && Object.keys(body).some((key) => key !== "confirmImpact");
    if (impact && body.confirmImpact !== true) throw new HttpError(409, "This event belongs to a published season. Review the impact and retry with confirmImpact=true.", "IMPACT_CONFIRMATION_REQUIRED");
    assertDateInSeason(updated.startsAt, String(event.start_date).slice(0, 10), String(event.end_date).slice(0, 10), event.timezone);
    assertDateInSeason(updated.endsAt, String(event.start_date).slice(0, 10), String(event.end_date).slice(0, 10), event.timezone);
    await transaction(async (tx) => {
      await tx.query("UPDATE events SET name=$1,starts_at=$2,ends_at=$3,location=$4 WHERE id=$5", [updated.name, new Date(updated.startsAt), new Date(updated.endsAt), updated.location, id]);
      await recordAudit(actor.id, "event_updated", `Updated event “${event.name}”.${impact ? " Published event impact confirmed." : ""}`, tx);
    });
    return json({ ok: true });
  });
}

export async function DELETE(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    await transaction(async (tx) => {
      const event = await tx.query<{ name: string; season_id: string; season_status: string }>(
        `SELECT e.name,e.season_id,s.status AS season_status FROM events e JOIN seasons s ON s.id=e.season_id WHERE e.id=$1`, [id],
      );
      if (!event.rows.length) throw new HttpError(404, "Event not found.", "NOT_FOUND");
      if (event.rows[0].season_status !== "Draft") throw new HttpError(409, "Only events in draft seasons can be deleted.", "DRAFT_ONLY");
      const reservations = await tx.query("SELECT 1 FROM reservations WHERE event_id=$1 LIMIT 1", [id]);
      if (reservations.rows.length) {
        throw new HttpError(409, "This event has reservation history. Cancel or reassign those reservations before deleting the event.", "EVENT_HAS_RESERVATIONS");
      }
      const songIds = await tx.query<{ id: string }>("SELECT id FROM event_songs WHERE event_id=$1", [id]);
      for (const item of songIds.rows) {
        await tx.query("DELETE FROM event_sheets WHERE event_song_id=$1", [item.id]);
        await tx.query("DELETE FROM event_requirements WHERE event_song_id=$1", [item.id]);
      }
      await tx.query("DELETE FROM event_songs WHERE event_id=$1", [id]);
      await tx.query("DELETE FROM events WHERE id=$1", [id]);
      await recordAudit(actor.id, "event_deleted", `Deleted draft event “${event.rows[0].name}”. Library songs and sheets were preserved.`, tx);
    });
    return json({ ok: true });
  });
}
