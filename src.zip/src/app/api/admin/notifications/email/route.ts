import { NextRequest } from "next/server";
import { queueEmail } from "@/server/email-queue";
import { query, transaction } from "@/server/db";
import { handle, HttpError, json, rateLimit, recordAudit, requireAdmin, requireAdminWrite } from "@/server/http";
import { adminEmailSchema, parseWith } from "@/server/validation";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ParentRecipient = { id: string; name: string; email: string };

async function getVerifiedParents() {
  const result = await query<ParentRecipient>(
    `SELECT u.id,u.name,u.email
     FROM parent_profiles pp JOIN "user" u ON u.id=pp.user_id
     WHERE u."emailVerified"=true AND pp.email_notifications_subscribed=true
     ORDER BY lower(u.name),lower(u.email)`,
  );
  return result.rows;
}

export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    return json({ parents: await getVerifiedParents() });
  });
}

export async function POST(request: NextRequest) {
  return handle(async () => {
    const admin = await requireAdminWrite(request);
    rateLimit(`admin-email:${admin.id}`, 3, 60_000);
    const input = parseWith(adminEmailSchema, await request.json());
    const recipients = input.allParents
      ? await getVerifiedParents()
      : (await query<ParentRecipient>(
        `SELECT u.id,u.name,u.email
         FROM parent_profiles pp JOIN "user" u ON u.id=pp.user_id
         WHERE u."emailVerified"=true AND pp.email_notifications_subscribed=true AND u.id IN ($1)
         ORDER BY lower(u.name),lower(u.email)`,
        [input.recipientIds],
      )).rows;

    if (!input.allParents && recipients.length !== input.recipientIds.length) {
      throw new HttpError(400, "One or more selected accounts are no longer subscribed, verified parents. Refresh the recipient list and try again.", "INVALID_RECIPIENT");
    }
    if (recipients.length === 0) {
      throw new HttpError(409, "There are no subscribed, verified parent accounts to email.", "NO_PARENTS");
    }

    await transaction(async (tx) => {
      await recordAudit(
        admin.id,
        "parent_email_queued",
        `Queued an administrator email to ${recipients.length} parent${recipients.length === 1 ? "" : "s"}.`,
        tx,
      );
      for (const recipient of recipients) {
        await queueEmail(tx, {
          userId: recipient.id, kind: "MinistryMessage", subject: input.subject, text: input.message,
        });
      }
    });
    return json({
      queuedCount: recipients.length,
      totalCount: recipients.length,
    }, 202);
  });
}
