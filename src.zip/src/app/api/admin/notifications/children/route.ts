import { NextRequest } from "next/server";
import { query, transaction } from "@/server/db";
import { handle, HttpError, idParam, json, parseJson, rateLimit, recordAudit, requiredString, requireAdmin, requireAdminWrite } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    const result = await query(
      `SELECT n.id,CASE WHEN n.recipient='Administrator' THEN 'Administrator registration' ELSE n.kind END AS kind,
         n.status,n.attempts,n.created_at,n.last_attempt_at,n.sent_at,
         u.name AS parent_name,c.full_name AS child_name
       FROM child_profile_notifications n JOIN "user" u ON u.id=n.parent_user_id
       JOIN children c ON c.id=n.child_id
       ORDER BY (n.status IN ('Pending','Failed','Sending')) DESC,n.created_at DESC,n.id LIMIT 100`,
    );
    const automated = await query(
      `SELECT n.id,n.kind,n.status,n.attempts,n.created_at,n.last_attempt_at,n.sent_at,
         u.name AS parent_name,s.name AS season_name,e.name AS event_name
       FROM automated_notifications n JOIN "user" u ON u.id=n.parent_user_id
       JOIN seasons s ON s.id=n.season_id LEFT JOIN events e ON e.id=n.event_id
       ORDER BY (n.status IN ('Pending','Failed','Sending')) DESC,n.created_at DESC,n.id LIMIT 100`,
    );
    const immediate = await query(
      `SELECT n.id,n.kind,n.status,n.attempts,n.created_at,n.last_attempt_at,n.sent_at,u.name AS parent_name
       FROM email_notifications n JOIN "user" u ON u.id=n.user_id
       ORDER BY (n.status IN ('Pending','Failed','Sending')) DESC,n.created_at DESC,n.id LIMIT 100`,
    );
    return json({ notifications: result.rows, automatedNotifications: automated.rows, immediateNotifications: immediate.rows });
  });
}

export async function POST(request: NextRequest) {
  return handle(async () => {
    const admin = await requireAdminWrite(request);
    rateLimit(`child-email-retry:${admin.id}`, 10, 60_000);
    const body = parseJson(await request.json());
    const id = idParam(requiredString(body.id, "id", 36));
    const status = await transaction(async (tx) => {
      const row = (await tx.query<{ status: string }>(
        "SELECT status FROM child_profile_notifications WHERE id=$1 FOR UPDATE", [id],
      )).rows[0];
      if (!row) throw new HttpError(404, "Notification not found.", "NOTIFICATION_NOT_FOUND");
      if (row.status !== "Pending" && row.status !== "Failed") return row.status;
      await tx.query("UPDATE child_profile_notifications SET status='Pending' WHERE id=$1", [id]);
      await recordAudit(admin.id, "child_email_retry", `Queued retry of child profile notification ${id}.`, tx);
      return "Pending";
    });
    return json({ status }, 202);
  });
}
