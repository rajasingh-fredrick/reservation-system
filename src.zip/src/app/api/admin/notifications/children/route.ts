import { NextRequest } from "next/server";
import { query } from "@/server/db";
import { deliverChildNotification } from "@/server/child-notifications";
import { handle, idParam, json, parseJson, rateLimit, recordAudit, requiredString, requireAdmin, requireAdminWrite } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  return handle(async () => {
    await requireAdmin(request);
    const result = await query(
      `SELECT n.id,CASE WHEN n.recipient='Administrator' THEN 'Administrator registration' ELSE n.kind END AS kind,
         n.status,n.attempts,n.created_at,n.last_attempt_at,n.sent_at,
         u.name AS parent_name,c.full_name AS child_name
       FROM child_profile_notifications n JOIN "user" u ON u.id=n.parent_user_id
       JOIN children c ON c.id=n.child_id
       ORDER BY (n.status IN ('Pending','Failed','Sending')) DESC,n.created_at DESC,n.id LIMIT 100`,
    );
    return json({ notifications: result.rows });
  });
}

export async function POST(request: NextRequest) {
  return handle(async () => {
    const admin = await requireAdminWrite(request);
    rateLimit(`child-email-retry:${admin.id}`, 10, 60_000);
    const body = parseJson(await request.json());
    const id = idParam(requiredString(body.id, "id", 36));
    await recordAudit(admin.id, "child_email_retry", `Requested delivery of child profile notification ${id}.`);
    return json({ status: await deliverChildNotification(id) });
  });
}
