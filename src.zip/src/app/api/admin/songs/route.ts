import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { query, transaction } from "@/server/db";
import { handle, HttpError, json, recordAudit, requireAdminWrite, requiredString } from "@/server/http";
import { auditSong, insertSheet, removeFiles, resolveSheetInputs, writePdf, type SheetInput } from "@/server/library";
import { parseMultipartJson, parseWith, requirePermission, songLinksSchema } from "@/server/validation";

export const runtime = "nodejs";
export async function POST(request: NextRequest) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const form = await request.formData();
    requirePermission(form);
    const title = requiredString(form.get("title"), "title", 200);
    const composerValue = form.get("composer");
    const notesValue = form.get("notes");
    if (composerValue !== null && typeof composerValue !== "string" || notesValue !== null && typeof notesValue !== "string") {
      throw new HttpError(400, "Composer and notes must be text.", "INVALID_FIELD");
    }
    const composer = String(composerValue || "").trim().slice(0, 200);
    const notes = String(notesValue || "").slice(0, 5000);
    const links = form.has("links") ? parseMultipartJson(form, "links", (value) => parseWith(songLinksSchema, value)) : [];
    const inputs = await resolveSheetInputs(form);
    const written: { input: SheetInput; key: string; target: string }[] = [];
    try {
      for (const input of inputs) written.push({ input, ...(await writePdf(input.file)) });
      const id = randomUUID();
      await transaction(async (tx) => {
        await tx.query("INSERT INTO songs (id,title,composer,notes,links) VALUES ($1,$2,$3,$4,$5)", [id, title, composer, notes, JSON.stringify(links)]);
        for (const item of written) await insertSheet(tx, id, item.input, item.key);
        await auditSong(tx, actor.id, "song_created", `Created song “${title}” with ${inputs.length} sheet(s).`);
      });
      return json({ id }, 201);
    } catch (error) {
      await removeFiles(written.map((item) => item.target));
      throw error;
    }
  });
}
