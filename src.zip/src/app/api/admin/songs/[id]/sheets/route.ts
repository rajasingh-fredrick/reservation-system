import { NextRequest } from "next/server";
import { randomUUID } from "node:crypto";
import { query, transaction } from "@/server/db";
import { handle, HttpError, idParam, json, requireAdminWrite } from "@/server/http";
import { auditSong, insertSheet, removeFiles, resolveSheetInputs, usageForSong, writePdf, type SheetInput } from "@/server/library";
import { requirePermission } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function POST(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const songId = idParam((await context.params).id);
    const form = await request.formData();
    requirePermission(form);
    const song = await query<{ title: string }>("SELECT title FROM songs WHERE id=$1 AND archived=false", [songId]);
    if (!song.rows.length) throw new HttpError(404, "Active song not found.", "NOT_FOUND");
    const usages = await usageForSong(songId);
    const published = usages.filter((usage) => usage.season_status === "Published");
    if (published.length && form.get("confirmImpact") !== "true") {
      throw new HttpError(409, "Adding sheets to a song used by published events requires reviewed impact confirmation.", "IMPACT_CONFIRMATION_REQUIRED");
    }
    const inputs = await resolveSheetInputs(form);
    const written: { input: SheetInput; key: string; target: string }[] = [];
    try {
      for (const input of inputs) written.push({ input, ...(await writePdf(input.file)) });
      const ids: string[] = [];
      await transaction(async (tx) => {
        for (const item of written) ids.push(await insertSheet(tx, songId, item.input, item.key));
        await auditSong(tx, actor.id, "sheets_added", `Added ${inputs.length} sheet(s) to “${song.rows[0].title}”.`);
      });
      return json({ ids }, 201);
    } catch (error) {
      await removeFiles(written.map((item) => item.target));
      throw error;
    }
  });
}
