import { NextRequest } from "next/server";
import path from "node:path";
import { transaction, uploadDirectory } from "@/server/db";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { removeFiles, usageForSong } from "@/server/library";
import { parseWith, songLinksSchema } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    const allowed = ["title", "composer", "notes", "links", "archived", "confirmImpact"];
    if (Object.keys(body).some((key) => !allowed.includes(key))) throw new HttpError(400, "Unsupported song field.", "INVALID_FIELD");
    const usages = await usageForSong(id);
    const published = usages.filter((usage) => usage.season_status === "Published");
    if (published.length && body.confirmImpact !== true) {
      throw new HttpError(409, "This shared song is used by published events. Review the listed impact and retry with confirmImpact=true.", "IMPACT_CONFIRMATION_REQUIRED");
    }
    const parts: string[] = [];
    const values: unknown[] = [];
    for (const [field, column, max] of [["title", "title", 200], ["composer", "composer", 200], ["notes", "notes", 5000]] as const) {
      if (body[field] !== undefined) {
        if (typeof body[field] !== "string" || !body[field].trim() && field === "title" || String(body[field]).length > max) {
          throw new HttpError(400, `Invalid ${field}.`, "INVALID_FIELD");
        }
        values.push(field === "title" || field === "composer" ? String(body[field]).trim() : body[field]);
        parts.push(`${column}=$${values.length}`);
      }
    }
    if (body.links !== undefined) {
      values.push(JSON.stringify(parseWith(songLinksSchema, body.links)));
      parts.push(`links=$${values.length}::jsonb`);
    }
    if (body.archived !== undefined) {
      if (typeof body.archived !== "boolean") throw new HttpError(400, "archived must be a boolean.", "INVALID_FIELD");
      values.push(body.archived); parts.push(`archived=$${values.length}`);
    }
    if (!parts.length) throw new HttpError(400, "No song fields to update.", "INVALID_FIELD");
    values.push(id);
    await transaction(async (tx) => {
      const updated = await tx.query(`UPDATE songs SET ${parts.join(",")},updated_at=now() WHERE id=$${values.length} RETURNING title`, values);
      if (!updated.rowCount) throw new HttpError(404, "Song not found.", "NOT_FOUND");
      await recordAudit(actor.id, body.archived === undefined ? "song_updated" : body.archived ? "song_archived" : "song_unarchived",
        `Updated song “${updated.rows[0].title}”.${published.length ? ` Published event impact confirmed (${published.length} usage(s)).` : ""}`, tx);
    });
    return json({ ok: true });
  });
}

export async function DELETE(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const fileKeys = await transaction(async (tx) => {
      const used = await tx.query("SELECT 1 FROM event_songs WHERE song_id=$1 LIMIT 1", [id]);
      if (used.rows.length) throw new HttpError(409, "This song is referenced by an event and cannot be deleted. Archive it instead.", "RECORD_IN_USE");
      const row = await tx.query("SELECT title FROM songs WHERE id=$1", [id]);
      if (!row.rows.length) throw new HttpError(404, "Song not found.", "NOT_FOUND");
      const sheetRows = await tx.query<{ storage_key: string }>("SELECT storage_key FROM sheet_versions WHERE sheet_id IN (SELECT id FROM sheets WHERE song_id=$1)", [id]);
      await tx.query("DELETE FROM sheet_versions WHERE sheet_id IN (SELECT id FROM sheets WHERE song_id=$1)", [id]);
      await tx.query("DELETE FROM sheets WHERE song_id=$1", [id]);
      await tx.query("DELETE FROM songs WHERE id=$1", [id]);
      await recordAudit(actor.id, "song_deleted", `Deleted unused song “${row.rows[0].title}”.`, tx);
      return sheetRows.rows.map((item) => item.storage_key);
    });
    await removeFiles(fileKeys.map((key) => path.join(uploadDirectory, key)));
    return json({ ok: true });
  });
}
