import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { parseWith, seasonCreateSchema } from "@/server/validation";
import { assertDateInSeason, schedulePublication, validSeasonColumns } from "@/server/seasons";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new HttpError(400, "Season fields must be an object.", "INVALID_FIELD");
    const keys = Object.keys(body);
    if (!keys.length || keys.some((key) => !Object.hasOwn(validSeasonColumns, key) && key !== "registrationNotificationAt")) throw new HttpError(400, "Unsupported or missing season fields.", "INVALID_FIELD");
    await transaction(async (tx) => {
      const current = await tx.query<Record<string, unknown>>("SELECT * FROM seasons WHERE id=$1 FOR UPDATE", [id]);
      if (!current.rows.length) throw new HttpError(404, "Season not found.", "NOT_FOUND");
      const row = current.rows[0];
      const merged = {
        name: body.name ?? row.name, description: body.description ?? row.description,
        startDate: body.startDate ?? String(row.start_date).slice(0, 10),
        endDate: body.endDate ?? String(row.end_date).slice(0, 10),
        registrationOpensAt: body.registrationOpensAt ?? new Date(String(row.registration_opens_at)).toISOString(),
        registrationClosesAt: body.registrationClosesAt ?? new Date(String(row.registration_closes_at)).toISOString(),
        timezone: body.timezone ?? row.timezone, location: body.location ?? row.location,
        instructions: body.instructions ?? row.instructions, cancellationHours: body.cancellationHours ?? row.cancellation_hours,
        status: body.status ?? row.status,
        registrationNotificationAt: body.registrationNotificationAt,
      };
      const parsed = parseWith(seasonCreateSchema, merged);
      await schedulePublication(tx, id, row.first_published_at, parsed.status, parsed.registrationNotificationAt, parsed.timezone);
      const events = await tx.query<{ starts_at: unknown; ends_at: unknown }>(
        "SELECT starts_at,ends_at FROM events WHERE season_id=$1",
        [id],
      );
      for (const event of events.rows) {
        assertDateInSeason(new Date(String(event.starts_at)).toISOString(), parsed.startDate, parsed.endDate, parsed.timezone);
        assertDateInSeason(new Date(String(event.ends_at)).toISOString(), parsed.startDate, parsed.endDate, parsed.timezone);
      }
      const editableKeys = keys.filter((key): key is keyof typeof validSeasonColumns => Object.hasOwn(validSeasonColumns, key));
      const entries = editableKeys.map((key) => [key, parsed[key]] as const);
      const sets = entries.map(([key], index) => `${validSeasonColumns[key]}=$${index + 1}`);
      const values: unknown[] = entries.map(([key, value]) =>
        key === "registrationOpensAt" || key === "registrationClosesAt" ? new Date(String(value)) : value);
      values.push(id);
      await tx.query(`UPDATE seasons SET ${[...sets, "updated_at=now()"].join(",")} WHERE id=$${values.length}`, values);
      await recordAudit(actor.id, "season_updated", `Updated season “${parsed.name}” (${keys.join(", ")}).`, tx);
    });
    return json({ ok: true });
  });
}

export async function DELETE(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const id = idParam((await context.params).id);
    await transaction(async (tx) => {
      const season = await tx.query<{ name: string; status: string }>("SELECT name,status FROM seasons WHERE id=$1 FOR UPDATE", [id]);
      if (!season.rows.length) throw new HttpError(404, "Season not found.", "NOT_FOUND");
      const reservations = await tx.query("SELECT id FROM reservations WHERE season_id=$1", [id]);
      if (reservations.rows.length && season.rows[0].status !== "Archived") {
        throw new HttpError(409, "This season has reservation history and cannot be deleted. Use Edit to change its status to Archived instead.", "SEASON_HAS_RESERVATIONS");
      }
      if (reservations.rows.length) await tx.query("DELETE FROM reservations WHERE season_id=$1", [id]);
      await tx.query(
        `DELETE FROM event_sheets WHERE event_song_id IN
         (SELECT es.id FROM event_songs es JOIN events e ON e.id=es.event_id WHERE e.season_id=$1)`,
        [id],
      );
      await tx.query(
        `DELETE FROM event_requirements WHERE event_song_id IN
         (SELECT es.id FROM event_songs es JOIN events e ON e.id=es.event_id WHERE e.season_id=$1)`,
        [id],
      );
      await tx.query("DELETE FROM event_songs WHERE event_id IN (SELECT id FROM events WHERE season_id=$1)", [id]);
      await tx.query("DELETE FROM events WHERE season_id=$1", [id]);
      await tx.query("DELETE FROM seasons WHERE id=$1", [id]);
      await recordAudit(actor.id, "season_deleted", `Deleted ${season.rows[0].status} season “${season.rows[0].name}”, ${reservations.rows.length} reservation record(s), and its events. Library songs and sheets were preserved.`, tx);
    });
    return json({ ok: true });
  });
}
