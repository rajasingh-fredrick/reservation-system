import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { handle, idParam, json, recordAudit, requireAdminWrite } from "@/server/http";
import { addEvent } from "@/server/seasons";
import { eventCreateSchema, parseWith } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function POST(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const seasonId = idParam((await context.params).id);
    const input = parseWith(eventCreateSchema, await request.json());
    const id = await transaction(async (tx) => {
      const newId = await addEvent(tx, seasonId, input);
      await recordAudit(actor.id, "event_created", `Added event “${input.name}” to season ${seasonId}.`, tx);
      return newId;
    });
    return json({ id }, 201);
  });
}
