import { NextRequest } from "next/server";
import { z } from "zod";
import { transaction } from "@/server/db";
import { handle, idParam, json, requireAdminWrite } from "@/server/http";
import { setSeasonSongExtra, setSeasonSongRole } from "@/server/season-songs";
import { SONG_ROLES } from "@/lib/contracts";
import { parseWith } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string; songId: string }> };
const settingsSchema = z.object({
  allowExtra: z.boolean().optional(),
  songRole: z.enum(SONG_ROLES).nullable().optional(),
  confirmImpact: z.boolean().default(false),
}).strict().refine((value) => value.allowExtra !== undefined || value.songRole !== undefined, "Choose a season song setting to update.");

export async function PATCH(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const params = await context.params;
    const seasonId = idParam(params.id);
    const songId = idParam(params.songId);
    const input = parseWith(settingsSchema, await request.json());
    await transaction(async (tx) => {
      if (input.allowExtra !== undefined) await setSeasonSongExtra(tx, { ...input, allowExtra: input.allowExtra, seasonId, songId, actorId: actor.id });
      if (input.songRole !== undefined) await setSeasonSongRole(tx, seasonId, songId, input.songRole, actor.id);
    });
    return json({ ok: true });
  });
}
