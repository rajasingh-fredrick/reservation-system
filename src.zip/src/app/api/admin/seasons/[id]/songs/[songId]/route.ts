import { NextRequest } from "next/server";
import { z } from "zod";
import { transaction } from "@/server/db";
import { handle, idParam, json, requireAdminWrite } from "@/server/http";
import { setSeasonSongExtra } from "@/server/season-songs";
import { parseWith } from "@/server/validation";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string; songId: string }> };
const settingsSchema = z.object({
  allowExtra: z.boolean(),
  confirmImpact: z.boolean().default(false),
}).strict();

export async function PATCH(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const params = await context.params;
    const seasonId = idParam(params.id);
    const songId = idParam(params.songId);
    const input = parseWith(settingsSchema, await request.json());
    await transaction((tx) => setSeasonSongExtra(tx, { ...input, seasonId, songId, actorId: actor.id }));
    return json({ ok: true });
  });
}
