import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite, requiredString } from "@/server/http";
import { localDateTimeToIso } from "@/server/time";
import { getSeason } from "@/server/seasons";
import { query } from "@/server/db";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function POST(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const seasonId = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    if (!Number.isInteger(body.weekday) || Number(body.weekday) < 0 || Number(body.weekday) > 6) throw new HttpError(400, "weekday must be an integer from 0 to 6.", "INVALID_FIELD");
    if (typeof body.time !== "string" || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.time)) throw new HttpError(400, "time must use HH:mm format.", "INVALID_FIELD");
    if (!Number.isInteger(body.durationMinutes) || Number(body.durationMinutes) < 1 || Number(body.durationMinutes) > 1440) throw new HttpError(400, "durationMinutes must be a positive integer no greater than one day.", "INVALID_FIELD");
    const name = requiredString(body.name, "name", 160);
    const season = await getSeason(seasonId);
    if (!season) throw new HttpError(404, "Season not found.", "NOT_FOUND");
    const [startYear, startMonth, startDay] = String(season.start_date).slice(0, 10).split("-").map(Number);
    const [endYear, endMonth, endDay] = String(season.end_date).slice(0, 10).split("-").map(Number);
    const cursor = new Date(Date.UTC(startYear, startMonth - 1, startDay));
    const end = Date.UTC(endYear, endMonth - 1, endDay);
    const firstWeekday = cursor.getUTCDay();
    cursor.setUTCDate(cursor.getUTCDate() + ((Number(body.weekday) - firstWeekday + 7) % 7));
    const dates: string[] = [];
    while (cursor.valueOf() <= end) {
      const date = cursor.toISOString().slice(0, 10);
      const startsAt = localDateTimeToIso(date, body.time, season.timezone);
      const endsAt = new Date(Date.parse(startsAt) + Number(body.durationMinutes) * 60_000).toISOString();
      dates.push(`${startsAt}|${endsAt}`);
      cursor.setUTCDate(cursor.getUTCDate() + 7);
    }
    const ids = await transaction(async (tx) => {
      const result: string[] = [];
      for (const item of dates) {
        const [startsAt, endsAt] = item.split("|");
        const id = randomUUID();
        await tx.query("INSERT INTO events (id,season_id,name,starts_at,ends_at,location) VALUES ($1,$2,$3,$4,$5,'')", [id, seasonId, name, new Date(startsAt), new Date(endsAt)]);
        result.push(id);
      }
      await recordAudit(actor.id, "events_generated", `Generated ${result.length} weekly event(s) named “${name}” for season ${seasonId}.`, tx);
      return result;
    });
    return json({ ids }, 201);
  });
}
