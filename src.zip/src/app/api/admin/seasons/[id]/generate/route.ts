import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { transaction } from "@/server/db";
import { handle, HttpError, idParam, json, recordAudit, requireAdminWrite, requiredString } from "@/server/http";
import { localDateTimeToIso } from "@/server/time";
import { getSeason } from "@/server/seasons";
import { query } from "@/server/db";
import { getScheduleDates, type SchedulePattern } from "@/lib/schedule";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function POST(request: NextRequest, context: Context) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const seasonId = idParam((await context.params).id);
    const body = await request.json() as Record<string, unknown>;
    if (!Number.isInteger(body.weekday) || Number(body.weekday) < 0 || Number(body.weekday) > 6) throw new HttpError(400, "weekday must be an integer from 0 to 6.", "INVALID_FIELD");
    const rawPatterns = body.patterns ?? [body.frequency === "monthly" ? `monthly-${String(body.weekOfMonth ?? "")}` : "weekly"];
    if (!Array.isArray(rawPatterns) || rawPatterns.length === 0 || rawPatterns.some((pattern) => typeof pattern !== "string")) {
      throw new HttpError(400, "Select at least one valid repeat pattern.", "INVALID_FIELD");
    }
    const patterns: SchedulePattern[] = [];
    for (const recurrence of new Set(rawPatterns as string[])) {
      if (recurrence === "weekly") patterns.push({ frequency: "weekly" });
      else {
        const match = /^monthly-([1-5])$/.exec(recurrence);
        if (!match) throw new HttpError(400, "Repeat patterns must be weekly or monthly-1 through monthly-5.", "INVALID_FIELD");
        patterns.push({ frequency: "monthly", weekOfMonth: Number(match[1]) });
      }
    }
    if (typeof body.time !== "string" || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.time)) throw new HttpError(400, "time must use HH:mm format.", "INVALID_FIELD");
    if (!Number.isInteger(body.durationMinutes) || Number(body.durationMinutes) < 1 || Number(body.durationMinutes) > 1440) throw new HttpError(400, "durationMinutes must be a positive integer no greater than one day.", "INVALID_FIELD");
    const name = requiredString(body.name, "name", 160);
    const season = await getSeason(seasonId);
    if (!season) throw new HttpError(404, "Season not found.", "NOT_FOUND");
    const dates = getScheduleDates(String(season.start_date), String(season.end_date), Number(body.weekday), patterns);
    if (!dates.length) throw new HttpError(400, "The selected schedule has no dates within this season.", "NO_SCHEDULE_DATES");
    const starts: string[] = [];
    for (const date of dates) {
      const startsAt = localDateTimeToIso(date, body.time, season.timezone);
      const endsAt = new Date(Date.parse(startsAt) + Number(body.durationMinutes) * 60_000).toISOString();
      starts.push(`${startsAt}|${endsAt}`);
    }
    const ids = await transaction(async (tx) => {
      const result: string[] = [];
      for (const item of starts) {
        const [startsAt, endsAt] = item.split("|");
        const id = randomUUID();
        await tx.query("INSERT INTO events (id,season_id,name,starts_at,ends_at,location) VALUES ($1,$2,$3,$4,$5,'')", [id, seasonId, name, new Date(startsAt), new Date(endsAt)]);
        result.push(id);
      }
      const cadence = patterns.map((pattern) => pattern.frequency === "weekly" ? "weekly" : `monthly week ${pattern.weekOfMonth}`).join(" and ");
      await recordAudit(actor.id, "events_generated", `Generated ${result.length} ${cadence} event(s) named “${name}” for season ${seasonId}.`, tx);
      return result;
    });
    return json({ ids }, 201);
  });
}
