import { randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { seasonCreateSchema, parseWith } from "@/server/validation";
import { transaction } from "@/server/db";
import { handle, json, recordAudit, requireAdminWrite } from "@/server/http";
import { schedulePublication } from "@/server/seasons";

export const runtime = "nodejs";
export async function POST(request: NextRequest) {
  return handle(async () => {
    const actor = await requireAdminWrite(request);
    const body = parseWith(seasonCreateSchema, await request.json());
    const id = randomUUID();
    await transaction(async (tx) => {
      await tx.query(
        `INSERT INTO seasons (id,name,description,start_date,end_date,registration_opens_at,registration_closes_at,
          timezone,location,instructions,cancellation_hours,status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [id, body.name, body.description, body.startDate, body.endDate, new Date(body.registrationOpensAt), new Date(body.registrationClosesAt),
          body.timezone, body.location, body.instructions, body.cancellationHours, body.status],
      );
      await schedulePublication(tx, id, null, body.status, body.registrationNotificationAt, body.timezone);
      await recordAudit(actor.id, "season_created", `Created ${body.status.toLowerCase()} season “${body.name}”.`, tx);
    });
    return json({ id }, 201);
  });
}
