import { randomBytes, timingSafeEqual, randomUUID } from "node:crypto";
import { NextRequest } from "next/server";
import { hashPassword } from "better-auth/crypto";
import { getAuth } from "@/server/auth";
import { query, transaction } from "@/server/db";
import { assertSameOrigin, handle, HttpError, json, rateLimit, requiredString } from "@/server/http";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
let generatedSetupToken: string | undefined;
let tokenLogged = false;
function setupToken() {
  if (process.env.NODE_ENV === "production") return process.env.SETUP_TOKEN;
  if (!generatedSetupToken) generatedSetupToken = randomBytes(32).toString("base64url");
  if (!tokenLogged) {
    tokenLogged = true;
    console.info(`[setup] One-time administrator setup token: ${generatedSetupToken}`);
  }
  return generatedSetupToken;
}
if (process.env.NODE_ENV !== "production") setupToken();

export async function GET() {
  return handle(async () => {
    const result = await query("SELECT 1 FROM admin_users LIMIT 1");
    return json({ needsSetup: result.rows.length === 0 });
  });
}

export async function POST(request: NextRequest) {
  return handle(async () => {
    assertSameOrigin(request);
    rateLimit(`setup:${request.headers.get("x-forwarded-for") || "unknown"}`, 5);
    const body = await request.json() as Record<string, unknown>;
    const suppliedToken = requiredString(body.token, "token", 500);
    const expected = setupToken();
    if (!expected) throw new HttpError(503, "Initial administrator setup is unavailable until SETUP_TOKEN is configured.", "SETUP_DISABLED");
    const suppliedBytes = Buffer.from(suppliedToken);
    const expectedBytes = Buffer.from(expected);
    if (suppliedBytes.length !== expectedBytes.length || !timingSafeEqual(suppliedBytes, expectedBytes)) {
      throw new HttpError(403, "The setup token is invalid.", "INVALID_SETUP_TOKEN");
    }
    const name = requiredString(body.name, "name", 120);
    const email = requiredString(body.email, "email", 320).toLowerCase();
    const password = requiredString(body.password, "password", 128);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpError(400, "Enter a valid email address.", "INVALID_EMAIL");
    if (password.length < 12) throw new HttpError(400, "Password must contain at least 12 characters.", "WEAK_PASSWORD");
    if (process.env.NODE_ENV === "production" && (!process.env.SMTP_HOST || !process.env.SMTP_FROM)) {
      throw new HttpError(503, "Production SMTP must be configured before administrator setup.", "MAIL_UNAVAILABLE");
    }
    const passwordHash = await hashPassword(password);
    const userId = randomUUID();
    await transaction(async (tx) => {
      const claim = await tx.query(
        "INSERT INTO app_settings (key,value) VALUES ('initial_admin_setup','complete') ON CONFLICT (key) DO NOTHING RETURNING key",
      );
      if (!claim.rows.length) throw new HttpError(409, "Initial administrator setup has already been completed.", "SETUP_COMPLETE");
      const setup = await tx.query("SELECT 1 FROM admin_users LIMIT 1");
      if (setup.rows.length) throw new HttpError(409, "Initial administrator setup has already been completed.", "SETUP_COMPLETE");
      const exists = await tx.query('SELECT 1 FROM "user" WHERE lower(email) = $1 LIMIT 1', [email]);
      if (exists.rows.length) throw new HttpError(409, "An account with this email already exists.", "EMAIL_EXISTS");
      await tx.query(
        `INSERT INTO "user" (id,name,email,"emailVerified") VALUES ($1,$2,$3,false)`,
        [userId, name, email],
      );
      await tx.query(
        `INSERT INTO account (id,"accountId","providerId","userId",password) VALUES ($1,$2,'credential',$3,$4)`,
        [randomUUID(), email, userId, passwordHash],
      );
      await tx.query("INSERT INTO admin_users (user_id) VALUES ($1)", [userId]);
      await tx.query(
        `INSERT INTO audit_log (id,action,description,actor_id) VALUES ($1,'admin_setup','Initial administrator account created; verification pending.',$2)`,
        [randomUUID(), userId],
      );
    });
    await getAuth().api.sendVerificationEmail({
      body: {
        email,
        callbackURL: new URL("/sign-in?verified=1", process.env.APP_URL || "http://localhost:3000").toString(),
      },
    });
    return json({
      message: process.env.NODE_ENV === "production"
        ? "Administrator created. Check your email for a verification link before signing in."
        : "Administrator created. Open the verification link printed in the local development server console output before signing in.",
    }, 201);
  });
}
