import { ParentSeasonBrowser } from "@/components/parent/ParentSeasonBrowser";

export default function ParentSeasonsPage() {
  return <ParentSeasonBrowser />;
}