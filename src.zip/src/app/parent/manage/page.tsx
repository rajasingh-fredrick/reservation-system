import { ParentDashboard } from "@/components/parent/ParentDashboard";

export default function ParentManagePage() {
  return <ParentDashboard view="manage" />;
}