import { AdminShell } from "@/components/shell/AdminShell";
import { ReservationRoster } from "@/components/dashboard/ReservationRoster";

export default function ReservationsPage() {
  return (
    <AdminShell>
      <ReservationRoster />
    </AdminShell>
  );
}