import { AdminDashboard } from "@/components/dashboard/AdminDashboard";
import { AdminShell } from "@/components/shell/AdminShell";

export default function DashboardPage() {
  return (
    <AdminShell>
      <AdminDashboard />
    </AdminShell>
  );
}