import { AdminShell } from "@/components/shell/AdminShell";
import { AdministratorManagement } from "@/components/dashboard/AdministratorManagement";

export default function AdministratorsPage() {
  return (
    <AdminShell>
      <AdministratorManagement />
    </AdminShell>
  );
}