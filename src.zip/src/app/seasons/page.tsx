import { AdminShell } from "@/components/shell/AdminShell";
import { SeasonManagement } from "@/components/seasons/SeasonManagement";

export default function SeasonsPage() {
  return (
    <AdminShell>
      <SeasonManagement />
    </AdminShell>
  );
}